package com.localsplash.mobile

import android.content.Context
import com.facebook.react.ReactInstanceManager

object ReactNativeFlipper {
  fun initializeFlipper(context: Context?, reactInstanceManager: ReactInstanceManager) {

  }
}