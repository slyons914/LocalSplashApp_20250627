package com.localsplash.mobile.sip;

import static java.sql.DriverManager.println;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.facebook.react.ReactApplication;
import com.facebook.react.ReactInstanceManager;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.WritableMap;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class FGNotificationService extends Service
{
    public FGNotificationService() { }

    @Nullable
    @Override
    public IBinder onBind ( Intent intent ) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        if (intent != null)
        {

            final Notification notification = intent.getParcelableExtra ("notification");
            final int notification_id = intent.getIntExtra ("notificationID", 1);
            Log.d ("notification", "in FG notification" + notification_id);
            //println("CALL : inside foreground service");
            final String notificationPayload = intent.getStringExtra ("notificationPayload");
            Long timeoutAfter = intent.getLongExtra ("timeoutAfter", 30000);
            try {
                startForeground(notification_id, notification);
            }catch ( Exception e){
                Log.d ("startForeground", "in FG notification" + e.toString());
                
               }
            Log.d ("notification TimeoutAfter", timeoutAfter + "-sec");
            Log.d ("notification FCMLkNotificationService", notification + "");

//            try
//            {
//                JSONObject notificationData = new JSONObject (notificationPayload);
//                String ringToneName = notificationData.getString ("ringtoneName");
//                //playAudio (ringToneName);
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
            //  AFTER 30 SECONDS WE WILL STOP THE FOREGROUND SERVICE. BECAUSE IT CAN NOT RUN FOREVER.
            Runnable runnable = new Runnable ()
            {
                public void run ()
                {
                    Handler handler = new Handler (Looper.getMainLooper ());
                    handler.post (new Runnable()
                    {
                        public void run()
                        {
                            // CONSTRUCT AND LOAD OUR NORMAL REACT JS CODE BUNDLE
                            final ReactInstanceManager mReactInstanceManager = ((ReactApplication) getApplication ()).getReactNativeHost ().getReactInstanceManager ();
                            ReactContext context = mReactInstanceManager.getCurrentReactContext ();

                            // IF IT'S CONSTRUCTED, SEND A NOTIFICATION
                            if (context != null)
                            {
                                sendToReactNative ((ReactApplicationContext) context, "stop_notification", notificationPayload);
                            }
                            else
                            {
                                // OTHERWISE WAIT FOR CONSTRUCTION, THEN SEND THE NOTIFICATION
                                mReactInstanceManager.addReactInstanceEventListener (new ReactInstanceManager.ReactInstanceEventListener ()
                                {
                                    public void onReactContextInitialized (ReactContext context)
                                    {
                                        sendToReactNative ((ReactApplicationContext) context, "stop_notification", notificationPayload);
                                        mReactInstanceManager.removeReactInstanceEventListener (this);
                                    }
                                });
                                if (!mReactInstanceManager.hasStartedCreatingInitialContext())
                                {
                                    // CONSTRUCT IT IN THE BACKGROUND
                                    mReactInstanceManager.createReactContextInBackground();
                                }
                            }
                        }
                    });
                    Log.d ("notification", "stop notification.");
                    stopForeground (true);
                }
            };  
            new android.os.Handler ().postDelayed (runnable, timeoutAfter);
        }
        return START_STICKY;
    }


    private void sendToReactNative ( ReactApplicationContext context, String command, String notificationPayload )
    {
//        NetworkService networkService = new NetworkService (context);
//        WritableMap params = Arguments.createMap ();
//        params.putString ( "command", command );
//        params.putString ( "notificationPayload", notificationPayload );
//        networkService.jsDelivery ("onNewCommand", params);
    }

    // SEND THE DATA TO JS APP.
    public void sendDataToJSApp (Context context, WritableMap fcmData)
    {
//        NetworkService networkService = new NetworkService (context);
//        Handler handler = new Handler(Looper.getMainLooper());
//        handler.post(new Runnable()
//        {
//            public void run()
//            {
//                // CONSTRUCT AND LOAD OUR NORMAL REACT JS CODE BUNDLE
//                final ReactInstanceManager mReactInstanceManager = ((ReactApplication) context.getApplicationContext()).getReactNativeHost().getReactInstanceManager();
//                ReactContext context = mReactInstanceManager.getCurrentReactContext();
//
//                // IF IT'S CONSTRUCTED, SEND A NOTIFICATION
//                if (context != null)
//                {
//                    Log.d ("TriggerNotification1",fcmData.toString());
//                    networkService.jsDelivery ("headsUpNotificationAction", fcmData);
//                }
//                else
//                {
//                    // OTHERWISE WAIT FOR CONSTRUCTION, THEN SEND THE NOTIFICATION
//                    mReactInstanceManager.addReactInstanceEventListener(new ReactInstanceManager.ReactInstanceEventListener()
//                    {
//                        public void onReactContextInitialized(ReactContext context)
//                        {
//                            Log.d ("TriggerNotification1",fcmData.toString());
//                            networkService.jsDelivery ("headsUpNotificationAction", fcmData);
//                            mReactInstanceManager.removeReactInstanceEventListener(this);
//                        }
//                    });
//
//                    // CONSTRUCT IT IN THE BACKGROUND
//                    if (!mReactInstanceManager.hasStartedCreatingInitialContext())
//                    {
//                        mReactInstanceManager.createReactContextInBackground();
//                    }
//                }
//            }
//        });
    }

    private MediaPlayer mediaPlayer;
    private void playAudio(String fileName)
    {
        String internalStoragePath = getFilesDir().getAbsolutePath(); // GET THE INTERNAL STORAGE PATH.
        System.out.println("Internal Storage Path: " + internalStoragePath); // PRINT THE INTERNAL STORAGE PATH.
        String downloadFilePath = internalStoragePath + "/ringtones";
        Log.d ("audio_file path",downloadFilePath + ","+ fileName);
        File audioFile = new File(downloadFilePath, fileName);
        mediaPlayer = new MediaPlayer();
        try
        {
            mediaPlayer.setDataSource(audioFile.getPath());
            mediaPlayer.setAudioAttributes(new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build());
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (IOException e) {
            Log.e("MediaPlayer", "Error playing audio", e);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
