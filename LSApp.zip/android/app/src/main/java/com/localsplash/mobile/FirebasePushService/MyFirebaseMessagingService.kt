package com.localsplash.mobile.firebasePushService

import android.util.Log
import com.google.firebase.messaging.RemoteMessage
import com.google.firebase.messaging.FirebaseMessagingService

class MyFirebaseMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        Log.i("FirebaseIdService", "[Push Notification] Refreshed token: $token")
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        Log.i("FirebaseMessaging", "[Push Notification] Received" + remoteMessage.data.toString())
    }
}