package com.localsplash.mobile.notifications

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class IncomingFirebaseMessagingService : FirebaseMessagingService()
{
    override fun onNewToken(token: String) {
        Log.i("FCM_SERVICE", "[Push Notification] Refreshed token: $token")
    }

    // QZ: I WAS USING IT, BUT NOW I AM PLANNING TO START THE INCOMING CALL FROM REACT NATIVE.
    // THAT WILL GIVE ME ABILITY TO FIRST ESTABLISH THE SIP CONNECTION AND ON SIP INVITE EVENT,
    // START THE NOTIFICATION.
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        Log.d("FCM_SERVICE", "[Push Notification] FCM Received: ${remoteMessage.data}")

        if (remoteMessage.data.isNotEmpty()) {
            val data = remoteMessage.data
            val type = data["type"]

            if (type == "call")
            {
                // START PJSIP CONNECTION.

                // WHEN THERE IS NEW INVITE THEN START THE RING.
                // CallNotificationService.showIncomingCallNotification (applicationContext, remoteMessage.data)
            }
        }
    }
}
