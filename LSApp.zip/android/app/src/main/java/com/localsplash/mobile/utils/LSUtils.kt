package com.localsplash.mobile.utils


import android.os.Build

import android.content.Context
import android.provider.Settings
import androidx.core.view.accessibility.AccessibilityEventCompat.setAction
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.flow.merge

import java.io.Serializable
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LSUtils {
    companion object {
        fun addDataNotification(user: User,callID: String,fieldname:String,fieldvalue: String,actionPerformed: String){
            try {
               println("firestore ${user?.toString()}")
                //Log.e("firestore","callID  : "+ callID + "action : " + fieldname +" actionValue :"+ actionPerformed)

                if(callID.toString().trim() == "" || callID == null) {
                    //Log.e("firestore","Added data")
                    val rootRef = FirebaseFirestore.getInstance()
                    val usersRef = rootRef.collection("callLog")
                    usersRef.add(user)
                }else {
                    if(fieldvalue == "notificationShow"){
//                        actiondata = hashMapOf(
//                            fieldname to fieldvalue,
//                            "action" to actionarray
//                        )
//                    }
                    val rootRef = FirebaseFirestore.getInstance()
                    val usersRef = rootRef.collection("callLog")
                    //  usersRef.document(callID).set({ actiondata }, SetOptions.merge())
                    //Log.e("firestore","set data actiondata" + actiondata)
                    usersRef.document(callID).set(user, SetOptions.merge())
                        .addOnSuccessListener {
                            //Log.e("firestore", "Document successfully written!")
                        }
                        .addOnFailureListener { e ->
                            //Log.e("firestore", "Error writing document: ${e.message}")
                        }
                    }else {
                        if(fieldname.isEmpty() && actionPerformed.isNotEmpty()){
                            //Log.e("firestore", "Update data")
                            updateAction(callID, actionPerformed);
                        } else {
                            //Log.e("firestore", "set data")
                            setAction(callID, actionPerformed, fieldvalue, fieldname)
                        }
                    }
                }
            }catch (e: Exception){
                e.printStackTrace()
            }
        }

        fun setAction(callID: String,actionPerformed: String,fieldvalue: String,fieldname: String){
            val actionarray = ArrayList<String>()
            actionarray.add(actionPerformed)
            var   actiondata: HashMap<String, Serializable>? = null;
            if(fieldname.isEmpty()){
                actiondata = hashMapOf(
                    "action" to actionarray
                )
            }else {
             actiondata = hashMapOf(
                fieldname to fieldvalue,
                "action" to actionarray
            )
            }
            val rootRef = FirebaseFirestore.getInstance()
            val usersRef = rootRef.collection("callLog")
            //  usersRef.document(callID).set({ actiondata }, SetOptions.merge())
            //Log.e("firestore","set data actiondata" + actiondata)
            usersRef.document(callID).set(actiondata, SetOptions.merge())
                .addOnSuccessListener {
                    //Log.e("firestore","Document successfully written!")
                }
                .addOnFailureListener { e ->
                    //Log.e("firestore","Error writing document: ${e.message}")
                }
        }

        fun updateAction(callID: String, actionPerformed: String) {
            val db = FirebaseFirestore.getInstance()
            val usersRef = db.collection("callLog").document(callID)

            // First, get the current value of the "action" field
            usersRef.get().addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    // Retrieve the old action value
                    val oldActionArray = document.get("action") as? List<String> ?: emptyList()

                    // Print the old action value
                    //Log.e("firestore","Old action value: $oldActionArray")

                    // Prepare the new action array
                    val actionarray = ArrayList(oldActionArray) // Copy old actions
                    actionarray.add(actionPerformed) // Add the new action

                    // Update the document with the new action array
                    usersRef.update("action", actionarray)
                        .addOnSuccessListener {
                            //Log.e("firestore","Action updated successfully.")
                        }
                        .addOnFailureListener { e ->
                            //Log.e("firestore","Error updating action: ${e.message}")
                        }
                } else {
                    setAction(callID,actionPerformed,"","")
                    //Log.e("firestore","No such document!")
                }
            }.addOnFailureListener { e ->
                //Log.e("firestore","Error getting document: ${e.message}")
            }
        }


        fun getCurrentDate(): String {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            return dateFormat.format(Date())
        }

        fun getDeviceId(context: Context): String {
            return Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
        }

    }


}