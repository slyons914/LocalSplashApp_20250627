package com.localsplash.mobile

import android.app.KeyguardManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import com.facebook.react.ReactActivity
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.WritableMap
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.fabricEnabled
import com.facebook.react.defaults.DefaultReactActivityDelegate
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.google.firebase.firestore.FirebaseFirestore
import com.localsplash.mobile.sip.FGNotificationService
import com.localsplash.mobile.utils.LSUtils
import com.localsplash.mobile.utils.User
import io.wazo.callkeep.RNCallKeepModule
import org.devio.rn.splashscreen.SplashScreen
import com.swmansion.rnscreens.ScreenContainer
import com.facebook.react.ReactRootView
import androidx.annotation.Nullable
import com.localsplash.mobile.utils.Utils.Companion.bundleToWritableMap
import com.localsplash.mobile.utils.Utils.Companion.sendEventToReact
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager

class MainActivity : ReactActivity()
{
    // ONCREATE() IS CALLED WHEN THE ACTIVITY IS CREATED FOR THE FIRST TIME
    // HERE WE HANDLE ANY INCOMING INTENT WHICH MAY CONTAIN CALL DATA
    override fun onCreate(savedInstanceState: Bundle?) {
        Log.e("SuperLog", "MainActivity: onCreate" );

        // IF THE APP IS OPENED BY THE CLICK ON THE NOTIFICATION, HANDLE THE INTENT.
        handleIncomingCallIntent(intent)

        val rootRef = FirebaseFirestore.getInstance()

        intent?.let {
            val action = intent.getStringExtra("ACTION_TYPE")
            if(isComingFromCallClick(action))
            {
            }
        }
        when(resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) {
            Configuration.UI_MODE_NIGHT_YES -> {
                setTheme(R.style.DarkTheme)
            }
            else -> {
                setTheme(R.style.LightTheme)
            }
        }
        super.onCreate(null)
        SplashScreen.show(this)
    }

    private fun isComingFromCallClick(action: String?): Boolean {
        return !action.isNullOrEmpty()
    }

    // ONNEWINTENT() IS CALLED WHEN ACTIVITY IS ALREADY RUNNING
    // AND A NEW INTENT IS DELIVERED (FOR EXAMPLE FROM A NOTIFICATION CLICK)
    override fun onNewIntent(intent: Intent) {
       // Log.e("SuperLog", "onNewIntent: " )
        super.onNewIntent(intent)

        handleIncomingCallIntent(intent)

        intent?.let {
           // Log.e("SuperLog", "onNewIntent: Intent " )
            ForegroundEmitter (intent)
        }
    }

    // THIS FUNCTION PROCESSES INCOMING CALL INTENTS AND SENDS ALL DATA TO REACT NATIVE
    private fun handleIncomingCallIntent(intent: Intent?) {
        // SAFETY CHECK TO AVOID NULL POINTER EXCEPTION
        if (intent == null) return

        // EXTRACT THE ACTION TYPE FROM INTENT ("ACCEPT" OR NULL)
        val actionType = intent.getStringExtra("ACTION_TYPE")

        // EXTRACT THE NOTIFICATION ID TO CANCEL THE INCOMING CALL NOTIFICATION
        val notificationId = intent.getIntExtra("notificationId", -1)

        // IF WE HAVE A VALID NOTIFICATION ID, CANCEL THE NOTIFICATION
        // THIS ENSURES THE INCOMING CALL BANNER IS DISMISSED WHEN USER ACCEPTS THE CALL
        if (notificationId != -1) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            manager.cancel(notificationId)
            Log.d("MainActivity", "INCOMING CALL NOTIFICATION CANCELLED IN MACTIVITY")
        }
        val payload = bundleToWritableMap (intent.extras)

        // SEND THE ENTIRE PAYLOAD TO REACT NATIVE
        sendEventToReact ("CALL_NOTIFICATION_ACTION", payload)
        Log.d ("MainActivity", "ALL INTENT EXTRAS SENT TO REACT NATIVE VIA sendEvent()")
    }


    // THIS METHOD IS TO SEND BACK DATA FROM JAVA TO JAVASCRIPT SO ONE CAN EASILY
    // KNOW WHICH BUTTON FROM NOTIFICATION OR FROM THE NOTIFICATION BTN IS CLICKED
    fun ForegroundEmitter(intent: Intent) {
        if (intent.extras != null) {
            val main = intent.getStringExtra("mainOnPress")
            val btn = intent.getStringExtra("buttonOnPress")
            val action = intent.getStringExtra("ACTION_TYPE")
            val data = intent.extras

            // Log.e("SuperLog", "ForegroundEmitter : $action  " + "dataintent"+ data)
            // Log.e("SuperLog", "ForegroundEmitter : $action  "  + "data" + intent.getBundleExtra("data"))

            // IF THERE IS A HEADSUP NOTIFICATION THEN DISABLE IT. ONLY DO IT IF ANDROID IS GREATER THAN 11.
//            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.R) {
//                Log.d("notification_action", "handling notification")
//                val notificationActionHandler = NotificationActionHandler()
//                notificationActionHandler.processNotificationIntentAction(this, intent)
//            }
            var bundle =  intent.getBundleExtra("data")
            var callId = bundle?.getString("SipCallId")?:bundle?.getString("callId")
            var toNumber = bundle?.getString("toNumber")
            var fromNumber = bundle?.getString("fromNumber")
           // Log.e("SuperLog", "ForegroundEmitter : $action  "  + "toNumber" + toNumber + "fromNumber"+fromNumber + "callId" +callId)
            val map: WritableMap = Arguments.createMap()
            map.putString("data", callId)
            map.putString("SipCallId",  bundle?.getString("SipCallId")?:"")
            map.putString("callId", intent.getStringExtra("callId"))
            map.putString("action", action)
            if (btn != null) {
                map.putString("button", btn)
            }
            try {
                 Log.d("SuperLog A", "Sending event to react app. " + map.toString());
                val notificationID = intent.getIntExtra("notificationID", 1)
                closeNotification(applicationContext, notificationID)

                try {
                    //  val call = coreContext.core.currentCall ?: coreContext.core.calls.getOrNull(0)
                    val actionarray = ArrayList<String>()
                    actionarray.add(0,"MainActivity NOTIFICATION_ACTION : action"+action + " pass data to react for ForegroundEmitter")
                    val user = User();
                    user.action= actionarray
                    user.date = LSUtils.getCurrentDate()
                    user.deviceId = LSUtils.getDeviceId(this)
                    user.Push_received = ""
                    user.logname = "Call"
                    user.id = callId ?:""
                    user.fromNumber = fromNumber
                    user.toNumber =  toNumber
                    user.method = "ForegroundEmitter"
                    LSUtils.addDataNotification(user,callId ?:"","","","MainActivity "+ action +" pass data to react for ForegroundEmitter")
                }catch (e: Exception){
                    e.printStackTrace()
                }
                this.sendEvent("NOTIFICATION_ACTION", map)
            } catch (e: Exception) {
               // Log.e("SuperLog", "Caught Exception: " + e.message)
            }
        }
    }


    // CLOSE THE FOREGROUND SERVICE THAT IS DISPLAYING THE INCOMING CALL NOTIFICATION.
    fun closeNotification(context: Context, notificationId: Int) {
        context.stopService(Intent(context, FGNotificationService::class.java))
        val notificationManager =
            context.getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(notificationId)
    }

    fun sendEvent(eventName: String, payload: WritableMap? = null) {
      //  Log.e("SuperLog", "sendEvent: " )
        reactNativeHost.reactInstanceManager.currentReactContext
            ?.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            ?.emit(eventName, payload)
    }

    override fun getMainComponentName(): String? {
        return "LocalSplashMobileApp"
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            RNCallKeepModule.REQUEST_READ_PHONE_STATE -> RNCallKeepModule.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
            )
        }
    }

//    override fun createReactActivityDelegate(): ReactActivityDelegate {
//        return DefaultReactActivityDelegate(
//            this,
//            mainComponentName!!,
//            fabricEnabled
//        )
//    }

    override fun createReactActivityDelegate(): ReactActivityDelegate {
        return object : ReactActivityDelegate(this, mainComponentName) {
            @Nullable
            override fun getLaunchOptions(): Bundle? {
                val callIntentExtras = this@MainActivity.intent.extras
                val initialProps = Bundle()

                if (callIntentExtras != null) {
                    // CHECK AND PUT YOUR CALL DATA
                    if (callIntentExtras.containsKey("ACTION_TYPE"))
                    {
                        initialProps.putBundle ("notification_data", callIntentExtras)
                    }

                    Log.d("notification_action", "INITIAL PROPS: $initialProps")
                }
                return initialProps
            }
        }
    }




    // override fun createReactActivityDelegate(): ReactActivityDelegate {
    //     return object : ReactActivityDelegate(this, mainComponentName) {
    //         override fun createRootView(): ReactRootView {
    //             // Create a ReactRootView and wrap the ScreenContainer inside it
    //             val rootView = ReactRootView(this@MainActivity)
    //             // Set the root view to use the ScreenContainer
    //             rootView.setRootViewTag(1) // Set a tag if needed
    //             return rootView
    //         }
    //     }
    // }
}
