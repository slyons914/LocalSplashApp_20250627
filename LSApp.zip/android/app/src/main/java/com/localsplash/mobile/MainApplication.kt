package com.localsplash.mobile

import android.annotation.SuppressLint
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context

import com.facebook.react.PackageList;
import com.facebook.react.ReactApplication;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.ReactPackage
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint
import com.facebook.react.defaults.DefaultReactNativeHost;
import com.facebook.react.views.text.ReactFontManager
import com.facebook.soloader.SoLoader;
import com.localsplash.mobile.audioroute.AudioRoutePackage
import com.localsplash.mobile.callhelper.CallHelperPackage
import com.localsplash.mobile.utils.PreferenceManager

import com.localsplash.mobile.utils.CallData
import com.localsplash.mobile.notifications.IncomingCallNotificationPackage
import com.localsplash.mobile.telephony.TelephonyPackage

class MainApplication : Application(), ReactApplication {
    private var mPreferenceManager: PreferenceManager ?= null
    @SuppressLint("StaticFieldLeak")

    companion object {
        @SuppressLint("StaticFieldLeak")
        var callList = ArrayList<CallData>()
        lateinit var reactContext: ReactApplicationContext


        @get:Synchronized
        var instance: MainApplication? = null


    }

    private val mReactNativeHost: ReactNativeHost = object : DefaultReactNativeHost(this) {
        override fun getJSMainModuleName(): String {
            return "index"
        }

        override val isNewArchEnabled: Boolean
            get() = BuildConfig.IS_NEW_ARCHITECTURE_ENABLED

        override fun getPackages(): List<ReactPackage> {
            return PackageList(this).packages + listOf(
                LogcatPackage(),
                AudioRoutePackage(),
                CallHelperPackage(),
                TelephonyPackage(),
                IncomingCallNotificationPackage()  // ADDED FOR INCOMING CALL NOTIFICATION
            )
        }


        override fun getUseDeveloperSupport(): Boolean {
            return BuildConfig.DEBUG
        }

        override val isHermesEnabled: Boolean
            get() = BuildConfig.IS_HERMES_ENABLED
    }

    val preferenceManager: PreferenceManager
        get() {
            if (mPreferenceManager == null) {
                mPreferenceManager = PreferenceManager(
                    getSharedPreferences(
                        "lsapp",
                        MODE_PRIVATE
                    )
                )
            }
            return mPreferenceManager as PreferenceManager
        }



    override fun onCreate() {
        super.onCreate()
        instance= this
        ReactFontManager.getInstance().addCustomFont(this, "Poppins", R.font.poppins)
        SoLoader.init(this, false)
        if (BuildConfig.IS_NEW_ARCHITECTURE_ENABLED) {
            DefaultNewArchitectureEntryPoint.load();
        }
        if (BuildConfig.DEBUG){
            ReactNativeFlipper.initializeFlipper(this, reactNativeHost.reactInstanceManager)
        }
//        val channel = NotificationChannel(
//            "1211",
//            "High priority notifications",
//            NotificationManager.IMPORTANCE_HIGH
//        )
//
//        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
//        notificationManager.createNotificationChannel(channel)

    }



//    fun ensureCoreExists(
//        context: Context,
//        pushReceived: Boolean = false,
//        service: CoreService? = null,
//        useAutoStartDescription: Boolean = false,
//        skipCoreStart: Boolean = false
//    ): Boolean {
//        if (::coreContext.isInitialized && !coreContext.stopped) {
//            Log.d("[Application] Skipping Core creation (push received? $pushReceived)")
//            return false
//        }
//
//        println(
//            "[Application] Core context is being created ${if (pushReceived) "from push" else ""}"
//        )
//        coreContext = CoreContext(
//            context,
//            corePreferences.config,
//            service,
//            useAutoStartDescription
//        )
//        if (!skipCoreStart) {
//            coreContext.start()
//        }
//        return true
//    }

    override fun getReactNativeHost(): ReactNativeHost {
        return mReactNativeHost
    }


}
