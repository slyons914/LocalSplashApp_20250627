// ProximityService.kt
package com.localsplash.mobile.sip

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.PowerManager
import android.os.PowerManager.WakeLock

class ProximityService (private val context: Context) : SensorEventListener
{
    private var sensorManager: SensorManager? = null
    private var proximitySensor: Sensor? = null
    private var wakeLock: WakeLock? = null

    fun start() {
        sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        proximitySensor = sensorManager?.getDefaultSensor(Sensor.TYPE_PROXIMITY)

        proximitySensor?.let {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK,
            "LocalSplash::ProximityWakeLock"
        )

        wakeLock?.acquire()
    }

    fun stop() {
        sensorManager?.unregisterListener(this)
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
    }

    override fun onSensorChanged(event: SensorEvent?)
    {
        // OPTIONALLY HANDLE PROXIMITY STATE CHANGES EXPLICITLY
        event?.let {
            val distance = it.values[0]
            val isNear = distance < proximitySensor?.maximumRange ?: 0f
            println("Proximity sensor: isNear = $isNear")
            // Screen handled automatically by PROXIMITY_SCREEN_OFF_WAKE_LOCK
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Not required
    }
}
