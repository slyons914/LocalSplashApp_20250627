package com.localsplash.mobile.utils

import android.os.Bundle
import android.util.Log
import com.facebook.react.ReactApplication
import com.facebook.react.ReactInstanceManager
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.ReactContext
import com.facebook.react.bridge.WritableMap
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.localsplash.mobile.MainApplication

class Utils {
    companion object {

        // UTILITY FUNCTION TO SEND EVENTS FROM NATIVE TO REACT NATIVE (JS) LAYER
        fun                                                                                           sendEventToReact (eventName: String, payload: WritableMap? = null)
        {
            // Use your existing instance as context
            val context = MainApplication.instance ?: return
            val reactApp = context as ReactApplication
            val reactInstanceManager: ReactInstanceManager = reactApp.reactNativeHost.reactInstanceManager
            val reactContext: ReactContext? = reactInstanceManager.currentReactContext

            // REACT CONTEXT IS READY, SEND EVENT DIRECTLY
            if (reactContext != null && reactContext.hasActiveCatalystInstance()) {
                reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                    .emit(eventName, payload)
                Log.d("Utils", "Event [$eventName] sent immediately to JS")
            }
            else
            {
                // REACT CONTEXT NOT READY (APP IN COLD START)
                Log.d("Utils", "ReactContext not ready, queuing event [$eventName]")
                reactInstanceManager.addReactInstanceEventListener(object : ReactInstanceManager.ReactInstanceEventListener {
                    override fun onReactContextInitialized(context: ReactContext) {
                        context.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                            .emit(eventName, payload)
                        Log.d("Utils", "Event [$eventName] sent after ReactContext ready")

                        // REMOVE LISTENER AFTER FIRING TO AVOID MEMORY LEAK
                        reactInstanceManager.removeReactInstanceEventListener(this)
                    }
                })

                // START REACT CONTEXT IF NOT ALREADY STARTED
                if (!reactInstanceManager.hasStartedCreatingInitialContext()) {
                    reactInstanceManager.createReactContextInBackground()
                }
            }
        }

        fun bundleToWritableMap(bundle: Bundle?): WritableMap {
            val map = Arguments.createMap()
            if (bundle != null) {
                for (key in bundle.keySet()) {
                    val value = bundle[key]
                    when (value) {
                        is String -> map.putString(key, value)
                        is Int -> map.putInt(key, value)
                        is Boolean -> map.putBoolean(key, value)
                        is Double -> map.putDouble(key, value)
                        is Bundle -> map.putMap(key, bundleToWritableMap(value)) // RECURSIVE UNPACK
                        else -> map.putString(key, value?.toString() ?: "")
                    }
                }
            }
            return map
        }
    }
}
