package com.localsplash.mobile.utils

import com.google.gson.annotations.SerializedName
import java.io.Serializable


data class User(
        @SerializedName("action") var action: ArrayList<String> = arrayListOf(),
        var method: String? = "",
        var date: String? = "",
        var deviceId: String? = "",
        var id: String?= "",
        var logname: String?= "",
        var toNumber: String?= "",
        var fromNumber: String?= "",
        var Push_received: String?= "",
        ): Serializable


