package com.localsplash.mobile.telephony

//  TELEPHONYMODULE.KT – REACT‑NATIVE BRIDGE FOR ANDROID PSTN STATE
//  THIS FILE EXPOSES A NATIVE MODULE THAT LISTENS TO PSTN CALL
//  STATE CHANGES (RINGING / OFFHOOK / IDLE) ON ANDROID 12 (API 31)+
//  AND EMITS THEM TO JAVASCRIPT VIA DEVICEEVENTEMITTER.
//  ALL COMMENTS ARE IN UPPER‑CASE AS REQUESTED.

// ANDROID / KOTLIN IMPORTS
import android.Manifest                                  // RUNTIME PERMISSION NEEDED TO READ PHONE STATE
import android.content.Context                           // PROVIDES ACCESS TO SYSTEM SERVICES
import android.content.pm.PackageManager                // CHECKS IF PERMISSION GRANTED AT RUNTIME
import android.os.Build                                  // ALLOWS SDK‑LEVEL GATING
import android.util.Log                                  // LOGS FOR DEBUGGING
import androidx.core.content.ContextCompat               // COMPATIBLE PERMISSION CHECKS
import android.telephony.*                               // TELEPHONYMANAGER & TELEPHONYCALLBACK

// REACT NATIVE BRIDGE IMPORTS 
import com.facebook.react.bridge.*                        // CORE BRIDGE TYPES (REACTAPPLICATIONCONTEXT, WRITABLEMAP, ETC.)
import com.facebook.react.modules.core.DeviceEventManagerModule // EMITS EVENTS TO JS

//  TELEPHONYMODULE CLASS – EXPOSED TO JS AS "TelephonyStateModule"
//  IMPLEMENTS LIFECYCLEEVENTLISTENER TO CLEAN UP WHEN THE HOST IS DESTROYED
class TelephonyModule(private val reactContext: ReactApplicationContext)
    : ReactContextBaseJavaModule(reactContext), LifecycleEventListener 
{

    // FIELDS
    private var telephonyManager: TelephonyManager? = null // HOLDS SYSTEM TELEPHONY SERVICE
    private var callback: TelephonyCallback? = null        // HOLDS REFERENCE TO ACTIVE CALLBACK

    //  NAME EXPOSED TO JAVASCRIPT
    override fun getName() = "TelephonyStateModule"        // JS: NativeModules.TelephonyStateModule

    //  STARTLISTENER – CALLED FROM JS TO BEGIN LISTENING
    //  1) VERIFIES API LEVEL >= 31 (ANDROID 12 S)
    //  2) ENSURES READ_PHONE_STATE PERMISSION GRANTED
    //  3) REGISTERS TELEPHONYCALLBACK TO EMIT EVENTS
    @ReactMethod
    fun startListener(promise: Promise)
    {
        // ENSURE SUPPORTED SDK 
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            promise.reject("NOT_SUPPORTED", "REQUIRES ANDROID 12 (API 31)+")
            return
        }

        // CHECK RUNTIME PERMISSION  
        val granted = ContextCompat.checkSelfPermission(
            reactContext, Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED

        if (!granted) {
            promise.reject("TELEPHONY_PERMISSION_DENIED", "READ_PHONE_STATE NOT GRANTED")
            return
        }

        // OBTAIN TELEPHONYMANAGER
        telephonyManager = reactContext.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

        // CREATE AND REGISTER TELEPHONYCALLBACK --------------------------------
        callback = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
            override fun onCallStateChanged(state: Int) {
                Log.d("CALL_STATE", "STATE = $state")

                // BUILD PAYLOAD MAP TO SEND TO REACT NATIVE
                val payload: WritableMap = Arguments.createMap().apply {
                    putString("STATE", when (state) {
                        TelephonyManager.CALL_STATE_RINGING -> "RINGING"   // INCOMING PSTN CALL RINGING
                        TelephonyManager.CALL_STATE_OFFHOOK -> "OFFHOOK"   // CALL ANSWERED OR OUTGOING
                        else -> "IDLE"                                      // NO CALL ACTIVE
                    })
                }
                sendEvent("TELEPHONY_CALL_STATE", payload) // EMIT EVENT TO JS
            }
        }

        // REGISTER CALLBACK ON MAIN EXECUTOR (UI THREAD)
        telephonyManager!!.registerTelephonyCallback(
            reactContext.mainExecutor, callback as TelephonyCallback
        )
        promise.resolve(true) // INFORM JS THAT LISTENER STARTED SUCCESSFULLY
    }

    //  STOPLISTENER – UNREGISTERS CALLBACK AND CLEARS REFERENCES
    @ReactMethod
    fun stopListener() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S)
        {
            Log.d ("TELEPHONY_APIS_NOT_SUPPORTED", "REQUIRES ANDROID 12 (API 31)+")
            return
        }
        callback?.let { telephonyManager?.unregisterTelephonyCallback(it) }
        callback = null
    }

    //  HELPER: SENDEVENT – FORWARD NATIVE EVENTS TO JAVASCRIPT LAYER
    private fun sendEvent(event: String, params: WritableMap) =
        reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            .emit(event, params)

    //  LIFECYCLE CLEAN‑UP – AUTOMATICALLY STOP LISTENING WHEN HOST DESTROYS
    init { reactContext.addLifecycleEventListener(this) }  // REGISTER LIFECYCLE LISTENER
    override fun onHostPause() { /* KEEP LISTENING IN BACKGROUND IF DESIRED */ }
    override fun onHostResume() { /* NO‑OP */ }
    override fun onHostDestroy() { stopListener() }          // PREVENT MEMORY LEAKS
}
