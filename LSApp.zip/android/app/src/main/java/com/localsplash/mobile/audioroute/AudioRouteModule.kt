package com.localsplash.mobile.audioroute

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.*
import android.content.pm.PackageManager
import android.media.*
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule

class AudioRouteModule(private val reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    override fun getName(): String = "AudioRouteModule"

    private val bluetoothManager = reactContext.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager.adapter

    private fun createDeviceInfoMap(device: AudioDeviceInfo, label: String, type: String, isActiveDevice: Boolean): WritableNativeMap
    {
        return WritableNativeMap().apply {
            putInt("id", device.id)
            putString("name", label)
            putString("type", type)
            putBoolean ("isActive", isActiveDevice)
        }
    }

    private fun getReadableLabel(device: AudioDeviceInfo): String {
        return when (device.type) {
            AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Earpiece"
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Phone Speaker"
            // AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "${device.productName} (Media)"
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "${device.productName}"
            else -> device.productName.toString()
        }
    }

    @SuppressLint("MissingPermission")
    @ReactMethod
    fun getAvailableAudioDevices(promise: Promise)
    {
        val deviceList = WritableNativeArray()

        // CODE REQUIRES SDK VERSION TO BE GREATER THAN 31. FOR LOWER VERSIONS DON'T DO ANYTHING.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
        {
            val audioManager = reactContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)

            val hasPermission = hasBluetoothPermission()

            devices.forEach { device ->
                Log.d("AudioDevice_Info", "Name: ${device.productName}, ID: ${device.id}, Type: ${device.type}")
                val label = getReadableLabel(device)
                val isActiveDevice = (audioManager.communicationDevice?.id == device.id)
                Log.d ("AudioDevice_Info", "isActiveDevice: $isActiveDevice Active Device Id: " + audioManager.communicationDevice?.id)
                when (device.type) {
                    AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> deviceList.pushMap(createDeviceInfoMap(device, label, "earpiece", isActiveDevice))
                    AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> deviceList.pushMap(createDeviceInfoMap(device, label, "speaker", isActiveDevice))
                    AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> {
                        if (bluetoothAdapter?.isEnabled == true && hasPermission) {
                            deviceList.pushMap(createDeviceInfoMap(device, label, "bluetooth", isActiveDevice))
                        }
                    }
                }
            }
        }
        promise.resolve(deviceList)
    }

    @ReactMethod
    fun setAudioRoute(deviceId: Int, promise: Promise)
    {
        // CODE REQUIRES SDK VERSION TO BE GREATER THAN 31. FOR LOWER VERSIONS DON'T DO ANYTHING.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
        {
            val audioManager = reactContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)

            val selectedDevice = devices.firstOrNull { it.id == deviceId }

            if (selectedDevice != null) {
                val result = audioManager.setCommunicationDevice(selectedDevice)
                promise.resolve(result)
            } else {
                promise.reject("DEVICE_NOT_FOUND", "Audio device with ID $deviceId not found.")
            }
        }
        else
        {
            Log.d ("audio_route", "Audio route is not supported on this device. minimum supported android version is 12");
        }
    }

    @SuppressLint("MissingPermission")
    @ReactMethod
    fun toggleSpeaker (isSpeakerOn: Boolean, promise: Promise)
    {
        Log.d("AudioRouteModule", "toggleSpeaker called with isSpeakerOn: $isSpeakerOn")
        // REQUIRE ANDROID 12 (API 31) OR NEWER
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            promise.reject(
                "NOT_SUPPORTED",
                "Changing audio route programmatically requires Android 12 (API 31) or later."
            )
            return
        }

        val audioManager = reactContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val devices      = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)

        // TARGET TYPE BASED ON THE PARAMETER
        val targetType = if (isSpeakerOn)
            AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
        else
            AudioDeviceInfo.TYPE_BUILTIN_EARPIECE

        // FIND A MATCHING DEVICE
        val targetDevice = devices.firstOrNull { it.type == targetType }

        // IF THERE IS NO AUDIO DEVICE FOUND OF THE TYPE EARPIECE OR SPEAKER THEN REJECT.
        if (targetDevice == null)
        {
            promise.reject(
                "DEVICE_NOT_FOUND",
                "Audio device of type ${if (isSpeakerOn) "SPEAKER" else "EARPIECE"} not found on this handset."
            )
            return
        }

        // REQUEST ROUTE CHANGE
        val succeeded = audioManager.setCommunicationDevice(targetDevice)
        Log.d("AudioRouteModule", "toggleSpeaker succeeded: $succeeded")
        promise.resolve (succeeded)   // true = SYSTEM ACCEPTED, false = IGNORED
    }



    @ReactMethod
    fun clearAudioRoute(promise: Promise)
    {
        // CODE REQUIRES SDK VERSION TO BE GREATER THAN 31. FOR LOWER VERSIONS DON'T DO ANYTHING.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
        {
            val audioManager = reactContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audioManager.clearCommunicationDevice()
            promise.resolve(true)
        }
    }

    private fun safeSendEvent(eventName: String, params: Any?) {
        if (reactContext.hasActiveReactInstance()) {
            reactContext
                .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                .emit(eventName, params)
        } else {
            Log.w("AudioRouteModule", "React instance not ready. Skipping event: $eventName")
        }
    }

    private fun hasBluetoothPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            reactContext,
            Manifest.permission.BLUETOOTH_CONNECT
        ) == PackageManager.PERMISSION_GRANTED
    }

    override fun invalidate() {
        super.invalidate()
    }
}
