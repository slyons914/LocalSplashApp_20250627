package com.localsplash.mobile.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import android.app.NotificationManager
import com.facebook.react.ReactApplication
import com.facebook.react.bridge.Arguments
import com.facebook.react.modules.core.DeviceEventManagerModule

class IncomingCallActionBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        Log.d("IncomingCallReceiver", "Call action received")

        // Cancel Notification
        val notificationId = intent.getIntExtra("notificationId", -1)
        if (notificationId != -1) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.cancel(notificationId)
        }

        // Send REJECT event to React Native
        val dataJson = intent.getStringExtra("data") ?: "{}"
        val reactContext = (context.applicationContext as ReactApplication).reactNativeHost.reactInstanceManager.currentReactContext
        reactContext?.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            ?.emit("CALL_NOTIFICATION_ACTION", Arguments.createMap().apply {
                putString("ACTION_TYPE", "REJECT")
                putString("data", dataJson)
            })
    }
}
