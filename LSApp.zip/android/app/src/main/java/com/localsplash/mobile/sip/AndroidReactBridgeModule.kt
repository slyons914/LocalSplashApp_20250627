/*
          FILENAME: lkphone_mobile/android/modules/AndroidReactBridgeModule.tsx
            AUTHOR: Qasim Zubair
           SUMMARY: N/A.
	       PURPOSE: N/A.
   IMPORTING FILES: N/A
 SUBSCRIBING FILES: N/A
 LAST COMMIT DATE: July 23, 2021
*/
package com.localsplash.mobile.sip

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.localsplash.mobile.MainActivity


//import com.localsplash.AlarmHandler
//import com.localsplash.services.FCMService
//import com.localsplash.services.NotificationHandler
//import com.localsplash.services.UtilsService

class AndroidReactBridgeModule(context: ReactApplicationContext?) :
    ReactContextBaseJavaModule(context) {

//    @ReactMethod
//    fun updateFCMToken(tokenObject: String?) {
//        android.util.Log.d("FCM_lk_phone_number", tokenObject)
//        val fcmService = FCMService()
//        fcmService.updateFCMToken(tokenObject)
//    }

    // CHECK IF THERE IS ANY ACTIVE CALL OR NOT ?
    @ReactMethod
    fun isThereAnyCall(promise: com.facebook.react.bridge.Promise) {
        val context: android.content.Context = getReactApplicationContext()
//        val fcmService = FCMService()
        android.util.Log.d("callstate", "starting")
        val manager: android.media.AudioManager =
            context.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
        promise.resolve(manager.getMode() == android.media.AudioManager.MODE_IN_CALL || manager.getMode() == android.media.AudioManager.MODE_IN_COMMUNICATION)
    }

    // SHOW THE HEADS-UP NOTIFICATION FOR INCOMING CHAT.
//    @ReactMethod
//    fun showChatHeadsUpNotification(notificationData: String?) {
//        var jsonObject: org.json.JSONObject? = null
//        try {
//            jsonObject = org.json.JSONObject(notificationData)
//            val context: android.content.Context =
//                getReactApplicationContext() // GET APPLICATION CONTEXT.
//            val notificationHandler: com.sun.nio.sctp.NotificationHandler =
//                com.sun.nio.sctp.NotificationHandler(context)
//            notificationHandler.NOTIFICATION_ID = notificationHandler.getUniqueId()
//            android.util.Log.d("chat_notification", "step1")
//            jsonObject.put("triggeredFromJS", true)
//            notificationHandler.showIncomingCallNotification(jsonObject)
//        } catch (e: org.json.JSONException) {
//            e.printStackTrace()
//        }
//    }

    // GET THE INTERRUPTION FILTER INFORMATION. IT WILL TELL US IF THE DND IS ON OR NOT.
    @ReactMethod
    fun getSystemSetting(promise: com.facebook.react.bridge.Promise) {
        val deviceData: org.json.JSONObject =
            org.json.JSONObject() // VARIABLE TO STORE JSON DATA AND SEND TO REACT APP.

        // TRY TO GET SYSTEM SETTINGS.
        try {
            val context: android.content.Context =
                getReactApplicationContext() // GET APPLICATION CONTEXT.
            val notificationManager: android.app.NotificationManager =
                context.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            val dndStatus: Int = notificationManager.getCurrentInterruptionFilter()

            // USE AUDIO MANAGER TO GET THE RINGTONE AND MEDIA VOLUME.
            val am: android.media.AudioManager =
                context.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
            val volumeLevelRing: Int = am.getStreamVolume(android.media.AudioManager.STREAM_RING)
            val volumeLevelMusic: Int = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)

            // CALL BATTERY MANAGER SERVICE TO GET THE DEVICE BATTERY.
            val batteryManager: android.os.BatteryManager =
                context.getSystemService(android.content.Context.BATTERY_SERVICE) as android.os.BatteryManager

            // GET THE BATTERY PERCENTAGE AND STORE IT IN A INT VARIABLE
            val batteryLevel: Int =
                batteryManager.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
            deviceData.put("dnd_status", dndStatus)
            deviceData.put("volume_level_ring", volumeLevelRing)
            deviceData.put("volume_level_media", volumeLevelMusic)
            deviceData.put("battery_level", batteryLevel)
            promise.resolve(deviceData.toString())
        } catch (e: org.json.JSONException) {
            promise.reject(e)
            e.printStackTrace()
        }
    }

    // THIS FUNCTION WILL BE EXECUTED WHEN ANY CALL COMES IN IF THE USER IS ALREADY ON CALL.
    // NOW WE WILL KEEP CHECKING WHEN THE PERSON GOES OFF THE CALL. AND WHEN THEY GO WE WILL SEND
    // THEIR "FREE" STATUS TO SERVER.
//    @ReactMethod
//    fun listenToCallEnd(triggerEvery: Int, lkphone_id: Int) {
//        android.util.Log.d("listenToCallEnd", "started")
//        val context: android.content.Context = getReactApplicationContext()
//        val alarmHandler = AlarmHandler(context)
//        alarmHandler.cancelAlarmManager() // CANCEL ALL ALARMS.
//        alarmHandler.setAlarmManager(triggerEvery, lkphone_id) // LISTEN TO ALARMS.
//    }

    // STOP THE INCOMING CALL PHONE CALL NOTIFICATION. FOR EXAMPLE, IF NOTIFICATION IS COMING FROM TWILIO,
    // THEN THIS METHOD CAN BE USED TO CLOSE THAT NOTIFICATION.
//    @ReactMethod
//    fun stopPhoneCallNotification(callUUID: String?) {
//        val context: android.content.Context = getReactApplicationContext()
//        val call_id: Int = UtilsService.extractDigitsFromUUID(callUUID)
//        val notificationHandler: com.sun.nio.sctp.NotificationHandler =
//            com.sun.nio.sctp.NotificationHandler(context)
//        notificationHandler.clearCallNotification(call_id)
//    }

    // CONVERT CALL UUID INTO INTEGER.
//    @ReactMethod
//    fun convertUUIDIntoInt(callUUID: String?, promise: com.facebook.react.bridge.Promise) {
//        val call_id: Int = UtilsService.extractDigitsFromUUID(callUUID)
//        promise.resolve(call_id)
//    }

    // SHOW INCOMING TWILIO CALL NOTIFICATION.
    @ReactMethod
    @kotlin.Throws(org.json.JSONException::class)
    fun showPhoneCallNotification(
        callUUID: String?,
        from: String?,
        notificationText: String?,
        respond_time: Int
    ) {
        val context: android.content.Context = getReactApplicationContext()
        val notificationData: org.json.JSONObject = org.json.JSONObject()
        notificationData.put("LKCallType", "call")
        notificationData.put("call_id", callUUID)
        notificationData.put("title", from)
        notificationData.put("text", notificationText)
        notificationData.put("twilio_call", "true")
        notificationData.put("respond_time", respond_time)

    }

    @ReactMethod
    fun showIncomingCallNotification(callId: String)
    {
        val notificationManager = reactApplicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        var notificationLayout: RemoteViews? = null
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N && Build.VERSION.SDK_INT < Build.VERSION_CODES.S
        ) {
            // DISPLAY A CUSTOM STYLED NOTIFICATION.
            notificationLayout = RemoteViews(reactApplicationContext.getPackageName(), com.localsplash.mobile.R.layout.notification)
            var color = -0xcb5f32 // NORMAL COLOR, BLUE.
            var colorButtonBar = -0xbc9776
            val colorDec: String = "14128198"

            // MEDIUM COLOR, ORANGE.
            if (colorDec == "14128198") {
                color = -0x286bba
                colorButtonBar = -0x538fd8
            }

            // URGENT COLOR. RED.
            if (colorDec == "13329508") {
                color = -0x349b9c
                colorButtonBar = -0x72d2d3
            }


//            notificationLayout!!.setInt(R.id.layout, "setBackgroundColor", color)
//            notificationLayout!!.setInt(R.id.lkButtonsBar, "setBackgroundColor", colorButtonBar)
//            notificationLayout!!.setTextViewText(R.id.lkTitle, " | $notification_title")
//            notificationLayout!!.setTextViewText(R.id.lkText, notification_text)
        }
        val channel = NotificationChannel("channel_id", name, NotificationManager.IMPORTANCE_HIGH)
        channel.setImportance(NotificationManager.IMPORTANCE_HIGH)

        // REGISTER THE CHANNEL WITH THE SYSTEM; YOU CAN'T CHANGE THE IMPORTANCE
        // OR OTHER NOTIFICATION BEHAVIORS AFTER THIS

        // REGISTER THE CHANNEL WITH THE SYSTEM; YOU CAN'T CHANGE THE IMPORTANCE
        // OR OTHER NOTIFICATION BEHAVIORS AFTER THIS

        notificationManager.createNotificationChannel(channel)
        val notificationBuilder =
            NotificationCompat.Builder(reactApplicationContext, "channel_id")
                .setSmallIcon(com.localsplash.mobile.R.drawable.common_full_open_on_phone)
                .setContentTitle("Incoming Call")
                .setContentText("You've an incoming call")
                .setDefaults (NotificationCompat.DEFAULT_ALL)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setGroupAlertBehavior (NotificationCompat.GROUP_ALERT_ALL)
                .setOnlyAlertOnce (true)
                .setOngoing(true)
                .setCustomContentView (notificationLayout)
                .setForegroundServiceBehavior(FOREGROUND_SERVICE_IMMEDIATE)
                .setVisibility ( NotificationCompat.VISIBILITY_PUBLIC );

        val yesButtonCode = "CALL_ACCEPTED"
        val noButtonCode = "CALL_REJECTED"

        val receiveLKCallAction = Intent(reactApplicationContext, MainActivity::class.java)
        receiveLKCallAction.putExtra ("ACTION_TYPE", yesButtonCode);
//        notificationBundle.putString ("ACTION_TYPE", yesButtonCode);
//        receiveLKCallAction.putExtras (notificationBundle);
        receiveLKCallAction.putExtra ("notificationID", 123);
        receiveLKCallAction.putExtra ("callId", callId)
        receiveLKCallAction.setAction ("RECEIVE_CALL")
        val receiveCallPendingIntent = PendingIntent.getActivity(
            reactApplicationContext,
            1202,
            receiveLKCallAction,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val rejectLKCallAction = Intent(reactApplicationContext, MainActivity::class.java)
        rejectLKCallAction.putExtra ("ACTION_TYPE", noButtonCode);
//        notificationBundle.putString ("ACTION_TYPE", yesButtonCode);
//        receiveLKCallAction.putExtras (notificationBundle);
        rejectLKCallAction.putExtra ("notificationID", 123);
        rejectLKCallAction.putExtra ("callId", callId)
        rejectLKCallAction.setAction ("CANCEL_CALL")
        val rejectCallPendingIntent = PendingIntent.getActivity(
            reactApplicationContext,
            1202,
            receiveLKCallAction,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if
                (
            android.os.Build.VERSION.SDK_INT > Build.VERSION_CODES.N &&
            android.os.Build.VERSION.SDK_INT < Build.VERSION_CODES.S
        )
        {
//            // SHOW ACCEPT CALL BUTTON.
//            notificationLayout?.setOnClickPendingIntent (R.id.lkButton1,receiveCallPendingIntent);
//            notificationLayout?.setTextViewText (R.id.lkButton1, context.getString (R.string.answer_call));
//            notificationLayout?.setViewVisibility (R.id.lkButton1, View.VISIBLE);
//
//            // SHOW REJECT CALL BUTTON.
//            notificationLayout?.setOnClickPendingIntent (R.id.lkButton2,cancelCallPendingIntent);
//            notificationLayout?.setTextViewText (R.id.lkButton2, context.getString (R.string.reject_call));
//            notificationLayout?.setViewVisibility (R.id.lkButton2, View.VISIBLE);
        }
        else
        {
            notificationBuilder
                .addAction(0, "Answer Call", receiveCallPendingIntent)
                .addAction(0, "Reject Call", rejectCallPendingIntent)
        }

        notificationBuilder.setContentIntent(receiveCallPendingIntent)


        val serviceIntent = Intent(reactApplicationContext, FGNotificationService::class.java)
        serviceIntent.putExtra ("notification", notificationBuilder.build());
        println("CALL : Starting foreground service")
        reactApplicationContext.startForegroundService(serviceIntent)
//            .notify(666, notificationBuilder.build())

    }

    override fun getName(): String {
        return "AndroidReactBridge";
    }
}