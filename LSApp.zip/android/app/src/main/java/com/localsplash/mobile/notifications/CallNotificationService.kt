package com.localsplash.mobile.notifications

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.os.*
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.localsplash.mobile.MainActivity
import com.localsplash.mobile.R
import org.json.JSONObject

object CallNotificationService {
    private const val CHANNEL_ID = "ls_voip_call_channel"
    private const val CHANNEL_NAME = "VoIP Incoming Call"

    @SuppressLint("MissingPermission")
    fun showIncomingCallNotification(context: Context, data: Map<String, String>, notificationId: Int?) {
        if(notificationId == null)
            return
        var fromNumber = data["src"] ?: "Unknown Number"
        fromNumber = formatPhoneNumber(fromNumber)
        val fromName = data["srcCallerIdName"] ?: "Unknown Caller"

        // Convert data to Bundle
        val bundleData = Bundle()
        data.forEach { (key, value) -> bundleData.putString(key, value) }
        bundleData.putString("NOTIFICATION_ACTION_CATEGORY", "INCOMING_CALL")
        bundleData.putInt("notificationId", notificationId)

        val fullScreenIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("ACTION_TYPE", "FULL_SCREEN")
            putExtra("notificationId", notificationId)
            putExtra("data", bundleData)
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            context, 1001, fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val acceptIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("ACTION_TYPE", "ACCEPT")
            putExtra("notificationId", notificationId)
            putExtra("data", bundleData)
        }
        val acceptPendingIntent = PendingIntent.getActivity(
            context, 1002, acceptIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val rejectIntent = Intent(context, IncomingCallActionBroadcastReceiver::class.java).apply {
            putExtra("ACTION_TYPE", "REJECT")
            putExtra("notificationId", notificationId)
            putExtra("data", JSONObject(data).toString())
        }
        val rejectPendingIntent = PendingIntent.getBroadcast(
            context, 1003, rejectIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val headsUpView = RemoteViews(context.packageName, R.layout.call_incoming_notification_heads_up).apply {
            setTextViewText(R.id.caller, fromName)
            setTextViewText(R.id.sip_uri, fromNumber)
            setTextViewText(R.id.incoming_call_info, "Incoming Call")
            setOnClickPendingIntent(R.id.button_accept, acceptPendingIntent)
            setOnClickPendingIntent(R.id.button_decline, rejectPendingIntent)
        }

        createNotificationChannel(context)

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.common_full_open_on_phone)
            .setCustomHeadsUpContentView(headsUpView)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setSound(null)
            .setAutoCancel(false)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .build()

        if (NotificationManagerCompat.from(context).areNotificationsEnabled()) {
            NotificationManagerCompat.from(context).notify(notificationId, notification)
            autoDismissNotificationAfterTimeout(context, notificationId)
        } else {
            println("Notifications are disabled or permission not granted")
        }
    }

    private fun autoDismissNotificationAfterTimeout(context: Context, notificationId: Int) {
        Handler(Looper.getMainLooper()).postDelayed({
            NotificationManagerCompat.from(context).cancel(notificationId)
            println("Notification auto-dismissed after 30 seconds")
        }, 30_000)
    }

    private fun createNotificationChannel(context: Context)
    {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                setSound (null, null)
                enableVibration (false)
                description = "Incoming VoIP Calls"
                lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            }
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }


    private fun formatPhoneNumber(src: String): String {
        // Check if the src length is greater than 10 characters
        val phoneNumber = if (src.length > 10) {
            src.takeLast(10) // Get the last 10 characters
        } else {
            src // If the length is 10 or less, use it as is
        }

        // Ensure the phone number has exactly 10 characters, then format it
        return if (phoneNumber.length == 10) {
            // Format the phone number as XXX-XXX-XXXX
            "(${phoneNumber.substring(0, 3)}) ${phoneNumber.substring(3, 6)}-${phoneNumber.substring(6, 10)}"
        } else {
            phoneNumber // Return the original phone number if it's not 10 digits
        }
    }
}
