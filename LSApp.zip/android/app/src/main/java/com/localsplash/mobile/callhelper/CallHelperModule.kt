package com.localsplash.mobile.callhelper

import android.content.Intent
import android.os.Build
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod

class CallHelperModule(reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {
    private val ctx: ReactApplicationContext = reactContext

    override fun getName(): String = "CallHelperModule"

    @ReactMethod
    fun startService()
    {
        val svc = Intent(ctx, CallForegroundService::class.java)
            .setAction(CallForegroundService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(svc)
        } else {
            ctx.startService(svc)
        }
    }

    @ReactMethod
    fun stopService() {
        val svc = Intent(ctx, CallForegroundService::class.java)
            .setAction(CallForegroundService.ACTION_STOP)
        ctx.startService(svc)
    }

    fun onHostDestroy() { stopService() }
}
