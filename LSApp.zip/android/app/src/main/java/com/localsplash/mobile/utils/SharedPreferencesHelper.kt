package com.localsplash.mobile.utils

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.localsplash.mobile.MainApplication

object SharedPreferencesHelper {

    fun saveCallList(messageList: ArrayList<CallData>) {
        // Log.e("mytag","liststore" + messageList.size)
        val gson = Gson()
        val json = gson.toJson(messageList)
        MainApplication?.instance?.preferenceManager?.setValue("callList",json)
        val jsonstor =  MainApplication?.instance?.preferenceManager?.getValue("callList","")
        //Log.e("mytag","calllist" + jsonstor)
    }
    fun getCallList(): ArrayList<CallData> {
        val gson = Gson()
        val json =  MainApplication?.instance?.preferenceManager?.getValue("callList","")
        val type = object : TypeToken<ArrayList<CallData>>() {}.type
        return gson.fromJson(json, type) ?: ArrayList()
    }

 }