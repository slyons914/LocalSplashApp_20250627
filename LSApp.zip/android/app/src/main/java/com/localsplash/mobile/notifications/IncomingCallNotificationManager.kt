package com.localsplash.mobile.notifications

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.facebook.react.bridge.*
import com.localsplash.mobile.MainActivity
import com.localsplash.mobile.R
import org.json.JSONObject

class IncomingCallNotificationManager(private val reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    private val CHANNEL_ID = "voip_call_channel"
    private val CHANNEL_NAME = "VoIP Incoming Call"
    private var activeNotificationId: Int? = null

    override fun getName(): String = "IncomingCallNotificationManager"

    @SuppressLint("MissingPermission")
    @ReactMethod
    fun showIncomingCallNotification(fcmData: ReadableMap) {
        val context = reactContext.applicationContext
        val dataMap = mutableMapOf<String, String>()
        val iterator = fcmData.keySetIterator()
        while (iterator.hasNextKey()) {
            val key = iterator.nextKey()
            dataMap[key] = fcmData.getString(key) ?: ""
        }
        val uniqueId = dataMap["uniqueId"] ?: System.currentTimeMillis().toString()
        activeNotificationId = uniqueId.hashCode()
        CallNotificationService.showIncomingCallNotification(context, dataMap, activeNotificationId)
    }

    @ReactMethod
    fun cancelIncomingCallNotification() {
        val context = reactContext.applicationContext
        activeNotificationId?.let { NotificationManagerCompat.from(context).cancel(it) }
        activeNotificationId = null
        println("Notification dismissed")
    }

    private fun autoDismissNotificationAfterTimeout(context: Context, notificationId: Int) {
        Handler(Looper.getMainLooper()).postDelayed({
            NotificationManagerCompat.from(context).cancel(notificationId)
            println("Notification auto-dismissed after 30 seconds")
        }, 30_000)
    }

    private fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Incoming VoIP Calls"
                lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            }
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun convertReadableMapToJson(readableMap: ReadableMap): JSONObject {
        val jsonObject = JSONObject()
        val iterator: ReadableMapKeySetIterator = readableMap.keySetIterator()
        while (iterator.hasNextKey()) {
            val key = iterator.nextKey()
            val value = readableMap.getString(key)
            jsonObject.put(key, value)
        }
        return jsonObject
    }
}
