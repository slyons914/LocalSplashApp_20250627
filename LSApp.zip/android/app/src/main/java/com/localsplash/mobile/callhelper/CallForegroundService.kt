package com.localsplash.mobile.callhelper
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.localsplash.mobile.MainActivity
import com.localsplash.mobile.R

class CallForegroundService : Service() {
    companion object {
        const val CHANNEL_ID = "CallServiceChannel"
        const val ACTION_START = "com.localsplash.mobile.action.START"
        const val ACTION_STOP  = "com.localsplash.mobile.action.STOP"
    }

    override fun onCreate() {
        super.onCreate()
        // Create the notification channel (for Android O+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Active Call Service",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startInForeground()
            ACTION_STOP  -> stopForeground(true).also { stopSelf() }
        }
        // If killed, restart with last intent
        return START_STICKY
    }

    private fun startInForeground() {
        // Intent to bring app back to foreground if notification tapped
        val tapIntent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pending = PendingIntent.getActivity(
            this, 0, tapIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Call in progress")
            .setContentText("Touch to return to call")
            .setSmallIcon(R.drawable.common_full_open_on_phone)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()

        startForeground(1, notification)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
