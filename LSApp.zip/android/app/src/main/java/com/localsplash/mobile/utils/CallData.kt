package com.localsplash.mobile.utils

data class CallData (
    var CallID: String?= "",
    var headerSIPID: String?= "",

)