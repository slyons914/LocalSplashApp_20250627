package com.localsplash.mobile

import android.content.Context
import android.util.Log
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.Promise
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.FileWriter
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import android.os.Handler
import android.os.Looper
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.WritableMap

class LogcatModule (reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext)
{
    private var logcatProcess: Process? = null
    private var logFilePath: String? = null
    private var logWriter: BufferedWriter? = null
    private var startTime: Long = 0L
    private var logThread: Thread? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun getName(): String
    {
        return "LogcatBridge"
    }

    // FUNCTION TO SAVE LOGCAT TO A FILE
    @ReactMethod
    fun saveLogcat (promise: Promise) {
        try {
            // CREATE DIRECTORY FOR LOG FILES
            val dir = File(reactApplicationContext.getExternalFilesDir(null), "Logs")
            if (!dir.exists()) {
                dir.mkdirs() // CREATE FOLDER IF IT DOES NOT EXIST
            }

            // GENERATE FILE NAME WITH TIMESTAMP
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val logFile = File(dir, "logcat_$timeStamp.txt")

            // EXECUTE LOGCAT COMMAND TO CAPTURE LOGS FOR THE SPECIFIC PACKAGE
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", "logcat -d | grep -E 'com\\.localsplash\\.mobile'"))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val fos = FileOutputStream(logFile)

            // WRITE LOG OUTPUT TO FILE LINE BY LINE
            reader.useLines { lines ->
                lines.forEach { line ->
                    fos.write("$line\n".toByteArray())
                }
            }

            fos.close()

            // RETURN FILE PATH TO THE CLIENT
            promise.resolve(logFile.absolutePath)

        } catch (e: Exception) {
            promise.reject("ERROR", "Failed to save logcat: ${e.message}")
        }
    }

    // FUNCTION TO START LOGCAT CAPTURE IN BACKGROUND
    @ReactMethod
    fun startLogcat (callId: String, profileId: String, promise: Promise)
    {
        // GETTING THE APPLICATION PACKAGE NAME.
        val packageName = reactApplicationContext.packageName
        startTime = System.currentTimeMillis()

        // GET THE APP CURRENT PID.
        val pid = android.os.Process.myPid().toString()

        try
        {
            // CREATE DIRECTORY FOR LOG FILES
            val logsDir = File(reactApplicationContext.getExternalFilesDir(null), "Logs")
            if (!logsDir.exists()) logsDir.mkdirs() // IF NOT EXIST THEN CREATED

            // GENERATE FILE NAME WITH TIMESTAMP
            // val fileName = "logcat_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.txt"
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val fileName = "${callId}_${profileId}_$timeStamp.log"
            val logFile = File(logsDir, fileName)
            logFilePath = logFile.absolutePath

            logWriter = BufferedWriter(FileWriter(logFile))

            // START A BACKGROUND THREAD TO CAPTURE LOG OUTPUT
            logThread = thread(start = true) {
                try {
                    // EXECUTE LOGCAT COMMAND TO FILTER LOGS FOR THE CURRENT PROCESS ID
                    val command = arrayOf("sh", "-c", "logcat -v time | grep $pid")
                    logcatProcess = Runtime.getRuntime().exec(command)
                    val reader = BufferedReader(InputStreamReader(logcatProcess!!.inputStream))
                    var line: String?

                    while (true)
                    {
                        // CONTINUOUSLY READ LOG LINES FROM THE PROCESS UNTIL END
                        line = reader.readLine() ?: break

                        // EXTRACT TIMESTAMP FROM LOG LINE
                        val regex = Regex("""^(\d{2}-\d{2}) (\d{2}:\d{2}:\d{2}\.\d{3})""")
                        val match = regex.find(line ?: "")
                        if (match != null) {
                            val (date, time) = match.destructured
                            val logTimeString = "${SimpleDateFormat("yyyy").format(Date())}-$date $time"
                            val logTimestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).parse(logTimeString)?.time

                            // CHECK IF LOG TIMESTAMP IS AFTER START TIME TO FILTER OLD LOGS
                            if (logTimestamp != null && logTimestamp >= startTime) {
                                logWriter?.write(line) // WRITE THE LOG TO FILE
                                logWriter?.newLine()
                                logWriter?.flush()
                            }
                        }
                    }
                    reader.close()
                } catch (e: java.io.InterruptedIOException) {
                    Log.w("LogcatModule", "Logcat reading interrupted.")
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            // AUTO STOP LOGCAT AFTER 120 SECONDS TO PREVENT INFINITE EXECUTION
            handler.postDelayed({
                //val stopPromise = Promise()
                stopLogcat(promise)
            }, 120000)

            // RETURN RESULT USING THE HELPER
            val result = buildResult (true, "Logcat started for callId: $callId")
            promise.resolve(result)
        } catch (e: Exception)
        {
            // RETURN ERROR RESPONSE TO JS
            val errorResult = buildResult (false, e.message ?: "Unknown error")
            promise.resolve(errorResult)
        }
    }

    // FUNCTION TO STOP LOGCAT CAPTURE
    @ReactMethod
    fun stopLogcat (promise: Promise)
    {
        try
        {
            // INTERRUPT AND STOP THE LOGGING THREAD
            logThread?.interrupt()
            logThread?.join(100) // WAIT FOR THREAD TO CLEAN UP
            logcatProcess?.destroy()
            logWriter?.flush()
            logWriter?.close()
            logcatProcess = null

            // RETURN FILE PATH OF SAVED LOGS
            val path = logFilePath

            // END EVENT TO REACT NATIVE
            if (path != null)
            {
                sendEvent ("LogcatStopped", path)
            }

            // RETURN SUCCESS WITH THE FILE AND PATH.
            val result = buildResult (true, null, path)
            promise.resolve (result)
        } catch (e: Exception)
        {
            // RETURN ERROR RESPONSE TO JS
            val errorResult = buildResult (false, e.message ?: "Unknown error")
            promise.resolve (errorResult)
        }
    }

    // DELETE THE LOGCAT FILE IN INTERNAL STORAGE BY FILE NAME .
    @ReactMethod
    fun deleteLogcatByFileName (fileName: String, promise: Promise)
    {
        try
        {
            // GET THE LOGS DIRECTORY FROM APP'S INTERNAL STORAGE
            val logsDir = File (reactApplicationContext.getExternalFilesDir (null), "Logs")

            // CHECK IF DIRECTORY EXISTS AND IS ACTUALLY A DIRECTORY
            if (!logsDir.exists()) {
                // RETURN ERROR RESPONSE TO JS
                val errorResult = buildResult (false, "Logs directory does not exist.")
                promise.resolve (errorResult)
                return
            }

            // CHECK THE FILE IS EXISTS.
            val fileToDelete = File(logsDir, fileName)
            if (!fileToDelete.exists())
            {
                // RETURN ERROR RESPONSE TO JS
                val errorResult = buildResult (false, "Failed to delete file: $fileName")
                promise.resolve (errorResult)
                return
            }

            // DELETE THE FILE FROM INTERNAL STORAGE.
            val deleted = fileToDelete.delete();

            // RESPONSE RETURN
            if (deleted)
            {
                // RETURN ERROR RESPONSE TO JS
                val result = buildResult (true, "Deleted file: $fileName")
                promise.resolve (result)
            }
            else
            {
                // RETURN ERROR RESPONSE TO JS
                val errorResult = buildResult (false, "Failed to delete file: $fileName")
                promise.resolve (errorResult)
            }

        } catch (e: Exception)
        {
            // RETURN ERROR RESPONSE TO JS
            val errorResult = buildResult (false, e.message ?: "Unknown error")
            promise.resolve (errorResult)
        }
    }

    // THIS FUNCTION WILL BE USED TO GET ALL FILE FROM THE LOGS FOLDERS.
    @ReactMethod
    fun getAllLogcatFiles (promise: Promise)
    {
        try
        {
            // GET THE LOGS DIRECTORY FROM APP'S INTERNAL STORAGE
            val logsDir = File(reactApplicationContext.getExternalFilesDir(null), "Logs")

            // CHECK IF DIRECTORY EXISTS AND IS ACTUALLY A DIRECTORY
            if (!logsDir.exists() || !logsDir.isDirectory)
            {
                // RETURN ERROR IF DIRECTORY DOES NOT EXIST
                val errorResult = buildResult (false, "No log files found")
                promise.resolve (errorResult)
                return
            }

            // FETCH ALL FILES IN THE DIRECTORY, FILTER ONLY FILES
            val files = logsDir.listFiles()
                ?.filter { it.isFile } // ONLY INCLUDE FILES, SKIP SUBDIRECTORIES
                ?.map { it.absolutePath }   // RETURN FULL PATH AND FILE NAME
                ?: emptyList()         // IF NULL, RETURN EMPTY LIST


            // IF NO FILES FOUND, RETURN FAILURE
            if (files.isEmpty())
            {
                val errorResult = buildResult (false, "No log files found")
                promise.resolve (errorResult)
                return
            }

            // IF FILES FOUND, RETURN SUCCESS WITH LIST
            val errorResult = buildResult (true,  null, files)
            promise.resolve (errorResult)
        } catch (e: Exception)
        {
            // RETURN ERROR RESPONSE TO JS
            val errorResult = buildResult (false, e.message ?: "Unknown error")
            promise.resolve (errorResult)
        }
    }

    // SEND THE EVENT TO REACT NATIVE
    private fun sendEvent (eventName: String, params: String)
    {
        reactApplicationContext
            .getJSModule (DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            .emit (eventName, params)
    }

    // FUNCTION TO BUILD A CONSISTENT RESULT OBJECT
    fun buildResult (success: Boolean, message: String? = null, data: Any? = null): WritableMap
    {
        val result: WritableMap = Arguments.createMap()
        result.putBoolean("success", success)

        message?.let {
            result.putString("message", it)
        }

        data?.let {
            when (it) {
                is String -> result.putString("data", it)
                is Boolean -> result.putBoolean("data", it)
                is Int -> result.putInt("data", it)
                is Double -> result.putDouble("data", it)
                is WritableMap -> result.putMap("data", it)
                is List<*> -> {
                    val array = Arguments.createArray()
                    it.forEach { item ->
                        array.pushString(item.toString())
                    }
                    result.putArray("data", array)
                }
                else -> result.putString("data", it.toString())
            }
        }

        return result
    }
}
