const listenLinphoneCallEvents = () =>
{
	const subscriptions =
	[
		twilioPhoneEmitter.addListener (EventType.CallInvite, ({ callSid, from }) =>
		{
			console.log ("twilio_phone_event_service", EventType.CallInvite, { callSid, from });
			const uuid = ramdomUuid().toLowerCase();
			RNTwilioPhone.addCall ({ uuid, sid: callSid, payload: null });
			RNCallKeep.displayIncomingCall (uuid, from);
		}),
		twilioPhoneEmitter.addListener (EventType.CancelledCallInvite, ({ callSid }) =>
		{
			console.log ("twilio_phone_event_service", EventType.CancelledCallInvite, { callSid });
			const uuid = RNTwilioPhone.getCallUUID (callSid);

			// IF A VALID UUID OF THE CALL IS FOUND THEN END THE CALL.
			if (uuid)
			{
				RNCallKeep.reportEndCallWithUUID (uuid, CK_CONSTANTS.END_CALL_REASONS.MISSED);
				RNTwilioPhone.removeCall (uuid);
				AndroidReactBridge.stopPhoneCallNotification (uuid);
			}
		}),
	];

	return () =>
	{
		removeTwilioPhoneListeners();
	};
}