import {
    createNativeStackNavigator,
    NativeStackNavigationOptions,
  } from "@react-navigation/native-stack"
  
  import { ReviewsScreen } from "@screens"
  import { Routes } from "@utils/constants"
  
  import { RouteParamList } from "../types"
  import { Header } from "@components"
  import { useNavigation } from "@react-navigation/native"
  
  const Stack = createNativeStackNavigator<RouteParamList>()
  
  export const ReviewsStackNavigator = () => {
    const { goBack } = useNavigation()
  
    const options: NativeStackNavigationOptions = {
      header: () => <Header onLeftPress={goBack} />,
    }
  
    return (
      <Stack.Navigator screenOptions={options}>
        <Stack.Screen name={Routes.Reviews} component={ReviewsScreen} />
      </Stack.Navigator>
    )
  }