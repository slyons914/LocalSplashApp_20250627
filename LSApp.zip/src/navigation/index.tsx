import React, {useEffect, useState} from "react"

import {
  NavigationContainer,
  createNavigationContainerRef,
  StackActions,
} from "@react-navigation/native"
import {
  createNativeStackNavigator,
  NativeStackNavigationOptions,
} from "@react-navigation/native-stack"
import SplashScreen from "react-native-splash-screen"

import { Stacks } from "@utils/constants"
import { AuthHelper } from "@utils/helpers"

import { CallStackNavigator } from "./CallStackNavigator"
import { HomeStackNavigator } from "./HomeStackNavigator"
import { LeadsStackNavigator } from "./LeadsStackNavigator"
import { LoginStackNavigator } from "./LoginStackNavigator"
import { MessageStackNavigator } from "./MessageStackNavigator"
import { SettingsStackNavigator } from "./SettingsNavigator"
import { RouteParamList } from "./types"
import { FacebookStackNavigator } from "./FacebookStackNavigator"
import { observer } from "mobx-react-lite"
import { ReviewsStackNavigator } from "./ReviewsStackNavigator"
import { GoogleAdsNavigator } from "./GoogleAdsNavigator"
import { GoogleInsightsNavigator } from "./GoogleInsightsNavigator"
import { About } from "@screens"
import { ContactUsStackNavigator } from "./ContactUsStackNavigator"
import { WebsiteStackNavigator } from "./WebsiteStackNavigator"
import { ListingsStackNavigator } from "./ListingStackNavigator"
import { PostsStackNavigator } from "./PostStackNavigator"
import { PreferencesStackNavigator } from "./PreferenceStackNavigator"
import {processNotificationAction} from "@utils/notification/notifications"
import IncomingTelephonyComponent from "@telephony/incoming.component"
import ActiveTelephonyCallComponent from "@telephony/activecall/activecall.component"
import CallOverlay from "@telephony/activecall/calloverlay.component"
import { useStore } from "@store"
const Stack = createNativeStackNavigator<RouteParamList>()

const options: NativeStackNavigationOptions = {
  headerShown: false,
}

// VARIABLE TO STORE NAVIGATION REQUEST WHEN NAVIGATION REF IS NOT READY. THIS WILL BE PROCESSED LATER IN
// useEffect HOOK THAT WILL HAVE NAVIGATION REF AS A DEPENDENCY.
export let queueNavigationRequest: any = null;

export const navigate = (name: string, params?: any) =>
{
	console.log ("navigate called with: ", name, params, "is navigation ready: ", navigationRef.isReady());
	
	// CHECK IF THE NAVIGATION REF IS READY BEFORE ATTEMPTING ANY NAVIGATION ACTIONS.
	if (navigationRef.isReady())
	{
		navigationRef.navigate (name, params);
	}
	else // IF THE NAVIGATION REF IS NOT READY THEN QUEUE THE NAVIGATION REQUEST.
	{
		queueNavigationRequest = {name, params};
	}
}

export const ResetHomeNavigator = () => {
	if (navigationRef.isReady())
	{
		const state = navigationRef.getState()
		if (state?.routes?.length > 1)
		{
			navigationRef.dispatch (StackActions.popToTop())
		} else {
			// Already at top screen, optionally handle this case.
		}
	}
}
export const GetCurrentScrrenNname = () => {
  if (navigationRef.isReady()) {
    return navigationRef.getCurrentRoute()?.name
  }
  return null
}
const NavigationComponent = () => {
  const [initialScreen, setInitialScreen] = useState<Stacks | null>(null)
  const [isNavigationReady, setNavigationReady] = useState(false)

  const { homeStore } = useStore()
  const {notificationData, setCurrentScreenName} = homeStore;

  useEffect(() => {
    AuthHelper.getIsAuthorized().then((isAuthorized: boolean) => {
      if (isAuthorized) {
        setInitialScreen(Stacks.Home)
      } else {
        setInitialScreen(Stacks.Login)
      }

      SplashScreen.hide()
    })
  }, [])
	
	// WHENEVER NAVIGATION STATE IS CHANGED, THIS FUNCTION WILL BE CALLED.
	const navigationStateChanged = (state: any) =>
	{
		let currentRoute = state?.routes[state.index].name; // GET THE CURRENT ROUTE NAME.
		global.currentScreenName = currentRoute; // STORE IT IN GLOBAL SCOPE VARIABLE.
		setCurrentScreenName (currentRoute); // STORE IT IN MOBX STORE.
		console.log ("%c current screen: %s", 'background: orange', global.currentScreenName);
	}
	
	// WHEN NAVIGATION IS READY THEN PROCESS THE NOTIFICATION ACTIONS.
	useEffect (() =>
	{
		if (isNavigationReady)
		{
			// VARIABLE TO STORE IF THE USER IS NAVIGATED TO SOME SCREEN. THIS WILL BE USED TO AVOID MULTIPLE NAVIGATIONS.
			let hasNavigated: boolean = false;
			
			// IF THERE IS ANY NOTIFICATION DATA THEN PROCESS IT. NOTIFICATION DATA WILL COME FROM MOBX FROM INDEX.JS.
			if (notificationData)
			{
				if (typeof notificationData.data !== undefined && Object.keys(notificationData.data).length > 0)
				{
					console.log ("notification was tapped. ", notificationData);
					let response: any = processNotificationAction (notificationData);
					console.log ("response returned by processing notification action", response)
					
					// IF RESPONSE IS AN INSTRUCTION TO REDIRECT USER TO SOME SCREEN THEN DO IT.
					if (response && response.action == "navigate")
					{
						hasNavigated = true;
						navigationRef.current.navigate (response.route, response.params);
					}
				}
				else
				{
					console.log ("%cIgnoring notification tap because data is not available.", "color:orange");
				}
			}
			
			// IF THERE IS ANY NAVIGATION REQUEST AND USER IS NOT NAVIGATED TO ANY OTHER SCREEN, THEN PROCESS IT.
			if (queueNavigationRequest && !hasNavigated)
			{
				hasNavigated = true;
				const {name, params} = queueNavigationRequest;
				navigationRef.current.navigate (name, params);
				queueNavigationRequest = null;
			}
			
			// RESET THE NOTIFICATION DATA AFTER PROCESSING.
			hasNavigated = false;
		}
	}, [isNavigationReady, notificationData]);

  if (!initialScreen) return null

  return (
    <React.Fragment>
      <NavigationContainer
	      onReady={() => {setNavigationReady(true)}}
	      onStateChange={navigationStateChanged}
        ref={(ref) => {
          navigationRef.current = ref
        }}
      >
	      <CallOverlay/>
        <Stack.Navigator screenOptions={options} initialRouteName={initialScreen}>
        {/*<Stack.Navigator screenOptions={options} initialRouteName={Stacks.TELEPHONY_CALL_ACTIVE}>*/}
          {/* {screenName==='callScreen'?(
        <Stack.Group screenOptions={{ headerShown: false }}>
         <Stack.Screen name={'incomingcall'} component={IncomingCallScreen}/>
         <Stack.Screen name={'callinprogress'} component={CallInProgressScreen}/>
        </Stack.Group>
        ):( */}
          <Stack.Group screenOptions={{ headerShown: false }}>
            <Stack.Screen name={Stacks.Login} component={LoginStackNavigator} />
            <Stack.Screen name={Stacks.Call} component={CallStackNavigator} />
            <Stack.Screen name={Stacks.Home} component={HomeStackNavigator} />
            <Stack.Screen name={Stacks.Leads} component={LeadsStackNavigator} />
            <Stack.Screen name={Stacks.Settings} component={SettingsStackNavigator} />
            <Stack.Screen name={Stacks.Messages} component={MessageStackNavigator} />
            <Stack.Screen name={Stacks.Facebook} component={FacebookStackNavigator} />
            <Stack.Screen name={Stacks.Reviews} component={ReviewsStackNavigator} />
            <Stack.Screen name={Stacks.GoogleAds} component={GoogleAdsNavigator} />
            <Stack.Screen name={Stacks.GoogleInsghts} component={GoogleInsightsNavigator} />
            <Stack.Screen name={Stacks.TELEPHONY_CALL_INCOMING} component={IncomingTelephonyComponent} />
            <Stack.Screen name={Stacks.TELEPHONY_CALL_ACTIVE} component={ActiveTelephonyCallComponent} />
            <Stack.Screen name={Stacks.ABOUT} component={About} />
            <Stack.Screen name={Stacks.CONTACT_US} component={ContactUsStackNavigator} />
            <Stack.Screen name={Stacks.WEBSITE} component={WebsiteStackNavigator} />
            <Stack.Screen name={Stacks.LISTINGS} component={ListingsStackNavigator} />
            <Stack.Screen name={Stacks.POSTS} component={PostsStackNavigator} />
            <Stack.Screen name={Stacks.PREFERENCES} component={PreferencesStackNavigator} />
          </Stack.Group>
          {/* )} */}
        </Stack.Navigator>
      </NavigationContainer>
    </React.Fragment>
  )
}

export const navigationRef: any = createNavigationContainerRef()

export const Navigation = observer(NavigationComponent)
