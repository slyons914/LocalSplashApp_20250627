import {
    createNativeStackNavigator,
    NativeStackNavigationOptions,
  } from "@react-navigation/native-stack"
  
  import { PostsScreen } from "@screens"
  import { Routes } from "@utils/constants"
  
  import { RouteParamList } from "../types"
  import { Header } from "@components"
  import { useNavigation } from "@react-navigation/native"
  import { AddPost } from "@screens"
  
  const Stack = createNativeStackNavigator<RouteParamList>()
  
  export const PostsStackNavigator = () => {
    const options: NativeStackNavigationOptions = {
        headerShown: false,
      } 
  
    return (
      <Stack.Navigator screenOptions={options}>
        <Stack.Screen name={Routes.Posts} component={PostsScreen} />
        <Stack.Screen name={Routes.AddPost} component={AddPost} />
      </Stack.Navigator>
    )
  }