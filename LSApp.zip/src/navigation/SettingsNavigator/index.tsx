import {
  NativeStackNavigationOptions,
  createNativeStackNavigator,
} from "@react-navigation/native-stack"

import {
  BusinessInformationScreen,
  PersonalInfoScreen,
  PrimarySearchPhraseScreen,
  RingerBehaviorScreen,
  SettingsGSMScreen,
  SettingsMakeCallsScreen,
  SettingsNotificationsScreen,
  SettingsScreen,
  BillingsScreen,
  BusinessPhotos,
  BusinessDocuments,
  BusinessVideos
} from "@screens"
import { Routes } from "@utils/constants"

import { RouteParamList } from "../types"

const Stack = createNativeStackNavigator<RouteParamList>()

const options: NativeStackNavigationOptions = {
  headerShown: false,
}

export const SettingsStackNavigator = () => {
  return (
    <Stack.Navigator screenOptions={options}>
      <Stack.Screen name={Routes.Settings} component={SettingsScreen} />
      <Stack.Screen name={Routes.PersonalInfo} component={PersonalInfoScreen} />
      <Stack.Screen name={Routes.SettingsNotifications} component={SettingsNotificationsScreen} />
      <Stack.Screen name={Routes.SettingsMakeCalls} component={SettingsMakeCallsScreen} />
      <Stack.Screen name={Routes.SettingsGSM} component={SettingsGSMScreen} />
      <Stack.Screen name={Routes.RingerBehavior} component={RingerBehaviorScreen} />
      <Stack.Screen name={Routes.BusinessInformation} component={BusinessInformationScreen} />
      <Stack.Screen name={Routes.Billings} component={BillingsScreen} />
      <Stack.Screen name={Routes.BusinessPhotos} component={BusinessPhotos} />
      <Stack.Screen name={Routes.BusinessDocuments} component={BusinessDocuments} />
      <Stack.Screen name={Routes.BusinessVideos} component={BusinessVideos} />
      <Stack.Screen
        name={Routes.PrimarySearchPhrase}
        component={PrimarySearchPhraseScreen}
        options={{ animation: "slide_from_bottom" }}
      />
    </Stack.Navigator>
  )
}
