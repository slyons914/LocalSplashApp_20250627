import {
  createNativeStackNavigator,
  NativeStackNavigationOptions,
} from "@react-navigation/native-stack"

import { Routes } from "@utils/constants"

import { RouteParamList } from "../types"
import { Header } from "@components"
import { useNavigation } from "@react-navigation/native"
import { GoogleInsightsScreen } from "@screens"

const Stack = createNativeStackNavigator<RouteParamList>()

export const GoogleInsightsNavigator = () => {
  const { goBack } = useNavigation()

  const options: NativeStackNavigationOptions = {
    header: () => <Header onLeftPress={goBack} />,
  }

  return (
    <Stack.Navigator screenOptions={options}>
      <Stack.Screen name={Routes.Google_Insights} component={GoogleInsightsScreen} />
    </Stack.Navigator>
  )
}
