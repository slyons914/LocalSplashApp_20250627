import {
  NativeStackNavigationOptions,
  createNativeStackNavigator,
} from "@react-navigation/native-stack"

import { MessagesScreen ,MessageDetail } from "@screens"
import { Routes } from "@utils/constants"

import { RouteParamList } from "../types"

const Stack = createNativeStackNavigator<RouteParamList>()

const options: NativeStackNavigationOptions = {
    headerShown: false,
}

export const MessageStackNavigator = () => {
  return (
    <Stack.Navigator screenOptions={options}>
      <Stack.Screen name={Routes.Messages} component={MessagesScreen} />
      <Stack.Screen name={Routes.MessageDetail} component={MessageDetail} />
    </Stack.Navigator>
  )
}
