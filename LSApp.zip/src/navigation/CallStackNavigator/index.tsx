import {
  BottomTabBarProps,
  BottomTabNavigationOptions,
  createBottomTabNavigator,
} from "@react-navigation/bottom-tabs"

import { CallLogScreen, DialPadScreen } from "@screens"
import { Routes } from "@utils/constants"
import { withPlayer } from "@utils/hocs"

import { BottomBar } from "./BottomBar"
import { Header } from "./Header"

const Tab = createBottomTabNavigator()

const options: BottomTabNavigationOptions = {
  header: () => <Header />,
}

const StackNavigator = () => {
  const renderBottomBar = (props: BottomTabBarProps) => {
    return <BottomBar {...props} />
  }

  return (
    <Tab.Navigator screenOptions={{headerShown:false}} tabBar={renderBottomBar}>
      <Tab.Screen name={Routes.DialPad} component={DialPadScreen} />
      <Tab.Screen name={Routes.CallLog} component={CallLogScreen} />
    </Tab.Navigator>
  )
}

export const CallStackNavigator = withPlayer(StackNavigator)
