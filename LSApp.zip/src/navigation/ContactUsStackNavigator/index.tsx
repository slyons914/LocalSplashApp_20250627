import {
    createNativeStackNavigator,
    NativeStackNavigationOptions,
} from "@react-navigation/native-stack"


import { Routes } from "@utils/constants"

import { ContactUsScreen } from "@screens"
import { RouteParamList } from "../types"

const Stack = createNativeStackNavigator<RouteParamList>()

export const ContactUsStackNavigator = () => {

    const options: NativeStackNavigationOptions = {
        headerShown: false
    }

    return (
        <Stack.Navigator screenOptions={options}>
            <Stack.Screen name={Routes.ContactUs} component={ContactUsScreen} />
        </Stack.Navigator>
    )
}
