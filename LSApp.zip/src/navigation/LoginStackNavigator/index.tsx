import {
  NativeStackNavigationOptions,
  createNativeStackNavigator,
} from "@react-navigation/native-stack"

import {
  LoginScreen,
  WelcomeScreen,
  TermsScreen,
  NotificationsScreen,
  PermissionsScreen,
  CodeScreen,
} from "@screens"
import { Routes } from "@utils/constants"

import { RouteParamList } from "../types"

const Stack = createNativeStackNavigator<RouteParamList>()

const options: NativeStackNavigationOptions = {
  headerShown: false,
}

export const LoginStackNavigator = () => {
  return (
    <Stack.Navigator screenOptions={options}>
      <Stack.Screen name={Routes.Welcome} component={WelcomeScreen} />
      <Stack.Screen name={Routes.Login} component={LoginScreen} />
      <Stack.Screen name={Routes.Terms} component={TermsScreen} />
      <Stack.Screen name={Routes.Notifications} component={NotificationsScreen} />
      <Stack.Screen name={Routes.Permissions} component={PermissionsScreen} />
      <Stack.Screen name={Routes.Code} component={CodeScreen} />
    </Stack.Navigator>
  )
}
