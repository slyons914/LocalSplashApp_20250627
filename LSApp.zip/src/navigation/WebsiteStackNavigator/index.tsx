import {
    createNativeStackNavigator,
    NativeStackNavigationOptions,
} from "@react-navigation/native-stack"


import { Routes } from "@utils/constants"
import { Header } from "@components"
import { useNavigation } from "@react-navigation/native"
import { WebsiteScreen } from "@screens"
import { RouteParamList } from "../types"

const Stack = createNativeStackNavigator<RouteParamList>()

export const WebsiteStackNavigator = () => {
    const { goBack } = useNavigation()

    const options: NativeStackNavigationOptions = {
        header: () => <Header onLeftPress={goBack} />,
      }

    return (
        <Stack.Navigator screenOptions={options}>
            <Stack.Screen name={Routes.Website} component={WebsiteScreen} />
        </Stack.Navigator>
    )
}
