import {
    createNativeStackNavigator,
    NativeStackNavigationOptions,
  } from "@react-navigation/native-stack"
  import { Routes } from "@utils/constants"
  
  import { RouteParamList } from "../types"
  import { PreferencesScreen, RingtoneScreen, SoundsScreen, TextToneScreen, NetworkPreferenceScreen, NotificationPreferenceScreeen, NetworkChangeScreen, NetworkPrioritiesScreen } from "@screens"

  const Stack = createNativeStackNavigator<RouteParamList>()
  
  export const PreferencesStackNavigator = () => {
    const options: NativeStackNavigationOptions = {
        headerShown: false,
      } 
  
    return (
      <Stack.Navigator screenOptions={options}>
        <Stack.Screen name={Routes.Preferences} component={PreferencesScreen} />
        <Stack.Screen name={Routes.Sound} component={SoundsScreen} />
        <Stack.Screen name={Routes.Ringtone} component={RingtoneScreen} />
        <Stack.Screen name={Routes.TextTone} component={TextToneScreen} />
        <Stack.Screen name={Routes.Network} component={NetworkPreferenceScreen} />
        <Stack.Screen name={Routes.NotificationsPreference} component={NotificationPreferenceScreeen} />
        <Stack.Screen name={Routes.NetworkChange} component={NetworkChangeScreen} />
        <Stack.Screen name={Routes.NetworkPriorites} component={NetworkPrioritiesScreen} />

      </Stack.Navigator>
    )
  }