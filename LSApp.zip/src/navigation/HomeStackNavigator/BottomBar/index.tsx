import { useEffect, useState } from "react"

import { Alert, TouchableOpacity, View } from "react-native"

import { BottomTabBarProps } from "@react-navigation/bottom-tabs"
import { observer } from "mobx-react-lite"
import Svg, { Path } from "react-native-svg"

import { Icon, Typography } from "@components"
import { useStore } from "@store"
import { Routes, Stacks, colors } from "@utils/constants"

import { useStyles } from "./styles"
import {isSipAvailable} from "@utils/helpers/sip"
import { CallHelper } from "@utils/helpers"
import { CallAlertModal } from "@modals"

interface Tab {
  key: number
  name: string
  stack: Stacks
  route: Routes
  activeIcon: IconName
  inactiveIcon: IconName
}

const tabs: Array<Tab> = [
  {
    key: 0,
    stack: Stacks.Home,
    route: Routes.Home,
    name: "Home",
    activeIcon: "homeFilled",
    inactiveIcon: "homeOutlined",
  },
  {
    key: 1,
    stack: Stacks.Home,
    route: Routes.Leads,
    name: "Leads",
    activeIcon: "leadsFilled",
    inactiveIcon: "leadsOutlined",
  },
  {
    key: 2,
    stack: Stacks.Call,
    route: Routes.CallLog,
    name: "Calls",
    activeIcon: "callsFilled",
    inactiveIcon: "callsOutlined",
  },
  {
    key: 3,
    stack: Stacks.Messages,
    route: Routes.Messages,
    name: "Messages",
    activeIcon: "messagesFilled",
    inactiveIcon: "messagesOutlined",
  },
]

const Component = ({ state, navigation }: BottomTabBarProps) => {
  const styles = useStyles()

  const { navigate, reset } = navigation

  const { homeStore } = useStore()
  const { locationsItem } = homeStore

  const [isCallAlertVisible, setIsCallAlertVisible] = useState(false)

  const onPhonePress = async () => {
    const sipCredentials = await CallHelper.getSipSettingsFromProfileId(locationsItem?.id)
    if (isSipAvailable(sipCredentials)) {
      navigate(Stacks.Call, { screen: Routes.DialPad })
    } else {
      setIsCallAlertVisible(true)
    }
  }

  const onBottomBarItemPress = (stack: Stacks, route: Routes) => {
    if(route === Routes.Leads) {
        reset({
            index:0,
            routes:[{name: route}]
        })
    } else {
        navigate(stack, {screen: route})
    }
  }

  const renderTab = ({ key, route, name, activeIcon, inactiveIcon, stack }: Tab) => {
    const isActive = state.index === key

    return (
      <TouchableOpacity
        key={key}
        onPress={() => onBottomBarItemPress(stack, route)}
        style={styles.tab}
      >
        <Icon name={isActive ? activeIcon : inactiveIcon} />
        <Typography style={[styles.text, isActive && styles.textActive]}>{name}</Typography>
      </TouchableOpacity>
    )
  }

  const leftTabs = tabs.slice(0, tabs.length / 2)
  const rightTabs = tabs.slice(tabs.length / 2)

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={onPhonePress} style={styles.phone}>
        <Icon name={"phonePlus"} />
      </TouchableOpacity>

      <View style={styles.tabs}>
        <View style={styles.tabRow}>{leftTabs.map(renderTab)}</View>
        <View style={styles.tabRow}>{rightTabs.map(renderTab)}</View>
      </View>

      <Svg width={"100%"} height={70} viewBox={"0 0 342 70"}>
        <Path
          d="M0 35C0 15.67 15.67 0 35 0h78.501a40.019 40.019 0 0128.995 12.46c15.741 16.575 42.205 16.599 57.92.001A39.884 39.884 0 01229.376 0H307c19.33 0 35 15.67 35 35s-15.67 35-35 35H35C15.67 70 0 54.33 0 35z"
          fill={colors.common.blueDark}
        />
      </Svg>
      <CallAlertModal isVisible={isCallAlertVisible} onClose={() => setIsCallAlertVisible(false)} isFromLead={false}/>
    </View>
  )
}

export const BottomBar = observer(Component)
