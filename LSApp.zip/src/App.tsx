import { useEffect } from "react"
import { LogBox, Platform } from "react-native"
import { Mixpanel } from "mixpanel-react-native"
import { SafeAreaProvider } from "react-native-safe-area-context"
import { GestureHandlerRootView } from "react-native-gesture-handler"
import { MIXPANEL_TOKEN } from "@env"
import { Navigation } from "@navigation"
import { LeadProvider, TranslationProvider } from "@providers"
import { useStore } from "@store"
import { observer } from "mobx-react-lite"
import { StorageHelper } from "@utils/helpers"
import { Pusher } from "@pusher/pusher-websocket-react-native"
import { PUSHER_KEY } from '@env'
import {TelephonyProvider} from '@telephony/telephony.provider';

import PushNotification from "react-native-push-notification"
import FlashMessage from "react-native-flash-message"
import {processPendingLogFilesUpload} from '@utils/logcat';
import CallKeepComponent from "@telephony/callkeep.component"
import VoipPushNotificationComponent from "@telephony/voippushnotification.component"
import { initializeConfig } from "@utils/constants/common"
import { sendPushToken } from "@utils/helpers/common"

const AppComponent = ({initialProps}: any) =>
{
	
	const { authStore, settingsStore } = useStore()
	const { deviceToken } = authStore
	const { checkSipSettings } = settingsStore
	
	//enableFreeze(Platform.OS == "android" ? true : false)
	
	
	useEffect (() =>
	{
		console.log ("initialProps ",initialProps);
	}, [initialProps]);
	
	const setUpPusher = async () => {
		const pusher = Pusher.getInstance()
		await pusher.init({
			apiKey: PUSHER_KEY,
			cluster: "us3",
		})
		await pusher.connect()
	}
	
	useEffect(() =>
	{
		setUpPusher()
		initializeConfig();
		PushNotification.cancelAllLocalNotifications()
		console.log("Device token : ", deviceToken)
		processPendingLogFilesUpload ().then();
		
		// GET THE ID TOKEN FROM LOCAL STORAGE TO KNOW THE LOGGED IN STATUS OF USER.
		StorageHelper.get<string>("idToken").then (async (idToken: string | null) =>
		{
			// IF USER IS LOGGED IN THEN GET UPDATED SIP SETTINGS.
			if (idToken)
			{
                await sendPushToken();
				await checkSipSettings();
			}
		});
		if (__DEV__) return
		
		new Mixpanel(MIXPANEL_TOKEN, true).init()
	}, [])
	
	// useEffect (() => {
	// 	const AppStateChanged = AppState.addEventListener("change", handleAppStateChange)
	// 	return () => {
	// 		AppStateChanged.remove()
	// 	}
	// }, [isCallActive])
	//
	// const handleAppStateChange = (nextAppState: any) => {
	// 	if (nextAppState === "active" && isCallActive) {
	// 		navigate(Stacks.TELEPHONY_CALL_ACTIVE, {})
	// 	} else {
	// 	}
	// }
	
	LogBox.ignoreAllLogs();
	
	return (
		<SafeAreaProvider>
			<TranslationProvider>
				<TelephonyProvider initialProps={initialProps}>
					{Platform.OS === "ios" && <VoipPushNotificationComponent />}
					<CallKeepComponent/>
                    <LeadProvider>
                        <GestureHandlerRootView style={{ flex: 1 }}>
                            <Navigation />
                            <FlashMessage position="top" />
                        </GestureHandlerRootView>
                    </LeadProvider>
				</TelephonyProvider>
			</TranslationProvider>
		</SafeAreaProvider>
	)
}

export const App = observer(AppComponent)
