import { PostsFilter, PostsInterface } from "@models/index"
import { mobileAPI } from "./base"
import { handleError } from "./common"
import { StorageHelper } from "@utils/helpers"
import { Response } from "./types"
import axios from "axios"
import { LsConfig } from "@utils/constants/common"

export class PostsAPI {
    static async getPosts(postsFiler:PostsFilter): Promise<Response<PostsInterface>> {

        try {
          const { data } = await mobileAPI.get<PostsInterface>(
            `/Profiles/${postsFiler.profileId}/GooglePosts`,postsFiler)
          return { data, error: null }
        } catch (err) {
          console.log(`ERROR: /Profiles/${postsFiler.profileId}/GooglePosts`, err)
          return handleError(err, "/Profiles/profileId/GooglePosts", postsFiler)
        }
    }
    static async addPost(profileId:number | undefined, postData:FormData) {
        const accessToken = await StorageHelper.get("accessToken")
        const headers = {
            'Content-Type': 'multipart/form-data',
            'Authorization': `Bearer ${accessToken}` 
          };
        console.log("post filter are: ",postData)
        try {
            const response = await axios.post(`${LsConfig.MOBILE_API_URL}/Profiles/${profileId}/GooglePosts`, postData, {
              headers: headers
            });
            return {data:response.data, error:null}
          } catch (error) {
            console.error(`Error:/Profiles/${profileId}/GooglePosts`, error);
            return handleError(error, "/Profiles/profileId/GooglePost", postData)
          }
    }
    static async deletePost(profileId:number | undefined, postId:string|undefined) {
        const payload = {
            postId:postId,
            isPostScheduled:false
        }
        const accessToken = await StorageHelper.get("accessToken")
        const headers = {
            'Authorization': `Bearer ${accessToken}` ,
          };
        try {
            const response = await axios.delete(`${LsConfig.MOBILE_API_URL}/Profiles/${profileId}/GooglePosts`, {
              headers: headers,
              data:payload
            });
            return {data:response.data, error:null}
          } catch (error) {
            console.error(`Error:/Profiles/${profileId}/GooglePosts`, error);
            return handleError(error, "/Profiles/profileId/GooglePosts", { profileId, postId })
          }


    }


}