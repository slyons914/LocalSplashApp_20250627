import { AxiosError } from "axios"
import crashlytics from '@react-native-firebase/crashlytics';
import { StorageHelper } from "@utils/helpers";
export async function handleError(err: any, url:string, payload?:any){
    const accessToken = await StorageHelper.get<string>("accessToken")
    if (err instanceof AxiosError) {
      console.log("error is: ", err)  
      var error = err.message
      if(error === "Network Error") {
        return { data: null, error: error }
      }
      let statusCode: number | null = null;
      const match = error.match(/status code (\d+)/);
      if (match) {
        statusCode = parseInt(match[1], 10);
      }
      crashlytics().recordError(err)
      crashlytics().log(`API ${url} FAILED With message ${err.message} and payload: ${JSON.stringify(payload)} with acessToken ${accessToken}`)
      console.log("FAIL : /AxiosError",error)
      switch (statusCode) {
        case 400:
          error = 'Something went wrong';
          break;
        case 401:
          error = 'Authentication Error';
          break;
        case 404:
          error = 'Something went wrong';
          break;
        case 410: 
          error = 'Please Update to Latest Version';
          break;    
        case 500:
          error = 'Internal Server Error';
          break;
        default:
          error = 'Something went wrong';
      }
      return { data: null, error: error };
    }
    return { data: null, error : "Something went wrong" }
  }
