
import {
  DateFilter,
  FacebookAdsInterface,
  FacebookAdsPreview,
  GetTermsAndConditionsContentResponseViewModel,
  GoogleAdsInsights,
  IAcceptTermsAndConditionsRequestViewModel,
  IGetProfileAnalyticsOverTimeResponseViewModel,
  IGetProfileAnalyticsResponseViewModel,
  IGetProfileListResponseViewModel,
  IProfileLocationViewModel,
  Listings,
  MonthlyKeywords,
  RecentMessagesList,
  RefreshToken,
  ReviewData,
  ReviewReqeusts,
  Reviews,
  UnreadLeads,
  WebsiteLeads,
} from "@models"
import { DudaUrls, UserCallTrackingSipSettings, UserCallTrackingSipSettingsList } from "@models/home"
import { AppTokensLocalsplashService, CallRoutingSettingsLocalsplashService, CreateOrUpdateAppTokenRequestViewModel, CreateOrUpdateAppTokensRequestViewModel, DeleteAppTokenRequestViewModel, FacebookActionsInsightViewModel, FacebookAdsLocalsplashService, FacebookAgesInsightsViewModel, FacebookBaseInsightsViewModel, FacebookGendersInsightsViewModel, FacebookRegionsInsightsViewModel, GoogleAdsLocalsplashService, ITotalResultsOverTimeViewModel, ReviewsLocalsplashService, UpdateCallRoutingSettingsRequestViewModel } from '@localsplash/mobile-api-client';

import { mobileAPI, mobileClient } from "./base"
import { Response } from "./types"
import { handleError } from "./common"
import { StorageHelper } from "@utils/helpers"
import axios from "axios"
import { LsConfig } from "@utils/constants/common"

export class MobileAPI {
  static async getProfiles(): Promise<Response<IGetProfileListResponseViewModel>> {
    try {
      const { data } = await mobileAPI.get<IGetProfileListResponseViewModel>("/Profiles")
      return { data, error: null }
    } catch (err) {
      console.log("ERROR : /Profiles", err)
      return handleError(err, "/Profiles", {})
    }
  }

  static async getLocations(id: number): Promise<Response<IProfileLocationViewModel>> {
    try {
      const { data } = await mobileAPI.get<IProfileLocationViewModel>(`/Profiles/${id}/Location`)
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/Location`, err)
      return handleError(err, "/Profiles/id/Location", {})
    }
  }

  static async getLogo(profileId: number): Promise<Response<{ mediaUrl: string }>> {
    try {
      const { data } = await mobileAPI.get<{ mediaUrl: string }>(`/Profiles/${profileId}/Logo`)
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${profileId}/Logo`, err)
      return handleError(err, "/Profiles/PorfileId/Logo", {profileId})
    }
  }

  static async getBackgroundImage(profileId: number): Promise<Response<{ mediaUrl: string }>> {
    try {
      const { data } = await mobileAPI.get<{ mediaUrl: string }>(`/Profiles/${profileId}/BackgroundImage`)
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${profileId}/BackgroundImage`, err)
      return handleError(err, "/Profiles/PorfileId/BackgroundImage", { profileId })
    }
  }

  static async getAnalytics(
    profileId: number,
  ): Promise<Response<IGetProfileAnalyticsResponseViewModel>> {
    try {
      const { data } = await mobileAPI.get<IGetProfileAnalyticsResponseViewModel>(
        `/Profiles/${profileId}/Analytics`,
      )

      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${profileId}/Analytics`, err)
      return handleError(err, "/Profiles/ProfileId/Analytics", { profileId })
    }
  }

  static async filterAnalytics(
    profileId: number,
    fromDate: string,
    toDate: string,
  ): Promise<Response<IGetProfileAnalyticsResponseViewModel>> {
    try {
      const { data } = await mobileAPI.get<IGetProfileAnalyticsResponseViewModel>(
        `/Profiles/${profileId}/TotalResults?FromDate=${fromDate}&ToDate=${toDate}`,
      )

      return { data, error: null }
    } catch (err) {
      console.log(
        `ERROR: /Profiles/${profileId}/TotalResults?FromDate=${fromDate}&ToDate=${toDate}`,
        err,
      )
      return handleError(err, "/Profiles/TotalResults/Analytics", {profileId, fromDate, toDate})
    }
  }

  static async getAnalyticsOverTime(
    profileId: number,
  ): Promise<Response<ITotalResultsOverTimeViewModel>> {
    try {
      const { data } = await mobileAPI.get<ITotalResultsOverTimeViewModel>(
        `/Profiles/${profileId}/TotalResultsOverTime`,
      )
      console.log("RESPONSE : ", `/Profiles/${profileId}/TotalResultsOverTime/LocalLeads` + data)
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${profileId}/TotalResultsOverTime/LocalLeads`, err)
      return handleError(err, "/Profiles/profileId/TotalResultsOverTime", { profileId })
    }
  }

  static async filterAnalyticsOverTime(
    profileId: number,
    fromDate: string,
    toDate: string,
    analyticsDataType: string
  ): Promise<Response<ITotalResultsOverTimeViewModel>> {
    try {
      const { data } = await mobileAPI.get<ITotalResultsOverTimeViewModel>(
        `/Profiles/${profileId}/TotalResultsOverTime/${analyticsDataType}?FromDate=${fromDate}&ToDate=${toDate}`,
      )
      return { data, error: null }
    } catch (err) {
      console.log(
        `ERROR: /Profiles/${profileId}/TotalResultsOverTime/${analyticsDataType}?FromDate=${fromDate}&ToDate=${toDate}`,
        err,
      )
      return handleError(err, "/Profiles/profileId/TotalResultsOverTime", { profileId, fromDate, toDate, analyticsDataType})
    }
  }

  static async getUnreadLeads(profileId:number | undefined ): Promise<Response<UnreadLeads>> {
    try {
      const { data } = await mobileAPI.get<UnreadLeads>("/LeadCount", {profileId:profileId})
      return { data, error: null }
    } catch (err) {
      console.log("ERROR : /LeadCount", err)
      return handleError(err, "/LeadCount", { profileId })
    }
  }

  static async getTerms(): Promise<Response<GetTermsAndConditionsContentResponseViewModel>> {
    try {
      const { data } = await mobileAPI.get<GetTermsAndConditionsContentResponseViewModel>("/Terms")
      return { data, error: null }
    } catch (err) {
      console.log("ERROR : /Terms", err)
      return handleError(err, "/Terms", {})
    }
  }

  static async confirmTerms(
    signature: string,
  ): Promise<Response<IAcceptTermsAndConditionsRequestViewModel>> {
    try {
      const { data } = await mobileAPI.post<IAcceptTermsAndConditionsRequestViewModel>("/Terms", {
        signature,
      })
      return { data, error: null }
    } catch (err) {
      console.log("ERROR : /Terms", err)
      return handleError(err, "/Terms", { signature })
    }
  }

  static async getSipSettings(): Promise<Response<UserCallTrackingSipSettingsList>> {
    try {
      const { data } = await mobileAPI.get<UserCallTrackingSipSettingsList>(`/PulseSipSettings`)
      console.log("SUCCESS : /PulseSipSettings", data)
      return { data:data, error: null }
    } catch (err) {
      console.log("ERROR : /PulseSipSettings", err)
      return handleError(err, "/PulseSipSettings", {})
    }
  }

  static async requestSipSettings(profileId: number): Promise<Response<UserCallTrackingSipSettings>> {
    try {
      const { data } = await mobileAPI.post<UserCallTrackingSipSettings>("/PulseSipSettings", {profileId: profileId})
      console.log("Requesting SIP settings : ", data)
      return { data, error: null }
    } catch (err) {
      console.log("ERROR : /PulseSipSettings", err)
      return handleError(err, "/PulseSipSettings", {})
    }
  }

  static async getWebsiteUrls(profileId: number): Promise<Response<DudaUrls>> {
    try {
      const { data } = await mobileAPI.get<DudaUrls>(`/Profiles/${profileId}/DudaUrls`, {
        profileId,
      })
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${profileId}/DudaUrls`, err)
      return handleError(err, "/Profiles/profileId/DudaUrls", { profileId })
    }
  }

  static async RefreshToken(grantType: string, refreshToken: string | null, clientId: string) {
    const payload = {
      grantType: grantType,
      refreshToken: refreshToken,
      clientId: clientId,
    }
    try {
      const { data } = await mobileAPI.post<RefreshToken>("/token", payload)
      return { data, error: null }
    } catch (err) {
      console.log("ERROR : /token", err)
      return handleError(err, "/token", { ...payload })
    }
  }

  static async getStatistics(profileId: number | undefined, date: DateFilter) {
    try {
      const { data } = await mobileAPI.get<ReviewData>(
        `/ReviewStatistics?ProfileId=${profileId}&FromDate=${date.fromDate}&ToDate=${date.toDate}`,
      )
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: /ReviewStatistics?ProfileId${profileId}`, err)
      return handleError(err, "/ReviewStatistics", { profileId, ...date})
    }
  }

  static async getReviews(filter:any, date: DateFilter,start:number) {
    const payload = {
        ...filter,
        ...date,
        FromNumber:start
    }
    try {
            const query = `/Reviews`
            const { data } = await mobileAPI.get<Reviews>(query,payload)
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: /Reviews`, err)
      return handleError(err, "/Reviews", { ...payload })
    }
  }
  static async getReviewsByFilter(pendingResponse:boolean | null, profileId: number | undefined, date: DateFilter) {
    try {
        let query ;
        if(pendingResponse === null){
            query = `Reviews?ProfileId=${profileId}&FromDate=${date.fromDate}&ToDate=${date.toDate}`
        }else{
            query = `Reviews?PendingResponse=${pendingResponse}&ProfileId=${profileId}&FromDate=${date.fromDate}&ToDate=${date.toDate}`
        }
      const { data } = await mobileAPI.get<Reviews>(
        query,
      )
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: /Reviews?PendingResponse=${pendingResponse}&ProfileId=${profileId}&FromDate=${date.fromDate}&ToDate=${date.toDate}`, err)
      return handleError(err, "/Reviews", { profileId, ...date})
    }
  }
  static async getReviewRequests(profileId: number | undefined) {
    try {
      const { data } = await mobileAPI.get<ReviewReqeusts>(`/ReviewRequests?ProfileId=${profileId}&FromNumber=1&PageSize=${100000}`)
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: /ReviewRequests?ProfileId=${profileId}`, err)
      return handleError(err, "/ReviewRequests", {profileId})
    }
  }
  static async sendReviewRequest(
    profileId: number | undefined,
    name: string,
    email: string,
    phone: string,
  ) {
    const payload = {
      profileId,
      name,
      email,
      phone,
    }
    try {
      await mobileAPI.post("/ReviewRequests", payload)
      return { data: true, error: null }
    } catch (err) {
      console.log("ERROR : /ReviewRequest", err)
      return handleError(err, "/ReviewRequests", { ...payload })
    }
  }

  static async sendReviewResponse(reviewId: number | undefined, response: string | undefined) {
    const payload = {
      responseText: response,
    }
    try {
      console.log(reviewId)
      await mobileAPI.post(`/Reviews/${reviewId}/Response`, payload)
      return { data: true, error: null }
    } catch (err) {
      console.log(`/Reviews/${reviewId}/Response`, err)
      return handleError(err, "/Reviews/reviewId/Response", { ...payload, reviewId })
    }
  }
  static async getGoogleInsightsData(profileId: number | undefined, date: DateFilter) {
    try {
      const { data } = await mobileAPI.get<GoogleAdsInsights>(
        `/Google/Profiles/${profileId}/Insights?FromDate=${date.fromDate}&ToDate=${date.toDate}`,
      )
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: /Google/Profiles/${profileId}/Insights?FromDate=${date.fromDate}&ToDate=${date.toDate}`, err)
      return handleError(err, `/Google/Profiles/${profileId}/Insights`, { profileId, ...date })
    }
  }
  static async getFacebookAdsPreview(profileId: number | undefined) {
    try {
      const { data } = await mobileAPI.get<FacebookAdsPreview>(
        `/FacebookAds/Profiles/${profileId}/Preview`,
      )
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: /FacebookAds/Profiles/${profileId}/Preview`, err)
      return handleError(err, "/FacebookAds/Profiles/profileId/Preview", { profileId })
    }
  }

  static async getFacebookBaseInsights(profileId: number, date?: DateFilter): Promise<Response<FacebookBaseInsightsViewModel>> {
    const payload = {
      from: date?.fromDate,
      to: date?.toDate
    }
    try {
        const fbadsService = new FacebookAdsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
        let response: FacebookBaseInsightsViewModel | null = null
        if(date?.fromDate === '1970-01-01') {
          response = await fbadsService.getBaseInsights(profileId, undefined, undefined, "maximum");
        } else {
            response = await fbadsService.getBaseInsights(profileId, date?.fromDate, date?.toDate,);
        }
        return { data:response, error: null }
    } catch (err) {
        console.log(`ERROR: /FacebookAds/Profiles/${profileId}/BaseInsights`, err)
        return handleError(err, "/FacebookAds/Profiles/profileId/BaseInsight", { ...payload, profileId })
    }
  }


  static async getFacebookGenderInsights(profileId: number, date: DateFilter): Promise<Response<FacebookGendersInsightsViewModel>> {
    const payload = {
        from: date?.fromDate,
        to: date?.toDate
      }
      try {
          const fbadsService = new FacebookAdsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          let response: FacebookGendersInsightsViewModel | null = null
          if(date?.fromDate === '1970-01-01') {
            response = await fbadsService.getGendersInsights(profileId, undefined, undefined, "maximum");
          } else {
              response = await fbadsService.getGendersInsights(profileId, date?.fromDate, date?.toDate,);
          }
          return { data:response, error: null }
    } catch (err) {
          console.log(`ERROR: /FacebookAds/Profiles/${profileId}/GendersInsights`, err)
          return handleError(err, "/FacebookAds/Profiles/profileId/GendersInsights", { ...payload, profileId })
    }
  }

  static async getActionInsights(profileId: number, date: DateFilter): Promise<Response<FacebookActionsInsightViewModel>> {
    const payload = {
        from: date?.fromDate,
        to: date?.toDate
      }
      try {
          const fbadsService = new FacebookAdsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          let response: FacebookActionsInsightViewModel | null = null
          if(date?.fromDate === '1970-01-01') {
            response = await fbadsService.getActionsInsights(profileId, undefined, undefined, "maximum");
          } else {
              response = await fbadsService.getGendersInsights(profileId, date?.fromDate, date?.toDate,);
          }
          return { data:response, error: null }
    } catch (err) {
          console.log(`ERROR: /FacebookAds/Profiles/${profileId}/ActionsInsights`, err)
          return handleError(err, "/FacebookAds/Profiles/profileId/ActionsInsighs", { ...payload, profileId })
    }
  }


  static async getFacebookAgeInsights(profileId: number, date: DateFilter): Promise<Response<FacebookAgesInsightsViewModel>> {
    const payload = {
        from: date?.fromDate,
        to: date?.toDate
      }
      try {
          const fbadsService = new FacebookAdsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          let response: FacebookAgesInsightsViewModel | null = null
          if(date?.fromDate === '1970-01-01') {
            response = await fbadsService.getAgesInsights(profileId, undefined, undefined, "maximum");
          } else {
              response = await fbadsService.getAgesInsights(profileId, date?.fromDate, date?.toDate,);
          }
          return { data:response, error: null }
    } catch (err) {
          console.log(`ERROR: /FacebookAds/Profiles/${profileId}/AgesInsights`, err)
          return handleError(err, "/FacebookAds/Profiles/profileId/AgesInsights", { ...payload, profileId })
    }
  }

  static async getFacebookRegionInsights(profileId: number, date: DateFilter): Promise<Response<FacebookRegionsInsightsViewModel>> {
    const payload = {
        from: date?.fromDate,
        to: date?.toDate
      }
      try {
          const fbadsService = new FacebookAdsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          let response: FacebookRegionsInsightsViewModel | null = null
          if(date?.fromDate === '1970-01-01') {
            response = await fbadsService.getRegionsInsights(profileId, undefined, undefined, "maximum");
          } else {
              response = await fbadsService.getRegionsInsights(profileId, date?.fromDate, date?.toDate,);
          }
          return { data:response, error: null }
    } catch (err) {
          console.log(`ERROR: /FacebookAds/Profiles/${profileId}/RegionsEndpoint`, err)
          return handleError(err, "/FacebookAds/Profiles/profileId/RegionsEndpoint", { ...payload, profileId })
    }
  }

  static async getListing(profileId:number | undefined): Promise<Response<Listings>> {
    try {
        const { data } = await mobileAPI.get<Listings>(
          `/Profiles/${profileId}/Placements?IsClientFacing=true&HasPermalinkUrl=true`
        )
        return { data, error: null }
      } catch (err) {
        console.log(`ERROR: /Profiles/${profileId}/Placements?IsClientFacing=true&HasPermalinkUrl=true`, err)
        return handleError(err, `/Profiles/${profileId}/Placements?IsClientFacing=true&HasPermalinkUrl=true`, { profileId })
      }
  }
  static async getWebsiteLeads(profileId:number | undefined,recordStart:number,leadFilter:any, dateFilter:DateFilter): Promise<Response<WebsiteLeads>> {
    const payload={
        ...leadFilter,
        ProfileId:profileId,
        RecordStart:recordStart,
        ...dateFilter
    }
    try {
        const { data } = await mobileAPI.get<WebsiteLeads>(
          `Profile/${profileId}/WebsiteLeads`,payload
        )
        return { data, error: null }
      } catch (err) {
        console.log(`Error: Profile/${profileId}/WebsiteLeads=${profileId}`, err)
        return handleError(err, `Profile/${profileId}/WebsiteLeads`, payload)
      }
  }
  static async updateWebsiteLead(leadId: number | undefined,response:boolean | undefined, profileId: number | undefined) {
    const payload = {
      isResponded:response
    }
    try {
      const { data } = await mobileAPI.put(
        `Profile/${profileId}/WebsiteLeads/${leadId}`,
        payload
      )
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: Profile/${profileId}/WebsiteLeads/${leadId}`,err)
      return handleError(err, `Profile/${profileId}/WebsiteLeads/${leadId}`, { ...payload,leadId })
    }
  }

  static async getLanguageVariables(language:string) {
    try {
      const { data } = await axios.get(`${LsConfig.MOBILE_API_URL}/LanguageVariables/${language}`)
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: /LanguageVariables/${language}`,err)
      return handleError(err, "/LanguageVariables", {})
    }
  }

  static async ContactUs(contactData:FormData) {
    const accessToken = await StorageHelper.get("accessToken")
    const headers = {
        'Content-Type': 'multipart/form-data',
        'Authorization': `Bearer ${accessToken}` 
      };
    console.log("Contact object is: ",contactData)
    try {
        const response = await axios.post(`${LsConfig.MOBILE_API_URL}/ContactUs`, contactData, {
          headers: headers
        });
        return {data:true, error:null}
      } catch (error) {
        console.error(`Error:/ContactUs`, error);
        return handleError(error, "/ContactUs")
      }
    }
    static async getToken(codeVerifier:string | null, code:string) {
        const payload = {
            code:code,
            codeVerifier:codeVerifier,
            clientId:LsConfig.CLIENT_ID,
            grantType: "authorization_code",
            redirectUri: "localsplash://oauth2callback",
        }
        const headers = {
            'Accept': 'text/plain'
          };
        try {
            const response = await axios.post(`${LsConfig.MOBILE_API_URL}/Token`, payload, {
              headers: headers
            });
            return {data:response}
          } catch (error) {
            console.error(`Error:/Token`, error);
            return handleError(error, "/Token", { ...payload })
          }
    }

    static async sendFeedback(feedback:string, rating:number | null) {
        const payload = {
            feedback:feedback,
            rating:rating
        }
        try {
          const { data } = await mobileAPI.post<any>(
            `/Feedbacks`,payload)
          return { data, error: null }
        } catch (err) {
          console.log(`ERROR: /Feedback`,err)
          return handleError(err, "/Feedback", { ...payload })
        }
      }

      static async sendFirebaseToken(payload:CreateOrUpdateAppTokenRequestViewModel []) {
        try {
          const appTokenService = new AppTokensLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          const request = new CreateOrUpdateAppTokensRequestViewModel({
            items: payload
          });
          const response = await appTokenService.createOrUpdate(request);
          return { data:true, error: null }
        } catch (err) {
          console.log(`ERROR: /AppTokens`,err)
          return handleError(err, "/AppTokens", payload)
        }
      }

      static async getGoogleAdsData(date:DateFilter) {
        try {
          const { data } = await mobileAPI.get<any>(
            `/GoogleAds/GeoPerformanceReport`,date)
          return { data, error: null }
        } catch (err) {
          console.log(`ERROR: /GoogleAds/GeoPerformanceReport`,err)
          return handleError(err, "/GoogleAds/GeoPerformanceReport", date)
        }
      }

      static async checkLastSmsFailed() {
        try {
          const { data } = await mobileAPI.get<any>(
            `/Customers/me`)
          return { data, error: null }
        } catch (err) {
          console.log(`ERROR: /Customers/me`,err)
          return handleError(err, "/Customers/me", {})
        }
      }

      static async getGoogleProfileStatus(profileId: number | undefined) {
        try {
          const { data } = await mobileAPI.get<any>(`/Profiles/${profileId}/GooglePin`)
          if(!data) 
            return { data: {isGooglePinVerified: true} , error: null}
          return { data, error: null }
        } catch (err) {
          console.log(`/Profiles/${profileId}/GooglePin`,err)
          return handleError(err, "/Profiles/profileId/GooglePin", { profileId })
        }
      }

      static async sendMessage(profileId:number | undefined, payload:FormData) {
        try {
          const { data } = await mobileAPI.post<any>(
            `/Profiles/${profileId}/MobileMessages`,payload)
          return { data, error: null }
        } catch (err) {
          console.log(`ERROR: /MobileMessages`,err)
          return handleError(err, "/MobileMessages", { profileId,payload })
        }
      }

      static async getRecentMessages(profileId: number | undefined ,count: number | undefined, rowNumber: number | undefined) {
        try {
          const { data } = await mobileAPI.get<RecentMessagesList>(`/MobileMessageLeads`, {Length: count, FromRowNumber: rowNumber, ProfileId: profileId})
          return { data, error: null }
        } catch (err) {
          console.log(`/MobileMessageContacts`,err)
          return handleError(err, "/MobileMessageContact", {Length: count, FromRowNumber: rowNumber})
        }
      }

      static async getMessageDetails(profileId: number | undefined, leadId: number | undefined) {
        try {
          const { data } = await mobileAPI.get<RecentMessagesList>(`/MobileMessageLeads`, { ProfileId: profileId, LeadId: leadId })
          return { data, error: null }
        } catch (err) {
          console.log(`/MobileMessageContacts`,err)
          return handleError(err, "/MobileMessageContact", {ProfileId: profileId, LeadId: leadId})
        }
      }

      static async getChatByNumber(profileId: number | undefined, leadId: number | undefined, count: number | undefined, rowNumber: number | undefined) {
        try {
          const { data } = await mobileAPI.get<any>(`/MobileMessages`,{ProfileId:profileId, LeadId:leadId, Length:count, FromRowNumber:rowNumber})
          return { data, error: null }
        } catch (err) {
          console.log(`/MobileMessages`,err)
          return handleError(err, "/MobileMessages", {ProfileId:profileId, LeadPhone:leadId, Length:count, FromRowNumber:rowNumber})
        }
      }

      static async deleteAppToken(deviceId:string) {
        console.log(LsConfig.MOBILE_API_URL)
        const tokenService = new AppTokensLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient)
        const payload = new DeleteAppTokenRequestViewModel({
            deviceId:deviceId
        })
        try {
          const data = await tokenService.delete(payload)
          return { data, error: null }
        } catch (err) {
          console.log(`/AppTokens/${deviceId}`,err)
          return handleError(err, `/AppTokens/${deviceId}`, { deviceId })
        }
      }

      static async getGoogleAdsClicks(payload?: DateFilter) {
        try {
          const { data } = await mobileAPI.get<{clicks: number}>(`/GoogleAds/CampaignReport`, payload)
          return { data, error: null }
        } catch (err) {
          console.log(`/GoogleAds/CampaignReport`,err)
          return handleError(err, `/GoogleAds/CampaignReport`, payload)
        }
      }

      static async getMonthlyKeywords(profileId: number | undefined, date?: DateFilter) {
        const payload = {
            FromDate: date?.fromDate,
            ToDate: date?.toDate
        }
        try {
          const { data } = await mobileAPI.get<MonthlyKeywords>(`/Google/Profiles/${profileId}/KeywordsImpressions`, payload)
          return { data, error: null }
        } catch (err) {
          console.log(`ERROR: /Google/Profiles/${profileId}/KeywordsImpressions`,err)
          return handleError(err, `/Google/Profiles/${profileId}/KeywordsImpressions`, payload)
        }
      }

      static async googleAdsClicksAndImpressions(profileId: number, dateFilter?:DateFilter) {
        try {
          const googleAdsService = new GoogleAdsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          let response;
          if(dateFilter) {
            response = await googleAdsService.getClicksImpressionsReport(profileId, new Date(dateFilter.fromDate), new Date(dateFilter.toDate));
          } else {
            response = await googleAdsService.getClicksImpressionsReport(profileId);
          }
          return { data:response, error: null }
        } catch (err) {
          console.log(`ERROR: /GoogleAds/ClicksImpressionsReport`,err)
          return handleError(err, "/GoogleAds/ClicksImpressionsReport", {profileId, ...dateFilter})
        }
      }
      static async getGoogleAdsKeywordsReport(profileId: number, dateFilter:DateFilter) {
        try {
          const googleAdsService = new GoogleAdsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          const response = await googleAdsService.getKeywordsReport(profileId, new Date(dateFilter.fromDate), new Date(dateFilter.toDate));
          return { data:response, error: null }
        } catch (err) {
          console.log(`ERROR: /GoogleAds/KeywordsReport`,err)
          return handleError(err, "/GoogleAds/KeywordsReport", {profileId, ...dateFilter})
        }
      }
      static async getGoogleAdsGeoPeformance(profileId: number, dateFilter:DateFilter) {
        try {
          const googleAdsService = new GoogleAdsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          const response = await googleAdsService.getGeoPerformanceReport(profileId, new Date(dateFilter.fromDate), new Date(dateFilter.toDate));
          return { data:response, error: null }
        } catch (err) {
          console.log(`ERROR: /GoogleAds/GeoPerformanceReport`,err)
          return handleError(err, "/GoogleAds/GeoPerformanceReport", {profileId, ...dateFilter})
        }
      }
      static async getGoogleAdsDeviceBreakDownReport(profileId: number, dateFilter:DateFilter) {
        try {
          const googleAdsService = new GoogleAdsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          const response = await googleAdsService.getDeviceBreakdownReport(profileId, new Date(dateFilter.fromDate), new Date(dateFilter.toDate));
          return { data:response, error: null }
        } catch (err) {
          console.log(`ERROR: /GoogleAds/DeviceBreakdownReport`,err)
          return handleError(err, "/GoogleAds/DeviceBreakdownReport", {profileId, ...dateFilter})
        }
      }
      static async getGoogleAdsImpressionsShare(profileId: number, dateFilter:DateFilter) {
        try {
          const googleAdsService = new GoogleAdsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          const response = await googleAdsService.getImpressionShareReport(profileId, new Date(dateFilter.fromDate), new Date(dateFilter.toDate));
          return { data:response, error: null }
        } catch (err) {
          console.log(`ERROR: /GoogleAds/ImpressionShareReport`,err)
          return handleError(err, "/GoogleAds/ImpressionShareReport", {profileId, ...dateFilter})
        }
      }
      static async getGoogleAdsImpressionClicksReport(profileId: number, dateFilter:DateFilter) {
        try {
          const googleAdsService = new GoogleAdsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          const response = await googleAdsService.getClicksImpressionsOverTimeReport(profileId, new Date(dateFilter.fromDate), new Date(dateFilter.toDate));
          return { data:response, error: null }
        } catch (err) {
          console.log(`ERROR: /GoogleAds/ClicksImpressionsAveragePositionsPageRanksReport`,err)
          return handleError(err, "/GoogleAds/ClicksImpressionsAveragePositionsPageRanksReport", {profileId, ...dateFilter})
        }
      }
      static async getCallRoutingActions() {
        try {
          const callRoutingService = new CallRoutingSettingsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          const response = await callRoutingService.getCallRoutingActions();
          return { data:response, error: null }
        } catch (err) {
          console.log(`ERROR: /AvailableCallRoutingActions`,err)
          return handleError(err, "/AvailableCallRoutingActions", {})
        }
        
      }
      static async getUserCallRoutingDetails(profileId:number) {
        try {
          const callRoutingService = new CallRoutingSettingsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          const response = await callRoutingService.getCallRoutingSettings(profileId);
          return { data:response, error: null }
        } catch (err) {
          console.log(`ERROR: /CallRoutingSettings`,err)
          return handleError(err, "/CallRoutingSettings", {profileId})
        }
        
      }
      static async updateUserCallRoutingDetails(profileId: number, payload: UpdateCallRoutingSettingsRequestViewModel) {
        try {
          const callRoutingService = new CallRoutingSettingsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          const response = await callRoutingService.updateCallRoutingSettings(profileId,payload);
          return { data:response, error: null }
        } catch (err) {
          console.log(`ERROR: /CallRoutingSettings`,err)
          return handleError(err, "/CallRoutingSettings", {profileId})
        }

      }

      static async getReviewsTotalCount(profileId: number, date: DateFilter) {
        try {
          const reviewsService = new ReviewsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          const response = await reviewsService.getReviewTotalCounts(profileId, date?.fromDate ? new Date(date.fromDate) : undefined, date?.toDate ? new Date(date.toDate) : undefined );
          return { data:response, error: null }
        } catch (err) {
          console.log(`ERROR: /Reviews/TotalCounts`,err)
          return handleError(err, "/Reviews/TotalCounts", {profileId})
        }
      }
      
      static async getReviewsStarCount(profileId: number, date: DateFilter) {
        try {
          const reviewsService = new ReviewsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          const response = await reviewsService.getReviewStarCounts(profileId, date?.fromDate ? new Date(date.fromDate) : undefined, date?.toDate ? new Date(date.toDate) : undefined );
          return { data:response, error: null }
        } catch (err) {
          console.log(`ERROR: /Reviews/StarCounts`,err)
          return handleError(err, "/Reviews/StarCounts", {profileId})
        } 
      }

      static async getReviewsDateCount(profileId: number, date: DateFilter) {
        try {
          const reviewsService = new ReviewsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          const response = await reviewsService.getReviewDateCounts(profileId, date?.fromDate ? new Date(date.fromDate) : undefined, date?.toDate ? new Date(date.toDate) : undefined );
          return { data:response, error: null }
        } catch (err) {
          console.log(`ERROR: /Reviews/DateCount`,err)
          return handleError(err, "/Reviews/DateCount", {profileId})
        }
      }

      static async getReviewsDestinationCount(profileId: number, date: DateFilter) {
        try {
          const reviewsService = new ReviewsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
          const response = await reviewsService.getReviewDestinationCounts(profileId, date?.fromDate ? new Date(date.fromDate) : undefined, date?.toDate ? new Date(date.toDate) : undefined );
          return { data:response, error: null }
        } catch (err) {
          console.log(`ERROR: /Reviews/DestinationCounts`,err)
          return handleError(err, "/Reviews/DestinationCounts", {profileId})
        }
      }

}
