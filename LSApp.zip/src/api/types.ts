import { AxiosError } from "axios"

export interface Response<T, P = string> {
  data: T | null
  error: P | null | undefined
}

interface Error {
  type: string | null
  title: string | null
  detail: string | null
  instance: string | null
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [key: string]: any
}

export class ServerError extends AxiosError<Error> {}
