import { AxiosError } from "axios"

import { LoginSuccess, SendMessageSuccessResponse } from "@models"

import { authAPI } from "./base"
import { Response } from "./types"
import { handleError } from "./common"

export class AuthAPI {
  static async sendMessage(to: string): Promise<Response<SendMessageSuccessResponse>> {
    console.log('send code api call')
    try {
      const { data } = await authAPI.post<SendMessageSuccessResponse>("/MobileLogin/message", { to })
      console.log("RESPONSE : /MobileLogin/MESSAGE", to)
     
      console.log()
      return { data, error: null }
    } catch (err) {
      console.log("ERROR : /MobileLogin/MESSAGE",err)
     return handleError(err, "/MobileLogin/MESSAGE", { to })
    }
  }

  static async Login(messageCode: string, clientId: string, state: string,firebaseToken:string) {

    if(firebaseToken == null || firebaseToken == "")
      firebaseToken = "device"
    const payload = { messageCode, clientId, state, firebaseToken }
    try {
      console.log('Firebasetoken', firebaseToken)
      const { data } = await authAPI.post<LoginSuccess>("/MobileLogin/token", payload)
      return { data, error: null }
    } catch (err) {
     console.log("ERROR : /MobileLogin/token",err)
     return handleError(err, "/MobileLogin/token", payload)
    }
  }
}



