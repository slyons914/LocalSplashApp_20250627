import axios, { AxiosResponse } from "axios"
import jwt_decode from "jwt-decode"
import { StorageHelper } from "@utils/helpers"
import { DecodedToken } from "@models/index"
import { LsConfig } from "@utils/constants/common"
import { handleError } from "./common"
import { AUTH_API_URL } from "@env"
import { navigate } from "@navigation"
import { Stacks } from "@utils/constants"

const authClient = axios.create({
  baseURL: AUTH_API_URL,
})

export const mobileClient = axios.create({
})

let isRefreshing = false
let failedQueue: Array<{ resolve: Function; reject: Function }> = []

const processQueue = (error: any, token: string | null = null) => {
  failedQueue.forEach((prom) => {
    if (error) {
      prom.reject(error)
    } else {
      prom.resolve(token)
    }
  })
  failedQueue = []
}

mobileClient.interceptors.request.use(async (config) => {
  const refresh_token = await StorageHelper.get<string>("refreshToken")
  let tokenExpiry = await StorageHelper.get<number>("tokenExpiry")

  config.baseURL = LsConfig.MOBILE_API_URL
  
  tokenExpiry = tokenExpiry === null ? 0 : tokenExpiry
  const now = new Date(tokenExpiry)
  const formattedHours = now.getHours().toString().padStart(2, "0")
  const formattedMinutes = now.getMinutes().toString().padStart(2, "0")
  const formattedSeconds = now.getSeconds().toString().padStart(2, "0")

  // console.log(`Token will expire on: ${formattedHours}:${formattedMinutes}:${formattedSeconds}`)
  if (Date.now() > tokenExpiry) {
    if (!isRefreshing) {
      isRefreshing = true
      const url = `${LsConfig.MOBILE_API_URL}/Token`
      const payload = {
        grantType: "refresh_token",
        refreshToken: refresh_token,
        clientId: LsConfig.CLIENT_ID,
      }
      try {
        const { data } = await axios.post(url, payload, {
          headers: {
            Accept: "text/plain",
            "Content-Type": "application/json",
          },
        })
        if (data.error) {
          handleError(data.error, `Token-refreshToken ${data.error}`, payload)
        }
        console.log("Token fetched successfully:", data)
        await StorageHelper.set<string>("idToken", data.idToken)
        await StorageHelper.set<string>("accessToken", data.accessToken)
        await StorageHelper.set<string>("refreshToken", data.refreshToken)
        const decoded: DecodedToken = jwt_decode(data.accessToken)
        await StorageHelper.set<number>("tokenExpiry", decoded.exp * 1000)
        config.headers.Authorization = `Bearer ${data.accessToken}`
        processQueue(null, data.accessToken)
        isRefreshing = false
        return config
      } catch (error: any) {
        handleError(error, `Token-refreshToken ${error}`)
        processQueue(error, null)
        var err = error.message
        let statusCode: number | null = null;
        const match = err?.match(/status code (\d+)/);
        if (match) {
            statusCode = parseInt(match[1], 10);
        }
        if(statusCode === 400) {
            await StorageHelper.set<string>("idToken", '')
            await StorageHelper.set<string>("accessToken", '')
            await StorageHelper.set<string>("refreshToken", '')
            navigate(Stacks.Login,{})
        }
        isRefreshing = false
      }
    }
    return new Promise((resolve, reject) => {
      failedQueue.push({ resolve, reject })
    })
      .then((accessToken) => {
        config.headers.Authorization = `Bearer ${accessToken}`
        return config
      })
      .catch((error) => {
        return Promise.reject(error)
      })
  }

  const accessToken = await StorageHelper.get<string>("accessToken")
  if (
    (config.url?.includes("/MobileMessages") ||
      config.url?.includes("/Logo") ||
      config.url?.includes("/Images") ||
      config.url?.includes("/Videos") ||
      config.url?.includes("/BackgroundImage") ||
      config.url?.includes("/Documents")) &&
      config.method === "post"
  ) {
    config.headers["Content-Type"] = `multipart/form-data`
  }
  if (accessToken) {
    config.headers.Authorization = `Bearer ${accessToken}`
  }

  return config
}, Promise.reject)

export const authAPI = {
  get: <T>(url: string, params = {}) => authClient.get<T, AxiosResponse<T>>(url, { params }),
  post: <T>(url: string, data = {}, params = {}) =>
    authClient.post<T, AxiosResponse<T>>(url, data, { params }),
  put: <T>(url: string, data = {}, params = {}) =>
    authClient.put<T, AxiosResponse<T>>(url, data, { params }),
  delete: <T>(url: string, params = {}) => authClient.delete<T, AxiosResponse<T>>(url, { params }),
}

export const mobileAPI = {
  get: <T>(url: string, params = {}) => mobileClient.get<T, AxiosResponse<T>>(url, { params }),
  post: <T>(url: string, data = {}, params = {}) =>
    mobileClient.post<T, AxiosResponse<T>>(url, data, { params }),
  patch: <T>(url: string, data = {}, params = {}) =>
    mobileClient.patch<T, AxiosResponse<T>>(url, data, { params }),
  put: <T>(url: string, data = {}, params = {}) =>
    mobileClient.put<T, AxiosResponse<T>>(url, data, { params }),
  delete: <T>(url: string, params = {}) =>
    mobileClient.delete<T, AxiosResponse<T>>(url, { params }),
}
