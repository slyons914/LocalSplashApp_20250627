import { AxiosError } from "axios"

import { getUserData } from "@models/user"

import { mobileAPI, mobileClient } from "./base"
import { Response } from "./types"
import { handleError } from "./common"
import { MembersLocalsplashService, UpdateMemberRequestViewModel } from "@localsplash/mobile-api-client"
import { LsConfig } from "@utils/constants/common"

interface ChangeUserError {
  ContactPhone: Array<string>
  EmailAddress: Array<string>
  FirstName: Array<string>
  LastName: Array<string>
}

export class UserAPI {
  static async getUserData(): Promise<Response<getUserData>> {
    try {
      const { data } = await mobileAPI.get<getUserData>("/Members/me")
      return { data, error: null }
    } catch (err) {
        console.log("ERROR : /Members/me", err)
        return handleError(err, "/Member/me", {})
    }
  }

  static async changeUserData(payload:UpdateMemberRequestViewModel): Promise<Response<boolean, ChangeUserError>> {
    try {
      const membersService = new MembersLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);  
      membersService.updateMember(payload)
      return { data: true, error: null }
    } catch (err) {
        console.log("ERROR : /Members/me", err)
        return handleError(err, "/Member/me", payload)
    }
  }
}
