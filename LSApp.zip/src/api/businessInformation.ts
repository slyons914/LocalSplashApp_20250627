import { AxiosError } from "axios"

import {
  AvailableCategories,
  AvailableGoogleCategories,
  AvailablePaymentMenhod,
  ChangeBusinessInfoError,
  ContactsModel,
  GetProfileLocation,
  PatchProfileLocation,
  PaymentMenhods,
  ProfileGoogleCategories,
  ProfilePaymentMenhod,
  ProfileTextContents,
  ProfileWorkingHours,
} from "@models/settings"

import { mobileAPI, mobileClient } from "./base"
import { Response } from "./types"
import { handleError } from "./common"
import { ContactsLocalsplashService, CreateOrUpdateContactRequestViewModel, CreateOrUpdateProfileServiceAreaRequestViewModel, CreateOrUpdateProfileTextContentRequestViewModel, CreateOrUpdateProfileWorkingHoursRequestViewModel, DeleteMediaRequestViewModel, DeleteMediasRequestViewModel, DeleteProfileServiceAreaRequestViewModel, ICreateOrUpdateContactRequestViewModel, ICreateOrUpdateProfileTextContentRequestViewModel, ICreateOrUpdateProfileWorkingHoursRequestViewModel, IProfileServiceAreaViewModel, MediaLocalsplashService, ProfileServiceAreasLocalsplashService, ProfileTextContentsLocalsplashService, ProfileWorkingHoursLocalsplashService, ReOrderMediaRequestViewModel } from "@localsplash/mobile-api-client"
import { LsConfig } from "@utils/constants/common"

export class BusinessInfoAPI {
  static async getProfileLocation(id: number): Promise<Response<GetProfileLocation>> {
    try {
      const { data } = await mobileAPI.get<GetProfileLocation>(`Profiles/${id}/Location`)
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: Profiles/${id}/Location`)
      return handleError(err, "Profiles/id/Location", { id })
    }
  }

  static async changeProfileLocation(
    id: number,
    locationInfo: PatchProfileLocation,
  ): Promise<Response<boolean, ChangeBusinessInfoError>> {
    try {
      await mobileAPI.patch(`Profiles/${id}/Location`, locationInfo)
      return { data: true, error: null }
    } catch (err) {
        console.log(`ERROR: Profiles/${id}/Location`)
        return handleError(err, "Profiles/id/Location", { id, ...locationInfo })
    }
  }

  static async getAvailableCategories(): Promise<Response<AvailableCategories>> {
    try {
      const { data } = await mobileAPI.get<AvailableCategories>("/AvailableCategories")
      return { data, error: null }
    } catch (err) {
        console.log("ERROR: /AvailableCategories")
        return handleError(err, "/AvailableCategories", {})
    }
  }

  static async changeAvailableCategories(
    profileId: number,
    id: number,
    customTitle?: string,
  ): Promise<Response<boolean, ChangeBusinessInfoError>> {
    try {
      await mobileAPI.post(`Profiles/${profileId}/Categories`, { id, customTitle })
      return { data: true, error: null }
    } catch (err) {
        console.log(`ERROR: Profiles/${profileId}/Categories`)
        return handleError(err, "/Profiles/profileId/Categories", { id, customTitle })
    }
  }

  static async getAvailableGoogleCategories(): Promise<Response<AvailableGoogleCategories>> {
    try {
      const { data } = await mobileAPI.get<AvailableGoogleCategories>("/AvailableGoogleCategories")
      return { data, error: null }
    } catch (err) {
        console.log("FAIL: /AvailableGoogleCategories")
        return handleError(err, "/AvailableGoogleCategories", {})
    }
  }

  static async getProfileGoogleCategories(
    profileId: number,
  ): Promise<Response<ProfileGoogleCategories>> {
    try {
      const { data } = await mobileAPI.get<ProfileGoogleCategories>(
        `Profiles/${profileId}/GoogleCategories`,
      )
      return { data, error: null }
    } catch (err) {
        console.log(`ERROR: Profiles/${profileId}/GoogleCategories`)
        return handleError(err, "Profiles/profileId/GoogleCategories", { profileId })
    }
  }

  static async changeProfileGoogleCategories(
    profileId: number,
    payload: ProfileGoogleCategories,
  ): Promise<Response<boolean, ChangeBusinessInfoError>> {
    try {
      await mobileAPI.post(`Profiles/${profileId}/GoogleCategories`, payload)
      return { data: true, error: null }
    } catch (err) {
        console.log(`ERROR: Profiles/${profileId}/GoogleCategories`)
        return handleError(err, "Profiles/profileId/GoogleCategories", { profileId, ...payload })
    }
  }

  static async getWorkingHours(id: number): Promise<Response<ProfileWorkingHours>> {
    try {
      const { data } = await mobileAPI.get<ProfileWorkingHours>(`Profiles/${id}/WorkingHours`)
      return { data, error: null }
    } catch (err) {
        console.log(`ERROR: Profiles/${id}/WorkingHours`)
        return handleError(err, "Profiles/id/WorkingHours", { id })
    }
  }

  static async getAvailablePaymentMethods(): Promise<
    Response<PaymentMenhods<AvailablePaymentMenhod>>
    > {
    try {
      const { data } = await mobileAPI.get<PaymentMenhods<AvailablePaymentMenhod>>(
        "/AvailablePaymentMethods",
      )
      return { data, error: null }
    } catch (err) {
        console.log("ERROR: /AvailablePaymentMethods")
        return handleError(err, "/AvailablePaymentMethods", {})
    }
  }
  static async getProfilePaymentMethods(
    id: number | undefined,
  ): Promise<Response<PaymentMenhods<ProfilePaymentMenhod>>> {
    try {
      const { data } = await mobileAPI.get<PaymentMenhods<ProfilePaymentMenhod>>(
        `/Profiles/${id}/PaymentMethods`,
      )
      return { data, error: null }
    } catch (err) {
        console.log(`ERROR: /Profiles/${id}/PaymentMethods`)
        return handleError(err, "/Profiles/id/PaymentMethods", { id })
    }
  }

  static async getProfileTextContents(id: number): Promise<Response<ProfileTextContents>> {
    try {
      const { data } = await mobileAPI.get<ProfileTextContents>(`/Profiles/${id}/TextContent`)
      return { data, error: null }
    } catch (err) {
        console.log(`ERROR: /Profiles/${id}/TextContent`)
        return handleError(err, "/Profiles/id/TextContent", { id })
    }
  }

  static async getContacts(): Promise<Response<ContactsModel>> {
    try {
      const { data } = await mobileAPI.get<ContactsModel>("/Contacts")
      return { data, error: null }
    } catch (err) {
        console.log("ERROR: /Contacts")
        return handleError(err, "/Contacts", {})
    }
  }

  static async addProfilePaymentMethod( profileId: number | undefined, paymentMethodId: number,){
    try {
      await mobileAPI.post(`Profiles/${profileId}/PaymentMethods/${paymentMethodId}`)
      return { data: true, error: null }
    } catch (err) {
        console.log(`ERROR: Profiles/${profileId}/PaymentMethods/${paymentMethodId}`)
        return handleError(err, `Profiles/${profileId}/PaymentMethods/${paymentMethodId}`, { profileId, paymentMethodId })
    }
  }

  static async deleteProfilePaymentMethod( profileId: number | undefined, paymentMethodId: number,){
    try {
      await mobileAPI.delete(`Profiles/${profileId}/PaymentMethods/${paymentMethodId}`)
      return { data: true, error: null }
    } catch (err) {
        console.log(`ERROR: Profiles/${profileId}/PaymentMethods/${paymentMethodId}`)
        return handleError(err, `Profiles/${profileId}/PaymentMethods/${paymentMethodId}`, { profileId, paymentMethodId })
    }
  }

  static async updateProfileTextContent(profileId:number, type:ICreateOrUpdateProfileTextContentRequestViewModel) {
    try {
      const textContentService = new ProfileTextContentsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const textContent = new CreateOrUpdateProfileTextContentRequestViewModel(type)
      const response = await textContentService.createOrUpdateTextContent(profileId, textContent);
      return { data:true, error: null }
    } catch (err) {
      console.log(`ERROR: /Profile/${profileId}/TextContent`,err)
      return handleError(err, `/Profile/${profileId}/TextContent`, {profileId, type})
    }
  }

  static async AddContact(data:ICreateOrUpdateContactRequestViewModel) {
    try {

      const textContentService = new ContactsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const payload = new CreateOrUpdateContactRequestViewModel(data)
      const response = await textContentService.create(payload);
      return { data:true, error: null }
    } catch (err) {
      console.log(`ERROR: /Contacts/`,err)
      return handleError(err, `/Contacts`, {data})
    }
  }

  static async deleteContact(id: number) {
    try {
      const textContentService = new ContactsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const response = await textContentService.delete(id);
      return { data:true, error: null }
    } catch (err) {
      console.log(`ERROR: /Contacts/`,err)
      return handleError(err, `/Contacts`, {id})
    }
  }

  static async editContact(id: number, data:ICreateOrUpdateContactRequestViewModel) {
    try {
      const textContentService = new ContactsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const payload = new CreateOrUpdateContactRequestViewModel(data)
      const response = await textContentService.update(id, payload);
      return { data:true, error: null }
    } catch (err) {
      console.log(`ERROR: /Contacts/`,err)
      return handleError(err, `/Contacts`, {id, data})
    }
  }

  static async addOrEditWorkingHours(id: number, data:ICreateOrUpdateProfileWorkingHoursRequestViewModel) {
    try {
      const textContentService = new ProfileWorkingHoursLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const payload = new CreateOrUpdateProfileWorkingHoursRequestViewModel(data)
      const response = await textContentService.createOrUpdateWorkingHours(id, payload);
      return { data:true, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/workingHours`,err)
      return handleError(err, `/Profiles/${id}/workingHours`, {id, data})
    }
  }

  static async getBusinessVideos(id: number) {
    try {
      const mediaService = new MediaLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const response = await mediaService.getVideos(id);
      return { data:response, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/Videos`,err)
      return handleError(err, `/Profiles/${id}/Videos`, {id})
    }
  }

  static async getBusinessPhotos(id: number) {
    try {
      const mediaService = new MediaLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const response = await mediaService.getImages(id);
      return { data:response, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/Images`,err)
      return handleError(err, `/Profiles/${id}/Images`, {id})
    }
  }

  static async updateOrAddLogo(id: number, image:FormData) {
    try {
      const { data }  = await mobileAPI.post(`/Profiles/${id}/Logo`, image)
      return { data:data, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/Logo`,err)
      return handleError(err, `/Profiles/${id}/Logo`, {id})
    }
  }

  static async deleteLogo(id: number, media:string) {
    console.log(id, media)
    try {
      const mediaService = new MediaLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const body = new DeleteMediaRequestViewModel({
        mediaUrl:media
      })
      const response = await mediaService.deleteLogo(id, body)
      return { data:response, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/Logo`,err)
      return handleError(err, `/Profiles/${id}/Logo`, {id})
    }
  }

  static async updateOrAddCoverPhoto(id: number, image: FormData) {
    try {
        const { data }  = await mobileAPI.post(`/Profiles/${id}/BackgroundImage`, image)
      return { data:data, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/BackgroundImage`,err)
      return handleError(err, `/Profiles/${id}/BackgroundImage`, {id})
    }
  }

  static async deleteCoverPhoto(id: number, media:string) {
    console.log(id, media)
    try {
      const mediaService = new MediaLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const body = new DeleteMediasRequestViewModel({
        mediaUrls:[media]
      })
      const response = await mediaService.deleteImages(id, body)
      return { data:response, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/BackgroundImage`,err)
      return handleError(err, `/Profiles/${id}/BackgroundImage`, {id})
    }
  }

  static async addBussinessImages(id: number, image: FormData) {
    try {
        const { data }  = await mobileAPI.post(`/Profiles/${id}/Images`, image)
      return { data:data, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/Images`,err)
      return handleError(err, `/Profiles/${id}/Images`, {id})
    }
  }

    static async addBussinessVideos(id: number, image: FormData) {
    try {
        const { data }  = await mobileAPI.post(`/Profiles/${id}/Videos`, image)
      return { data:data, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/Videos`,err)
      return handleError(err, `/Profiles/${id}/Videos`, {id})
    }
  }

  static async deleteBusinessImages(id: number, media: any) {
    if(!media) return;
    try {
      const mediaService = new MediaLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const body = new DeleteMediasRequestViewModel({
        mediaUrls: media
      })
      const response = await mediaService.deleteImages(id, body)
      return { data:response, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/Images`,err)
      return handleError(err, `/Profiles/${id}/Images`, {id})
    }
  }

    static async deleteBusinesVideos(id: number, media: any) {
    if(!media) return;
    try {
      const mediaService = new MediaLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const body = new DeleteMediasRequestViewModel({
        mediaUrls: media
      })
      const response = await mediaService.deleteVideos(id, body)
      return { data:response, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/Videos`,err)
      return handleError(err, `/Profiles/${id}/Videos`, {id})
    }
  }

  static async getServiceAreas(id: number) {
    try {
      const serviceAreaService = new ProfileServiceAreasLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const response = await serviceAreaService.getServiceAreas(id);
      return { data:response, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/ServiceAreas`,err)
      return handleError(err, `/Profiles/${id}/ServiceAreas`, {id})
    }
  }

  static async postServiceAreas(id: number, service: IProfileServiceAreaViewModel) {
    try {
      const serviceAreaService = new ProfileServiceAreasLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const payload = new CreateOrUpdateProfileServiceAreaRequestViewModel(service)
      const response = await serviceAreaService.createOrUpdateServiceArea(id, payload);
      return { data:response, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/ServiceAreas`,err)
      return handleError(err, `/Profiles/${id}/ServiceAreas`, {id})
    }
  }

  static async deleteServiceArea(id: number, service: IProfileServiceAreaViewModel) {
    try {
      const serviceAreaService = new ProfileServiceAreasLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const payload = new DeleteProfileServiceAreaRequestViewModel(service)
      const response = await serviceAreaService.deleteServiceArea(id, payload);
      console.log(response)
      return { data:response, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/ServiceAreas`,err)
      return handleError(err, `/Profiles/${id}/ServiceAreas`, {id})
    }
  }

  static async updateBusinessPhotosOrder(id: number | undefined, media: string | undefined, order:number) {
    if(!media || !id) return;
    try {
      const mediaService = new MediaLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const body = new ReOrderMediaRequestViewModel({
        mediaUrl: media,
        newOrder: order
      })
      const response = await mediaService.reOrderImages(id, body)
      return { data:response, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/Images`,err)
      return handleError(err, `/Profiles/${id}/Images`, {id})
    }
  }

  static async addBussinessDocuments(profileId: number, formData: FormData) {
    try {
        const { data }  = await mobileAPI.post(`/Profiles/${profileId}/Documents`, formData)
      return { data:data, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${profileId}/Documents`,err)
      return handleError(err, `/Profiles/${profileId}/Documents`, {profileId})
    }
  }

  static async getBusinessDocuments(id: number) {
    try {
      const mediaService = new MediaLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const response = await mediaService.getDocuments(id);
      return { data:response, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/Documents`,err)
      return handleError(err, `/Profiles/${id}/Documents`, {id})
    }
  }


  static async deleteBusinesDocuments(id: number, media: any) {
    if(!media) return;
    try {
      const mediaService = new MediaLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const body = new DeleteMediasRequestViewModel({
        mediaUrls: media
      })
      const response = await mediaService.deleteDocuments(id, body)
      return { data:response, error: null }
    } catch (err) {
      console.log(`ERROR: /Profiles/${id}/Documents`,err)
      return handleError(err, `/Profiles/${id}/Documents`, {id})
    }
  }

  static async getBusinessDocumentTypes() {
    try {
      const mediaService = new MediaLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const response = await mediaService.getDocumentTypes();
      return { data:response, error: null }
    } catch (err) {
      console.log(`ERROR: /DocumentTypes`,err)
      return handleError(err, `DocumentTypes`)
    }
  }

}
