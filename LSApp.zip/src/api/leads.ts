import {
  CallLeadLog,
  Lead,
  LeadFilters,
  LeadList,
  LeadListItem,
  LeadLogType,
  LeadUpdate,
} from "@models/leads"

import { mobileAPI, mobileClient } from "./base"
import { handleError } from "./common"
import { LeadsLocalsplashService } from "@localsplash/mobile-api-client"
import { LsConfig } from "@utils/constants/common"

export class LeadsAPI {
  static async getLeads(start:number, filters?: LeadFilters, profileId?: number | undefined) {
    let LeadStructure: number | null = 0
    let LeadDisposition: number | null = 0
    if(!filters?.AreCallLeadLogsIncluded && !filters?.AreFacebookLeadLogsIncluded && !filters?.AreWebsiteFormLeadLogsIncluded && !filters?.AreSmsLeadLogsIncluded && !filters?.AreGoogleLeadLogsIncluded){
        LeadStructure = null
    } else {
        if(filters?.AreCallLeadLogsIncluded)
            LeadStructure += 66
        if(filters?.AreSmsLeadLogsIncluded)
            LeadStructure += 1028
        if(filters?.AreGoogleLeadLogsIncluded)
            LeadStructure += 776
        if(filters?.AreFacebookLeadLogsIncluded)
            LeadStructure += 48
        if(filters?.AreWebsiteFormLeadLogsIncluded)
            LeadStructure += 1
    }
    if(!filters?.AreCompletedLeadsIncluded && !filters?.AreFollowUpNeededLeadsIncluded && !filters?.AreNoAnswerLeadsIncluded && !filters?.AreNotInterestedLeadsIncluded && !filters?.AreNotaValidLeadsIncluded && !filters?.AreScheduledLeadsIncluded){
        LeadDisposition = null
    } else {
        if(filters?.AreCompletedLeadsIncluded)
            LeadDisposition += 64
        if(filters?.AreFollowUpNeededLeadsIncluded)
            LeadDisposition += 1
        if(filters?.AreNoAnswerLeadsIncluded)
            LeadDisposition += 4096
        if(filters?.AreNotInterestedLeadsIncluded)
            LeadDisposition += 32768
        if(filters?.AreNotaValidLeadsIncluded)
            LeadDisposition += 512
        if(filters?.AreScheduledLeadsIncluded)
            LeadDisposition += 8
    }
    const payload = {
        ...filters,
        FromRowNumber:start,
        LeadStructureType:LeadStructure,
        DispositionStatus: LeadDisposition
    }
    try {
      const { data } = await mobileAPI.get<LeadList<LeadListItem>>(`/Profiles/${profileId}/Leads`, {...payload, IsLogTotalCountIncluded:true })
      return { data, error: null }
    } catch (err) {
        console.log(`ERROR : /Profiles/${profileId}/Leads`, err)
        return handleError(err, `/Profiles/${profileId}/Leads`, payload)
    }
  }

  static async getRecentLeads(profileId:number) {
    try {
        const { data } = await mobileAPI.get<LeadList<LeadListItem>>(`/Profiles/${profileId}/Leads`)
        return { data, error: null }
      } catch (err) {
          console.log(`ERROR : /Profiles/${profileId}/Leads`, err)
          return handleError(err, `/Profiles/${profileId}/Leads`, {profileId})
      }
  }

  static async getCtmLeadLogs(leadStructure: LeadLogType) {
    try {
      const { data } = await mobileAPI.get<LeadList<CallLeadLog>>("/CtmLeadLogs", {
        LeadStructure: leadStructure,
      })
      return { data, error: null }
    } catch (err) {
        console.log("ERROR : /CtmLeadLogs", err)
        return handleError(err, "/CtmLeadLogs", { leadStructure })
    }
  }

  static async getLeadsDetails(id: string | number, profiledId: number | undefined) {
    try {
      const { data } = await mobileAPI.get<Lead>(`Profiles/${profiledId}/Leads/${id}`)
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: Profiles/${profiledId}/Leads/${id}`, err)
      return handleError(err, `Profiles/${profiledId}/Leads/${id}`, { id })
    }
  }

  static async setLeadsLogIsRead(profiledId: number | undefined, id: number, logId: number, isRead:boolean, leadStructure: number | undefined) {
    try {
      const { data } = await mobileAPI.patch<Lead>(`Profiles/${profiledId}/Leads/${id}/Logs/${leadStructure}/${logId}`, {
        isRead: isRead,
      })
      return { data, error: null }
    } catch (err) {
        console.log(`ERROR: /Leads/${id}/Logs/$${leadStructure}/${logId}`, err)
        return handleError(err, "/Leads/id/Logs/logId", { id, logId, isRead, leadStructure })
    }
  }

  static async setLeadLogStatus(profiledId: number | undefined, id: number, logId: number | undefined, dispositionStatus:number, leadStructure: number | undefined) {
    console.log(profiledId, id, logId, dispositionStatus)
    try {
      const { data } = await mobileAPI.patch<Lead>(`Profiles/${profiledId}/Leads/${id}/Logs/${leadStructure}/${logId}`, {
        dispositionStatus: dispositionStatus,
      })
      console.log("data: ",data)
      return { data, error: null }
    } catch (err) {
        console.log(`ERROR: /Leads/${id}/Logs/${logId}`, err)
        return handleError(err, `/Leads/${id}/Logs/${logId}`, { id, logId, dispositionStatus })
    }
  }


  static async updateLead(id: number, payload: Partial<LeadUpdate>) {
    try {
      await mobileAPI.patch(`/Leads/${id}`, payload)
      return { error: null }
    } catch (err) {
        console.log(`ERROR: /Leads/${id}`, err)
        return handleError(err, "/Leads/id", { id, ...payload })
    }
  }

  static async setLeadStatus(profiledId: number | undefined, id: number | string | undefined, payload: LeadFilters) {
    try {
      const { data } = await mobileAPI.patch<Lead>(`Profiles/${profiledId}/Leads/${id}`, payload)
      return { data, error: null }
    } catch (err) {
        console.log(`ERROR: /Leads/${id}` , err)
        return handleError(err, "/Leads/id", { id, ...payload })
    }
  }

  static async getCallLogs(profiledId: number | undefined, count:number, startRow: number) {
    try {
      const { data } = await mobileAPI.get<any>(`/PhoneCalls`,{ProfileId: profiledId, Length:count, FromRowNumber:startRow})
      return { data, error: null }
    } catch (err) {
      console.log(`ERROR: /PhoneCalls`, err)
      return handleError(err, "/PhoneCalls", { ProfileId: profiledId, count, startRow })
    }
  }

  static async getLeadLogs(leadId: number  , profileId: number, fromRowNumber:number, length:number) {
    try {
      const LeadsService = new LeadsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const response = await LeadsService.getItemLogs(profileId, leadId, undefined, length, fromRowNumber);
      return { data:response, error: null }
    } catch (err) {
      console.log(`ERROR: /Lead/${profileId}/Leads/${leadId}/Logs`,err)
      return handleError(err, `/Lead/${profileId}/Leads/${leadId}/Logs`, {profileId, leadId})
    }
  }

  static async getCustomerStatuses() {
    try {
      const LeadsService = new LeadsLocalsplashService(LsConfig.MOBILE_API_URL, mobileClient);
      const response = await LeadsService.getDispositionStatuses();
      return { data:response, error: null }
    } catch (err) {
      console.log(`ERROR: /CustomerStatus`,err)
      return handleError(err, `/CustomerStatus`, {})
    }
  }

}
