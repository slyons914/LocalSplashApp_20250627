import { useMemo } from "react"

import { ActivityIndicator, StyleProp, TouchableOpacity, View, ViewStyle } from "react-native"

import { FormatHelper } from "@utils/helpers"

import { Tile } from "./Tile"
import { useStyles } from "./styles"
import { Icon } from "../Icon"
import { Typography } from "../Typography"

interface Props {
  playing?: boolean
  loading: boolean
  position: number
  duration: number | undefined
  onPlayToggle: () => void
  style?: StyleProp<ViewStyle>
}

const SIZE = 40

export const Track = ({ playing, loading, position, duration, onPlayToggle, style }: Props) => {
  const styles = useStyles()

  const listenedIndex = duration ? Math.round((position * SIZE) / duration) : 0

  const tracks = useMemo(() => Array.from({ length: SIZE }, () => (Math.random() + 1) * 10), [])

  const renderItem = (height: number, index: number) => {
    return <Tile key={index} height={height} colored={index < listenedIndex} />
  }

  return (
    <View style={[styles.container, style]}>
      <TouchableOpacity
        hitSlop={2}
        disabled={loading}
        onPress={onPlayToggle}
        activeOpacity={loading ? 1 : 0.4}
      >
        {loading ? (
          <ActivityIndicator color={"white"} size={"small"} style={styles.spinner} />
        ) : (
          <Icon name={playing ? "pause" : "play"} width={24} height={24} />
        )}
      </TouchableOpacity>
      <View style={styles.voice}>{tracks.map(renderItem)}</View>
      <Typography style={styles.duration}>{FormatHelper.formatTimeToDuration(duration)}</Typography>
    </View>
  )
}
