import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    borderRadius: 4,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    justifyContent: "space-between",
    paddingVertical: 6,
    paddingHorizontal: 12,
    backgroundColor: colors.blue,
  },
  content: {
    paddingHorizontal: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  spinner: {
    width: 24,
    height: 24,
  },
  voice: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  duration: {
    fontSize: 14,
    fontWeight: "400",
    color: colors.white,
  },
}))
