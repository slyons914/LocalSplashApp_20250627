import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(() => ({
  tile: {
    width: 2,
    borderRadius: 2,
  },
}))
