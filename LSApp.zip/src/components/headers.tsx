import { View, Text, StyleSheet, StatusBar, StyleProp, TextStyle, Pressable } from 'react-native'
import React, { ReactElement } from 'react'
import { Typography } from './Typography';

interface HeaderProps {
    title: string;
    RightIcon?: ReactElement;
    LeftIcon?: ReactElement;
    CenterIcon?: ReactElement;
    titleTextStyle?: StyleProp<TextStyle>;
    onPressLeftIcon?: () => void;
    onPressRightIcon?: () => void
}

const Header = ({title, RightIcon, LeftIcon, CenterIcon, titleTextStyle, onPressLeftIcon, onPressRightIcon}: HeaderProps) => {
  return (
    <View style={styles.container}>
        <Pressable onPress={onPressLeftIcon} style={styles.leftContainer}>
            {LeftIcon ? LeftIcon : null}
        </Pressable>

        <View style={styles.titleContainer}>
            {CenterIcon ? CenterIcon : null}
            <Typography style={[styles.titleText, titleTextStyle]}>{title}</Typography>
        </View>
        
        
        <Pressable onPress={onPressRightIcon} style={styles.rightContainer}>
            {RightIcon ? RightIcon : null}
        </Pressable>
        
    </View>
  )
}

const styles = StyleSheet.create({
    container: {
        marginTop: StatusBar.currentHeight,
        height: 40,
        justifyContent: "center",
        marginHorizontal: "5%"
    },
    titleContainer: {
        position: "absolute",
        alignSelf: "center",
        flexDirection: "row",
        alignItems: "center",
        gap: 10
    },
    leftContainer: {
        position: "absolute",
        alignSelf: "flex-start"
    },
    rightContainer: {
        position: "absolute",
        alignSelf: "flex-end"
    },
    titleText: {
        color: "white"
    }
})

export default Header
