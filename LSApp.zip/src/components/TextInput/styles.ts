import { withStyles } from "@utils/hocs";

export const useStyles = withStyles(({ colors,isDarkTheme }) => ({
    textInputContainer: {
        marginVertical: 10
    },
    textInputField: {
        flex: 1,
        borderColor: colors.gray6,
        borderWidth: 1,
        borderRadius: 8,
        padding: 10,
        paddingHorizontal: 15,
        color:isDarkTheme ? colors.white : colors.dark
    },
}))