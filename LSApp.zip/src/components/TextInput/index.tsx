import { TextInput, TextInputProps, View } from "react-native"
import { useStyles } from "./styles"
import { Typography } from "../Typography"
import { colors } from "@utils/constants"

interface Props extends TextInputProps {
    title?: string,
    placeholder: string,
    style?: object
}

export const AppTextInput = ({ title, placeholder, style, ...otherProperties }: Props) => {
    const styles = useStyles()
    return (
        <View
            style={styles.textInputContainer}
        >
            {title && <Typography>{title}</Typography>}
            <TextInput
                style={[styles.textInputField, style]}
                placeholder={placeholder}
                placeholderTextColor={colors.common.gray4}
                {...otherProperties}
            />
        </View>
    )
}
