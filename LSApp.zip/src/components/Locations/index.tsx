import { useState } from "react"

import { TouchableOpacity, useColorScheme } from "react-native"

import { observer } from "mobx-react-lite"

import { LocationsModal } from "@modals"
import { useStore } from "@store"

import { useStyles } from "./styles"
import { Icon } from "../Icon"
import { Typography } from "../Typography"

const Component = () => {
  const styles = useStyles()

  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"

  const { homeStore } = useStore()
  const { profiles, locationsIndex, setLocationsIndex, setLocationsItem } = homeStore

  const [locationsLabel, setLocationsLabel] = useState<string>(profiles?.profiles![locationsIndex].title || "")
  const [locationsModal, setLocationsModal] = useState(false)

  return (
    <>
      <TouchableOpacity onPress={() => setLocationsModal(true)} style={styles.locationContainer}>
        <Typography numberOfLines={1} style={styles.locationName}>
          {locationsLabel}
        </Typography>
        <Icon name={isLightTheme ? "chevronDown" : "chevronDownWhite"} />
      </TouchableOpacity>
      <LocationsModal
        isVisible={locationsModal}
        onClose={() => setLocationsModal(false)}
        setLocationsLabel={setLocationsLabel}
        setLocationsIndex={setLocationsIndex}
        setLocationsItem={setLocationsItem}
        locationsIndex={locationsIndex}
      />
    </>
  )
}

export const Locations = observer(Component)
