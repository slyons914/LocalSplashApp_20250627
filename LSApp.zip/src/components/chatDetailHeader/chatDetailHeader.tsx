import {withStyles} from "@utils/hocs";
import React from "react"
import {View, TouchableOpacity, useColorScheme, Pressable, } from "react-native"
import {Icon, Typography} from "@components"
import { backIconHitSlope } from "@utils/constants/common";
import { FormatHelper } from "@utils/helpers";
import { navigate } from "@navigation";
import { Routes, Stacks } from "@utils/constants";


interface IchatDetail
{
    onBackPress: () => void
    openActionsModal: () => void
    number : string
    name:string,
    isSpam: boolean | undefined
    isBlocked: boolean | undefined
}

const ChatDetailHeader: React.FC<IchatDetail> = (props) =>
{

    const {
        onBackPress,
        openActionsModal,
        number,
        name,
        isSpam,
        isBlocked
    } = props

    const systemColorScheme = useColorScheme()
    const isLightTheme = systemColorScheme === "light"

    const styles = cutomStyle();

    const onPhonePress = () => {
        navigate(Stacks.Call, { screen: Routes.DialPad, params: {
            phoneNumber: number.toString()
        }})
    }
    return (
        <View style={styles.header}>
            <View style={styles.centerContent}>

                <TouchableOpacity hitSlop={backIconHitSlope} onPress={onBackPress}><Icon name={isLightTheme ? "backIcon" : "bacIconWhite"} /></TouchableOpacity>
                {/* <UserAvatar size={30} name={name} bgColor={'#9a57dd'} style={{alignSelf: 'stat', }} /> */}

                <View>
                    {/* <Typography>{name}</Typography> */}
                    <Typography>{FormatHelper.formatPhoneNumber(number.toString())}</Typography>
                    {isSpam && !isBlocked && <Icon name={"spam"} style={styles.spam} />}
                    {!isSpam && isBlocked && <Icon name={"blocked"} style={styles.spam} />}
                    {isSpam && isBlocked && <Icon name={"spamblock"} style={styles.spamblock} />}
                </View>

            </View>

            <View style={styles.rightSideContent}>
                <Pressable onPress={onPhonePress} hitSlop={backIconHitSlope}>
                    <Icon name={ isLightTheme ? "phoneblack" : "phoneDark"}></Icon>
                </Pressable>
                <Pressable onPress={openActionsModal} hitSlop={backIconHitSlope} >
                    <Icon name={ isLightTheme ? "dotsVerticalBlack" : "dotsVertical"}></Icon>
                </Pressable>
            </View>
        </View>
    )
}

const cutomStyle = withStyles(({insets, colors}) => ({

    header: {
        paddingHorizontal: 16,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderBottomColor: colors.whiteSecondary,
        borderBottomWidth: 1,
        paddingBottom: 5,
    },
    centerContent: {flexDirection: 'row', alignItems: 'center', gap: 25, alignContent:"center"},
    rightSideContent: {flexDirection: 'row', alignItems: 'center', gap: 15},
    spam: {
        marginTop: 10,
    },
    spamblock: {
        marginTop: 15,
    },

}))
export default ChatDetailHeader;