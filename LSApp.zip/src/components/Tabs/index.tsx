import React, { useEffect, useRef } from "react"
import { FlatList, TouchableOpacity } from "react-native"
import { useStyles } from "./styles"
import { Typography } from "../Typography"

interface Props {
  tabs: Array<string>
  onTabPress?: (index: number) => void
  activeTab?: number
  setActiveTab?: (tab: number) => void
  allTabsDisabled?: boolean
}

export const Tabs = ({
  tabs,
  onTabPress,
  activeTab = 0,
  setActiveTab = () => {},
  allTabsDisabled = false,
}: Props) => {
  const styles = useStyles()
  const flatListRef = useRef<FlatList | null>(null)

  useEffect(() => {
    flatListRef.current?.scrollToIndex({ index: activeTab, animated: true, viewOffset: 50 })
  }, [activeTab])

  const renderItem = (item: string, index: number) => {
    return (
      <TouchableOpacity
        onPress={() => {
          setActiveTab(index)
          onTabPress?.(index)
          // flatListRef.current?.scrollToIndex({ index, animated: true })
        }}
        style={[styles.tab, activeTab === index && !allTabsDisabled && styles.activeTab]}
        key={item + index}
      >
        <Typography
          style={[styles.tabText, activeTab === index && !allTabsDisabled && styles.activeTabText]}
        >
          {item}
        </Typography>
      </TouchableOpacity>
    )
  }

  return (
    <FlatList
      ref={(ref) => (flatListRef.current = ref)}
      contentContainerStyle={styles.content}
      data={tabs}
      renderItem={({ item, index }) => renderItem(item, index)}
      alwaysBounceHorizontal
      scrollEnabled
      horizontal
      showsHorizontalScrollIndicator={false}
      style={styles.outerContainer}
    />
  )
}
