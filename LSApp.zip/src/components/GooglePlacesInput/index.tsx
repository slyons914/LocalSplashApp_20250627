import { SetStateAction, useEffect, useState } from "react"

import { useColorScheme, View } from "react-native"

import {
  GooglePlaceDetail,
  GooglePlacesAutocomplete,
} from "react-native-google-places-autocomplete"

import { PLACES_API_TOKEN } from "@env"
import { Address } from "@models/settings"

import { useStyles } from "./styles"
import { Typography } from "../Typography"
import { colors } from "@utils/constants"

interface Props {
  setAddress: (value: SetStateAction<Address | null>) => void
  label: string
  onSubmit?: (val:string, val2:string) => void
  type?: string
}

export const GooglePlacesInput = ({ setAddress, label, type = 'default', onSubmit }: Props) => {
  const styles = useStyles()

  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"

  const [addressDetails, setAddressDetails] = useState({
    streetNumber: "",
    route: "",
    city: "",
    state: "",
    country: "",
    postalCode: "",
  })

  const updateAddressDetails = async (details: GooglePlaceDetail) => {

    setAddress((prev) => ({
        ...prev,
        latitude: details.geometry.location.lat,
        longitude: details.geometry.location.lng,
        placesId: details.place_id
      }))

    details.address_components.forEach((component) => {
      switch (component.types[0]) {
        case "street_number":
          setAddressDetails((prev) => ({ ...prev, streetNumber: component.long_name }))
          break
        case "route":
          setAddressDetails((prev) => ({ ...prev, route: component.long_name }))
          break
        case "locality":
          setAddressDetails((prev) => ({ ...prev, city: component.long_name }))
          break
        case "administrative_area_level_1":
          setAddressDetails((prev) => ({ ...prev, state: component.short_name }))
          break
        case "country":
          setAddressDetails((prev) => ({ ...prev, country: component.short_name }))
          break
        case "postal_code":
          setAddressDetails((prev) => ({ ...prev, postalCode: component.long_name }))
          break
        default:
          break
      }
    })

    if(type === 'service' && onSubmit) {
        onSubmit(details?.place_id, details?.formatted_address)
    }
  }

  return (
    <View style={styles.container}>
      <Typography>{label}</Typography>
      <GooglePlacesAutocomplete
        placeholder="Search"
        minLength={2}
        debounce={500}
        keyboardShouldPersistTaps={"always"}
        onPress={(_, details = null) => {
          details && updateAddressDetails(details)
        }}
        fetchDetails
        query={{
          key: PLACES_API_TOKEN,
          language: "en",
        }}
        styles={{
          description: {color: isLightTheme? colors.common.black: colors.common.white},  
          textInput: styles.textInput,
          poweredContainer: { display: "none" },
          row: styles.row,
        }}
      />
    </View>
  )
}
