import { View, Text, StyleSheet, Pressable } from "react-native"
import React, { ReactElement } from "react"
import { Typography } from "./Typography"
import {TouchableOpacity} from "react-native-gesture-handler"

interface IconWithLabelProps {
  label: string
  Icon: ReactElement | any
  onPress: () => void
}

const IconWithLabel = ({ label, Icon, onPress }: IconWithLabelProps) => {
  return (
    <TouchableOpacity activeOpacity={0.7} onPress={onPress} style={styles.container}>
      {Icon ? <Icon width={30} height={30} /> : null}
      <Typography style={styles.label}>{label}</Typography>
    </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    width: 100,
    height: 80,
    gap: 5,
  },
  label: {
    textAlign: "center",
    color: "white",
  },
})

export default IconWithLabel
