import { withStyles } from "@utils/hocs"

const THUMB_SIZE = 16

export const useStyles = withStyles(({ colors }) => ({
  container: {
    height: 3,
    borderRadius: 3,
    backgroundColor: `${colors.white}30`,
    justifyContent: "center",
  },
  progress: {
    height: "100%",
    borderRadius: 3,
    backgroundColor: colors.white,
  },
  thumb: {
    width: THUMB_SIZE,
    height: THUMB_SIZE,
    borderRadius: THUMB_SIZE,
    backgroundColor: colors.white,
    position: "absolute",
    transform: [{ translateX: -THUMB_SIZE / 2 }],
  },
}))
