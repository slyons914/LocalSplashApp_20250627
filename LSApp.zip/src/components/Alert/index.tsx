import { Pressable, View } from "react-native"

import { Routes, Stacks } from "@utils/constants"

import { useStyles } from "./styles"
import { Icon } from "../Icon"
import { Typography } from "../Typography"
import { navigate } from "@navigation"
import { useState } from "react"
import InAppBrowser from "react-native-inappbrowser-reborn"
import { InAppBrowserStyle, LsConfig } from "@utils/constants/common"
import { useStore } from "@store"

interface Props {
  isSmsFailed: boolean
  profileVerified:boolean
}

export const HomeAlert = ({
  isSmsFailed ,
  profileVerified
}: Props) => {
  const styles = useStyles()
  const { homeStore }  = useStore()
  const { artMemberID, locationsItem } = homeStore
  const [isEpanded, setIsExpanded] = useState(false)

  const toggleViews = () => {
    if(isSmsFailed && !profileVerified)
        setIsExpanded(!isEpanded);
  };

  const onGoogleVerifyClick = async () => {
    const url = `https://${LsConfig.MODE}my.localsplash.com/GooglePinVerification/?contentonly=true`
    await InAppBrowser.open(url, InAppBrowserStyle)
  }

  return (
    <Pressable onPress={()=> toggleViews()}>
        {
            !profileVerified ? (
                <View style = {[!isEpanded && styles.fixSmsView ,styles.smsFailedView]}>
                    <Icon name="homeAlertIcon"></Icon>
                    <Typography style={styles.smsFailedText}>{isEpanded || !isSmsFailed ?"Your Google Profile Is Not Verified":""}</Typography>
                    <Pressable onPress={onGoogleVerifyClick} style={styles.updateButton}>
                        <Typography style={styles.buttonText}>Verify</Typography>
                    </Pressable>
                </View>
            ) : (null)
        }
        {
            isSmsFailed ? (
                <View style = {[!isEpanded && !profileVerified && styles.fixView,styles.smsFailedView]}>
                    <Icon name="homeAlertIcon"></Icon>
                    <Typography style={styles.smsFailedText}>Our last SMS to you failed, Please review your cell phone number.</Typography>
                    <Pressable onPress={()=>navigate(Stacks.Settings,{screen:Routes.PersonalInfo})} style={styles.updateButton}>
                        <Typography style={styles.buttonText}>Update</Typography>
                    </Pressable>
                </View>
            ) : (null)
        }
    </Pressable>
  )
}
