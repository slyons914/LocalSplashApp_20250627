import { withStyles } from "@utils/hocs"
import { Platform } from "react-native"

export const useStyles = withStyles(({ colors, width }) => ({
    smsFailedView:{
        flexDirection:"row",
        gap:4,
        alignItems:"center",
        padding:Platform.OS === "ios" ? 12 : 8,
        borderRadius:12,
        backgroundColor:colors.lightRed,
        marginTop:8,
        shadowColor: 'rgba(0, 0, 0, .1',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: .1,
    shadowRadius: 4,
    // Android shadow property
    elevation: 4,
    },
    smsFailedText:{
        flex:1,
        color:colors.redText,
        fontSize:Platform.OS==="ios" ? 14 : 13,
        paddingLeft: 4
    },
    updateButton:{
        paddingVertical:8,
        paddingHorizontal:12,
        borderRadius:115,
        backgroundColor:colors.redText,
    },
    buttonText:{
        color:"#fff",
        textAlign:"center",
    },
    fixView:{
        position:"absolute",
        top:Platform.OS === "ios" ? 10 : 8,
    },
    fixSmsView:{
        alignSelf:"center",
        marginBottom:Platform.OS === "ios" ? 8 : 20,
    }
}))
