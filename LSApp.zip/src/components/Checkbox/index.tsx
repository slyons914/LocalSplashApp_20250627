import { TouchableOpacity } from "react-native"

import { Icon } from "../Icon"

interface Props {
  onPress: () => void
  value: boolean
  disabled?: boolean
}

export const Checkbox = ({ onPress, value, disabled = false }: Props) => {
  return (
    <TouchableOpacity disabled={disabled} onPress={onPress}>
      {value ? <Icon name={"checkboxActive"} /> : <Icon name={"checkboxInactive"} />}
    </TouchableOpacity>
  )
}
