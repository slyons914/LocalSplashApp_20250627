import { useState } from "react"

import {
  Pressable,
  StyleProp,
  TouchableOpacity,
  useColorScheme,
  View,
  ViewStyle,
} from "react-native"

import { useNavigation } from "@react-navigation/native"

import { BurgerMenuModal } from "@modals"
import { Routes, Stacks } from "@utils/constants"

import { useStyles } from "./styles"
import { Icon } from "../Icon"
import { Typography } from "../Typography"
import { backIconHitSlope } from "@utils/constants/common"
import { showDevelopmentToast } from "@utils/helpers/common"

interface Props {
  onBurgerPress?: () => void
  name?: string
  onLeftPress?: () => void
  style?: StyleProp<ViewStyle>
}

export const Header = ({ name, style, onLeftPress }: Props) => {
  const styles = useStyles()

  const { navigate } = useNavigation()

  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"

  const [burgerMenuModal, setBurgerMenuModal] = useState(false)

  const onBurgerPress = () => {
    setBurgerMenuModal(true)
  }

  const onSettingsPress = () => {
    navigate(Stacks.Settings, { screen: Routes.Settings })
  }

  return (
    <View>
    <View style={[styles.container, style]}>
      {name ? (
        <Typography style={styles.title}>{name}</Typography>
      ) : (
        <TouchableOpacity hitSlop={backIconHitSlope} onPress={onLeftPress}>
          <Icon name={isLightTheme ? "backIcon" : "bacIconWhite"} />
        </TouchableOpacity>
      )}
      <View style={styles.iconsContainer}>
        <Pressable onPress={onSettingsPress}>
          <Icon name={isLightTheme ? "settingsIcon" : "settingsIconWhite"} />
        </Pressable>
        <Pressable onPress={showDevelopmentToast}>
            <Icon name={isLightTheme ? "headerBell" : "headerBellWhite"} />
        </Pressable>
        <Pressable onPress={onBurgerPress}>
          <Icon name={isLightTheme ? "burgerIcon" : "burgerIconWhite"} />
        </Pressable>
      </View>
      <BurgerMenuModal isVisible={burgerMenuModal} onClose={() => setBurgerMenuModal(false)} setBurgerMenu ={ setBurgerMenuModal } />
    </View>
    </View>
  )
}
