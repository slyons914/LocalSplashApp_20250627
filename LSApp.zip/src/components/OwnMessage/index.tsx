import { ActivityIndicator, Image, Platform, Pressable, Share, Text, View } from "react-native"
import { Typography } from "../Typography";
import { withStyles } from "@utils/hocs";
import { useState } from "react";
import { FullChatImageModal } from "@modals";
import { Icon } from "../Icon";
import ReactNativeBlobUtil from 'react-native-blob-util'
import Toast from 'react-native-simple-toast';
import DoubleCheck from '../../../assets/icons/doubleCheckGreen.svg'
import Clipboard from "@react-native-clipboard/clipboard";

let dirs = ReactNativeBlobUtil.fs.dirs

function getHoursAndMinutes(milliseconds: any) {
    const date = new Date(milliseconds);
    let hours = date.getHours();
    let minutes: string | number = date.getMinutes();
    const period = hours >= 12 ? 'PM' : 'AM';

    hours = hours % 12 || 12;
    minutes = String(minutes).padStart(2, '0');
    return { hours, minutes, period };
}

const OthersMessage = (props: any) => {
    const { message, sendingInProgress, lastestMessageId } = props
    const { body, dateCreated, id, media, fileName, mediaItems } = message
    const { hours, minutes, period } = getHoursAndMinutes(dateCreated);
    const customeStyle = styles()

    const [fullImageModal, setFullImageModal] = useState<string | boolean>(false)
    const formatFileName = (url: any) => {
        if (!url) {
            return
        }
        const fileNameWithExtension = url.substring(url.lastIndexOf('/') + 1);
        const firstUnderscoreIndex = fileNameWithExtension.indexOf('_');
        const nameAfterUnderscore = fileNameWithExtension.substring(firstUnderscoreIndex ? firstUnderscoreIndex + 1 : 0);
        const [name, extension] = nameAfterUnderscore.split('.');
        const limitedName = name.length > 20 ? name.substring(0, 20) : name;
        return `${limitedName}${extension ? '.' + extension : ''}`;
    }

    const handleChatItemPress = (message: string) => {
        Clipboard.setString(message);

        Toast.showWithGravity(
        'Copied',
        Toast.SHORT,
        Toast.BOTTOM,
        );
    }


    const downloadFile = async (url: String) => {
        if (!(url.toLowerCase().includes('https') || url.toLowerCase().includes('https'))) {
            return
        }
        const fileName = formatFileName(url)
        ReactNativeBlobUtil
            .config({
                fileCache: true,
                path: `${dirs.DownloadDir}/${fileName}`,
                addAndroidDownloads: {
                    useDownloadManager: true,
                    notification: true,
                    title: fileName,
                    description: 'Downloading'
                }
            })
            .fetch('GET', url, {
            })
            .then(async (res) => {
                if (Platform.OS === 'ios') {
                    const filePath = res.path();
                    await Share.share({
                        url: `file://${filePath}`,
                        title: fileName,
                    });
                }
            })
    }
    return (
        <View style={{ marginBottom: 20, flex: 1 }}>
            <View style={{ alignSelf: "flex-end", flex: 1 }}>
                {mediaItems && mediaItems.length > 0 ? (
                    mediaItems.map((item: any, index: number) => {
                        const isImage = item?.includes("jpg") || item?.includes("png") || item?.includes("jpeg");

                        return (
                            <View key={index} style={{ marginBottom: 4 }}>
                                {isImage ? (
                                    <Pressable onPress={() => setFullImageModal(item)}>
                                        <Image
                                            source={{ uri: item }}
                                            style={customeStyle.image}
                                            resizeMode="cover"
                                        />
                                    </Pressable>
                                ) : (
                                    <Pressable onPress={() => downloadFile(item)} style={customeStyle.fileView}>
                                        <Typography style={customeStyle.fileName}>{formatFileName(item)}</Typography>
                                        <Icon name="Media" />
                                    </Pressable>
                                )}
                            </View>
                        );
                    })
                ) : null}

                {body && (
                    <Pressable onLongPress={() => handleChatItemPress(body)} style={customeStyle.messageView}>
                        <Typography style={customeStyle.message}>{body}</Typography>
                    </Pressable>
                )}

                <View style={{ alignSelf: 'flex-end' }}>
                    <View style={{ alignItems: 'center', flexDirection: 'row', gap: 5 }}>
                        <Typography style={customeStyle.timeStyle}>{`${hours}:${minutes} ${period}`}</Typography>
                        {sendingInProgress && lastestMessageId === id ? (
                            <ActivityIndicator size={"small"} />
                        ) : (
                            <DoubleCheck />
                        )}
                    </View>
                </View>
            </View>

            <FullChatImageModal
                imageUrl={typeof fullImageModal === 'string' ? fullImageModal : ''}
                onClose={() => setFullImageModal(false)}
                isVisible={!!fullImageModal}
            />
        </View>
    )
}
const styles = withStyles(({ insets, colors }) => ({

    message: {
        maxWidth: '70%',
        paddingHorizontal: 16,
        paddingVertical: 7,
        fontSize: 14,
        fontWeight: '400',
        color: colors.white,
        lineHeight: 21
    },
    fileName: {
        lineHeight: 21,
        paddingLeft: 16,
    },
    timeStyle: { fontSize: 10, fontWeight: '400', color: colors.lightGrey },
    messageView: {
        backgroundColor: colors.blue,
        alignSelf: "flex-end",
        borderRadius: 12,
        borderTopEndRadius: 0,
        marginBottom: 4,
    },
    image: {
        width: 200,
        height: 200,
        alignSelf: "flex-end",
        borderRadius: 8,
        borderBottomRightRadius: 0
    },
    fileView: {
        flexDirection: "row",
        gap: 4,
        paddingRight: 16,
        paddingVertical: 4,
    },
    bottomBorder: {
        borderBottomWidth: 1
    }
})

)

export default OthersMessage;