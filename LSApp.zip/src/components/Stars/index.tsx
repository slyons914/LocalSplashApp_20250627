import { View } from "react-native"
import { Icon } from "../Icon"
import { useStyles } from "./style"

interface props{
    data:number
}

export const StarsCompoment = ({data}:props) =>{
    const styles = useStyles()
    var stars:any = [];
    for (let index = 0; index < 5; index++) {
        if(index<data){
            stars[index] = "yellowStar"
        }else{
            stars[index] = "whiteStar"
        }
    }
    return (<View style={styles.container}>
        {stars.map((item:any , index)=>(
            <Icon key={index} name={item}></Icon>
        ))}
    </View>
    )
        
}