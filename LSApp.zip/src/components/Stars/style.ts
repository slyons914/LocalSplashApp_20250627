import { withStyles } from "@utils/hocs"
export const useStyles = withStyles(({ colors }) => ({
  container: {
    flexDirection:"row",
    gap:3
  },
}))