import { useState } from "react"

import { StyleProp, TextInput, View, ViewStyle, useColorScheme } from "react-native"

import { useStyles } from "./styles"
import { Icon } from "../Icon"

interface Props {
  value: string
  onSearch: (searchValue: string) => void
  placeholder: string
  style?: StyleProp<ViewStyle>
}

export const SearchBar = ({ value = "", onSearch, placeholder = "", style }: Props) => {
  const styles = useStyles()
  const [currentValue, setCurrentValue] = useState(value)
  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"

  const handleSearchChange = (text: string) => {
    setCurrentValue(text)
    onSearch(text)
  }

  return (
    <View style={[styles.container, style]}>
      <Icon name={isLightTheme?"search" : "searchDark"} />
      <TextInput
        inputMode="text"
        autoCapitalize="none"
        style={styles.container}
        placeholderTextColor={isLightTheme?'#3C3C4399':'#EBEBF599'}
        placeholder={placeholder}
        value={currentValue}
        onChangeText={handleSearchChange}
      />
    </View>
  )
}
