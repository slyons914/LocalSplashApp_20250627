import { Image, Platform, Pressable, Share, View } from "react-native"
import UserAvatar from 'react-native-user-avatar';
import { Typography } from "../Typography";
import { withStyles } from "@utils/hocs";
import { useState } from "react";
import { FullChatImageModal } from "@modals";
import { Icon } from "../Icon";
import Clipboard from "@react-native-clipboard/clipboard";
import Toast from 'react-native-simple-toast';
import ReactNativeBlobUtil from "react-native-blob-util";

let dirs = ReactNativeBlobUtil.fs.dirs

const getHoursAndMinutes = (milliseconds: any) => {
    const date = new Date(milliseconds);
    let hours = date.getHours();
    let minutes: string | number = date.getMinutes();
    const period = hours >= 12 ? 'PM' : 'AM';

    hours = hours % 12 || 12;
    minutes = String(minutes).padStart(2, '0');
    return { hours, minutes, period };
}

const handleChatItemPress = (message: string) => {
    Clipboard.setString(message);

    Toast.showWithGravity(
      'Copied',
      Toast.SHORT,
      Toast.BOTTOM,
    );
}


const OwnMessage = (props: any) => {
    const { message } = props
    const { body, dateCreated, mediaItems } = message

    const { hours, minutes, period } = getHoursAndMinutes(dateCreated);

    const customeStyle = styles()

    const [fullImageModal, setFullImageModal] = useState<string | false>(false)

    const formatFileName = (url: any) => {
        if (!url) {
            return
        }
        const fileNameWithExtension = url.substring(url.lastIndexOf('/') + 1);
        const firstUnderscoreIndex = fileNameWithExtension.indexOf('_');

        if (firstUnderscoreIndex === -1) {
            return fileNameWithExtension;
        }

        const nameAfterUnderscore = fileNameWithExtension.substring(firstUnderscoreIndex + 1);
        const [name, extension] = nameAfterUnderscore.split('.');
        const limitedName = name.length > 20 ? name.substring(0, 20) : name;
        return `${limitedName}${extension ? '.' + extension : ''}`;
    }

    const downloadFile = async (url: any) => {
        const fileName = formatFileName(url)
        ReactNativeBlobUtil
            .config({
                fileCache: true,
                path: `${dirs.DownloadDir}/${fileName}`,
                addAndroidDownloads: {
                    useDownloadManager: true,
                    notification: true,
                    title: fileName,
                    description: 'Downloading'
                }
            })
            .fetch('GET', url, {
            })
            .then(async (res) => {
                if (Platform.OS === 'ios') {
                    const filePath = res.path();
                    await Share.share({
                        url: `file://${filePath}`,
                        title: fileName,
                    });
                }
            })
    }
    return (
        <View style={{ marginBottom: 20 }}>
            {/* {index===0 &&
            <View style={customeStyle.userName}>
                <UserAvatar size={30} name="Jane Cooper" bgColor={'#9a57dd'} style={{alignSelf: 'stat', }} />
                <Typography>Jane Cooper</Typography>
            </View>
            } */}

            <View style={customeStyle.flexStart}>
                {mediaItems && mediaItems.length > 0 && mediaItems.map((item: any, idx: number) => {
                    const isImage = item && (item.endsWith("jpg") || item.endsWith("jpeg") || item.endsWith("png"));

                    return (
                        <View key={idx} style={{ marginBottom: 6 }}>
                            {isImage ? (
                                <Pressable onPress={() => setFullImageModal(item)}>
                                    <Image
                                        source={{ uri: item }}
                                        style={customeStyle.image}
                                        resizeMode="cover"
                                    />
                                </Pressable>
                            ) : (
                                <Pressable
                                    onPress={() => downloadFile(item)}
                                    style={[customeStyle.fileView, idx !== mediaItems.length - 1 && customeStyle.bottomBorder]}
                                >
                                    <Typography style={customeStyle.fileName}>{formatFileName(item)}</Typography>
                                    <Icon name="Media" />
                                </Pressable>
                            )}
                        </View>
                    );
                })}

                {body && (
                    <Pressable onLongPress={() => handleChatItemPress(body)} style={customeStyle.messageView}>
                        <Typography style={customeStyle.message}>{body}</Typography>
                    </Pressable>
                )}

                <Typography style={customeStyle.timeStyle}>{`${hours}:${minutes} ${period}`}</Typography>
            </View>
            <FullChatImageModal
                imageUrl={typeof fullImageModal === 'string' ? fullImageModal : ''}
                onClose={() => setFullImageModal(false)}
                isVisible={!!fullImageModal}
            />
        </View>
    )
}
const styles = withStyles(({ insets, colors }) => ({

    userName: { flexDirection: 'row', alignItems: 'center', gap: 10 },

    message: {
        marginLeft: 4,  // userAvtar + gap = 30+10
        maxWidth: '70%',
        borderTopLeftRadius: 0,
        paddingHorizontal: 16,
        paddingVertical: 7,
        fontSize: 14,
        fontWeight: '400',
        color: colors.subText,
    },
    messageView: {
        borderRadius: 12,
        alignSelf: "flex-start",
        backgroundColor: colors.lightBlue,
        borderTopLeftRadius: 0,
        marginBottom: 4
    },
    timeStyle: { textAlign: 'right', fontSize: 10, fontWeight: '400', color: colors.lightGrey },
    image: {
        width: 200,
        height: 200,
        alignSelf: "flex-end",
        borderRadius: 8,
        borderBottomRightRadius: 0
    },
    fileName: {
        lineHeight: 21,
        paddingLeft: 16,
    },
    fileView: {
        flexDirection: "row",
        gap: 4,
        paddingRight: 16,
        paddingVertical: 4,
    },
    bottomBorder: {
        borderBottomWidth: 1
    },
    flexStart: {
        alignSelf: "flex-start"
    }
})

)

export default OwnMessage;