import { withStyles } from '@utils/hocs';
import React from 'react';
import { Text, TextStyle } from 'react-native';
import { Typography } from '../Typography';

interface ErrorMessageProps {
    message: string;
    style?: TextStyle;
}

const ErrorMessage: React.FC<ErrorMessageProps> = ({ message, style }) => {
    const styles = useStyles()
    return <Typography type='default' style={[styles.errorMessage, style]}>{message}</Typography>;
};

export default ErrorMessage;


const useStyles = withStyles(({ colors }) => ({
    errorMessage: {
        color: colors.red
    }
}))
