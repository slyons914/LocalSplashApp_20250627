import { View, Text, useColorScheme, Pressable } from "react-native"
import React from "react"
import { useStyles } from "./styles"
import { Typography } from "../Typography"
import { Icon } from "../Icon"
import { colors } from "@utils/constants"
import { CustomTooltip } from "@components"

interface ContentHeaderProps {
  title: string
  toolTip:boolean
  setToolTip: (val:boolean)=>void
  toolTipText: string
}

export const HeaderWithTooltip: React.FC<ContentHeaderProps> = ({ title, toolTip, setToolTip, toolTipText }) => {
  const styles = useStyles()
  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"
  const reviewIconDark = isLightTheme ? "helpSquareBlack" : "helpSquare"
  return (
    <View style={styles.mainContainer}>
      <Typography style={styles.title}>{title}</Typography>
      <Pressable onPress={()=> setToolTip(true)}>
        <CustomTooltip isVisible={toolTip} location={"top"} onClose={()=>setToolTip(false)} Text={toolTipText}>
            <Icon name={reviewIconDark} fill={colors.common.white} />
        </CustomTooltip>
      </Pressable>
    </View>
  )
}
