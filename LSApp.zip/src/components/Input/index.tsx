import React from "react"

import { TextInput, Pressable, KeyboardTypeOptions, StyleProp, View, TextStyle } from "react-native"
import { TextInputMask } from "react-native-masked-text"
import { useStyles } from "./styles"
import { Typography } from "../Typography"
import { colors } from "@utils/constants"

interface Props {
  value: string
  label: string
  onChange?: (text: string) => void
  type?: "phone" | "default"
  error?: string
  setError?: (text: string) => void
  disabled?: boolean
  multiline?: boolean
  onPress?: () => void
  editable?: boolean
  onSubmitEditing?: () => void
  placeholder?: string
  keyboardType?: KeyboardTypeOptions | undefined
  style?: StyleProp<TextStyle>
}

export const Input = ({
  value,
  label,
  onChange,
  type = "default",
  error,
  setError,
  disabled,
  multiline,
  onPress,
  editable,
  onSubmitEditing,
  placeholder,
  keyboardType,
  style
}: Props) => {
  const styles = useStyles()

  const onChangeText = (text: string) => {
    onChange && onChange(text)
    setError && setError("")
  }

  return (
    <Pressable onPress={onPress} style={styles.container}>
      <Typography style={styles.inputLabel}>{label}</Typography>
      <React.Fragment>
        {type === "phone" ? (
          <TextInputMask
            onChangeText={(text) => onChangeText(text)}
            value={value}
            type={"cel-phone"}
            options={{
              maskType: "BRL",
              withDDD: true,
              dddMask: "(999) 999-9999",
            }}
            style={[styles.textInput, !!error && styles.error, disabled && styles.disabled, style]}
            placeholder={placeholder}
            placeholderTextColor={colors.common.gray4}
            maxLength={14}
            textContentType={"telephoneNumber"}
            dataDetectorTypes={"phoneNumber"}
            includeRawValueInChangeText={true}
            editable={!disabled && editable}
            onSubmitEditing={onSubmitEditing}
            //pointerEvents={"none"}
          />
        ) : (
          <TextInput
            style={[styles.textInput, !!error && styles.error, disabled && styles.disabled, style]}
            value={value}
            onChangeText={onChangeText}
            editable={!disabled && editable}
            multiline={multiline}
            onSubmitEditing={onSubmitEditing}
            placeholder={placeholder}
            placeholderTextColor={colors.common.gray4}
            keyboardType={keyboardType}
            //pointerEvents={"none"}
          />
        )}
        {!!error && <Typography style={styles.errorText}>{error}</Typography>}
      </React.Fragment>
    </Pressable>
  )
}
