import { StatusBar as RNStausBar, ColorValue, useColorScheme } from "react-native"

import { useColors } from "@utils/hooks"

interface Props {
  backgroundColor?: ColorValue
}

export const StatusBar = ({ backgroundColor }: Props) => {
  const colors = useColors()

  const scheme = useColorScheme()
  const isLightTheme = scheme === "light"

  return (
    <RNStausBar
      barStyle={isLightTheme ? "dark-content" : "light-content"}
      backgroundColor={backgroundColor ?? colors.background}
    />
  )
}
