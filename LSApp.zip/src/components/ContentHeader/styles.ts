import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  mainContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 10,
    alignItems: "center",
  },
  title: {
    fontWeight: "500",
    fontSize: 20,
  },
}))
