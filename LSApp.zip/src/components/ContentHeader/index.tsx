import { View, Text, useColorScheme, Pressable } from "react-native"
import React from "react"
import { useStyles } from "./styles"
import { Typography } from "../Typography"
import { Icon } from "../Icon"
import { colors } from "@utils/constants"

interface ContentHeaderProps {
  title: string
  onPress?: () => {}
}

export const ContentHeader: React.FC<ContentHeaderProps> = ({ title, onPress }) => {
  const styles = useStyles()
  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"
  const reviewIconDark = isLightTheme ? "helpSquareBlack" : "helpSquare"
  return (
    <View style={styles.mainContainer}>
      <Typography style={styles.title}>{title}</Typography>
      <Pressable onPress={onPress}>
        <Icon name={reviewIconDark} fill={colors.common.white} />
      </Pressable>
    </View>
  )
}
