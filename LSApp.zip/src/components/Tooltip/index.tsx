import Tooltip from "react-native-walkthrough-tooltip"
import { Typography } from "../Typography"
import { colors } from "@utils/constants"
import { useColorScheme } from "react-native"

interface props{
    children:any,
    isVisible:boolean,
    onClose:()=>void,
    Text:string,
    location:any
}
export const CustomTooltip = ({children, isVisible, onClose, Text, location}:props) =>{
    const systemColorScheme = useColorScheme()
    const isLightTheme = systemColorScheme === "light"
    return (
                <Tooltip
                    isVisible={isVisible}
                    content={<Typography style={{color:isLightTheme?"#fff":"#000"}}>{Text}</Typography>}
                    placement={location}
                    onClose={onClose}
                    contentStyle={{backgroundColor:isLightTheme?colors.common.dark:"#fff"}}
                >
                    {children}
                </Tooltip>
    )
}