import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, width }) => ({
  buttonContainer: {
    backgroundColor: colors.orangePrimary,
    paddingVertical: 6,
    width: width * 0.85,
    minHeight: 56,
    alignItems: "center",
    borderRadius: 50,
    flexDirection: "row",
    justifyContent: "center",
    alignSelf: "center",
    gap: 8,
  },
  label: {
    fontSize: 16,
    fontWeight: "500",
    color: colors.white,
    textTransform: "capitalize",
  },
  rightIcon: {
    position: "absolute",
    right: 16,
  },
  icon: {},
  disabled: {
    backgroundColor: colors.gray5,
  },
}))
