import { ActivityIndicator, StyleProp, TouchableOpacity, ViewStyle } from "react-native"

import { colors } from "@utils/constants"

import { useStyles } from "./style"
import { Icon } from "../Icon"
import { Typography } from "../Typography"

interface Props {
  onPress: () => void
  disabled?: boolean
  label: string
  right?: IconName
  btnStyle?: StyleProp<ViewStyle>
  labelStyle?: StyleProp<ViewStyle>
  icon?: IconName
  isLoading?: boolean
}

export const Button = ({
  onPress,
  disabled,
  label,
  right,
  btnStyle,
  labelStyle,
  icon,
  isLoading,
  ...rest
}: Props) => {
  const styles = useStyles()

  const getRight = () => {
    if (!right) return null
    return <Icon style={styles.rightIcon} name={right} />
  }
  const getIcon = () => {
    if (!icon) return null
    return <Icon style={styles.icon} name={icon} />
  }

  return (
    <TouchableOpacity
      style={[styles.buttonContainer, btnStyle, disabled && styles.disabled]}
      onPress={onPress}
      disabled={disabled}
      {...rest}
    >
      {getIcon()}
      {isLoading ? (
        <ActivityIndicator size="small" color={colors.common.white} />
      ) : (
        <Typography style={[styles.label, labelStyle]}>{label}</Typography>
      )}
      {getRight()}
    </TouchableOpacity>
  )
}
