import { withStyles } from "@utils/hocs";

export const useStyles = withStyles(({ colors, height, isDarkTheme }) => ({
    container: {
        marginVertical: 10,
        overflow: "hidden",
    },
    dropdown: {
        borderWidth: 1,
        borderColor: colors.gray6,
        paddingHorizontal: 24,
        paddingVertical: 16,
        borderRadius: 8,
        backgroundColor: colors.background,
        flexDirection: "row",
        justifyContent: "space-between",
    },
    dropdownText: {
        color: colors.gray4,
    },
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modalContent: {
        width: '80%',
        backgroundColor: colors.background,
        borderRadius: 5,
        maxHeight: '50%',
    },
    option: {
        padding: 15,
        borderBottomWidth: 1,
        borderBottomColor: colors.gray6,
    },
    optionText: {
        color: colors.black,
    },
    errorMessage: {
        color: colors.red
    },
    label:{
        color:isDarkTheme? colors.white : colors.dark
    }
}))