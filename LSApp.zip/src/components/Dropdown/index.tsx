import React, { useState } from 'react';
import {
    FlatList,
    Modal,
    Pressable,
    useColorScheme,
    View,
} from 'react-native';
import { Icon } from '../Icon';
import { Typography } from '../Typography';
import { useStyles } from './styles';
import { colors } from '@utils/constants';

interface Option {
    label: string;
    value: string;
}

interface CustomDropdownProps {
    options: Option[];
    placeholder: string;
    value: string;
    onValueChange: (value: string) => void;
}

const CustomDropdown: React.FC<CustomDropdownProps> = ({
    options,
    placeholder,
    value,
    onValueChange,
}) => {
    const [visible, setVisible] = useState(false);
    const styles = useStyles();

    const handleSelect = (item: Option) => {
        onValueChange(item.value);
        setVisible(false);
    };
    
    const isDarkTheme = useColorScheme() === "dark"
    const selectedLabel = options.find(option => option.value === value)?.label;

    return (
        <View style={styles.container}>
            <Pressable style={styles.dropdown} onPress={() => setVisible(true)}>
                <Typography style={{ color: selectedLabel ? isDarkTheme?colors.common.white:colors.common.dark : colors.common.gray4 }}>
                    {selectedLabel ? selectedLabel : placeholder}
                </Typography>
                <Icon name={isDarkTheme ? "chevronDownWhite" : "chevronDown"} />
            </Pressable>

            <Modal
                transparent={true}
                visible={visible}
                onRequestClose={() => setVisible(false)}
            >
                <Pressable
                    style={styles.modalOverlay}
                    onPress={() => setVisible(false)}
                >
                    <View style={styles.modalContent}>
                        <FlatList
                            data={options}
                            keyExtractor={(item) => item?.value}
                            showsVerticalScrollIndicator={false}
                            renderItem={({ item }) => (
                                <Pressable
                                    style={styles.option}
                                    onPress={() => handleSelect(item)}
                                >
                                    <Typography type='default'>{item.label}</Typography>
                                </Pressable>
                            )}
                        />
                    </View>
                </Pressable>
            </Modal>
        </View>
    );
};

export default CustomDropdown;
