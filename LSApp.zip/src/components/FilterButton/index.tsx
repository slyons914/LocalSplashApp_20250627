import { useState } from "react"

import { TouchableOpacity, useColorScheme } from "react-native"

import { Icon, Typography } from "@components"
import { AnalyticsModal } from "@modals"
import { DateFilter } from "@models"

import { useStyles } from "./styles"

interface FilterButtonProps {
  setDateFilter: (filter: DateFilter) => void
}

export const FilterButton: React.FC<FilterButtonProps> = ({ setDateFilter }) => {
  const styles = useStyles()
  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"

  const [analyticsModal, setAnalyticsModal] = useState(false)

  const [analyticsLabel, setAnalyticsLabel] = useState<string>("All time")

  return (
    <>
      <TouchableOpacity onPress={() => setAnalyticsModal(true)} style={styles.filterBtn}>
        <Typography type={"subtext"}>{analyticsLabel}</Typography>
        <Icon name={isLightTheme ? "chevronDown" : "chevronDownWhite"} height={17} width={17} />
      </TouchableOpacity>

      <AnalyticsModal
        isVisible={analyticsModal}
        onClose={() => setAnalyticsModal(false)}
        setDateFilter={setDateFilter}
        setAnalyticsLabel={setAnalyticsLabel}
      />
    </>
  )
}
