import { StyleProp, TouchableOpacity, View, ViewStyle } from "react-native"

import { Icon } from "@components"

import { useStyles } from "./styles"

interface Props {
  playing?: boolean
  loading: boolean
  muted?: boolean
  repeat?: boolean
  onPlaybackToggle: () => void
  onRewind: (value: number) => void
  onVolumeToggle: () => void
  onRepeatToggle: () => void
  style?: StyleProp<ViewStyle>
}

interface Action {
  icon: IconName
  onPress: () => void
  style?: StyleProp<ViewStyle>
}

export const Actions = ({
  playing,
  loading,
  muted,
  repeat,
  onVolumeToggle,
  onPlaybackToggle,
  onRepeatToggle,
  onRewind,
  style,
}: Props) => {
  const styles = useStyles()

  const actions: Array<Action> = [
    {
      icon: muted ? "noVolume" : "volume",
      onPress: onVolumeToggle,
      style: !muted && styles.disabled,
    },
    {
      icon: "goBackward",
      onPress: () => onRewind(-15),
    },
    {
      icon: playing ? "pause" : "play",
      onPress: onPlaybackToggle,
      style: loading && styles.disabled,
    },
    {
      icon: "goForward",
      onPress: () => onRewind(15),
    },
    {
      icon: "repeat",
      onPress: onRepeatToggle,
      style: !repeat && styles.disabled,
    },
  ]

  const renderAction = ({ icon, onPress, style }: Action, index: number) => {
    return (
      <TouchableOpacity key={index} disabled={loading} onPress={onPress} style={style}>
        <Icon name={icon} />
      </TouchableOpacity>
    )
  }

  return <View style={[styles.container, style]}>{actions.map(renderAction)}</View>
}
