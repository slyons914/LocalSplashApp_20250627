import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(() => ({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  disabled: {
    opacity: 0.3,
  },
}))
