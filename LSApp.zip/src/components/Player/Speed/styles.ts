import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets, width }) => ({
  modal: {
    margin: 0,
  },
  container: {
    width: 126,
    paddingLeft: 12,
    paddingRight: 8,
    paddingVertical: 4,
    borderWidth: 1,
    borderRadius: 42,
    borderColor: `${colors.white}30`,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  text: {
    fontSize: 14,
    fontWeight: "400",
    color: colors.white,
  },
  menu: {
    width: width * 0.6,
    borderRadius: 12,
    position: "absolute",
    alignSelf: "center",
    backgroundColor: colors.white,
    bottom: (insets.bottom || 16) + 30 + 20,
  },
  menuItem: {
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  menuItemText: {
    color: colors.dark,
  },
  separator: {
    height: 1,
    backgroundColor: `${colors.black}36`,
  },
}))
