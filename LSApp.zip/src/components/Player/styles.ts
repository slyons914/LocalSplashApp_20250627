import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    paddingTop: 28,
    paddingHorizontal: 24,
    paddingBottom: insets.bottom || 16,
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    backgroundColor: colors.blue,
  },
  handle: {
    width: 36,
    height: 5,
    borderRadius: 36,
    backgroundColor: `${colors.white}30`,
    alignSelf: "center",
    position: "absolute",
    top: 5,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    flex: 1,
    textAlign: "center",
    fontSize: 16,
    fontWeight: "500",
    color: colors.white,
  },
  closeIcon: {
    position: "absolute",
    right: 0,
  },
  actions: {
    marginTop: 30,
    marginBottom: 20,
  },
  timeContainer: {
    marginTop: 8,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  time: {
    color: colors.white,
  },
  speed: {
    marginTop: 16,
    alignSelf: "center",
  },
}))
