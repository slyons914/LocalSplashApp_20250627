import { useEffect, useState } from "react"

import { TouchableOpacity, View } from "react-native"

import Modal from "react-native-modal"
import TrackPlayer, { RepeatMode } from "react-native-track-player"

import { usePlayer } from "@providers"
import { colors } from "@utils/constants"
import { FormatHelper } from "@utils/helpers"

import { Actions } from "./Actions"
import { Speed } from "./Speed"
import { useStyles } from "./styles"
import { Icon } from "../Icon"
import { Slider } from "../Slider"
import { Typography } from "../Typography"

interface Props {
  visible: boolean
  onClose: () => void
}

export const Player = ({ visible, onClose }: Props) => {
  const [progress, setProgress] = useState(0)
  const [isMuted, setIsMuted] = useState(false)
  const [isRepeat, setIsRepeat] = useState(false)
  const [speed, setSpeed] = useState(1)

  const { playing, loading, position, duration, track } = usePlayer()

  const styles = useStyles()

  useEffect(() => {
    setProgress((position / duration) * 100)
  }, [position, duration])

  const onPlaybackToggle = () => {
    playing ? TrackPlayer.pause() : TrackPlayer.play()
  }

  const onRewind = (time: number) => {
    const newPosition = Math.min(Math.max(position + time, 0), duration)
    setProgress((newPosition / duration) * 100)
    TrackPlayer.seekTo(newPosition)
  }

  const onVolumeToggle = () => {
    const newIsMuted = !isMuted
    setIsMuted(newIsMuted)
    TrackPlayer.setVolume(newIsMuted ? 0 : 1)
  }

  const onRepeatToggle = () => {
    const newIsRepeat = !isRepeat
    setIsRepeat(newIsRepeat)
    TrackPlayer.setRepeatMode(newIsRepeat ? RepeatMode.Track : RepeatMode.Off)
  }

  const onProgressChangeStop = (value: number) => {
    TrackPlayer.seekTo(duration * (value / 100))
  }

  const onSpeedChange = (value: number) => {
    setSpeed(value)
    TrackPlayer.setRate(value)
  }

  const handleModalClosePress = () => {
    onClose()
    TrackPlayer.stop()
  }

  return (
    <Modal isVisible={visible} hasBackdrop={false} coverScreen={false} style={styles.modal}>
      <View style={styles.container}>
        <View style={styles.handle} />
        <View style={styles.header}>
          <Typography style={styles.title}>{`${track?.leadName || ""} Call Recording`}</Typography>
          <TouchableOpacity hitSlop={10} onPress={handleModalClosePress} style={styles.closeIcon}>
            <Icon name={"remove"} stroke={colors.common.white} strokeWidth={2} />
          </TouchableOpacity>
        </View>
        <Actions
          playing={playing}
          loading={loading}
          muted={isMuted}
          repeat={isRepeat}
          onRepeatToggle={onRepeatToggle}
          onPlaybackToggle={onPlaybackToggle}
          onVolumeToggle={onVolumeToggle}
          onRewind={onRewind}
          style={styles.actions}
        />
        <Slider value={progress} onChangeStop={onProgressChangeStop} />
        <View style={styles.timeContainer}>
          <Typography style={styles.time}>{FormatHelper.formatTimeToDuration(position)}</Typography>
          <Typography style={styles.time}>{FormatHelper.formatTimeToDuration(duration)}</Typography>
        </View>
        <Speed speed={speed} onChange={onSpeedChange} style={styles.speed} />
      </View>
    </Modal>
  )
}
