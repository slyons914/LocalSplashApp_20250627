import { PropsWithChildren } from "react"

import { StyleProp, TextStyle, Text } from "react-native"

import { useStyles } from "./styles"

interface Props {
  type?: "title" | "subtext" | "default"
  onPress?: () => void
  style?: StyleProp<TextStyle>
  numberOfLines?: number
}

export const Typography = ({
  style,
  type = "default",
  onPress,
  children,
  numberOfLines,
}: PropsWithChildren<Props>) => {
  const styles = useStyles()

  return (
    <Text
      onPress={onPress}
      style={[styles.common, styles[type], style]}
      numberOfLines={numberOfLines}
      allowFontScaling={false}
    >
      {children}
    </Text>
  )
}
