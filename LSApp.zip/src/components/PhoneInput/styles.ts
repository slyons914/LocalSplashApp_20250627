import { Platform } from "react-native"

import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme }) => ({
  container: {
    backgroundColor: isDarkTheme ? colors.darklightBackground : colors.white,
    borderRadius: 12,
    paddingHorizontal: 24,
    flexDirection: "row",
    gap: 32,
    alignItems: "center",
    minHeight: 50,
    borderWidth: 1,
    borderColor: isDarkTheme ? colors.darklightBackground : colors.grey,
  },
  countryCode: {
    color: colors.title,
    fontSize: 16,
    marginTop: Platform.OS === "android" ? 4 : 0,
  },
  textInput: {
    flex: 1,
    color: colors.title,
    fontSize: 16,
    paddingVertical: Platform.OS === "ios" ? 8 : 0,
  },
}))
