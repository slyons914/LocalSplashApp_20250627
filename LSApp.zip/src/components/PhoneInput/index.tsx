import { useColorScheme, View } from "react-native"

import { TextInputMask } from "react-native-masked-text"

import { colors } from "@utils/constants"

import { useStyles } from "./styles"
import { Typography } from "../Typography"

interface Props {
  value: string
  handleChangePhone: (text: string, rawPhone: string | undefined) => void
  onSubmitEditing: () => void
}

export const PhoneInput = ({ value, handleChangePhone, onSubmitEditing }: Props) => {
  const styles = useStyles()

  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"

  return (
    <View style={styles.container}>
      <Typography style={styles.countryCode}>+1</Typography>
      <TextInputMask
        onChangeText={(text, rawText) => handleChangePhone(text, rawText)}
        onSubmitEditing={onSubmitEditing}
        value={value}
        type={"cel-phone"}
        options={{
          maskType: "BRL",
          withDDD: true,
          dddMask: "(999) 999-9999",
        }}
        style={styles.textInput}
        placeholder={"Your phone number"}
        placeholderTextColor={isLightTheme ? colors.common.grey : colors.common.white}
        maxLength={14}
        textContentType={"telephoneNumber"}
        dataDetectorTypes={"phoneNumber"}
        includeRawValueInChangeText={true}
      />
    </View>
  )
}
