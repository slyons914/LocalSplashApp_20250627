import { RTCPeerConnection, RTCSessionDescription, RTCIceCandidate, mediaDevices } from 'react-native-webrtc';

global.window = global.window || {};
global.window.RTCPeerConnection = RTCPeerConnection;
global.window.RTCSessionDescription = RTCSessionDescription;
global.window.RTCIceCandidate = RTCIceCandidate;
global.navigator = global.navigator || {};
global.navigator.mediaDevices = mediaDevices;
