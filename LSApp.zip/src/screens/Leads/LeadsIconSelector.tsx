import React from "react"

import { Icon } from "@components"
import { LeadListItem, LeadLogType } from "@models/leads"

import { useStyles } from "./styles"

interface Props {
  item: LeadListItem
}

export const LeadsIconSelector = ({ item }: Props) => {
  const styles = useStyles()

  switch (item.lastLeadStructure) {
    case LeadLogType.Website: {
      return (
        <Icon
          name={item.isBlocked ? "webLeadBlocked" : "webLead"}
          height={50}
          width={50}
          style={styles.leadIconSpacing}
        />
      )
    }
    case LeadLogType.Call:
      return (
        <Icon
          name={item.isBlocked ? "leadsPhoneBlocked" : "leadsPhone"}
          height={50}
          width={50}
          style={styles.leadIconSpacing}
        />
      )

    case LeadLogType.Sms:
      return (
        <Icon
          name={item.isBlocked ? "leadsSmsBlocked" : "smsIcon"}
          height={50}
          width={50}
          style={styles.leadIconSpacing}
        />
      )
      case LeadLogType.PulseCall:
      return (
        <Icon
          name={item.isBlocked ? "leadsPhoneBlocked" : "leadsPhone"}
          height={50}
          width={50}
          style={styles.leadIconSpacing}
        />
      )
      case LeadLogType.TychromSms:
      return (
        <Icon
          name={item.isBlocked ? "leadsSmsBlocked" : "smsIcon"}
          height={50}
          width={50}
          style={styles.leadIconSpacing}
        />
      )
      case LeadLogType.GoogleGuaranteedAds:
      return (
        <Icon
          name={item.isBlocked ? "leadsGoogleAdsBlocked" : "leadsGoogleAds"}
          height={50}
          width={50}
          style={styles.leadIconSpacing}
        />
      )
      case LeadLogType.GoogleGuaranteedMessage:
      return (
        <Icon
          name={item.isBlocked ? "leadsGoogleAdsBlocked" : "leadsGoogleAds"}
          height={50}
          width={50}
          style={styles.leadIconSpacing}
        />
      )
      case LeadLogType.GoogleGuaranteedBooking:
      return (
        <Icon
          name={item.isBlocked ? "leadsGoogleAdsBlocked" : "leadsGoogleAds"}
          height={50}
          width={50}
          style={styles.leadIconSpacing}
        />
      )
      case LeadLogType.FacebookForm:
      return (
        <Icon
          name={item.isBlocked ? "leadsFacebookBlock" : "leadsFacebook"}
          height={50}
          width={50}
          style={styles.leadIconSpacing}
        />
      )
      case LeadLogType.FacebookMessenger:
      return (
        <Icon
          name={item.isBlocked ? "leadsFacebookBlock" : "leadsFacebook"}
          height={50}
          width={50}
          style={styles.leadIconSpacing}
        />
      )
    default:
      return (
        <Icon 
          name={"leadsPhone"} 
          height={50} 
          width={50} 
          style={styles.leadIconSpacing} 
        />
      )
  }
}
