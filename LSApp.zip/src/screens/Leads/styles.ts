import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  leadsHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  leadsHeaderName: {
    fontSize: 24,
    fontWeight: "600",
  },
  statusLead: {
    height: "100%",
    width:"30%"
  },
  leadName: {
    fontSize: 20,
    fontWeight: "500",
    lineHeight: 25,
  },
  spam: {
    marginTop: 10,
  },
  spamblock: {
    marginTop: 15,
  },
  headerContainer: {
    paddingHorizontal: 24,
    paddingBottom: 16,
  },
  pageNameContainer: {
    flexDirection:"row", 
    gap:16, 
    marginTop:16, 
    alignItems:"center"
  },
  pageName: {
    fontSize:24, 
    fontWeight: "600"
  },
  leadIcon: {
    flexDirection: "column",
    height: "100%",
  },
  leadIconSpacing: {
    marginRight: 8,
  },
  filterBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 8,
    paddingLeft: 12,
    paddingRight: 8,
    borderWidth: 2,
    borderColor: colors.greyLight,
    borderRadius: 42,
    gap: 8,
  },
  filterTitle: {
    color: colors.title
  },
  leadItemContainer: {
    paddingHorizontal: 20,
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
    paddingVertical:8
  },
  leadTitle: {
    width: "65%",
  },
  leadItemReadedContainer: {
    borderColor: colors.orangePrimary,
    borderLeftWidth: 3.5,
    paddingHorizontal: 16.5,
    backgroundColor: isDarkTheme ? colors.darklightBackground : colors.orangeLight,
  },
  dateText: {
    color: colors.greyText,
    marginTop: 10,
  },
  blocked: {
    color: colors.greyText,
  },
  spamBadge: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 50,
    borderColor: colors.red,
    justifyContent: "center",
    width: 90,
  },
  spamText: {
    color: colors.red,
  },
  errorText:{
    textAlign:"center",
    color: colors.red,
    fontWeight:"500"
  },
  largeText:{
    fontSize:18
  },
  list: {
    paddingBottom:140
  },
  leadStatusView: {
    marginTop:8,
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 36,
    alignSelf: "flex-start",

  },
  leadStatusText: {
    color: colors.white
  },
  leadAmount: {
    marginTop:4, 
    fontWeight:"500"
  },
  notesIconView: {
    gap:16, 
    flexDirection:"row",
    width:"70%",
    justifyContent:"flex-end",
  }
}))
