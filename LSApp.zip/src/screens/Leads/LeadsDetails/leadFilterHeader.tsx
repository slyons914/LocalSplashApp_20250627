import { Pressable, ScrollView, View } from "react-native"
import { useLeadContext } from "@providers"
import { Icon, Typography } from "@components"
import { useColors } from "@utils/hooks"
import { useStyles } from "./styles"
import { LeadFilters } from "@models/leads"


export const LeadFilterHeader = () => {
    const { filters, activeDate, setFilters, setActiveDate } = useLeadContext()
    const { blue, redText, dark, blueDark, green } = useColors()

    const styles  = useStyles()

    const getValueFromActiveDate = () => {
        switch (activeDate) {
            case 1:
                return 'All Time'
            case 2:
                return 'Last 7 Days'
            case 3:
                return 'Last 30 Days'
            case 4:
                return 'Last 3 Months'
            case 5:
                return 'Last 6 Months'
        }
    }
    const setTypeHandler = (key: keyof LeadFilters) => {
          const newFilter:LeadFilters = {
              ...filters,
              [key] : !filters[key]
          }
          setFilters(newFilter)
    }

    const handleTimeFilterRemovePress = () => {
        setFilters({
            ...filters,
            FromDate: null,
            ToDate: null
        })
        setActiveDate(1)
    }
    return (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterScrollView}>
            {
                filters?.AreCallLeadLogsIncluded &&
                <Pressable style={[styles.leadFilterView, styles.leadTypeFilter]}>
                    <Pressable hitSlop={10} onPress={() => setTypeHandler("AreCallLeadLogsIncluded")}>
                        <Icon name={"remove"} stroke={blue} />
                    </Pressable>
                    <Typography style={styles.leadTypeText}>Phone Call</Typography>
                </Pressable>
            }
            {
                filters?.AreSmsLeadLogsIncluded &&
                <Pressable style={[styles.leadFilterView, styles.leadTypeFilter]}>
                    <Pressable hitSlop={10} onPress={() => setTypeHandler("AreSmsLeadLogsIncluded")}>
                        <Icon name={"remove"} stroke={blue} />
                    </Pressable>
                    <Typography style={styles.leadTypeText}>SMS</Typography>
                </Pressable>
            }
            {
                filters?.AreWebsiteFormLeadLogsIncluded &&
                <Pressable style={[styles.leadFilterView, styles.leadTypeFilter]}>
                    <Pressable hitSlop={10} onPress={() => setTypeHandler("AreWebsiteFormLeadLogsIncluded")}>
                        <Icon name={"remove"} stroke={blue} />
                    </Pressable>
                    <Typography style={styles.leadTypeText}>Website</Typography>
                </Pressable>
            }
            {
                filters?.AreFacebookLeadLogsIncluded &&
                <Pressable style={[styles.leadFilterView, styles.leadTypeFilter]}>
                    <Pressable hitSlop={10} onPress={() => setTypeHandler("AreFacebookLeadLogsIncluded")}>
                        <Icon name={"remove"} stroke={blue} />
                    </Pressable>
                    <Typography style={styles.leadTypeText}>Facebook Ads</Typography>
                </Pressable>
            }
            {
                filters?.AreGoogleLeadLogsIncluded &&
                <Pressable style={[styles.leadFilterView, styles.leadTypeFilter]}>
                    <Pressable hitSlop={10} onPress={() => setTypeHandler("AreGoogleLeadLogsIncluded")}>
                        <Icon name={"remove"} stroke={blue} />
                    </Pressable>
                    <Typography style={styles.leadTypeText}>Google Guaranteed Ads</Typography>
                </Pressable>
            }
            {
                filters?.isSpam &&
                <Pressable style={[styles.leadFilterView, styles.leadSpamFilter]}>
                    <Pressable hitSlop={10} onPress={() => setTypeHandler("isSpam")}>
                        <Icon name={"remove"} stroke={redText} />
                    </Pressable>
                    <Typography style={styles.leadSpamText}>Spam</Typography>
                </Pressable>
            }
            {
                filters?.isBlocked &&
                <Pressable style={[styles.leadFilterView, styles.leadBlockFilter]}>
                    <Pressable hitSlop={10} onPress={() => setTypeHandler("isBlocked")}>
                        <Icon name={"remove"} stroke={dark} />
                    </Pressable>
                    <Typography style={styles.leadBlockText}>Blocked</Typography>
                </Pressable>
            }
            {
                activeDate !== 1 &&
                <Pressable style={[styles.leadFilterView, styles.leadTimeFilter]}>
                    <Pressable hitSlop={10} onPress={handleTimeFilterRemovePress}>
                        <Icon name={"remove"} stroke={blueDark} />
                    </Pressable>
                    <Typography style={styles.leadTimeText}>{activeDate === 6 ? `${filters?.FromDate} to ${filters?.ToDate}` :getValueFromActiveDate()}</Typography>
                </Pressable>
            }
            {
                filters?.AreCompletedLeadsIncluded &&
                <Pressable style={[styles.leadFilterView, styles.leadStatusFilter]}>
                    <Pressable hitSlop={10} onPress={() => setTypeHandler("AreCompletedLeadsIncluded")}>
                        <Icon name={"remove"} stroke={green} />
                    </Pressable>
                    <Typography style={styles.leadFilterStatusText}>Completed</Typography>
                </Pressable>
            }
            {
                filters?.AreNotInterestedLeadsIncluded &&
                <Pressable style={[styles.leadFilterView, styles.leadStatusFilter]}>
                    <Pressable hitSlop={10} onPress={() => setTypeHandler("AreNotInterestedLeadsIncluded")}>
                        <Icon name={"remove"} stroke={green} />
                    </Pressable>
                    <Typography style={styles.leadFilterStatusText}>Not Interested</Typography>
                </Pressable>
            }
            {
                filters?.AreNoAnswerLeadsIncluded &&
                <Pressable style={[styles.leadFilterView, styles.leadStatusFilter]}>
                    <Pressable hitSlop={10} onPress={() => setTypeHandler("AreNoAnswerLeadsIncluded")}>
                        <Icon name={"remove"} stroke={green} />
                    </Pressable>
                    <Typography style={styles.leadFilterStatusText}>No Answer</Typography>
                </Pressable>
            }
            {
                filters?.AreFollowUpNeededLeadsIncluded &&
                <Pressable style={[styles.leadFilterView, styles.leadStatusFilter]}>
                    <Pressable hitSlop={10} onPress={() => setTypeHandler("AreFollowUpNeededLeadsIncluded")}>
                        <Icon name={"remove"} stroke={green} />
                    </Pressable>
                    <Typography style={styles.leadFilterStatusText}>Follow-Up Needed</Typography>
                </Pressable>
            }
            {
                filters?.AreNotaValidLeadsIncluded &&
                <Pressable style={[styles.leadFilterView, styles.leadStatusFilter]}>
                    <Pressable hitSlop={10} onPress={() => setTypeHandler("AreNotaValidLeadsIncluded")}>
                        <Icon name={"remove"} stroke={green} />
                    </Pressable>
                    <Typography style={styles.leadFilterStatusText}>Not a Valid Lead</Typography>
                </Pressable>
            }
            {
                filters?.AreScheduledLeadsIncluded &&
                <Pressable style={[styles.leadFilterView, styles.leadStatusFilter]}>
                    <Pressable hitSlop={10} onPress={() => setTypeHandler("AreScheduledLeadsIncluded")}>
                        <Icon name={"remove"} stroke={green} />
                    </Pressable>
                    <Typography style={styles.leadFilterStatusText}>Scheduled</Typography>
                </Pressable>
            }
        </ScrollView>
    )
}