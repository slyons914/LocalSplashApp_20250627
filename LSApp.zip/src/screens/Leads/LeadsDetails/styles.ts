import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: 24,
    paddingTop:20
  },
  listHeaderContainer: {
    gap:18
  },
  headerSubview: {
    gap:14
  },
  blueContainer: {
    paddingVertical: 16,
    paddingLeft: 16,
    paddingRight: 8,
    backgroundColor: colors.backgroundSecondary,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderRadius: 8,
  },
  infoBoxItem: {
    flexDirection: "row",
    alignItems: "center",
  },
  infoPhone: {
    marginLeft: 12,
    fontSize: 20,
    fontWeight: "500",
  },
  infoText: {
    marginLeft: 12,
    fontSize: 16,
  },
  list: {   
  },
  timelineItem: {
    flexDirection: "row",
    alignItems: "flex-start",
  },
  line: {
    width: 1,
    backgroundColor: colors.subText,
    height: "100%",
    marginLeft: 5,
  },
  dotContainer: {
    position: "absolute",
    left: 0,
    width: "100%",
    flexDirection: "row",
    gap: 20,
    marginBottom:16,
    paddingBottom:18
  },
  dot: {
    width: 10,
    height: 10,
    backgroundColor: colors.subText,
    borderRadius: 5,
  },
  date: {
    alignSelf:"flex-start",
    fontWeight: "bold",
    color: colors.subText,
  },

  historyItemTitle: {
    color: colors.subText,

    fontSize: 18,
    fontWeight: "bold",
  },
  description: {
    color: colors.subText,
    marginTop: 5,
  },
  historyTitle: {
    marginBottom: 30,
    marginTop:20,
    fontSize: 20,
    fontWeight: "500",
  },
  title: {
    fontSize: 20,
  },
  historyTitleAmount: {
    fontSize: 14,
    fontWeight: "400",
  },
  historyItemTypeContainer: {
    backgroundColor: colors.blue,
    flexDirection: "row",
    borderRadius: 4,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  historyItemTypeLabel: {
    color: colors.white,
    fontSize: 14,
    fontWeight: "600",
    paddingLeft: 8,
  },
  historyItemStatus: {
    flexDirection: "row",
    borderRadius: 4,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  historyStatusReadLabel: {
    fontSize: 14,
    fontWeight: "500",
    paddingLeft: 4,
  },
  historyStatusUnreadLabel: {
    color: colors.red,
    fontSize: 14,
    fontWeight: "500",
    paddingLeft: 4,
  },

  statusLabelContainer: {
    marginTop: 12,
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 4,
    backgroundColor: colors.black,
    alignItems: "center",
    alignSelf: "flex-start",
  },
  statusLabelText: {
    color: colors.white,
  },
  historyItemContainer: {
    flex: 1,
    marginLeft: 10,
    padding: 10,
    marginVertical: 30,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 8,
  },
  tagListContainer: {
    marginTop:8,
    borderWidth: 1,
    borderColor: colors.blue,
    borderRadius:4,
    paddingHorizontal:8,
    paddingVertical:4,
    alignSelf:"flex-start"
  },
  tagLineText: {
    color:colors.blue
  },
  mediumFont: {
    fontSize: 16
  },
  boldFont: {
    fontWeight: "500"
  },
  blueSubView: {
    flexDirection: "row",
    gap:8
  },
  lightText: {
    color: colors.subText
  },
  orangeText: {
    color: colors.orangePrimary,
    fontWeight: "500"
  },
  blueText: {
    color: colors.blue,
    fontWeight: "500"
  },
  notesContainer: {
    gap: 18,
    marginTop: 8
  },
  notesContainerRow: {
    flexDirection: "row",
    gap:8,
    alignItems: "center"
  },
  notesHeading: {
    fontSize: 20,
    fontWeight: "500"
  },
  noNotesText: {
    textAlign: "center",
    color: colors.subText
  },
  notesTextView: {
    padding:16, 
    borderRadius:8,
    borderWidth:1, 
    borderColor: colors?.gray6
  },
  leadStatusView: {
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 20,
    alignSelf: "flex-start",
    flexDirection:"row",
    alignItems:"center",
    gap: 8
  },
  leadLogStatusView: {
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 20,
    alignItems:"center",
    position:'absolute',
    right:0,
    top:-8
  },
  leadStatusText: {
    color: colors.white
  },
  dotView: {
    height: 12, 
    width: 12,
    borderRadius: 6
  },
  dispositionView: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent:"space-between",
    gap: 8
  },
  statusText: {
    width:"55%"
  },
  leadLogDotView: {
    flexDirection:"row", 
    alignItems:'center',
    gap:4
  },
  leadFilterView: {
    borderRadius: 42,
    flexDirection: 'row',
    gap: 6,
    paddingVertical: 2,
    borderWidth: 1,
    paddingRight: 12,
    paddingLeft: 4,
    alignItems: 'center'
  },
  filterScrollView: {
    gap: 4,
    marginTop: 12
  },
  leadTypeFilter: {
    borderColor: colors.blue
  },
  leadTypeText: {
    color: colors.blue
  },
  leadSpamFilter: {
    borderColor: colors.redText
  },
  leadSpamText: {
    color: colors.redText
  },
  leadBlockFilter: {
    borderColor: colors.blocked
  },
  leadBlockText: {
    color: colors.blocked
  },
  leadTimeFilter: {
    borderColor: colors.blueDark
  }, 
  leadTimeText: {
    color: colors.blueDark
  },
  leadStatusFilter: {
    borderColor: colors.green
  },
  leadFilterStatusText: {
    color: colors.green
  }
}))
