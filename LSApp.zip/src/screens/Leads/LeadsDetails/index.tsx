import { useEffect, useMemo, useState } from "react"

import { Pressable, TouchableOpacity, useColorScheme, View } from "react-native"

import { useNavigation } from "@react-navigation/native"
import { FlashList } from "@shopify/flash-list"
import { GetLeadLogsResponseViewModel, LeadLogDetailsViewModel } from "@localsplash/mobile-api-client"

import { LeadsAPI } from "@api"
import { Header, Icon, Typography } from "@components"
import { AddUpdateLeadAmountModal, AddUpdateLeadStatusModal, AddUpdateNotesModal, LeadsSpamBlockModal, RequestReviewModal } from "@modals"
import { Lead } from "@models/leads"
import { Routes } from "@utils/constants"
import { FormatHelper } from "@utils/helpers"
import { useColors } from "@utils/hooks"

import { LeadsBottomBar } from "./BottomBar"
import { HistoryItem } from "./HistoryItem/historyItem"
import { useStyles } from "./styles"
import { useStore } from "@store"
import { leadStatusColors } from "@utils/constants/common"

export const LeadsDetailsScreen = ({ route }: ScreenProps<Routes.LeadsDetails>) => {
  const { setOptions, goBack } = useNavigation()

  const { homeStore } = useStore()
  const { customerStatusTypes } = homeStore

  const [leadsDetails, setLeadsDetails] = useState<Lead | null>(null)
  const [loading, setLoading] = useState(false)
  const [requestModal, setRequestModal] = useState(false)
  const [spamBlockModal, setSpamBlockModal] = useState(false)
  const [leadLogs, setLeadLogs] = useState< GetLeadLogsResponseViewModel | null>()
  const [leadLogCurrentCount, setLeadLogCurrentCount] = useState(3)
  const [listRefreshing, setListRefreshing] = useState(false)
  const [leadStatus, setLeadStatus] = useState<string>()
  const [isLeadAmountModalVisible, setIsLeadAmountModalVisible] = useState(false)
  const [isLeadStatusModalVisible, setIsLeadStatusModalVisible] = useState(false)
  const [isLeadNotesModalVisible, setIsLeadNotesModalVisible] = useState(false)

  const isLightTheme = useColorScheme() === "light"
  
  const { id, profileItem, setLeadsList } = route.params

  const handleLeadBlocking = async (isBlocked: boolean) => {
    await LeadsAPI.setLeadStatus(profileItem?.id, id, {isBlocked: isBlocked})
    getLeadDetails()
  }

  const handleLeadSpamMarking = async (isSpam: boolean) => {
    await LeadsAPI.setLeadStatus(profileItem?.id, id, {isSpam: isSpam})
    getLeadDetails()
  }

  const handleAddAmount = async (amount: string | number) => {
    if(amount === '')
        amount = -1
    await LeadsAPI.setLeadStatus(profileItem?.id, id, {customerAmount: Number(amount)})
    await getLeadDetails()
  }

  const handleAddNotes = async (notes: string) => {
    await LeadsAPI.setLeadStatus(profileItem?.id, id, {customerNotes: notes})
    await getLeadDetails()
  }

  const handleAddLeadStatus = async (status: number) => {
    if(!leadLogs?.items)
        return;
    await LeadsAPI.setLeadStatus(profileItem?.id, id, {dispositionStatus: status} )
    await getLeadDetails()
  }


  const markLeadLogAsRead = (leadLogId: number | undefined, isRead:boolean) => { 
    setLeadLogs((prevState) => {
        if (!prevState) return prevState;
        const updatedItems = prevState?.items?.map((entry) => {
          if (entry.item && entry.item.leadLogId === leadLogId) {
            return {
              ...entry, 
              item: {
                ...entry.item,  
                isRead: isRead, 
              },
            };
          }
          return entry; 
        });
      
        return {
          ...prevState, 
          items: updatedItems,
        } as GetLeadLogsResponseViewModel;
      });
  }

  const updateLeadLog = async (id: number, logId: number, isRead:boolean, leadStructure: number | undefined) => {
    markLeadLogAsRead(logId, isRead)
    await LeadsAPI.setLeadsLogIsRead(profileItem?.id, id, logId, isRead, leadStructure)
  }

  const getLeadDetails = async () => {
    const { data } = await LeadsAPI.getLeadsDetails(id, profileItem?.id)
    setLeadsDetails(data)
  }

  const getAndMarkLeadsAsRead = async (id: string | number) => {
    setLoading(true)
    getLeadDetails()
    const {data: leadLogs} = await LeadsAPI.getLeadLogs(Number(id), profileItem?.id ?? 0, 0, 2)
    setLeadLogs(leadLogs)
    setLoading(false)
  }

  const getStatusNameById = (id: number) => {
    const status = customerStatusTypes?.items?.find(status => status.id === id);
    return status ? status.statusName : '';
  };

  const getLeadById = async () => {
    if(id && profileItem) {
        const leadById = await LeadsAPI.getLeadsDetails(id, profileItem?.id)
        setLeadsList(prevData => {
            return prevData.map(item => {
              if (item.id === leadById?.data?.id) {
                return {
                  ...item,
                  ...leadById?.data,
                };
              }
              return item;
            });
          });
    }
  }

  useEffect(() => {
    getAndMarkLeadsAsRead(id)
    return () => {
        getLeadById()
        setLeadsDetails(null)
    }
  }, [id])

  const sortedLeadsHistory = useMemo(() => {
    if (!leadLogs?.items) return []

    return leadLogs?.items
  }, [leadLogs])

  const styles = useStyles()

  const renderItem = ({
    item,
    index,
  }: {
    item:  LeadLogDetailsViewModel
    index: number
  }) => {
    return (
      <View style={styles.timelineItem}>
        {index + 1 !== sortedLeadsHistory.length && <View style={styles.line} />}
        <View style={styles.dotContainer}>
          <View style={styles.dot} />
          {item.item?.createdOn && (
            <Typography style={styles.date}>
              {FormatHelper.formatDate(item.item.createdOn, { time: true }, true)}
            </Typography>
          )}
        </View>
        {
            !item?.disposition && item.item?.dispositionStatus && item.item.dispositionStatus !==2 &&
            <View style={[styles.leadLogStatusView, leadStatusColors[item.item.dispositionStatus]]}>
                <Typography style={styles.leadStatusText}>
                    {getStatusNameById(item.item.dispositionStatus)}
                </Typography>
            </View>
        }
        <HistoryItem item={item} updateLeadLog={updateLeadLog} />
      </View>
    )
  }

    const ListHeader = () => {
        return (
            <View style={styles.listHeaderContainer}>
                <View style={styles.blueContainer}>
                    <View>
                        <Typography type={"title"} style={styles.title}>
                            {leadsDetails?.name}
                        </Typography>
                        {leadsDetails?.isBlocked && <Icon name={"blocked"} />}
                        {leadsDetails?.isSpam && <Icon name={"spam"} />}
                    </View>
                    <TouchableOpacity onPress={() => setSpamBlockModal(true)}>
                        <Icon name={"dotsVerticalDark"} stroke={text} />
                    </TouchableOpacity>
                </View>
                {
                    leadsDetails?.dispositionStatus && leadsDetails.dispositionStatus !== 2 &&
                    <Pressable onPress={() => setIsLeadStatusModalVisible(true)} style={[styles.leadStatusView, leadStatusColors[leadsDetails.dispositionStatus]]}>
                        <Typography style={styles.leadStatusText}>
                            {getStatusNameById(leadsDetails.dispositionStatus)}
                        </Typography>
                        <Icon name="chevronDownWhite"></Icon>
                    </Pressable>
                }
                {
                    leadsDetails?.dispositionStatus && leadsDetails.dispositionStatus === 2 &&
                    <Pressable onPress={() => setIsLeadStatusModalVisible(true)} style={[styles.leadStatusView, leadStatusColors[leadsDetails.dispositionStatus]]}>
                        <Typography style={styles.leadStatusText}>
                            Select option
                        </Typography>
                        <Icon name="chevronDownWhite"></Icon>
                    </Pressable>
                }
                <View style={styles.headerSubview}>
                    <View style={styles.infoBoxItem}>
                        <Icon name="smallPhone" stroke={text} />
                        <Typography type={"title"} style={styles.infoPhone}>
                            {leadsDetails?.phoneNumber
                                ? FormatHelper.formatPhoneNumber(leadsDetails.phoneNumber.toString())
                                : "--"}
                        </Typography>
                    </View>
                    <View style={styles.infoBoxItem}>
                        <Icon name="email" stroke={text} />
                        <Typography type={"title"} style={styles.infoText}>
                            {leadsDetails?.email || "--"}
                        </Typography>
                    </View>
                    <View style={styles.infoBoxItem}>
                        <Icon name="location" stroke={text} />
                        <Typography style={styles.infoText}>{leadsDetails?.streetAddress || "--"}</Typography>
                    </View>
                    <View style={styles.blueContainer}>
                        <View>
                            <Typography style={styles.mediumFont}>
                                Amount
                            </Typography>
                        </View>
                        {
                            leadsDetails?.customerAmount ? 
                           (<TouchableOpacity onPress={() => setIsLeadAmountModalVisible(true)} style={styles.blueSubView}>
                                <Typography style={[styles.mediumFont, styles.boldFont]}>{`$${leadsDetails.customerAmount}`}</Typography>
                                <Icon name={"editIconOrange"} stroke={text} />
                            </TouchableOpacity>) : 
                            (<TouchableOpacity onPress={() => setIsLeadAmountModalVisible(true)} style={styles.blueSubView}>
                                <Icon name={"OrangeAddIcon"} stroke={text} />
                                <Typography style={styles.orangeText}>Add</Typography>
                            </TouchableOpacity>)
                        }
                    </View>
                    <View style={styles.notesContainer}>
                        <View style={styles.notesContainerRow}>
                            <Icon name={isLightTheme ? "notesIcon" : "notesIconWhite"} ></Icon>
                            <Typography style={styles.notesHeading}>Notes</Typography>
                        </View>
                        {
                            leadsDetails?.customerNotes ? 
                            <Pressable onPress={() => setIsLeadNotesModalVisible(true)} style={styles.notesTextView}>
                                <Typography>{leadsDetails?.customerNotes}</Typography>
                            </Pressable> : 
                            <Typography style={styles.noNotesText}>No Notes Added</Typography>
                        }
                        <TouchableOpacity onPress={() => setIsLeadNotesModalVisible(true)} style={styles.notesContainerRow}>
                            <Icon name="OrangeAddIcon"></Icon>
                            <Typography style={[styles.orangeText, styles.mediumFont, styles.boldFont]}>Add Note</Typography>
                        </TouchableOpacity>
                    </View>
                    <Typography type={"title"} style={styles.historyTitle}>
                        {"History "}
                        <Typography style={styles.historyTitleAmount}>
                            ({leadLogs?.totalCount || 0} interactions)
                        </Typography>
                    </Typography>
                </View>
            </View>)
    }

  const keyExtractor = (item: LeadLogDetailsViewModel, index: number) => {
    return (item.item?.leadLogId || index).toString()
  }

  const onEndReached = async () => {
    if(!leadLogs?.items?.length)
        return;
    if(leadLogs?.items?.length + 1 >= leadLogCurrentCount && !listRefreshing) {
        setListRefreshing(true)
        const {data: leadLogs} = await LeadsAPI.getLeadLogs(Number(id), profileItem?.id ?? 0, leadLogCurrentCount, 20)
        setLeadLogCurrentCount(leadLogCurrentCount + 20)
        setLeadLogs((prevState) => {
            if (!prevState) {
              return {
                items: leadLogs?.items || [],
                fromRowNumber: leadLogs?.fromRowNumber,
                length: leadLogs?.length,
                totalCount: leadLogs?.totalCount,
              } as GetLeadLogsResponseViewModel;
            }

            const prevItems = prevState?.items ?? []; 
      
            return {
              fromRowNumber: leadLogs?.fromRowNumber,
              length: leadLogs?.length,
              totalCount: leadLogs?.totalCount,
              items: [...prevItems, ...(leadLogs?.items || [])],
            } as GetLeadLogsResponseViewModel;
          });
      
        setListRefreshing(false)  
    }
  }

  const onViewableItemsChanged = ({ viewableItems }: { viewableItems: Array<{ item: LeadLogDetailsViewModel }> }) => {
    viewableItems.forEach(({ item }) => {
      if (!item?.item?.isRead && item?.item?.leadId && item?.item?.leadLogId) {
        updateLeadLog(item?.item?.leadId, item?.item?.leadLogId, true, item?.item?.leadStructureType)
      }
    })
  }

  const { text } = useColors()

  useEffect(() => {
    setOptions({ header: () => <Header onLeftPress={goBack} /> })
  }, [])

  return (
    <View style={{flex:1}}>
      <View style={styles.container}>
        <FlashList
          ListHeaderComponent={ListHeader}
          estimatedItemSize={20}
          scrollEnabled={true}
          nestedScrollEnabled={true}
          data={sortedLeadsHistory}
          refreshing={loading}
          keyExtractor={keyExtractor}
          contentContainerStyle={styles.list}
          renderItem= {renderItem}
          onEndReached={onEndReached}
          onEndReachedThreshold={2.5}
          viewabilityConfig={{ itemVisiblePercentThreshold: 99 }}
          onViewableItemsChanged={onViewableItemsChanged}
        />
      </View>
      { leadsDetails !== null &&
        <LeadsBottomBar
        leadDetails={leadsDetails}
        setRequestModal={setRequestModal}
        profileItem = {profileItem}
        />
      }
      <RequestReviewModal 
      isVisible={requestModal} 
      onClose={() => setRequestModal(false)} 
      leadDetails={leadsDetails}
      profileId={profileItem?.id}
      />
      <LeadsSpamBlockModal
        isSpam={leadsDetails?.isSpam}
        isBlocked={leadsDetails?.isBlocked}
        isVisible={spamBlockModal}
        onClose={() => setSpamBlockModal(false)}
        handleLeadBlocking = {handleLeadBlocking}
        handleLeadSpamMarking = {handleLeadSpamMarking}
      />
      <AddUpdateLeadAmountModal 
        isVisible={isLeadAmountModalVisible}
        onClose={() => setIsLeadAmountModalVisible(false)}
        lead={leadsDetails}
        onSavePress={handleAddAmount}
      />
      <AddUpdateLeadStatusModal 
        isVisible={isLeadStatusModalVisible}
        onClose={() => setIsLeadStatusModalVisible(false)}
        lead={leadsDetails}
        onSavePress={handleAddLeadStatus}
        customerStatusTypes={customerStatusTypes}
      />
      <AddUpdateNotesModal 
        isVisible={isLeadNotesModalVisible}
        onClose={() => setIsLeadNotesModalVisible(false)}
        lead={leadsDetails}
        onSavePress={handleAddNotes}
      />
    </View>
  )
}
