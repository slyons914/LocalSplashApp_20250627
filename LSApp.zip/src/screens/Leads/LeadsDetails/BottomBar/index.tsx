import { Alert, Linking, TouchableOpacity, View } from "react-native"

import { Icon, Typography } from "@components"
import { useStore } from "@store"
import { CallHelper, FormatHelper } from "@utils/helpers"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"
import { navigate } from "@navigation"
import { Routes, Stacks } from "@utils/constants"
import { Lead } from "@models/leads"
import { ProfileViewModel } from "@models/localsplash-mobile-api.service"
import { isSipAvailable } from "@utils/helpers/sip"
import { CallAlertModal } from "@modals"
import { useState } from "react"

interface Tab {
  name: string
  icon: IconName
  callback?: () => void
}
interface Props {
  leadDetails: Lead | null
  setRequestModal: (value: boolean) => void
  profileItem: ProfileViewModel | undefined | null
}

export const LeadsBottomBar = ({ leadDetails, setRequestModal, profileItem }: Props) => {
  const styles = useStyles()

  const { subText } = useColors()

  const { settingsStore, homeStore } = useStore()
  const { requestSipSettings } = settingsStore
  const { locationsItem } = homeStore

  const [isCallAlertVisible,setIsCallAlertVisible] = useState(false)


  const sendEmail = () => {
    Linking.openURL(`mailto:${leadDetails?.email}`)
  }

  const sendMessage = () => {
    navigate(Stacks.Messages, {screen: Routes.MessageDetail, params: {
        number: leadDetails?.phoneNumber,
        leadId: leadDetails?.id
    }})
  }

  const makeCallAlert = async () => {
    const sipCredentials = await CallHelper.getSipSettingsFromProfileId(locationsItem?.id)
    if (isSipAvailable(sipCredentials)) {
      navigate(Stacks.Call, { screen: Routes.DialPad, params: {
        phoneNumber:leadDetails?.phoneNumber
    }})
    } else {
      setIsCallAlertVisible(true)
    }
  }

  const tabs: Array<Tab> = [
    {
      name: "Call",
      icon: "barPhone",
      callback: makeCallAlert,
    },
    {
      name: "Message",
      icon: "barMessage",
      callback: sendMessage
    },
    leadDetails?.email ? {
      name: "Email",
      icon: "barEmail",
      callback: sendEmail,
    } : {},
    (profileItem?.reviewTinyUrl || profileItem?.newReviewUrl) ?
    {
      name: "Review",
      icon: "barReview",
      callback: () => {
        setRequestModal(true)
      },
    } : {},
  ] as Array<Tab>;


  const renderTab = ({ name, icon, callback }: Tab, index: number) => {
    if ( name ) {
        return (
        <TouchableOpacity key={index} onPress={callback} style={styles.tab}>
            <Icon name={icon} width={20} height={20} stroke={subText} />
            <Typography style={styles.text}>{name}</Typography>
        </TouchableOpacity>
        )
    }
    return (
        null
    )
  }

  return <View style={styles.container}>{tabs.map(renderTab)}
         <CallAlertModal isVisible={isCallAlertVisible} isFromLead={true} onClose={() => setIsCallAlertVisible(false)} callNumber={FormatHelper.formatPhoneNumber(leadDetails?.phoneNumber.toString())}/>
        </View>
}
