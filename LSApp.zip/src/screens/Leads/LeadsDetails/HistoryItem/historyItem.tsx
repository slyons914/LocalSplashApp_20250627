import React from "react"

import { View, Text } from "react-native"

import { CtmLeadLog, FacebookLeadLog, LeadLogType, WebsiteFormLeadLog } from "@models/leads"

import { CallItem, PulseCallItem } from "./Ctm"
import { FaceBookItem } from "./Facebook"
import { WebsiteSMSItem } from "./WebsiteSMS"
import { useStyles } from "../styles"
import { Typography } from "@components"
import { LeadLogDetailsViewModel } from "@localsplash/mobile-api-client"
import { SmsItem } from "./SmsItem"
import { GoogleGuaranteedAds, GoogleGuaranteedBooking, GoogleGuaranteedMessage } from "./GoogleAds"
import { leadStatusColors } from "@utils/constants/common"
import { useStore } from "@store"

interface Props {
  item: LeadLogDetailsViewModel
  updateLeadLog: (id: number, logId: number, isRead:boolean, leadStructure: number | undefined) => void
}

export const HistoryItem = ({ item, updateLeadLog }: Props) => {
  const styles = useStyles()

  const { homeStore } = useStore()
  const { customerStatusTypes } = homeStore

  const getStatusNameById = (id: number) => {
    const status = customerStatusTypes?.items?.find(status => status.id === id);
    return status ? status.statusName : '';
  };

  switch (item.item?.leadStructureType) {
    case LeadLogType.Website:
      return <WebsiteSMSItem item={item} text="WEBSITE" icon="website" updateLeadLog={updateLeadLog}/>

    case LeadLogType.Call:
      return <CallItem item={item} updateLeadLog={updateLeadLog} />

    case LeadLogType.PulseCall:
      return <PulseCallItem item={item} updateLeadLog={updateLeadLog} />

    case LeadLogType.Sms:
      return <SmsItem item={item} text="SMS" icon="sms" updateLeadLog={updateLeadLog} />

    case LeadLogType.TychromSms:
      return <SmsItem item={item} text="SMS" icon="sms" updateLeadLog={updateLeadLog} />

    case LeadLogType.FacebookForm :
      return <FaceBookItem title="Facebook Messenger" item={item} updateLeadLog={updateLeadLog} />

    case LeadLogType.GoogleGuaranteedAds:
        return <GoogleGuaranteedAds item={item} updateLeadLog={updateLeadLog} /> 

    case LeadLogType.GoogleGuaranteedBooking:
        return <GoogleGuaranteedBooking item={item} updateLeadLog={updateLeadLog} />  

    case LeadLogType.GoogleGuaranteedMessage:
        return <GoogleGuaranteedMessage item={item} updateLeadLog={updateLeadLog} />      

    case LeadLogType.FacebookMessenger:
      return <FaceBookItem title="Facebook Form" item={item} updateLeadLog={updateLeadLog} />
    case LeadLogType.Disposition:
      return (
        <View style={[styles.historyItemContainer]}>
            {
                item?.disposition?.dispositionStatus !== 2 ? (
                    <View style={styles.dispositionView}>
                        <Typography style={styles.statusText} >{item?.disposition?.loggedBy} changed status to</Typography>
                        <View style={styles.leadLogDotView}>
                            <View style={[styles.dotView, leadStatusColors[item?.disposition?.dispositionStatus ?? 1]]}>
                            </View>
                            <Typography>{getStatusNameById(item?.disposition?.dispositionStatus ?? 1)}</Typography>
                        </View>
                    </View>
                ) : (
                    <Typography >{item?.disposition?.loggedBy} cleared the lead status</Typography> 
                )
            }
        </View>
        )
    default:
      return (
        <View style={styles.historyItemContainer}>
          <Typography style={styles.historyItemTitle}>{"Placeholder"}</Typography>
          <Typography style={styles.description}>{"Placeholder"}</Typography>
        </View>
      )
  }
}
