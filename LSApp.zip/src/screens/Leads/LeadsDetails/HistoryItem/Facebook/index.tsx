import { LayoutAnimation, TouchableOpacity, View } from "react-native"

import { useStyles } from "./styles"
import { HistoryTypeLabel, HistoryTypeStatus } from "../../utils"
import { LeadLogDetailsViewModel } from "@localsplash/mobile-api-client"
import { useState } from "react"
import { Typography } from "@components"

interface Props {
  item: LeadLogDetailsViewModel
  updateLeadLog: (id: number, logId: number, isRead:boolean, leadStructure: number | undefined) => void
  title: string
}

const characterLimit = 80

export const FaceBookItem = ({ item, updateLeadLog, title }: Props) => {
  const styles = useStyles()

  const [expanded, setExpanded] = useState(false)
  const message = item?.facebookForm?.message || item?.facebookMessager?.message || ""
  const shouldShowExpandButton = message.length > characterLimit

  const toggleExpand = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut)
    setExpanded(!expanded)
  }

  return (
    <View
      style={[
        styles.historyContainer,
        item?.item?.isRead ? styles.historyReadBackground : styles.historyUnreadBackground,
      ]}
    >
      <View style={styles.headerContainer}>
        <HistoryTypeLabel text={title} icon="facebook" />

        <HistoryTypeStatus
          isRead={item?.item?.isRead}
          updateLeadLog={updateLeadLog}
          id={item?.item?.leadId}
          logId={item?.item?.leadLogId}
          leadStructure={item?.item?.leadStructureType}
        />
      </View>
      {expanded ? (
        <Typography style={styles.facebookDescription}>{message}</Typography>
      ) : (
        <Typography style={styles.facebookDescription}>
          {message.length > characterLimit ? `${message.slice(0, characterLimit)}...` : message}
        </Typography>
      )}

      {shouldShowExpandButton && (
        <TouchableOpacity onPress={toggleExpand}>
          <Typography style={styles.expandButton}>{expanded ? "Less" : "More"}</Typography>
        </TouchableOpacity>
      )}
    </View>
  )
}
