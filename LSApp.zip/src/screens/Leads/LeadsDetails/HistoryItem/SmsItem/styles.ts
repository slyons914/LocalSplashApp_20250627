import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  historyItemWebsiteContainer: {
    flex: 1,
    marginLeft: 10,
    padding: 16,
    marginVertical: 30,
    borderRadius: 5,
  },
  historyReadBackground: {
    backgroundColor: colors.backgroundSecondary,
  },
  historyUnreadBackground: {
    backgroundColor: colors.backgroundLeadItem,
  },
  headerContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  websiteDescription: {
    color: colors.subText,
    fontSize: 14,
    paddingTop: 16,
  },
  expandButton: {
    color: colors.orangePrimary,
  },
}))
