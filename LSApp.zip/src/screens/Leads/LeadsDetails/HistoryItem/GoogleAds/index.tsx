import { View } from "react-native"

import { useStyles } from "./styles"
import { HistoryTypeLabel, HistoryTypeStatus } from "../../utils"
import { LeadLogDetailsViewModel } from "@localsplash/mobile-api-client"
import { Icon, Track, Typography } from "@components"
import { usePlayer } from "@providers"
import { useProgress } from "react-native-track-player"

interface Props {
  item: LeadLogDetailsViewModel
  updateLeadLog: (id: number, logId: number, isRead:boolean, leadStructure: number | undefined) => void
}

export const GoogleGuaranteedAds = ({ item, updateLeadLog }: Props) => {

  const styles = useStyles()
  const { playing, showPlayer, playTrack, load, track } = usePlayer()
  const { position, duration } = useProgress()
    
  const onPlay = async () => {
    load(item?.googleGuaranteedPhoneCall?.callRecordingUrl)
    playTrack()
    showPlayer()
  }

  const hasAudio = item?.googleGuaranteedPhoneCall?.callRecordingUrl

  return (
    <View
      style={[
        styles.historyItemWebsiteContainer,
        item?.item?.isRead ? styles.historyReadBackground : styles.historyUnreadBackground,
      ]}
    >
      <View style={styles.headerContainer}>
        <HistoryTypeLabel text="Google Guaranteed Call" icon="ctmPhone" />
        <HistoryTypeStatus
          isRead={item?.item?.isRead}
          updateLeadLog={updateLeadLog}
          id={item?.item?.leadId}
          logId={item?.item?.leadLogId}
          leadStructure={item?.item?.leadStructureType}
        />
      </View>
      <View style={styles.audioContainer}>
          {hasAudio && <Typography>Call duration: {Math.round(item?.googleGuaranteedPhoneCall?.callDurationMillis? item?.googleGuaranteedPhoneCall?.callDurationMillis/1000 : 0)} sec</Typography>}
      </View>
      {hasAudio && (
        <Track
            playing={item?.googleGuaranteedPhoneCall?.callRecordingUrl === track? playing : false }
            position={item?.googleGuaranteedPhoneCall?.callRecordingUrl === track? position : 0}
            duration={item?.googleGuaranteedPhoneCall?.callRecordingUrl === track? duration : item?.googleGuaranteedPhoneCall?.callDurationMillis? item?.googleGuaranteedPhoneCall?.callDurationMillis/1000 : 0}
            loading={false}
            onPlayToggle={onPlay}
        />
      )}
      <View style={styles.googleGuaranteedView}>
        <View style={styles.chargedView}>
            <Icon name="googleGuaranteed"></Icon>
            <Typography>Google Guaranteed</Typography>
        </View>
        <View style={styles.chargedView}>
            <Icon name="chargedDollar"></Icon>
            <Typography style={item?.googleGuaranteedPhoneCall?.chargeStatus === "Charged" ? styles.green : styles.red}>{item?.googleGuaranteedPhoneCall?.chargeStatus}</Typography>
        </View>
      </View>
    </View>
  )
}

export const GoogleGuaranteedMessage = ({ item, updateLeadLog }: Props) => {

    const styles = useStyles()
    const { playing, showPlayer, playTrack, load, track } = usePlayer()
    const { position, duration } = useProgress()
    const onPlay = async () => {
        load(item?.googleGuaranteedMessage?.callRecordingUrl)
        playTrack()
        showPlayer()
      }
    
    const hasAudio = item?.googleGuaranteedMessage?.callRecordingUrl
    return (
      <View
        style={[
          styles.historyItemWebsiteContainer,
          item?.item?.isRead ? styles.historyReadBackground : styles.historyUnreadBackground,
        ]}
      >
        <View style={styles.headerContainer}>
          <HistoryTypeLabel text="Google Guaranteed Message" icon="sms" />
          <HistoryTypeStatus
            isRead={item?.item?.isRead}
            updateLeadLog={updateLeadLog}
            id={item?.item?.leadId}
            logId={item?.item?.leadLogId}
            leadStructure={item?.item?.leadStructureType}
          />
        </View>
        <View style={styles.audioContainer}>
          {hasAudio && <Typography>Call duration: {Math.round(item?.googleGuaranteedMessage?.callDurationMillis? item?.googleGuaranteedMessage?.callDurationMillis/1000 : 0)} sec</Typography>}
        </View>
        {hasAudio && (
            <Track
                playing={item?.googleGuaranteedMessage?.callRecordingUrl === track? playing : false }
                position={item?.googleGuaranteedMessage?.callRecordingUrl === track? position : 0}
                duration={item?.googleGuaranteedMessage?.callRecordingUrl === track? duration : item?.googleGuaranteedMessage?.callDurationMillis? item?.googleGuaranteedMessage?.callDurationMillis/1000 : 0}
                loading={false}
                onPlayToggle={onPlay}
            />
        )}
        <View style={styles.googleGuaranteedView}>
            <View style={styles.chargedView}>
                <Icon name="googleGuaranteed"></Icon>
                <Typography>Google Guaranteed</Typography>
            </View>
            <View style={styles.chargedView}>
                <Icon name="chargedDollar"></Icon>
                <Typography style={item?.googleGuaranteedMessage?.chargeStatus === "Charged" ? styles.green : styles.red}>{item?.googleGuaranteedMessage?.chargeStatus}</Typography>
            </View>
        </View>
      </View>
    )
  }

  export const GoogleGuaranteedBooking = ({ item, updateLeadLog }: Props) => {

    const styles = useStyles()
  
    return (
      <View
        style={[
          styles.historyItemWebsiteContainer,
          item?.item?.isRead ? styles.historyReadBackground : styles.historyUnreadBackground,
        ]}
      >
        <View style={styles.headerContainer}>
          <HistoryTypeLabel text="Google Guaranteed Booking" icon="website" />
          <HistoryTypeStatus
            isRead={item?.item?.isRead}
            updateLeadLog={updateLeadLog}
            id={item?.item?.leadId}
            logId={item?.item?.leadLogId}
            leadStructure={item?.item?.leadStructureType}
          />
        </View>
        <View style={styles.googleGuaranteedView}>
            <View style={styles.chargedView}>
                <Icon name="googleGuaranteed"></Icon>
                <Typography>Google Guaranteed</Typography>
            </View>
            <View style={styles.chargedView}>
                <Icon name="chargedDollar"></Icon>
                <Typography style={item?.googleGuaranteedBook?.chargeStatus == "Charged" ? styles.green : styles.red}>{item?.googleGuaranteedBook?.chargeStatus}</Typography>
            </View>
        </View>
      </View>
    )
  }