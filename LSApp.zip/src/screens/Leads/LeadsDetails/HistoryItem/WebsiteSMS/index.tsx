import { useState } from "react"

import { LayoutAnimation, TouchableOpacity, View } from "react-native"

import { Typography } from "@components"

import { useStyles } from "./styles"
import { HistoryTypeLabel, HistoryTypeStatus } from "../../utils"
import { LeadLogDetailsViewModel } from "@localsplash/mobile-api-client"

interface Props {
  item: LeadLogDetailsViewModel
  text: string
  icon: IconName
  updateLeadLog: (id: number, logId: number, isRead:boolean,  leadStructure: number | undefined) => void
}

const characterLimit = 80

export const WebsiteSMSItem = ({ item, text, icon, updateLeadLog }: Props) => {
  const styles = useStyles()
  const [expanded, setExpanded] = useState(false)
  const message = item.websiteForm?.message || ""
  const shouldShowExpandButton = message.length > characterLimit
  const toggleExpand = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut)
    setExpanded(!expanded)
  }
  return (
    <View
      style={[
        styles.historyItemWebsiteContainer,
        item?.item?.isRead ? styles.historyReadBackground : styles.historyUnreadBackground,
      ]}
    >
      <View style={styles.headerContainer}>
        <HistoryTypeLabel text={text} icon={icon} />
        <HistoryTypeStatus
          isRead={item?.item?.isRead}
          id={item?.item?.leadId}
          logId={item?.item?.leadLogId}
          updateLeadLog={updateLeadLog}
          leadStructure={item?.item?.leadStructureType}
        />
      </View>
      {expanded ? (
        <Typography style={styles.websiteDescription}>{message}</Typography>
      ) : (
        <Typography style={styles.websiteDescription}>
          {message.length > characterLimit ? `${message.slice(0, characterLimit)}...` : message}
        </Typography>
      )}

      {shouldShowExpandButton && (
        <TouchableOpacity onPress={toggleExpand}>
          <Typography style={styles.expandButton}>{expanded ? "Less" : "More"}</Typography>
        </TouchableOpacity>
      )}

    </View>
  )
}
