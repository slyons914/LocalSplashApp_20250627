import { View } from "react-native"

import { useProgress } from "react-native-track-player"

import { Icon, Track, Typography } from "@components"
import { usePlayer } from "@providers"

import { useStyles } from "./styles"
import { HistoryTypeLabel, HistoryTypeStatus, StatusLabel, TagList } from "../../utils"
import { LeadLogDetailsViewModel } from "@localsplash/mobile-api-client"

interface Props {
  item: LeadLogDetailsViewModel
  updateLeadLog: (id: number, logId: number, isRead:boolean,  leadStructure: number | undefined) => void
}

export const CallItem = ({ item, updateLeadLog }: Props) => {
  const styles = useStyles()
  const { playing, loading, showPlayer, playTrack, load, track } = usePlayer()
  const { position, duration } = useProgress()

  const onPlay = async () => {
    load(item?.ctmPhoneCall?.audioPath)
    playTrack()
    showPlayer()
  }

  const hasAudio = item?.ctmPhoneCall?.audioPath

  return (
    <View
      style={[
        styles.historyItemWebsiteContainer,
        item?.item?.isRead ? styles.historyReadBackground : styles.historyUnreadBackground,
      ]}
    >
      <View style={styles.headerContainer}>
        <View style={styles.forwardingView}>
            <HistoryTypeLabel text="PHONE CALL" icon="ctmPhone" />
            {/* <Icon height={24} width={24} name="callForwarding"></Icon> */}
        </View> 
        <HistoryTypeStatus
          isRead={item?.item?.isRead}
          updateLeadLog={updateLeadLog}
          id={item?.item?.leadId}
          logId={item?.item?.leadLogId}
          leadStructure={item?.item?.leadStructureType}
        />
      </View>
      <View style={styles.audioContainer}>
        {hasAudio && <Typography>Call duration: {Math.round(item?.ctmPhoneCall?.callDuration ?? 0)} sec</Typography>}
      </View>
      {hasAudio && (
        <Track
          playing={item?.ctmPhoneCall?.audioPath === track? playing : false }
          position={item?.ctmPhoneCall?.audioPath === track? position : 0}
          duration={item?.ctmPhoneCall?.audioPath === track? duration : item?.ctmPhoneCall?.callDuration}
          loading={false}
          onPlayToggle={onPlay}
        />
      )}
      {
         item?.ctmPhoneCall?.tagList
         && <TagList tagList={item?.ctmPhoneCall?.tagList} />
      }
      <StatusLabel item={item} />
    </View>
  )
}

export const PulseCallItem = ({ item, updateLeadLog }: Props) => {
    const styles = useStyles()
    const { playing, loading, showPlayer, playTrack, load, track } = usePlayer()
    const { position, duration } = useProgress()
  
    const onPlay = async () => {
      load(item?.pulsePhoneCall?.audioUrl)
      playTrack()
      showPlayer()
    }
  
    const hasAudio = item?.pulsePhoneCall?.audioUrl
  
    return (
      <View
        style={[
          styles.historyItemWebsiteContainer,
          item?.item?.isRead ? styles.historyReadBackground : styles.historyUnreadBackground,
        ]}
      >
        <View style={styles.headerContainer}>
          <View style={styles.forwardingView}>
            <HistoryTypeLabel text="PHONE CALL" icon="ctmPhone" />
            {
                item?.pulsePhoneCall?.callDestinationType == "forward" &&
                <Icon height={24} width={24} name="callForwarding"></Icon>
            }
          </View>  
          <HistoryTypeStatus
            isRead={item?.item?.isRead}
            updateLeadLog={updateLeadLog}
            id={item?.item?.leadId}
            logId={item?.item?.leadLogId}
            leadStructure={item?.item?.leadStructureType}
          />
        </View>
        <View style={styles.audioContainer}>
          {hasAudio && <Typography>Call duration: {Math.round(item?.pulsePhoneCall?.duration ?? 0)} sec</Typography>}
        </View>
  
        {hasAudio && (
          <Track
            playing={item?.pulsePhoneCall?.audioUrl === track? playing : false }
            position={item?.pulsePhoneCall?.audioUrl === track? position : 0}
            duration={item?.pulsePhoneCall?.audioUrl === track? duration : item?.pulsePhoneCall?.duration}
            loading={false}
            onPlayToggle={onPlay}
          />
        )}
        {
         item?.pulsePhoneCall?.intentTag
         && <TagList tagList={item?.pulsePhoneCall?.intentTag} />
        }
        <StatusLabel item={item} />
      </View>
    )
  }
