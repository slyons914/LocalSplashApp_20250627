import { Pressable, Text, TouchableOpacity, View } from "react-native"

import { Icon, Typography } from "@components"
import { CtmLeadLog } from "@models/leads"
import { FormatHelper } from "@utils/helpers"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"
import { LeadUnreadModal } from "@modals"
import { useState } from "react"
import { LeadLogDetailsViewModel } from "@localsplash/mobile-api-client"

interface Props {
  icon: IconName
  text: string
}

interface PropsLabel {
  item: LeadLogDetailsViewModel
}

interface StatusProps {
  isRead: boolean | undefined
  id: number | undefined
  logId: number | undefined
  leadStructure: number | undefined,
  updateLeadLog: (id: number, logId: number, isRead:boolean,  leadStructure: number | undefined) => void
}

export const HistoryTypeLabel = ({ icon, text }: Props) => {
  const styles = useStyles()

  return (
    <View style={styles.historyItemTypeContainer}>
      <Icon name={icon} />
      <Typography style={styles.historyItemTypeLabel}>{text}</Typography>
    </View>
  )
}

export const HistoryTypeStatus = ({ isRead, id, logId, updateLeadLog, leadStructure }: StatusProps) => {
  const styles = useStyles()

  const { text } = useColors()

  const [isLeadUnrealModalVisible, setIsLeadUnrealModalVisible] = useState(false)

  const onLeadUpdate = () => {
     updateLeadLog(id, logId, !isRead, leadStructure)
     setIsLeadUnrealModalVisible(false)
  }
  return isRead ? (
    <Pressable onLongPress={() => setIsLeadUnrealModalVisible(true)} style={styles.historyItemStatus}>
      <Icon name={"checkedBlack"} stroke={text} />
      <Typography style={styles.historyStatusReadLabel}>READ</Typography>
      <LeadUnreadModal isRead={isRead} updateLeadStatus = {onLeadUpdate} isVisible={isLeadUnrealModalVisible} onClose={() => {setIsLeadUnrealModalVisible(false)}} />
    </Pressable>
  ) : (
    <TouchableOpacity onPress={() => updateLeadLog(id, logId, true,  leadStructure)}>
      <View style={styles.historyItemStatus}>
        <Icon name="warning" />
        <Typography style={styles.historyStatusUnreadLabel}>UNREAD</Typography>
      </View>
    </TouchableOpacity>
  )
}

export const StatusLabel = ({ item }: PropsLabel) => {
  const styles = useStyles()

  return (
    <View style={styles.statusLabelContainer}>
      <Typography style={styles.statusLabelText}>
        {FormatHelper.capitalizeFirstLetter(item?.ctmPhoneCall?.callStatus || item?.pulsePhoneCall?.dialStatus || "")}
      </Typography>
    </View>
  )
}

export const TagList = ({ tagList }: {tagList: string}) => {
    const styles = useStyles()
  
    return (
        <View style={styles.tagListContainer}>
            <Typography style={styles.tagLineText}>{tagList}</Typography>
        </View>

    )
  }
