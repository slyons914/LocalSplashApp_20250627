import { useEffect, useState } from "react"

import { ActivityIndicator, FlatList, TouchableOpacity, useColorScheme, View } from "react-native"

import { LeadsAPI } from "@api"
import { Icon, SearchBar, Typography } from "@components"
import { LeadFilters, LeadList, LeadListItem } from "@models/leads"
import { Routes, Stacks } from "@utils/constants"
import { FormatHelper } from "@utils/helpers"
import { useColors, useDebounce } from "@utils/hooks"
import { useStore } from "@store"

import { LeadsIconSelector } from "./LeadsIconSelector"
import { useStyles } from "./styles"
import { observer } from "mobx-react-lite"
import { leadStatusColors } from "@utils/constants/common"
import { useLeadContext } from "@providers"
import { LeadFilterHeader } from "./LeadsDetails/leadFilterHeader"

export const component = ({ navigation }: ScreenProps<Routes.Leads>) => {
  const { navigate } = navigation

  const { homeStore } = useStore()
  const { locationsItem, customerStatusTypes, getCustomerStatusTypes } = homeStore

  const styles = useStyles()
  const isDarkTheme = useColorScheme() === "dark"

  const {filters, setFilters } = useLeadContext()

  const { title } = useColors()

  const [hasMore , setHasMore] = useState(true)
  const [loading, setLoading] = useState(false)
  const [leads, setLeads] = useState<LeadList<LeadListItem> | null>(null)
  const [currentItem, setCurrentItem] = useState(1)
  const [leadsList , setLeadsList] = useState<LeadListItem [] | undefined>([])
  const [error, setError] = useState("")
  const [isRefresing, setIsRefresing] = useState(false)

  const getLeads = async () => {
    setError("")
    setHasMore(true)
    setLoading(true)
    const { data, error } = await LeadsAPI.getLeads(1,filters, locationsItem?.id)
    if(error){
        setError(error)
    }else{
        setCurrentItem(31)
        setLeads(data)
        setLeadsList(data?.items)
    }
    setLoading(false)
  }

  const onLeadPress= async (item:any)=>{
    navigate(Stacks.Leads, { screen: Routes.LeadsDetails, params: { id: item.id, profileItem:locationsItem, setLeadsList: setLeadsList} })
  }

  const getStatusNameById = (id: number) => {
    const status = customerStatusTypes?.items?.find(status => status.id === id);
    return status ? status.statusName : '';
  };

//   useEffect(() => {
//     setCurrentItem(1)
//     setFilters({
//         isSpam: false,
//         isBlocked: false,
//         isRead: null,
//         ProfileId: locationsItem?.id,
//         FromDate: null,
//         ToDate: null,
//         Search: "",
//         Length:30,
//         AreCallLeadLogsIncluded:true,
//         AreGoogleLeadLogsIncluded:true,
//         AreSmsLeadLogsIncluded:true,
//         AreFacebookLeadLogsIncluded:true,
//         AreWebsiteFormLeadLogsIncluded:true
//     })
//   },[locationsItem])

  useEffect(() => {
    if(!customerStatusTypes) {
        getCustomerStatusTypes()
    }
    if(locationsItem?.id)
    getLeads()
  }, [filters])

  const onRefresh = async () =>{
    setLoading(true)
    setIsRefresing(true)
    setCurrentItem(1)
    await getLeads()
    setIsRefresing(false)
  }

  const onSearchHandler = useDebounce((searchValue?: string) => {
    setCurrentItem(1)
    setFilters((prev: LeadFilters) => ({
      ...prev,
      Search: searchValue,
    }))
  }, 1000)

  const keyExtractor = (item: LeadListItem, index: number) => {
    return index.toString()
  }

  const onEndReached = async () =>{
    if(loading || !hasMore || isRefresing)
        return;
    setIsRefresing(true)
    try {
        const { data } = await LeadsAPI.getLeads(currentItem,filters, locationsItem?.id)
        if(data?.items?.length??0 > 0){
            setLeadsList((prevData)=>[...prevData , ...data?.items])
            setCurrentItem((prevData)=>prevData+30)
        }else{
            setHasMore(false)
        }
        
        
    }
    catch(error){
        console.log(error)
    }
    finally{
        setIsRefresing(false)
    }
  }

  useEffect(() => {
    if(!customerStatusTypes)
        getCustomerStatusTypes()
    if(locationsItem?.id)
        getLeads()
  },[filters])

  const renderItem = ({ item, index }: { item: LeadListItem, index:number }) => {
    const lastSeenDate = new Date(item.lastInOn)
    const phoneNumber = item.phoneNumber.toString()
    return (
      <TouchableOpacity
        onPress={() => onLeadPress(item)}
      >
        <View style={[styles.leadItemContainer, !item.isRead && styles.leadItemReadedContainer]}>
          <View style={styles.leadIcon}>
            <LeadsIconSelector item={item} />
          </View>
          <View style={styles.leadTitle}>
            <Typography type={"title"} style={[styles.leadName, item.isBlocked && styles.blocked]}>
              {item.name}
            </Typography>
            <Typography type={"title"} style={item.isBlocked && styles.blocked}>
              {FormatHelper.formatPhoneNumber(phoneNumber)}
            </Typography>
            {
                item.dispositionStatus && item.dispositionStatus !== 2 &&
                <View style={[styles.leadStatusView, leadStatusColors[item.dispositionStatus]]}>
                    <Typography style={styles.leadStatusText}>
                        {getStatusNameById(item.dispositionStatus)}
                    </Typography>
                </View>
            }
            {
                item?.customerAmount && item?.customerAmount !== 0 ?
                    <Typography style={styles.leadAmount}>
                        {`$${item.customerAmount}`}
                    </Typography> : null
            }
            <Typography style={styles.dateText}>
              {FormatHelper.formatDate(lastSeenDate, { time: true }, true)}
            </Typography>
          </View>
          <View style={styles.statusLead}>
            <View style={styles.notesIconView}>
                {
                    item.customerNotes &&  <Icon name={isDarkTheme ? "notesIconWhite" : "notesIcon"} />
                }
                <Icon name={"leadsDetailsArrow"} height={38} width={38} />
            </View>
            {item.isSpam && !item.isBlocked && <Icon name={"spam"} style={styles.spam} />}
            {!item.isSpam && item.isBlocked && <Icon name={"blocked"} style={styles.spam} />}
            {item.isSpam && item.isBlocked && <Icon name={"spamblock"} style={styles.spamblock} />}
          </View>
        </View>
      </TouchableOpacity>
    )
  }

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <View style={styles.pageNameContainer}>
            <Typography style={styles.pageName}>
                Leads
            </Typography>
            <Icon name={isDarkTheme ? "ReloadArrowWhite" : "ReloadArrow"} />
        </View>
        <SearchBar
          placeholder="Search by Name, Phone Number..."
          value={filters.Search || ""}
          onSearch={onSearchHandler}
        />
        <View style={styles.leadsHeader}>
          <Typography style={styles.leadsHeaderName}>{`Total (${
            leads?.totalCount || 0
          })`}</Typography>
          <TouchableOpacity style={styles.filterBtn} onPress={() => navigate(Stacks.Leads, { screen: Routes.LeadFilters})}>
            <Icon name={"filters"} stroke={title} height={20} width={20} />
            <Typography style={styles.filterTitle} type={"title"}>Filters</Typography>
          </TouchableOpacity>
        </View>
        <LeadFilterHeader />
        {
            loading &&
            <View style={{marginTop:16}}>
                <ActivityIndicator size={"large"}/>
            </View>
        }
      </View>
      { error ? (<View>
                    <Typography style={[styles.errorText, styles.largeText]}>{error}</Typography>
                    <Typography style={styles.errorText}>Drag down to refresh</Typography>
                </View>) : (null)}
        <FlatList
            onRefresh={onRefresh}
            refreshing={false}
            data={error ? [] :leadsList || []}
            renderItem={renderItem}
            keyExtractor={keyExtractor}
            onEndReached={onEndReached}
            onEndReachedThreshold={1}
            contentContainerStyle={styles.list}
        />
    </View>
  )
}
export const LeadsScreen = observer(component)