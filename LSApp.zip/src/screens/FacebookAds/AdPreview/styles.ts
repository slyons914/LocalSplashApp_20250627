import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets, width }) => ({
  container: {
    flex: 1,
    paddingBottom: insets.bottom,
    paddingTop: 8,
    gap: 12,
    overflow: "visible",
  },
  title: {
    fontSize: 20,
    fontWeight: "500",
    paddingTop: 0.5,
  },
  titleContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  adPreview: {
    alignItems: "center",
    width: 970,
    height: 550
  }
}))
