import { Icon, Typography } from "@components"
import { useStore } from "@store"
import { View } from "react-native"
import WebView from "react-native-webview"
import { useStyles } from "./styles"
import { useEffect, useState } from "react"

interface Props {}

export const AdPreview = ({}: Props) => {
  const styles = useStyles()
  const { facebookAdsStore } = useStore()
  const{facebookAdsPreview}=facebookAdsStore
  const [previewLink, setPreviewLink] = useState("")

  useEffect(() => {
    if (facebookAdsPreview) {
      setPreviewLink(facebookAdsPreview?.Preview)
    }
  }, [facebookAdsPreview?.Preview])
  

  return (
    <View style={styles.container} key={"adPreview"}>
    <View style={styles.titleContainer}>
          <Typography style={styles.title}>Facebook Ad Preview</Typography>
          <Icon name="helpSquareBlack"></Icon>
      </View>
    {
        previewLink ? (
            <View>
                <WebView  source={{
                    html: `
                          <!DOCTYPE html>
                          <html>
                            <body>
                              <div id="baseDiv">${previewLink}</div>
                            </body>
                          </html>
                    `,
                  }} style={styles.adPreview}/>
              </View>
        ) : (<Typography style={{textAlign:"center"}}>No Ad Preview Found</Typography>)
    }  
    </View>
  )
}
