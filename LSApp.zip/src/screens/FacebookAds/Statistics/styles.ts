import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    flex: 1,
    paddingBottom: insets.bottom,
    gap: 12,
    overflow: "visible",
    marginBottom:12
  },
  title:{
    fontWeight:"500",
    fontSize:20
  },
  itemView: {
    flexDirection: "row",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: 8
  }
}))
