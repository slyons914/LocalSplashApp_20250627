import { View, useColorScheme } from "react-native"
import { useStyles } from "./styles"
import { Typography } from "@components"
import { StatsItem } from "./StatsItem"
import { colors } from "@utils/constants"
import { useStore } from "@store"
import { useState } from "react"
import { observer } from "mobx-react-lite"

interface Props {}

export const StatisticsComponent = ({}: Props) => {
  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"  
  const styles = useStyles()
  const { facebookAdsStore, languageStore } = useStore()
  const { facebookAdsBaseInsights, facebookAdsActionsInsights } = facebookAdsStore
  const { languageVariables } = languageStore
  const [clickTooltip, setClickToolTip] = useState(false)
  const [spentTooltip, setSpentTooltip] = useState(false)
  const [impressionTooltip, setImpressionTooltip] = useState(false)
  const [reachTooltip, setReactTooltip] = useState(false)
  const [messagesTooltip, setMessagesTooltip] = useState(false)
  const [callsToolTip, setCallsTooptip] = useState(false)
  const [engagementTooltip, setEngagementTooltip] = useState(false)

  const helpIcon = isLightTheme ? "helpSquareBlack" : "helpSquare"


  return (
    <View style={styles.container} key={"statistics"}>
      <Typography style={styles.title}>Statistics</Typography>
      <View style={styles.itemView}>
      <StatsItem
          isActive={true}
          title={"Link Clicks"}
          count={Number(facebookAdsBaseInsights?.inlineLinkClicks ?? 0)}
          icon={"clickIcon"}
          iconFill={colors.common.blueBright}
          topIcon={isLightTheme ? "helpSquare" : "helpSquareBlack"}
          tooltip = {clickTooltip}
          setTooltip = {setClickToolTip}
          tooltipText = {languageVariables? languageVariables["App.fb.wid1"]:""}
        />
        <StatsItem
          title={`Amount
Spent`}
          count={Number(facebookAdsBaseInsights?.spend ?? 0)}
          icon={"helpSquare"}
          iconFill={colors.light.backgroundSecondary}
          topIcon={helpIcon}
          tooltip = {spentTooltip}
          setTooltip = {setSpentTooltip}
          tooltipText = {languageVariables? languageVariables["App.fb.wid4"] : ""}
        />
        <StatsItem
          title={"Impressions"}
          count={Number(facebookAdsBaseInsights?.impressions ?? 0)}
          icon={"eye"}
          iconFill={"#fff"}
          topIcon={helpIcon}
          tooltip = {impressionTooltip}
          setTooltip = {setImpressionTooltip}
          tooltipText = {languageVariables? languageVariables["App.fb.wid5"] : ""}
        />
        <StatsItem
          title={"Reach"}
          count={Number(facebookAdsBaseInsights?.reach ?? 0)}
          icon={"reachIcon"}
          iconFill={"#fff"}
          topIcon={helpIcon}
          tooltip = {reachTooltip}
          setTooltip = {setReactTooltip}
          tooltipText = {languageVariables? languageVariables["App.fb.wid6"] : ""}
        />
        <StatsItem
          title={"Messages"}
          count={facebookAdsActionsInsights?.messages ?? 0}
          icon={"FbMessage"}
          iconFill={"#fff"}
          topIcon={helpIcon}
          tooltip = {messagesTooltip}
          setTooltip = {setMessagesTooltip}
          tooltipText = {languageVariables? languageVariables["App.fb.wid7"] : ""}
        />
        <StatsItem
          title={"Calls"}
          count={facebookAdsActionsInsights?.calls ?? 0}
          icon={isLightTheme ? "FbCallIcon" : "phoneDark"}
          iconFill={"#fff"}
          topIcon={helpIcon}
          tooltip = {callsToolTip}
          setTooltip = {setCallsTooptip}
          tooltipText = {languageVariables? languageVariables["App.fb.wid7"] : ""}
        />
        <StatsItem
          title={"Page Engagement"}
          count={Number(facebookAdsBaseInsights?.inlinePostEngagement ?? 0)}
          icon={"FbIcon"}
          iconFill={"#fff"}
          topIcon={helpIcon}
          tooltip = {engagementTooltip}
          setTooltip = {setEngagementTooltip}
          tooltipText = {languageVariables? languageVariables["App.fb.wid12"] : ""}
        />
      </View>
      
    </View>
  )
}

export const Statistics = observer(StatisticsComponent)
