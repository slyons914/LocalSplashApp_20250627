import { Platform } from "react-native"

import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme, width, height }) => ({
  analyticsItem: {
    width: width * 0.42,
    height: height * 0.23,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 12,
    padding: 16,
  },
  activeAnalyticsItem: {
    backgroundColor: isDarkTheme ? colors.white : colors.blueBright,
  },
  analyticsItemTitleContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    minHeight: 48,
  },
  analyticsItemTitle: {
    fontSize: 16,
  },
  activeAnalyticsItemTitle: {
    color: colors.background,
  },
  countContainer: {
    flexDirection: "row",
    gap: 8,
    alignItems: "flex-end",
    marginTop: 16
  },
  count: {
    fontSize: 56,
    fontWeight: "200",
    marginBottom: Platform.OS === "ios" ? -23 : -36,
  },
  lowerFontSize: {
    fontSize: 36,
    fontWeight: "200",
    marginBottom: Platform.OS === "ios" ? -23 : -24,
  },
  activeCount: {
    color: colors.background,
  },
}))
