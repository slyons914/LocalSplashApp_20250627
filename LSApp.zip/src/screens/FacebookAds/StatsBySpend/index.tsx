import { Dimensions, View } from "react-native"
import { useStyles } from "./styles"
import { Icon, Typography } from "@components"
import { TouchableOpacity } from "react-native-gesture-handler"
import React, { useEffect, useState } from "react"
import { PieChart } from "react-native-chart-kit"
import { colors } from "@utils/constants"
import { useStore } from "@store"
import MapView, { Marker, PROVIDER_GOOGLE } from "react-native-maps"
import { customMapStyle } from "../../GoogleAds/Location/customMapStyle"
import LinearGradient from "react-native-linear-gradient"
import { DateFilter } from "@models/index"
import WebView from "react-native-webview"



const pieChartColors:Record<string, string> = {
  "18-24": colors.common.gray7,
  "25-34": colors.common.superBrightBlue,
  "35-44": colors.common.skyBlue,
  "45-54": colors.common.gray8,
  "55-64": colors.common.gray6,
  "65+": colors.common.blueBright,
}

const genderPieChartColors:Record<string, string> = {
  "male": colors.common.skyBlue,
  "female": colors.common.superBrightBlue
}

const chartConfig = {
    color: (opacity = 1) => `rgba(26, 255, 146, ${opacity})`,
  }
interface Props {
    date:DateFilter
}

export const StatsBySpend = ({date}: Props) => {
  const [selected , setSelected] =  useState("Age")
  const [pieChartData , setPieChartData] = useState<any[]>()
  const styles = useStyles()
  const { facebookAdsStore, languageStore } = useStore()
  const { facebookAdsAgeInsights,facebookAdsGenderInsights, facebookAdsRegionInsights } = facebookAdsStore
  const { languageVariables } = languageStore

  const [facebookAgeInsights , setFacebookAgeInsights] = useState<any []>()
  const [facebookGenderInsights , setFacebooGenderInsights] = useState<any []>()

  useEffect(()=>{
    let transformedAgeData;
    if(facebookAdsAgeInsights){
        transformedAgeData = facebookAdsAgeInsights?.items?.map((item, index) => ({
            age: item.age,
            spend: Number(item?.spend?.toFixed(2)),// Adjust decimal places as needed
            color: index === 0 ? colors.common.blueBright : // Assign colors based on index
                   index === 1 ? colors.common.superBrightBlue :
                   index === 2 ? colors.common.skyBlue :
                   index === 3 ? colors.common.gray8 :
                                 colors.common.gray7
          }));
    }
    let transformedGenderData;
    if(facebookAdsGenderInsights){
        transformedGenderData = facebookAdsGenderInsights?.items?.map((item, index) => ({
            age: item.gender,
            spend: Number(item?.spend?.toFixed(2)),// Adjust decimal places as needed
            color: index === 0 ? colors.common.blueBright : // Assign colors based on index
                   index === 1 ? colors.common.superBrightBlue :
                   colors.common.gray7
          }));
    }
    setPieChartData(transformedAgeData)
    setFacebooGenderInsights(transformedGenderData)
    setFacebookAgeInsights(transformedAgeData)
  },[facebookAdsAgeInsights,facebookAdsGenderInsights,date])

  const dataTable = facebookAdsRegionInsights?.items?.map(item => {
    if (!item.region) return null;
    return [item.region, Number(item?.spend?.toFixed(2))];  // Clean float
  }).filter(item => item !== null);

  dataTable?.unshift(['Region', 'Spend']);

  const htmlContent = `<html>
  <head>
    <script type='text/javascript' src='https://www.gstatic.com/charts/loader.js'></script>
    <script type='text/javascript'>
     google.charts.load('current', {
       'packages': ['geochart'],
       'mapsApiKey': 'AIzaSyBvouXAka2mbBgl19Tdelw8zfVS_qefcAA'
     });
     google.charts.setOnLoadCallback(drawMarkersMap);

      function drawMarkersMap() {
        // Ensure dataTable is properly formatted here
        var data = google.visualization.arrayToDataTable(${JSON.stringify(dataTable)});

        var options = {
          region: 'US',
          displayMode: 'markers',
          colorAxis: {
            colors: ['#A3CAF6', '#1F78FF'],
            legend: {position: 'none'} 
          }
        };

        var chart = new google.visualization.GeoChart(document.getElementById('chart_div'));
        google.visualization.events.addListener(chart, 'select', function(event) {
        var selectedItem = chart.getSelection()[0];
        if (selectedItem) {
            var region = data.getValue(selectedItem.row, 0);  // Region
            var spend = data.getValue(selectedItem.row, 1);   // Spend
            window.ReactNativeWebView.postMessage(JSON.stringify({
            region: region,
            spend: spend,
            }));
        }
        });
        chart.draw(data, options);
      };
    </script>
    <style>
      body, html {
        width: 50vw;  
        overflow-x: auto;   
        overflow-y: hidden; /* Disable vertical scrolling */ 
      }

      #chart_div {
      }
    </style>
  </head>
  <body>
    <div id="chart_div"></div>
  </body>
</html>
`;

const handleMarkerClick = (event: any) => {
    const data = JSON.parse(event.nativeEvent.data);
    const clickedData = facebookAdsRegionInsights?.items?.find((item: any) => item.city == data.region && item.clicks == data.clicks && item.impressions == data.impressions);
};

  const CustomMarker = () => {
    const styles = useStyles()
    return (
      <View style={styles.marker}>
        <View style={styles.dot} />
      </View>
    )
  };
  return (
    <View style={styles.container} key={"statsBySpend"}>
       <View style={styles.titleContainer}>
          <Typography style={styles.title}>Stats By Spend</Typography>
          <Icon name="helpSquareBlack"></Icon>
      </View>
      <View style={styles.statsShift}>
        <TouchableOpacity onPress={()=>{setSelected("Age") , setPieChartData(facebookAgeInsights)}}>
            <Typography style={[styles.statsShiftText, selected==="Age" && styles.blackText]}>{languageVariables? languageVariables["App.fb.wid3"] : ''}</Typography>
        </TouchableOpacity>
        <TouchableOpacity onPress={()=>{setSelected("Gender") , setPieChartData(facebookGenderInsights)}}>
            <Typography style={[styles.statsShiftText, selected==="Gender" && styles.blackText]}>{languageVariables? languageVariables["App.fb.wid2"] : ''}</Typography>
        </TouchableOpacity>
        <TouchableOpacity onPress={()=>setSelected("Locations")}>
            <Typography style={[styles.statsShiftText, selected==="Locations" && styles.blackText]}>{languageVariables? languageVariables["App.fb.wid8"] : ''}</Typography>
        </TouchableOpacity>
      </View>
      {
        selected !== "Locations" ?(<View style={styles.chartView}>
            <PieChart
              data={pieChartData??[]}
              width={pieChartData? 180 : 0}
              height={pieChartData? 220 : 0}
              chartConfig={chartConfig}
              accessor={"spend"}
              backgroundColor={"transparent"}
              paddingLeft={"32"}
              absolute={false}
              hasLegend={false}
              center={[12,0]}
            />
            <View>
            {pieChartData?.map((legend) => (
                <View style={styles.statsView} key={legend.age}>
                  <View style={[styles.circle, { backgroundColor: legend?.color }]} />
                  <Typography style={styles.legendTitle}>
                    {` ${legend?.age}`}
                    </Typography>
                    <Typography style={styles.legendPercentage}>{`${legend?.spend}`}</Typography>
                </View>
              ))}
              </View>
            </View>):(null)
      }
      {
        selected === "Locations" && facebookAdsRegionInsights?.items ? (<View>
            <WebView 
                originWhitelist={['*']}
                source={{ html: htmlContent }} 
                style={styles.webView}
                scrollEnabled
                showsHorizontalScrollIndicator={false}
                onMessage={handleMarkerClick}
                javaScriptEnabled={true}
                onLoad={() => console.log('WebView Loaded')}
                onError={(err) => console.log('WebView Error', err)}
            />
          </View>) : (null)
      }
      {
        selected === 'Locations' && !facebookAdsRegionInsights?.items ? (<View>
            <Typography style={styles.centerText}>No data found</Typography>
        </View>) : (null)
      }
      {
        selected === 'Gender' && !facebookAdsAgeInsights?.items ? (<View>
            <Typography style={styles.centerText}>No data found</Typography>
        </View>) : (null)
      }
      {
        selected === 'Age' && !facebookAdsGenderInsights?.items ? (<View>
            <Typography style={styles.centerText}>No data found</Typography>
        </View>) : (null)
      }
    </View>
  )
}
