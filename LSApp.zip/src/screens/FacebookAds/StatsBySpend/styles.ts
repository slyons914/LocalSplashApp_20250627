import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets,width }) => ({
  container: {
    flex: 1,
    paddingBottom: insets.bottom,
    paddingTop: 8,
    gap: 12,
    overflow: "visible",
  },
  title: {
    fontSize: 20,
    fontWeight: "500",
  },
  statsShift:{
    flexDirection:"row",
    gap:24,
    marginLeft:16
  },
  statsShiftText:{
    color:colors.greyDarkMode
  },
  blackText:{
    color:colors.black
  },
  legend: {
    flexDirection: "row",
    alignItems: "center",
    columnGap: 10,
  },
  circle: {
    height: 10,
    width: 10,
    borderRadius: 50,
  },
  legendTitle: {
    color: colors.black,
    fontSize: 12,
    fontWeight: "400",
  },
  legendPercentage: {
    fontSize: 16,
    fontWeight: "500",
  },
  chartView:{
    flexDirection:"row",
    gap:20,
    alignItems:"center",
  },
  statsView:{
    flexDirection:"row",
    alignItems:"center",
    gap:6
  },
  titleContainer:{
    flexDirection:"row",
    alignItems:"center",
    justifyContent:"space-between"
  },
  contentContainer: {
    marginVertical: 10,
  },
  impressionCount: {
    color: colors.dark,
    fontWeight: "500",
    fontSize: 16,
  },
  marker: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 30,
    height: 30,
  },
  linearGradient: {
    borderRadius: 5,
    height: 10,
    width: width - 160,
    marginHorizontal: 10,
  },
  dot: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: colors.blueBright,
  },
  map: {
    height: 400,
  },
  gradientView:{
    flexDirection:"row",
    alignItems:"center",
    justifyContent:"space-between"
  },
  webView: {
    width:"200%",
    height:250
  },
  centerText: {
    textAlign: 'center'
  }
}))
