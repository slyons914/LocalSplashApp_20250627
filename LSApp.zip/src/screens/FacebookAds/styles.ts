import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingBottom: insets.bottom,
    paddingTop: 8,
    paddingHorizontal: 24,
    gap: 12,
    overflow: "visible",
  },
  title: {
    fontSize: 24,
    fontWeight: "600",
    paddingTop: 0.5,
  },
  titleContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  filterBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 8,
    paddingLeft: 12,
    paddingRight: 8,
    borderWidth: 2,
    borderColor: colors.greyLight,
    borderRadius: 42,
    gap: 8,
  },
  indicatorContainer: {
    justifyContent: "center",
    flex: 1,
  },
  spinner: {
    alignSelf: "center",
  },
}))
