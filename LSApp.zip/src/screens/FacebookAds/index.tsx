import React, { useCallback, useEffect, useRef, useState } from "react"

import { ActivityIndicator, FlatList, TouchableOpacity, View, ViewToken, useColorScheme } from "react-native"

import { observer } from "mobx-react-lite"

import { Button, Icon, Locations, Tabs, Typography } from "@components"
import { Routes, colors } from "@utils/constants"

import { AnalyticsModal, ChangeRequestModal } from "@modals"
import { DateFilter } from "@models/index"
import { useStore } from "@store"
import moment from "moment"
import { AdPreview } from "./AdPreview"
import { Statistics } from "./Statistics"
import { StatsBySpend } from "./StatsBySpend"
import { useStyles } from "./styles"

const TABS: string[] = [
  "Stats",
  "Stats by Spend",
  "Facebook Ad Preview",
]

const Component: React.FC<ScreenProps<Routes.Facebook>> = () => {
  const styles = useStyles()

  const flatRef = useRef<FlatList>(null)

  const [activeTab, setActiveTab] = useState(0)
  const [scrollHandlerDisabled, setScrollHandlerDisabled] = useState(false)
  const [analyticsLabel, setAnalyticsLabel] = useState<string>("All time")
  const [analyticsModal, setAnalyticsModal] = useState(false)
  const date=new Date()
  const currentDate=moment(date).format("YYYY-MM-DD")
  const [dateFilter, setDateFilter] = useState<DateFilter>({
    fromDate: "1970-01-01",
    toDate: currentDate,
  })
  const [changeRequestModal,setChangeRequestModal] = useState(false)
  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"
  const { facebookAdsStore, homeStore } = useStore()
  const { getFacebookAdsPreview,getFacebookBaseInsights,getFacebookGenderInsights,getFacebookAgeInsights,getFacebookRegionInsights, getFacebookActionsInsights, isLoading} = facebookAdsStore
  const { locationsItem } = homeStore

  const sections = [
    (key: number) => <Statistics key={key} />,
    (key: number) => <StatsBySpend date={dateFilter} key={key} />,
    (key: number) => <AdPreview key={key} />,
  ]
  
  const onTabPress = (index: number) => {
    setScrollHandlerDisabled(true)
    flatRef.current?.scrollToIndex({ index, animated: true })

    setTimeout(() => {
      setScrollHandlerDisabled(false)
    }, 400)
  }

  const handleScroll = useCallback((info: {
    viewableItems: Array<ViewToken>;
    changed: Array<ViewToken>;
  }) => {
    info.viewableItems[0] &&
      info.viewableItems[0].index !== null &&
      setActiveTab(info.viewableItems[0].index)
  }, [])

  const renderSection = ({
    item,
    index,
  }: {
    item: (key: number) => React.JSX.Element
    index: number
  }) => item(index)

  useEffect(() => {
      if(!locationsItem?.id)
        return;
      getFacebookAdsPreview(locationsItem.id)
      getFacebookBaseInsights(locationsItem.id,dateFilter)
      getFacebookGenderInsights(locationsItem.id,dateFilter)
      getFacebookRegionInsights(locationsItem.id,dateFilter)
      getFacebookAgeInsights(locationsItem.id,dateFilter)  
      getFacebookActionsInsights(locationsItem.id, dateFilter)
  }, [locationsItem?.id,dateFilter])
  return (
    <View style={styles.container}>
      <View style={styles.titleContainer}>
        <Typography style={styles.title}>Facebook Ads</Typography>
        <TouchableOpacity onPress={() => setAnalyticsModal(true)} style={styles.filterBtn}>
        <Typography type={"subtext"}>{analyticsLabel}</Typography>
        <Icon name={isLightTheme ? "chevronDown" : "chevronDownWhite"} height={17} width={17} />
      </TouchableOpacity>
      </View>
      <Locations />
      <View>
        <Tabs
          tabs={TABS}
          onTabPress={onTabPress}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          allTabsDisabled={scrollHandlerDisabled}
        />
      </View>
      {isLoading ?
      <View style={styles.indicatorContainer}>
      <ActivityIndicator
        color={colors.common.orangePrimary}
        style={styles.spinner}
        size={"large"}
      />
    </View>
    : 
      <FlatList
        ref={flatRef}
        data={sections}
        renderItem={renderSection}
        onViewableItemsChanged={handleScroll}
        showsVerticalScrollIndicator={false}
        viewabilityConfig={{
          itemVisiblePercentThreshold: 50,
        }}
      />
    }
      <View style={{marginBottom:10}}>
        <Button icon={"reqReview"} onPress={()=>setChangeRequestModal(true)} label="Request Changes"></Button>
      </View>
      <AnalyticsModal
        isVisible={analyticsModal}
        onClose={() => setAnalyticsModal(false)}
        setDateFilter={setDateFilter}
        setAnalyticsLabel={setAnalyticsLabel}
      />
      <ChangeRequestModal 
        onClose={()=>setChangeRequestModal(false)}
        isVisible={changeRequestModal} >
      </ChangeRequestModal>
    </View>
  )
}

export const FacebookAdsScreen = observer(Component)
