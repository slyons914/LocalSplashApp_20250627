import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, width, height }) => ({
  container: {
    backgroundColor: colors.blue,
    width: width,
    alignItems: "center",
    justifyContent: "flex-end",
    height: height * 0.2,
  },
  messages: {
    alignItems: "center",
    marginBottom: 20,
  },
  back: {
    zIndex: 1,
    position: "absolute",
    bottom: 45,
  },
  front: {
    zIndex: 2,
    elevation: 20,
    shadowColor: "black",
    shadowOpacity: 0.4,
  },
}))
