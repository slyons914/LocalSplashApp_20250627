import { useState } from "react"

import { Alert, Linking, ScrollView, View } from "react-native"

import { useNavigation } from "@react-navigation/native"
import { requestNotifications, RESULTS } from "react-native-permissions"

import { Button, StatusBar, Typography } from "@components"
import { AreYouShureModal } from "@modals"
import { colors, Routes } from "@utils/constants"

import { BlueBlock } from "./BlueBlock"
import { InfoItem } from "./InfoItem"
import { useStyles } from "./styles"

export const NotificationsScreen = () => {
  const styles = useStyles()
  const { navigate } = useNavigation()

  const [confirmModal, setConfirmModal] = useState(false)

  const openSettings = async () => {
    await Linking.openSettings()
  }

  const anotherTimeHandler = () => {
    navigate(Routes.Permissions)
  }

  const showAlert = async () => {
    Alert.alert(
        `Notification Permission Blocked`,
        `If you want to receive notifications you need to enable Notification access in settings. Would you like to open the settings?`,
        [
          {
            text: "Cancel",
            onPress: () => navigate(Routes.Permissions),
            style: "cancel",
          },
          {
            text: "Open Settings",
            onPress: () => Linking.openSettings(),
          },
        ]
      );
  }


  const pushNotificationHandler = async () => {
    setConfirmModal(false)
    const { status } = await requestNotifications(["alert", "sound"])
    console.log("status is: ", status)
    if (status === RESULTS.BLOCKED) {
      showAlert()
    }
    if (status === RESULTS.GRANTED) {
      navigate(Routes.Permissions)
    }
  }

  const onDecline = () => {
    setConfirmModal(false)
    navigate(Routes.Permissions)
  }

  return (
    <View style={styles.container}>
      <StatusBar backgroundColor={colors.common.blue} />
      <BlueBlock />
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <Typography style={styles.title}>Notifications</Typography>
        <View style={styles.infoBlock}>
          <InfoItem
            icon={"userPlus"}
            label={"Leads"}
            text={"Get notified as soon as a potential customer is trying to reach you."}
          />
          <InfoItem
            icon={"messageChatSquare"}
            label={"Calls & SMS"}
            text={"Get notified when a potential customer is calling or texting your business."}
          />
          <InfoItem
            icon={"lineChartUp"}
            label={"Business Information"}
            text={"Get notified about important updates regarding your account."}
          />
        </View>
        <Typography style={styles.settingsText}>
          You can always adjust these later from within the{" "}
          <Typography onPress={openSettings} style={styles.settings}>
            System Settings.
          </Typography>
        </Typography>
        <View style={styles.buttonsContainer}>
          <Button icon={"bell"} onPress={pushNotificationHandler} label="enable" />
          <Typography onPress={anotherTimeHandler} style={styles.anotherTime}>
            No, another time
          </Typography>
        </View>
      </ScrollView>
      <AreYouShureModal
        onDecline={onDecline}
        onEnable={pushNotificationHandler}
        isVisible={confirmModal}
        onClose={() => setConfirmModal(false)}
        text={
          "By giving access to Notifications, you will be able to see in real time when your customers are trying to reach you."
        }
      />
    </View>
  )
}
