import { Icon, Typography } from "@components"
import { useNavigation } from "@react-navigation/native"
import { imagePath } from "@utils/constants/imagesPath"
import React, { useState } from "react"
import { ImageBackground, Platform, Pressable, View, useColorScheme } from "react-native"
import BackIcon from "../../../assets/icons/bacIconWhite.svg"
import { useStyles } from "./style"
import { FeedbackModal } from "@modals"
import DeviceInfo from "react-native-device-info"
import { InAppBrowserStyle, LsConfig } from "@utils/constants/common"
import InAppBrowser from "react-native-inappbrowser-reborn"
import { UserAPI } from "@api"

export const About = () => {
  const styles = useStyles()
  const [isFeedbackModalVisible, setIsFeedbackModalVisible] = useState(false)
  const navigation = useNavigation()
  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"

  const handleBack = () => {
    navigation.goBack()
  }

  const fetchUserData = async () => {
    const { data } = await UserAPI.getUserData()
    if (!data) {
        return
    }
    return data.authenticatedMember.contactPhone
  }

  const openTerms = async () => {
    const phonrNumber = await fetchUserData ()
    InAppBrowser.open(`https://${LsConfig.MODE}my.localsplash.com/terms/${phonrNumber}?contentonly=true`, InAppBrowserStyle)
  }

  return (
    <ImageBackground
      source={isLightTheme ? imagePath.aboutBackground : imagePath.aboutDarkBackground}
      style={styles.backgroundImage}
    >
      <View style={styles.header}>
        <Pressable style={styles.backButton} onPress={handleBack}>
          <BackIcon />
        </Pressable>
        <Typography type="title" style={styles.title}>
          About
        </Typography>
        <View />
      </View>
      <View style={styles.container}>
        <Typography style={styles.version} type="default">
          {Platform.OS === "android" ?  DeviceInfo.getVersion() :  DeviceInfo.getVersion() + '.' + DeviceInfo.getBuildNumber()}
        </Typography>
        <Typography style={styles.text} type="subtext">
          Effortlessly manage your leads and everything else your company needs to succeed.
        </Typography>
        <Pressable
          style={styles.leaveFeedbackButton}
          onPress={() => setIsFeedbackModalVisible(true)}
        >
          <Icon name="happy_emoji" color={"orange"} />
          <Typography style={styles.leaveFeedbackText} type="subtext">
            Leave Feedback
          </Typography>
        </Pressable>
        <Typography
          type="title"
          style={styles.footerText}
          onPress={openTerms}>
          Local Splash Terms of Experience
        </Typography>
      </View>
      <FeedbackModal
        isVisible={isFeedbackModalVisible}
        onClose={() => setIsFeedbackModalVisible(false)}
        setFeedbackModal={setIsFeedbackModalVisible}
      />
    </ImageBackground>
  )
}
