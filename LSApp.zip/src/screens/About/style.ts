import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets, height, isDarkTheme }) => ({
    backgroundImage: {
        flex: 1,
        resizeMode: "cover",
        justifyContent: "space-between",
    },
    header: {
        flexDirection: "row",
        marginVertical: insets.top,
        justifyContent: "center",
        padding: 10,
        alignItems: "center",
    },
    title: {
        color: colors.white,
        fontWeight: "500",
        fontSize: 20,
    },
    backButton: {
        position:"absolute",
        height: 40,
        width: 30,
        left:20,
        justifyContent: "center",
        alignItems: "center",

    },
    container: {
        paddingHorizontal: 60,
        marginBottom: 30,
        height: "30%"
    },
    version: {
        fontWeight: "500",
        fontSize: 20,
        textAlign: "center",
        color: isDarkTheme ? colors.white : colors.black
    },
    text: {
        textAlign: "center",
        lineHeight: 24,
        marginVertical: 10,
        fontSize: 16,
        color: isDarkTheme ? colors.white : colors.greyText
    },
    leaveFeedbackButton: {
        flexDirection: "row",
        backgroundColor: colors.orangePrimary,
        borderRadius: 115,
        alignItems: "center",
        justifyContent: "space-around",
        width: "60%",
        alignSelf: "center",
        padding: 10,
        marginBottom: 35,
    },
    leaveFeedbackText: {
        color: colors.white,
        fontSize: 14,
        fontWeight: "400"
    },
    footerText: {
        color: colors.orangePrimary,
        fontWeight: "400",
        fontSize: 14,
        textAlign: "center",
        marginTop: 10

    },
}))
