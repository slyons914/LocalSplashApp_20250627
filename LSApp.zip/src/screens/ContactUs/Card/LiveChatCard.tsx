import { Button,   Typography } from "@components"
import React from "react"
import { View, useColorScheme } from "react-native"
import { useStyles } from "./styles"
import InAppBrowser from "react-native-inappbrowser-reborn"
import { InAppBrowserStyle } from "@utils/constants/common"

const LiveChatCard = () => {
    const styles = useStyles()

    const handleChatPress = () => {
        InAppBrowser.close()
        InAppBrowser.open("https://localsplash.com/contact", InAppBrowserStyle)
    }

    // const handleCloseChat = () => {
    //     setChatVisible(false)
    // }
    return (
        <View style={styles.cardContainer}>
            <Typography type="title" style={styles.cardTitle}>
                Live Chat
            </Typography>
            <Typography type="subtext" style={styles.subText}>
                Chat now with an available representative.
            </Typography>
            <Button label="Let's Chat" onPress={handleChatPress} btnStyle={styles.button} />
            {/* <Modal visible={isChatVisible} animationType="slide" onRequestClose={handleCloseChat}>
                <View style={styles.modalContainer}>
                    <View style={styles.header}>
                        <Pressable style={styles.closeButton} onPress={handleCloseChat}>
                            <Icon
                                name={isLightTheme ? "ChevronLeftReviews" : "bacIconWhite"}
                                height={20}
                                width={20}
                            />
                        </Pressable>
                        <View
                            style={styles.circle}
                        >
                            <Typography style={styles.circleText} >LS</Typography>
                        </View>
                        <Typography style={styles.title} >Local Splash</Typography>
                    </View>
                    <DriftChatWebView />
                </View>
            </Modal> */}
        </View>
    )
}

export default LiveChatCard
