import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme }) => ({
    cardContainer: {
        backgroundColor: isDarkTheme ? colors.lightBlack : colors.superLightBlue,
        borderRadius: 16,
        gap: 16,
        padding: 22,
        marginVertical: 10
    },
    cardTitle: {
        fontWeight: "500",
        fontSize: 20,
    },
    subText: {
        fontSize: 16,
        fontWeight: "400",
    },
    timeText: {
        fontSize: 16,
        fontWeight: "400",
    },
    button: {
        width: "40%",
        alignSelf: "flex-start",
    },
    sendMessageButton: {
        width: "50%"
    },
    modalContainer: {
        flex: 1,
        backgroundColor: colors.background,
    },
    closeButton: {
        padding: 10,
        paddingHorizontal: 15
    },
    closeButtonText: {
        fontSize: 16,
        color: '#333',
    },
    header: {
        flexDirection: "row",
        padding: 10,
        alignItems: "center",
        paddingVertical: 15
    },
    circle: {
        backgroundColor: colors.blueDark,
        height: 50,
        width: 50,
        borderRadius: 50,
        justifyContent: "center",
        alignItems: "center",
        marginHorizontal: 10
    },
    circleText: {
        fontWeight: "500",
        fontSize: 16,
        color: colors.white
    },
    title: {
        fontSize: 16,
        fontWeight: "400"
    },


}))
