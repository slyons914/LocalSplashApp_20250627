import { View, Text } from 'react-native'
import React from 'react'
import { useStyles } from './styles'
import { Button, Typography } from '@components'

interface Props {
    setSendMessageModalVisible: (visible: boolean) => void;
}


const SendMessage = ({ setSendMessageModalVisible }: Props) => {
    const styles = useStyles()
    return (
        <View
            style={styles.cardContainer}>
            <Typography
                type="title"
                style={styles.cardTitle} >
                Send Message
            </Typography>
            <Typography
                type="subtext"
                style={styles.subText}
            >Fill out the form and our staff will be in touch.</Typography>
            <Button
                label="Send Message"
                onPress={() => setSendMessageModalVisible(true)}
                btnStyle={[styles.button, styles.sendMessageButton]}

            />
        </View>
    )
}

export default SendMessage
