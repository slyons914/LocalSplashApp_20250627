import { View, Text, Linking } from 'react-native'
import React from 'react'
import { useStyles } from './styles'
import { Button, Typography } from '@components'
import { FormatHelper } from '@utils/helpers'


const CallUsCard = () => {
    const styles = useStyles()
    const phoneNumber = "8776356225"
    const onPhonePress = () => {
        Linking.openURL("tel:1-877-635-6225")
    }
    return (
        <View
            style={styles.cardContainer}>
            <Typography
                type="title"
                style={styles.cardTitle} >
                Phone
            </Typography>
            <Typography
                type="subtext"
                style={styles.subText}
            >{FormatHelper.formatPhoneNumber(phoneNumber)}</Typography>
            <Typography
                type="subtext"
                style={styles.timeText}
            >
                M-F 7:00AM-4:00PM PST
            </Typography>
            <Button
                label="Call Us"
                onPress={onPhonePress}
                btnStyle={styles.button}
            />
        </View>
    )
}

export default CallUsCard