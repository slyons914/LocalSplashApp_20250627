import { Button, Typography } from '@components'
import React from 'react'
import { Linking, View } from 'react-native'
import { useStyles } from './styles'


const EmailCard = () => {
    const styles = useStyles()
    const sendEmail = () => {
        Linking.openURL("mailto:support@localsplash.com")
    }
    return (
        <View
            style={styles.cardContainer}>
            <Typography
                type="title"
                style={styles.cardTitle} >
                Email
            </Typography>
            <Typography
                type="subtext"
                style={styles.subText}
            >support@localsplash.com</Typography>
            <Button
                label="Email Us"
                onPress={sendEmail}
                btnStyle={styles.button}

            />
        </View>
    )
}

export default EmailCard