import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
    container: {
        flex: 1,
        backgroundColor: colors.background,
        paddingHorizontal: 24,
        paddingTop: insets.top || 16,
        paddingBottom: insets.bottom || 16,
    },
    helpText: {
        fontWeight: "600",
        fontSize: 24,
    },
    contentContainer: {
        marginVertical: 10,
        marginBottom: 30
    }
}))
