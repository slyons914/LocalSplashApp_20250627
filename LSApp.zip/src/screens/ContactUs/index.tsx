import React, { useState } from "react"

import { ScrollView, View } from "react-native"

import { SimpleHeader, Typography } from "@components"
import { SendMessageModal } from "@modals"
import { useNavigation } from "@react-navigation/native"
import { Routes } from "@utils/constants"
import { observer } from "mobx-react-lite"
import CallUsCard from "./Card/CallUsCard"
import EmailCard from "./Card/EmailCard"
import LiveChatCard from "./Card/LiveChatCard"
import SendMessage from "./Card/SendMessage"
import { useStyles } from "./styles"

const Component: React.FC<ScreenProps<Routes.ContactUs>> = () => {
    const styles = useStyles()
    const navigation = useNavigation()
    const [sendMessageModalVisible, setSendMessageModalVisible] = useState(false)


    const handleGoback = () => {
        navigation.goBack()
    }



    return (
        <>
            <ScrollView style={styles.container}>
                <SimpleHeader onLeftPress={handleGoback} />
                <Typography
                    type="default"
                    style={styles.helpText}
                >Need some help?</Typography>
                <View
                    style={styles.contentContainer}
                >
                    <CallUsCard />
                    <LiveChatCard />
                    <EmailCard />
                    <SendMessage
                        setSendMessageModalVisible={setSendMessageModalVisible}
                    />
                </View>
            </ScrollView>
            <SendMessageModal
                isVisible={sendMessageModalVisible}
                onClose={() => setSendMessageModalVisible(false)}
            />
        </>
    )
}

export const ContactUsScreen = observer(Component)
