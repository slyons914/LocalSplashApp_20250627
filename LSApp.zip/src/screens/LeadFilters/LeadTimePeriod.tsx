import { FlatList, Pressable, View } from "react-native"
import { useStyles } from "./styles"
import { observer } from "mobx-react-lite"
import { Icon, Typography } from "@components"
import { useLeadContext } from "@providers"
import { FormatHelper } from "@utils/helpers"
import { DateFilter } from "@models/index"
import { RadioButton } from "react-native-radio-buttons-group"
import { colors } from "@utils/constants"
import React, { useState } from "react"
import DatePicker from "react-native-date-picker"
import { LeadFilters } from "@models/leads"

const enum activeTabEnum {
  AllTime = 1,
  Last7Days = 2,
  Last30Days = 3,
  Last3Month = 4,
  Last6Month = 5,
  CustomRange = 6
}

interface props {
    leadFilters: LeadFilters,
    setLeadFilters: React.Dispatch<React.SetStateAction<LeadFilters>>
    activeTimeTab: number
    setActiveTimeTab: React.Dispatch<React.SetStateAction<number>>
}

export const component = ({leadFilters, activeTimeTab, setLeadFilters, setActiveTimeTab}: props ) => {

  const [isStartDatePickerVisible, setIsStartDatePickerVisible] = useState(false)
  const [isEndDatePickerVisible, setIsEndtDatePickerVisible] = useState(false)
  const [startDate, setStartDate] = useState<Date>(new Date ())
  const [endDate, setEndDate] = useState<Date>(new Date ())
  const styles = useStyles()

  const leadTimePeriod = [
    {
      title: "All Time",
      onPress:() => onItemPress(activeTabEnum.AllTime, "All time"),
      value: activeTimeTab === activeTabEnum.AllTime
    },
    {
      title: "Last 7 Days",
      onPress:() => onItemPress(activeTabEnum.Last7Days, "Last 7 Days"),
      value: activeTimeTab === activeTabEnum.Last7Days,
     },
    {
      title: "Last 30 Days",
      onPress:() => onItemPress(activeTabEnum.Last30Days, "Last 30 Days"),
      value: activeTimeTab === activeTabEnum.Last30Days,
    },

    {
      title: "Last 3 Months",
      onPress:() => onItemPress(activeTabEnum.Last3Month, "Last 3 Months"),
      value: activeTimeTab === activeTabEnum.Last3Month,
    },
    {
      title: "Last 6 Months",
      onPress:() => onItemPress(activeTabEnum.Last6Month, "Last 6 Months"),
      value: activeTimeTab === activeTabEnum.Last6Month,
    },
    {
      title: "Custom Range",
      onPress:() => onItemPress(activeTabEnum.CustomRange, "Custom Range"),
      value: activeTimeTab === activeTabEnum.CustomRange,
    },
  ]

  const getLastNDaysDateRange = (days: number) => {
    const today = new Date()
    const fromDate = new Date()
    const toDate = new Date()
  
    fromDate.setDate(today.getDate() - days + 1)
  
    return {
        fromDate: FormatHelper.formatDateString(fromDate),
        toDate: FormatHelper.formatDateString(toDate),
      }
  }
  
  const getLastNMonthsDateRange = (months: number) => {
    const today = new Date()
    const fromDate = new Date(today.getFullYear(), today.getMonth() - months, 1)
    const toDate = new Date(today.getFullYear(), today.getMonth() + 1, 0)
  
    return {
        fromDate: FormatHelper.formatDateString(fromDate),
        toDate: FormatHelper.formatDateString(toDate),
      }
  }
  
  const getAllTime = () => {
    const today = new Date()
    const toDate = new Date(today.getFullYear(), today.getMonth() + 1, 0)
  
    return { fromDate: "1970-01-01", toDate: FormatHelper.formatDateString(toDate) }
  }

  const setDateFilter = (date: DateFilter) => {
    setLeadFilters({
        ...leadFilters,
        FromDate: date.fromDate,
        ToDate: date.toDate,
      })
  }

  const pickDateRange = (activeTab: number) => {
    switch (activeTab) {
      case activeTabEnum.AllTime:
        setDateFilter(getAllTime())
        break
      case activeTabEnum.Last7Days:
        setDateFilter(getLastNDaysDateRange(7))
        break
      case activeTabEnum.Last30Days:
        setDateFilter(getLastNDaysDateRange(30))
        break
      case activeTabEnum.Last3Month:
        setDateFilter(getLastNMonthsDateRange(3))
        break
      case activeTabEnum.Last6Month:
        setDateFilter(getLastNMonthsDateRange(6))
        break
      default:
        setDateFilter({fromDate: FormatHelper.formatDateString(startDate), toDate: FormatHelper.formatDateString(endDate)})
        break
    }
  }
  const onItemPress = (activeTab: number, tabName: string) => {
    pickDateRange(activeTab)
    setActiveTimeTab(activeTab)
  }

  const handleSetStartDate = (startDate: Date) => {
    setIsStartDatePickerVisible(false)
    setStartDate(startDate)
    setDateFilter({fromDate: FormatHelper.formatDateString(startDate), toDate: FormatHelper.formatDateString(endDate)})
  }

  const handleSetEndDate = (endDate: Date) => {
    setIsEndtDatePickerVisible(false)
    setEndDate(endDate)
    setDateFilter({fromDate: FormatHelper.formatDateString(startDate), toDate: FormatHelper.formatDateString(endDate)})
  }


  return (
    <View>
        <FlatList
        data={leadTimePeriod}
        keyExtractor={(_, index) => index.toString()}
        renderItem={({ item }) => (
        <Pressable style={styles.radioButtonContainer} onPress={item?.onPress}>
            <RadioButton
                id={item.title}
                selected={item.value}
                onPress={item.onPress}
                size={24}
                color={colors.common.orangePrimary}
                borderSize={2}
            />
            <Typography style={[styles.label, item.value && styles.selectedText]}>
                {item.title}
            </Typography>
        </Pressable>
        )}
        />
        {
            activeTimeTab === activeTabEnum.CustomRange &&
            <View style={styles.dateView}>
                <View style={styles.dateSubView}>
                    <Typography style={styles.greyText}>
                        Start Date
                    </Typography>
                    <Pressable onPress={() => setIsStartDatePickerVisible(true)} style={styles.dateContainer}>
                        <Typography>
                            {leadFilters?.FromDate ? leadFilters?.FromDate : startDate.toLocaleString()}
                        </Typography>
                        <Icon name="CalenderIcon" />
                    </Pressable>
                </View>
                <View style={styles.dateSubView}>
                    <Typography style={styles.greyText}>
                        End Date
                    </Typography>
                    <Pressable onPress={() => setIsEndtDatePickerVisible(true)} style={styles.dateContainer}>
                        <Typography>
                            {leadFilters?.ToDate ? leadFilters?.ToDate : endDate.toLocaleString()}
                        </Typography>
                        <Icon name="CalenderIcon" />
                    </Pressable>
                </View>
            </View>
        }
        <DatePicker
          modal
          date={endDate}
          onConfirm={handleSetStartDate}
          open={isStartDatePickerVisible}
          mode={"date"}
          minimumDate={new Date('1970-01-01')}
          maximumDate={new Date ()}
          onCancel={()=>setIsStartDatePickerVisible(false)}
        />
        <DatePicker
          modal
          date={endDate}
          onConfirm={handleSetEndDate}
          open={isEndDatePickerVisible}
          mode={"date"}
          minimumDate={new Date('1970-01-01')}
          maximumDate={new Date ()}
          onCancel={()=>setIsEndtDatePickerVisible(false)}
        />  
    </View>
  )
}
export const LeadTimeList = observer(component)