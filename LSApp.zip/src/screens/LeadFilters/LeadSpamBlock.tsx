import { FlatList, Pressable, Switch } from "react-native"
import { useStyles } from "./styles"
import { observer } from "mobx-react-lite"
import { Typography } from "@components"
import { LeadFilters } from "@models/leads"

interface props {
    leadFilters: LeadFilters,
    setLeadFilters: React.Dispatch<React.SetStateAction<LeadFilters>>
}


export const component = ({leadFilters, setLeadFilters} : props) => {

  const LeadSpamBlock = [
    {
      title: "Include Spam",
      onPress: () => setTypeHandler("isSpam"),
      value: !!leadFilters.isSpam
    },
    {
      title: "Include Blocked",
      onPress: () => setTypeHandler("isBlocked"),
      value: !!leadFilters.isBlocked
    },
  ]

  const setTypeHandler = (key: keyof LeadFilters) => {
      const newFilter:LeadFilters = {
        ...leadFilters,
        [key] : !leadFilters[key]
      }
      setLeadFilters(newFilter)
  }

  const styles = useStyles()
  return (
    <FlatList
    data={LeadSpamBlock}
    keyExtractor={(_, index) => index.toString()}
    renderItem={({ item }) => (
    <Pressable style={styles.checkboxContainer} onPress={item?.onPress}>
        <Typography style={[styles.label, styles.selectedText]}>
            {item.title}
        </Typography>
        <Switch value={item.value} onChange={item.onPress}></Switch>
    </Pressable>
    )}
    />
  )
}
export const LeadSpamBlockList = observer(component)