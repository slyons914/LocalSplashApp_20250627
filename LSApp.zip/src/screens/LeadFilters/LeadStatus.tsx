import { FlatList, Pressable } from "react-native"
import { useStyles } from "./styles"
import { observer } from "mobx-react-lite"
import { Checkbox, Typography } from "@components"
import { LeadFilters } from "@models/leads"

interface props {
    leadFilters: LeadFilters,
    setLeadFilters: React.Dispatch<React.SetStateAction<LeadFilters>>
}

export const component = ({leadFilters, setLeadFilters}: props) => {

  const leadStatus = [
    {
      title: "Follow-Up Needed",
      onPress: () => setTypeHandler("AreFollowUpNeededLeadsIncluded"),
      value: !!leadFilters.AreFollowUpNeededLeadsIncluded
    },
    {
      title: "Scheduled",
      onPress: () => setTypeHandler("AreScheduledLeadsIncluded"),
      value: !!leadFilters.AreScheduledLeadsIncluded
     },
    {
      title: "Completed",
      onPress: () => setTypeHandler("AreCompletedLeadsIncluded"),
      value: !!leadFilters.AreCompletedLeadsIncluded
    },

    {
      title: "Not a Valid Lead",
      onPress: () => setTypeHandler("AreNotaValidLeadsIncluded"),
      value: !!leadFilters.AreNotaValidLeadsIncluded
    },
    {
      title: "No Answer",
      onPress: () => setTypeHandler("AreNoAnswerLeadsIncluded"),
      value: !!leadFilters.AreNoAnswerLeadsIncluded
    },
    {
      title: "Not Interested",
      onPress: () => setTypeHandler("AreNotInterestedLeadsIncluded"),
      value: !!leadFilters.AreNotInterestedLeadsIncluded
    }
  ]

  const setTypeHandler = (key: keyof LeadFilters) => {
    const newFilter:LeadFilters = {
        ...leadFilters,
        [key] : !leadFilters[key]
    }
    setLeadFilters(newFilter)
  }

  const styles = useStyles()
  return (
    <FlatList
    data={leadStatus}
    keyExtractor={(_, index) => index.toString()}
    renderItem={({ item }) => (
    <Pressable style={styles.checkboxContainer} onPress={item?.onPress}>
        <Checkbox
            value={item.value}
            onPress={item.onPress}
        />
        <Typography style={[styles.label, item.value && styles.selectedText]}>
            {item.title}
        </Typography>
    </Pressable>
    )}
    />
  )
}
export const LeadStatusList = observer(component)