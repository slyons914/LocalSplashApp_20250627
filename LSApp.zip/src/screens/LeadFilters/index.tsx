import { Pressable, View } from "react-native"
import { Routes } from "@utils/constants"
import { useStyles } from "./styles"
import { observer } from "mobx-react-lite"
import { Button, Icon, Typography } from "@components"
import { useEffect, useMemo, useState } from "react"
import { LeadTypeList } from "./LeadType"
import { LeadStatusList } from "./LeadStatus"
import { LeadLocationsList } from "./LeadLocations"
import { LeadTimeList } from "./LeadTimePeriod"
import { LeadSpamBlockList } from "./LeadSpamBlock"
import { useLeadContext } from "@providers"
import { useStore } from "@store"

const filtersArray = [
    'Lead Type', 
    'Status Type', 
    'Time Period', 
    'Location', 
    'Spam'
  ]

export const component = ({ navigation }: ScreenProps<Routes.LeadFilters>) => {

  const {filters, setFilters, setActiveDate, activeDate} = useLeadContext()

  const {homeStore} = useStore()
  const {locationsItem, profiles, setLocationsIndex, setLocationsItem} = homeStore

  const [currentSection, setCurrentSection] = useState('Lead Type')  
  const [leadFilters, setLeadFilters] = useState(filters)
  const [activeTimeTab, setActiveTimeTab] = useState(activeDate)
  const [selectedLocationId, setSelectedLocationId] = useState(locationsItem?.id)

  const styles = useStyles()

  const sections = [
      {
        name: "Lead Type",
        component: <LeadTypeList leadFilters={leadFilters} setLeadFilters={setLeadFilters}/>,
      },
      {
        name: "Status Type",
        component: <LeadStatusList leadFilters={leadFilters} setLeadFilters={setLeadFilters}/>,
      },
      {
        name: "Time Period",
        component: <LeadTimeList leadFilters={leadFilters} setLeadFilters={setLeadFilters} activeTimeTab={activeTimeTab} setActiveTimeTab={setActiveTimeTab}/>,
      },
      {
        name: "Location",
        component: <LeadLocationsList leadFilters={leadFilters} setLeadFilters={setLeadFilters} selectedLocationId={selectedLocationId} setSelectedLocationId={setSelectedLocationId}/>,
      },
      {
        name: "Spam",
        component: <LeadSpamBlockList leadFilters={leadFilters} setLeadFilters={setLeadFilters}/>,
      }
    ]
  const handleFilterPress = (item: string) => {
    setCurrentSection(item)
  }

  const handleViewLeadPress = () => {
    if(selectedLocationId !== locationsItem?.id) {
        const index = profiles?.profiles?.findIndex(item => item.id === selectedLocationId)
        if (index !== -1 && (index || index === 0) && profiles?.profiles?.[index]) {
            setLocationsIndex(index)
            setLocationsItem(profiles?.profiles?.[index])
        }
    }
    setFilters(leadFilters)
    setActiveDate(activeTimeTab)
    navigation.goBack()
  }

  const handleClearPress = () => {
    setLeadFilters({
        isSpam: false,
        isBlocked: false,
        isRead: null,
        FromDate: null,
        ToDate: null,
        Search: "",
        Length:30,
        AreCallLeadLogsIncluded:false,
        AreGoogleLeadLogsIncluded:false,
        AreSmsLeadLogsIncluded:false,
        AreFacebookLeadLogsIncluded:false,
        AreWebsiteFormLeadLogsIncluded:false ,
        AreScheduledLeadsIncluded: false,
        AreFollowUpNeededLeadsIncluded: false,
        AreCompletedLeadsIncluded: false,
        AreNotaValidLeadsIncluded: false,
        AreNoAnswerLeadsIncluded: false,
        AreNotInterestedLeadsIncluded: false,
    })
    setActiveDate(1)
    setSelectedLocationId(locationsItem?.id)
  }

  const getFilterCount = useMemo(() => {
    return (itemName: string) => {
        let count = 0;
      if (itemName === 'Spam') {
        count = leadFilters?.isSpam ? count + 1 : count
        count = leadFilters?.isBlocked ? count + 1 : count
      } else if (itemName === 'Status Type') {
        count = leadFilters?.AreCompletedLeadsIncluded ? count + 1 : count
        count = leadFilters?.AreFollowUpNeededLeadsIncluded ? count + 1 : count
        count = leadFilters?.AreScheduledLeadsIncluded ? count + 1 : count
        count = leadFilters?.AreNotaValidLeadsIncluded ? count + 1 : count
        count = leadFilters?.AreNoAnswerLeadsIncluded ? count + 1 : count
        count = leadFilters?.AreNotInterestedLeadsIncluded ? count + 1 : count
      } else if (itemName === 'Time Period') {
        return null;
      } else if (itemName === 'Location') {
        return null;
      } else if (itemName === 'Lead Type') {
        count = leadFilters?.AreCallLeadLogsIncluded ? count + 1 : count
        count = leadFilters?.AreFacebookLeadLogsIncluded ? count + 1 : count
        count = leadFilters?.AreGoogleLeadLogsIncluded ? count + 1 : count
        count = leadFilters?.AreSmsLeadLogsIncluded ? count + 1 : count
        count = leadFilters?.AreWebsiteFormLeadLogsIncluded ? count + 1 : count
      }
      if(count === 0) {
        return null;
      }
      return count;
    }
  }, [leadFilters])

  useEffect(() => {
    setLeadFilters(filters)
  },[filters])

  useEffect(() => {
    setActiveTimeTab(activeDate)
  },[activeDate])

  useEffect(() => {
    setSelectedLocationId(locationsItem?.id)
  },[locationsItem])

  return (
    <View style={styles.container}>
        <View style={styles.headerContainer}>
            <Typography style={styles.titleText}>Filters</Typography>
            <Typography onPress={handleClearPress} style={styles.clearText}>Clear All</Typography>
        </View>
        <View style={styles.mainView}>
            <View style={styles.sidebar}>
                {filtersArray.map((item) => (
                <View key={item} style={{flexDirection:"row", alignItems:"center"}}>
                    <Pressable onPress={() => handleFilterPress(item)} style={[styles.sidebarItem, item === currentSection && styles.selectedTab]}>
                        <Typography style={[styles.sidebarText, item === currentSection && styles.selectedTabText]}>{item}</Typography>
                        <Typography style={[ styles.filterCount, item === currentSection && styles.itemCountText]}>{getFilterCount(item)}</Typography>
                    </Pressable>
                    {
                        currentSection === item &&
                        <Icon name="blueArrow" />
                    }
                </View>
                ))}
            </View>
            <View style={styles.content}>
                {sections.map(({ component, name }, i) => (
                    <View key={i} style={currentSection === name ? styles.flexed : styles.hidden}>
                    {component}
                    </View>
                ))}
            </View>
        </View>
        <View>
            <Button label="View Leads" onPress={handleViewLeadPress}/>
        </View>
    </View>
  )
}
export const LeadsFilter = observer(component)