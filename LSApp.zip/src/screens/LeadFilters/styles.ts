import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    gap: 12
  },
  headerContainer: {
    flexDirection:"row",
    justifyContent:"space-between",
    paddingVertical: 16,
    paddingHorizontal: 24,
  },
  titleText: {
    fontWeight: "500",
    fontSize: 20
  },
  clearText: {
    fontSize: 16,
    color: colors.redText
  },
  sidebar: { 
    width: '33%', 
    backgroundColor: colors.lightBlue,
    height:"100%"
  },
  sidebarItem: { 
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderColor: isDarkTheme ? 'rgba(255, 255, 255, 0.2' : 'rgba(0, 0, 0, 0.06)',
    justifyContent: "space-between",
    width:"100%",
    flexDirection: 'row',
    alignItems: 'center',
  },
  sidebarText: { 
    lineHeight: 21
  },
  filterCount: {
    color:"#454F59",
    fontSize: 12
  },
  selectedTab: { 
    backgroundColor: colors.blue, 
  },
  selectedTabText: { 
    color: colors.white
  },
  mainView: {
   flexDirection:"row",
   height:"80%",
   borderWidth: 1,
   borderColor: isDarkTheme ? 'rgba(255, 255, 255, 0.2' : 'rgba(0, 0, 0, 0.06)',
  },
  itemCountText: {
    color: colors.white, 
  },
  content: { 
    flex: 1,
    height:"80%"
  },
  checkboxContainer: { 
    flexDirection: 'row', 
    alignItems: 'center',
    paddingHorizontal:16,
    paddingVertical: 11,
  },
  radioButtonContainer: { 
    flexDirection: 'row', 
    alignItems: 'center',
    paddingHorizontal:16,
    paddingVertical: 6,
  },
  label: { 
    fontSize: 16, 
    marginLeft: 10, 
    flex: 1 ,
    color: colors.subText,
  },
  selectedText: {
    color: colors.text
  },
  count: { 
    fontSize: 16, 
    color: colors.subText
  },
  hidden: {
    display: "none",
  },
  flexed: {
    display: "flex",
  },
  dateView: {
    paddingVertical :12,
    paddingHorizontal: 16,
    gap:12
  },
  dateSubView: {
    gap:6
  },
  dateContainer: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    flexDirection:"row",
    justifyContent:"space-between",
    borderWidth: 1,
    borderRadius: 8,
    borderColor: colors.gray6
  },
  greyText: {
    color: colors.subText
  }
}))
