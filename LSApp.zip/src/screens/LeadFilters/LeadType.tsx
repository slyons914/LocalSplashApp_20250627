import { FlatList, Pressable } from "react-native"
import { useStyles } from "./styles"
import { observer } from "mobx-react-lite"
import { Checkbox, Typography } from "@components"
import { LeadFilters } from "@models/leads"

interface props {
    leadFilters: LeadFilters,
    setLeadFilters: React.Dispatch<React.SetStateAction<LeadFilters>>
}

export const component = ({leadFilters, setLeadFilters} : props) => {

  const leadTypes = [
    {
      title: "Phone Calls",
      onPress: () => setTypeHandler("AreCallLeadLogsIncluded"),
      value: !!leadFilters.AreCallLeadLogsIncluded,
    },
    {
        title: "SMS",
        onPress: () => setTypeHandler("AreSmsLeadLogsIncluded"),
        value: !!leadFilters.AreSmsLeadLogsIncluded,
     },
    {
      title: "Website",
      onPress: () => setTypeHandler("AreWebsiteFormLeadLogsIncluded"),
      value: !!leadFilters.AreWebsiteFormLeadLogsIncluded,
    },

    {
      title: "Facebook Ads",
      onPress: () => setTypeHandler("AreFacebookLeadLogsIncluded"),
      value: !!leadFilters.AreFacebookLeadLogsIncluded,
    },
    {
      title: "Google Guaranteed Ads",
      onPress: () => setTypeHandler("AreGoogleLeadLogsIncluded"),
      value: !!leadFilters.AreGoogleLeadLogsIncluded,
    },
  ]

  const setTypeHandler = (key: keyof LeadFilters) => {
      const newFilter:LeadFilters = {
          ...leadFilters,
          [key] : !leadFilters[key]
      }
      setLeadFilters(newFilter)
  }

  const styles = useStyles()
  return (
    <FlatList
    data={leadTypes}
    keyExtractor={(_, index) => index.toString()}
    renderItem={({ item }) => (
    <Pressable style={styles.checkboxContainer} onPress={item?.onPress}>
        <Checkbox
            value={item.value}
            onPress={item.onPress}
        />
        <Typography style={[styles.label, item.value && styles.selectedText]}>
            {item.title}
        </Typography>
    </Pressable>
    )}
    />
  )
}
export const LeadTypeList = observer(component)