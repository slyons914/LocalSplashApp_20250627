import { FlatList, Pressable } from "react-native"
import { useStyles } from "./styles"
import { observer } from "mobx-react-lite"
import { Typography } from "@components"
import { useStore } from "@store"
import { ProfileViewModel } from "@models/localsplash-mobile-api.service"
import { RadioButton } from "react-native-radio-buttons-group"
import { colors } from "@utils/constants"
import { LeadFilters } from "@models/leads"

interface props {
    leadFilters: LeadFilters,
    setLeadFilters: React.Dispatch<React.SetStateAction<LeadFilters>>
    selectedLocationId: number | undefined
    setSelectedLocationId: React.Dispatch<React.SetStateAction<number | undefined>>
}

export const component = ({leadFilters, selectedLocationId, setLeadFilters, setSelectedLocationId} : props) => {

  const { homeStore } = useStore()
  const {profiles, locationsItem } = homeStore

  const styles = useStyles()
  const setLocationHandler = (item: ProfileViewModel, index:number) => {
    setLeadFilters({ ...leadFilters, ProfileId: item?.id })
    setSelectedLocationId(item?.id)
  }
  return (
    <FlatList
    data={profiles?.profiles}
    keyExtractor={(_, index) => index.toString()}
    renderItem={({ item, index }) => (
    <Pressable style={styles.radioButtonContainer} onPress={Promise.resolve}>
        <RadioButton
            id={item?.id?.toString() ?? ''}
            selected={item.id === selectedLocationId}
            onPress={() => setLocationHandler(item, index)}
            size={24}
            color={colors.common.orangePrimary}
            borderSize={2}
        />
        <Typography style={[styles.label, item.id === locationsItem?.id && styles.selectedText]}>
            {item?.title}
        </Typography>
    </Pressable>
    )}
    />
  )
}
export const LeadLocationsList = observer(component)