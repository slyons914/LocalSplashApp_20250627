import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingBottom: insets.bottom,
    paddingTop: 8,
    paddingHorizontal: 24,
    gap: 12,
    overflow: "visible",
  },
  title: {
    fontSize: 24,
    fontWeight: "600",
    paddingTop: 0.5,
  },
  titleContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  indicatorContainer: {
    justifyContent: "center",
    flex: 1,
  },
  spinner: {
    alignSelf: "center",
  },
}))
