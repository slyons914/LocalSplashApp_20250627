import { Typography } from "@components"
import { colors } from "@utils/constants"
import { View, useColorScheme } from "react-native"
import { LineChart, lineDataItem, PieChart } from "react-native-gifted-charts"
import { useStyles } from "./styles"
import { useStore } from "@store"
import { useEffect, useState } from "react"

interface Props {}

interface SearchAndMapView {
  searchViews: number
  mapsViews: number
  dateRecorded: string
}

interface PieData {
  value: number
  color: string
}

interface LineData {
  value: number
  label: string
}

export const TotalViews = ({}: Props) => {
  const styles = useStyles()
  const systemColorScheme = useColorScheme()
  const { googleInsightsStore } = useStore()
  const { googleInsightsData } = googleInsightsStore
  const insights = googleInsightsData?.insights
  const isLightTheme = systemColorScheme === "light"
  const searchAndMapViews = insights?.views
  const totalMapsViews = insights?.mapViews ?? 0
  const totalSearchViews = insights?.searchViews ?? 0

  let totalViews: number
  let pieData: PieData[] = []

  function convertToPieData(): PieData[] {
    totalViews = totalSearchViews + totalMapsViews 

    return [
      {
        value: totalViews > 0 ? parseFloat(((totalSearchViews / totalViews) * 100).toFixed(2)) : 0,
        color: colors.common.blueBright,
      },
      {
        value: totalViews > 0 ? parseFloat(((totalMapsViews / totalViews) * 100).toFixed(2)) : 0,
        color: colors.common.yellow,
      },
    ]
  }
   pieData = convertToPieData()

  let chartLegendData = [
    {
      id: 0,
      name: "Search",
      value: pieData ? pieData[0]?.value : 0,
      color: colors.common.blueBright,
    },
    {
      id: 1,
      name: "Map",
      value: pieData ? pieData[1]?.value : 0,
      color: colors.common.yellow,
    },
  ]

  const monthNames = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ]

  function convertToLineData(
    data: SearchAndMapView[],
    dataType: "searchViews" | "mapsViews"
  ): LineData[] {
    return data?.map((entry) => {
      const date = new Date(entry.dateRecorded);
      
      const day = date.getUTCDate();
      const month = monthNames[date.getUTCMonth()];
      const year = date.getUTCFullYear().toString().slice(-2); 
      
      const label = `${day} ${month} ${year}`;
  
      const value = entry[dataType];
  
      return {
        value,
        label,
      };
    });
  }
  const [lineData,setlineData] = useState(convertToLineData(searchAndMapViews || [], "searchViews"))
  const [lineData2, setLineData2] = useState(convertToLineData(searchAndMapViews || [], "mapsViews"))
  useEffect(()=>{
    setlineData(convertToLineData(searchAndMapViews || [], "searchViews"))
    setLineData2(convertToLineData(searchAndMapViews || [], "mapsViews"))
  },[])
  return (
    <View style={styles.container} key={"totalViews"}>
      <Typography type="title" style={styles.sectionTitle}>Total Views</Typography>
      {(pieData && pieData?.length > 0) ||
        (lineData && lineData.length > 0) ||
        (lineData2 && lineData2.length > 0 && (
          <Typography type="title" style={styles.sectionTitle}>
            TotalViews
          </Typography>
        ))}
      {pieData && pieData?.length > 0 && (
        <View style={styles.pieChartContainer}>
          <PieChart
            donut
            radius={100}
            showTextBackground
            data={pieData}
            innerRadius={85}
            centerLabelComponent={() => {
              return (
                <View
                  style={[
                    styles.pieChartCenterLabelContainer,
                    { backgroundColor: isLightTheme ? colors.common.white : colors.common.dark },
                  ]}
                >
                  <Typography type="default" style={styles.pieChartCenterLabelNumber}>
                    {totalViews}
                  </Typography>
                  <Typography style={styles.pieChartCenterLabelText} type="default">
                    Total Views
                  </Typography>
                </View>
              )
            }}
          />
          <View>
            {chartLegendData?.map((item) => (
              <View style={styles.legendContainer} key={item.id}>
                <View
                  style={[
                    styles.legendIndicator,
                    {
                      backgroundColor: item.color,
                    },
                  ]}
                />
                <Typography>{item.name}</Typography>
                <Typography>{item.value}%</Typography>
              </View>
            ))}
          </View>
        </View>
      )}
        { ((lineData && lineData.length>0) || (lineData2 && lineData2.length>0)) ? (
            <View style={styles.areaChartContainer}>
            <View style={styles.areaChartLegend}>
              {chartLegendData.map((legend) => (
               <View key={legend.id} style={styles.areaChartLegendContainer}>
                 <View
                   style={[
                     styles.areaChartLegendIndicator,
                     {
                       backgroundColor: legend.color,
                     },
                   ]}
                 />
                 <Typography>{legend.name}</Typography>
               </View>
             ))}
           </View>
           <LineChart
             areaChart
             curved
             data={lineData}
             data2={lineData2}
             height={250}
             spacing={80}
             initialSpacing={32}
             color1={colors.common.blueBright}
             color2={colors.common.yellow}
             textColor1={colors.common.dark}
             focusedDataPointColor={colors.common.blueBright}
             dataPointsColor={colors.common.blueBright}
             startFillColor1={colors.common.blueBright}
             startFillColor2={colors.common.blueBright}
             startOpacity={0.1}
             endOpacity={0.1}
             thickness={2}
             focusEnabled={true}
             showDataPointOnFocus={true}
             showStripOnFocus={true}
             showTextOnFocus={true}
           />
         </View>
        ) : (null)}
    </View>
  )
}
