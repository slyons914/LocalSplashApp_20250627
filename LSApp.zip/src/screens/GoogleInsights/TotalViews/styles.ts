import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {},
  sectionTitle: {
    fontWeight: "500",
    fontSize: 20,
    marginBottom: 10,
  },
  pieChartContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 20,
    marginBottom: 20,
  },
  pieChartCenterLabelContainer: {
    justifyContent: "center",
    alignItems: "center",
    width: 170,
    height: 170,
    borderRadius: 85,
  },
  pieChartCenterLabelText: {
    fontSize: 16,
    fontWeight: "400",
  },
  pieChartCenterLabelNumber: {
    fontSize: 32,
    fontWeight: "300",
  },
  legendIndicator: {
    height: 15,
    width: 15,
    borderRadius: 7.5,
  },
  legendContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  areaChartLegendContainer: {
    flexDirection: "row",
    gap: 10,
    alignItems: "center",
    marginLeft: 20,
  },
  areaChartLegendIndicator: {
    height: 15,
    width: 15,
    borderRadius: 7.5,
  },
  areaChartLegend: { flexDirection: "row", marginVertical: 15 },
  areaChartContainer: {
    marginBottom: 30,
  },
  tooltipContainer: {
    position: "absolute",
    backgroundColor: "rgba(0, 0, 0, 0.8)",
    padding: 5,
    borderRadius: 5,
  },
  tooltipText: {
    color: "#fff",
  },
}))
