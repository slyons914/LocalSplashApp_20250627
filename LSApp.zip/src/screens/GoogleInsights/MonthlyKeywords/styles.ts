import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, width }) => ({
  mainContainer: {
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 10,
  },
  flatList: {
    width: width - 85,
    paddingHorizontal: 15,
  },
  keywordContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom:4,
    gap:8
  },
  keyword: {
    fontSize: 16,
    flex: 1,
  },
  impressions: {
    fontSize: 16,
    fontWeight: "500",
  },
  bulletsContainer: {
    flexDirection: "row",
    justifyContent: "center",
  },
  bullet: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginHorizontal: 5,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  headerText: {
    color: colors.gray4,
    fontWeight: "500",
    fontSize: 16,
  },
  sectionTitle: {
    fontWeight: "500",
    fontSize: 20,
  },
  contentContainer:{
    width:width-85
  }
}))
