import { Typography } from "@components"
import { useStore } from "@store"
import { colors } from "@utils/constants"
import { useState } from "react"
import { Dimensions, FlatList, ScrollView, View, useColorScheme } from "react-native"
import { useStyles } from "./styles"

interface Props {}
interface KeywordPage {
  keyword: string
  impressions: number
}

const screenWidth = Dimensions.get("window").width

function splitIntoSubarrays(array: KeywordPage[] | undefined, chunkSize: number): KeywordPage[][] {
  if (!array) return []
  const result: KeywordPage[][] = []
  for (let i = 0; i < array.length; i += chunkSize) {
    result.push(array.slice(i, i + chunkSize))
  }
  return result
}

export const MonthlyKeywords = ({}: Props) => {
  const styles = useStyles()

  const systemColorScheme = useColorScheme()
  const [activePage, setActivePage] = useState(0)
  const { googleInsightsStore } = useStore()
  const { monthlyKeywords } = googleInsightsStore
  const keywords = monthlyKeywords?.keywordsImpressionsMonthlyList
  const isLightTheme = systemColorScheme === "light"
  const borderColor = isLightTheme ? colors.light.lighBlack : colors.common.blueDark

  const handleScroll = (event: any) => {
    const pageIndex = Math.floor(event.nativeEvent.contentOffset.x / (screenWidth - 100))
    setActivePage(pageIndex)
  }

  const result = splitIntoSubarrays(keywords, 8)


  return (
    <View key={"monthlyKeywords"}>
      <Typography type="title" style={styles.sectionTitle}>
        {`Monthly Keywords (${keywords?.length ?? 0})`}
      </Typography>
      <View style={[styles.mainContainer, { borderColor }]}>
        <View style={styles.header}>
          <Typography style={styles.headerText} type="title">
            SEARCH KEYWORDS
          </Typography>
          <Typography style={styles.headerText} type="title">
            IMPRESSIONS
          </Typography>
        </View>
        <ScrollView
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onScroll={handleScroll}
          scrollEventThrottle={16}
          style={styles.contentContainer}
        >
          {result?.map((keyword, pageIndex) => (
            <FlatList
              key={pageIndex}
              data={keyword}
              keyExtractor={(item) => item?.keyword}
              renderItem={({ item }) => (
                <View style={styles.keywordContainer}>
                  <Typography style={styles.keyword} type="default">
                    {item?.keyword}
                  </Typography>
                  <Typography style={styles.impressions} type="default">
                    {item?.impressions}
                  </Typography>
                </View>
              )}
              style={styles.flatList}
              showsHorizontalScrollIndicator={false}
            />
          ))}
        </ScrollView>
        <View style={styles.bulletsContainer}>
          {result?.map((_, index) => (
            <View
              key={index}
              style={[
                styles.bullet,
                {
                  backgroundColor:
                    index === activePage
                      ? isLightTheme
                        ? colors.common.dark
                        : colors.common.white
                      : isLightTheme
                      ? colors.common.gray6
                      : colors.dark.blocked,
                },
              ]}
            />
          ))}
        </View>
      </View>
    </View>
  )
}
