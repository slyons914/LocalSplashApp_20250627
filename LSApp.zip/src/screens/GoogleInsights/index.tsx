import React, { useCallback, useEffect, useRef, useState } from "react"

import { ActivityIndicator, FlatList, View, ViewToken } from "react-native"

import { observer } from "mobx-react-lite"

import { Locations, Tabs, Typography } from "@components"
import { Routes, colors } from "@utils/constants"

import { DateFilter } from "@models/index"
import { useStore } from "@store"
import { FilterButton } from "../../components/FilterButton"
import { MonthlyKeywords } from "./MonthlyKeywords"
import { Statistics } from "./Statistics"
import { TotalViews } from "./TotalViews"
import { useStyles } from "./styles"
import moment from "moment"

const TABS: string[] = ["Stats", "TotalViews", "MonthlyKeywords"]

const sections = [
  (key: number) => <Statistics key={key} />,
  (key: number) => <TotalViews key={key} />,
  (key: number) => <MonthlyKeywords key={key} />,
]

const Component: React.FC<ScreenProps<Routes.Google_Insights>> = () => {
  const styles = useStyles()

  const flatRef = useRef<FlatList>(null)
  const date = new Date()
  const currentDate = moment(date).format("YYYY-MM-DD")

  const [dateFilter, setDateFilter] = useState<DateFilter>({
    fromDate: "1970-01-01",
    toDate: currentDate,
  })

  const { googleInsightsStore, homeStore, } = useStore()
  const { getGoogleInsightsData, getMonthlyKeywords, isLoading } = googleInsightsStore
  const { locationsItem } = homeStore

  const [activeTab, setActiveTab] = useState(0)
  const [scrollHandlerDisabled, setScrollHandlerDisabled] = useState(false)

  const onTabPress = (index: number) => {
    setScrollHandlerDisabled(true)
    flatRef.current?.scrollToIndex({ index, animated: true })

    setTimeout(() => {
      setScrollHandlerDisabled(false)
    }, 400)
  }

  const handleScroll = useCallback(
    (info: { viewableItems: Array<ViewToken>; changed: Array<ViewToken> }) => {
      info.viewableItems[0] &&
        info.viewableItems[0].index !== null &&
        setActiveTab(info.viewableItems[0].index)
    },
    [],
  )

  const renderSection = ({
    item,
    index,
  }: {
    item: (key: number) => React.JSX.Element
    index: number
  }) => item(index)

  useEffect(() => {
    getGoogleInsightsData(locationsItem?.id, dateFilter)
    getMonthlyKeywords(locationsItem?.id, dateFilter)
  }, [locationsItem, dateFilter])

  return (
    <View style={styles.container}>
      <View style={styles.titleContainer}>
        <Typography style={styles.title}>Google Insights</Typography>
        <FilterButton setDateFilter={setDateFilter} />
      </View>
      <Locations />
      <View>
        <Tabs
          tabs={TABS}
          onTabPress={onTabPress}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          allTabsDisabled={scrollHandlerDisabled}
        />
      </View>
      {isLoading ?
      <View style={styles.indicatorContainer}>
      <ActivityIndicator
        color={colors.common.orangePrimary}
        style={styles.spinner}
        size={"large"}
      />
    </View>:
    
      <FlatList
        ref={flatRef}
        data={sections}
        renderItem={renderSection}
        onViewableItemsChanged={handleScroll}
        viewabilityConfig={{
          itemVisiblePercentThreshold: 50,
        }}
        showsVerticalScrollIndicator={false}
      />
    }
    </View>
  )
}

export const GoogleInsightsScreen = observer(Component)
