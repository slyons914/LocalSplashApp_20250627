import { Typography } from "@components"
import { GoogleProfileActionsModal } from "@modals"
import { colors } from "@utils/constants"
import { useState } from "react"
import { View, useColorScheme } from "react-native"
import { ScrollView } from "react-native-gesture-handler"
import { BarChart } from "react-native-gifted-charts"
import { StatsCard } from "../../GoogleAds/Stats/StatsCard"
import { useStyles } from "./styles"
import { useStore } from "@store"

interface Props {}
interface DataItem {
  frontColor: string
  gradientColor: string
  label?: string
  spacing?: number
  value: number
}

const barChartLegend = [
  {
    id: 0,
    name: "Web Visits",
    color: colors.common.skyBlue,
  },
  {
    id: 1,
    name: "Direction",
    color: colors.common.blueBright,
  },
  {
    id: 2,
    name: "Call",
    color: "rgba(163, 202, 246, 1)",
  },
]

export const Statistics = ({}: Props) => {
  const styles = useStyles()
  const systemColorScheme = useColorScheme()
  const { googleInsightsStore, languageStore } = useStore()
  const { languageVariables } = languageStore
  const { googleInsightsData } = googleInsightsStore
  const insights = googleInsightsData?.insights

  const [googleProfileActionModal, setGoogleProfileActionModal] = useState(false)
  const isLightTheme = systemColorScheme === "light"
  const reviewIcon = isLightTheme ? "helpSquare" : "helpSquareBlack"
  const reviewIconDark = isLightTheme ? "helpSquareBlack" : "helpSquare"
  const internetIcon = isLightTheme ? "worldOutlined" : "worldOutlinedWhite"
  const messageIcon = isLightTheme ? "message" : "messageIconOutlinedWhite"
  const phoneIcon = isLightTheme ? "phoneblack" : "phoneIconWhiteOutined"
  const locationIcon = isLightTheme ? "locationOutlined" : "locationIconWhiteOutlined"
  const directionAndCallAndWebVisits = insights?.directionAndCallAndWebVisits

  const [profileActionTooltip, setProfileActionTooltip] = useState(false)
  const [callToYouTooltip, setCallToYouTooltip] = useState(false)
  const [webVisitsTooltip, setWebVisitsTooltip] = useState(false)
  const [directionRequestsTooltip, setDirectionRequestsTooltip] = useState(false)

  let data
  let maxValue = 0
  function findMaxValue(data: DataItem[]): number {
    return Math.max(...data?.map((item) => item?.value))
  }
  if (directionAndCallAndWebVisits && directionAndCallAndWebVisits?.length > 0) {
    data = directionAndCallAndWebVisits?.flatMap((entry, index) => {
      const date = new Date(entry.dateRecorded)
      const month = date.toLocaleString("default", { month: "short" })

      return [
        {
          value: entry?.webVisits,
          frontColor: colors?.common.skyBlue,
          gradientColor: colors?.common.skyBlue,
          spacing: 5,
          label: month,
        },
        {
          value: entry?.directions,
          frontColor: colors?.common.blueBright,
          gradientColor: colors?.common.blueBright,
          spacing: 5,
        },
        {
          value: entry?.calls,
          frontColor: "rgba(163, 202, 246, 1)",
          gradientColor: "rgba(163, 202, 246, 1)",
        },
      ]
    })
    maxValue = findMaxValue(data)
  }

  return (
    <View style={styles.container} key={"statistics"}>
      <Typography style={styles.statisticsTitle}>Statistics</Typography>
      <View style={styles.statsCardContainer}>
        <StatsCard
          isActive={true}
          title={"Google Profile Actions"}
          count={insights?.actions ?? 0}
          icon={"locationWhite"}
          iconFill={"none"}
          isLightTheme={isLightTheme}
          topIcon={"helpSquare"}
          tooltip={profileActionTooltip}
          setTooltip={setProfileActionTooltip}
          tooltipText={languageVariables? languageVariables["App.ins.wid1"] : ""}
        />
        <StatsCard
          isActive={false}
          title={"Website visits"}
          count={insights?.websiteVisits ?? 0}
          icon={internetIcon}
          iconFill={"none"}
          isLightTheme={isLightTheme}
          topIcon={reviewIconDark}
          tooltip={webVisitsTooltip}
          setTooltip={setWebVisitsTooltip}
          tooltipText={languageVariables? languageVariables["App.ins.wid3"] : ""}
        />
        <StatsCard
          isActive={false}
          title={"Calls to you"}
          count={insights?.callsYou ?? 0}
          icon={phoneIcon}
          iconFill={"none"}
          isLightTheme={isLightTheme}
          topIcon={reviewIconDark}
          tooltip={callToYouTooltip}
          setTooltip={setCallToYouTooltip}
          tooltipText={languageVariables? languageVariables["App.ins.wid5"] : ""}
        />
        <StatsCard
          isActive={false}
          title={"Direction Requests"}
          count={insights?.directionRequests ?? 0}
          icon={locationIcon}
          iconFill={"none"}
          isLightTheme={isLightTheme}
          topIcon={reviewIconDark}
          tooltip={directionRequestsTooltip}
          setTooltip={setDirectionRequestsTooltip}
          tooltipText={languageVariables? languageVariables["App.ins.wid4"] : ""}
        />
      </View>
      {data && data.length > 0 && maxValue > 0 && (
        <>
          <View style={styles.barChartLegendContainer}>
            {barChartLegend?.map((legend) => (
              <View key={legend.id} style={styles.barChartLegendContainer}>
                <View
                  style={[
                    styles.barChartLegendIndicator,
                    {
                      backgroundColor: legend.color,
                    },
                  ]}
                />
                <Typography>{legend.name}</Typography>
              </View>
            ))}
          </View>
          <View style = {[styles.barChartContentContainerStyle, styles.barChartScrollView]}
          >
            <BarChart
              data={data}
              barWidth={10}
              initialSpacing={20}
              spacing={20}
              barBorderRadius={4}
              showGradient
              yAxisThickness={0}
              xAxisType={"dashed"}
              xAxisColor={"lightgray"}
              yAxisTextStyle={{ color: colors.common.dark }}
              stepValue={maxValue/5}
              maxValue={maxValue > 0 ? maxValue + maxValue/10 : 40}
              noOfSections={6}
              labelWidth={40}
              xAxisLabelTextStyle={{ color: colors.common.dark, textAlign: "center" }}
              renderTooltip={(
                item: {
                  value: string | number
                },
                index: any,
              ) => {
                return (
                  <View style={styles.tooltipContainer}>
                    <Typography style={styles.tooltipText}>{item.value}</Typography>
                  </View>
                )
              }}
            />
          </View>
        </>
      )}

      <GoogleProfileActionsModal
        isVisible={googleProfileActionModal}
        onClose={() => setGoogleProfileActionModal(false)}
      />
    </View>
  )
}
