import { colors as colorsConstant } from "@utils/constants"
import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, width }) => ({
  container: {},
  statisticsTitle: {
    fontSize: 20,
    fontWeight: "500",
    color: colorsConstant.common.dark,
    marginBottom: 10,
  },
  statsCardContainer: {
    gap: 8,
    marginVertical: 10,
    flexWrap: "wrap",
    flexDirection:"row"
  },
  barChartContentContainerStyle: {
    alignItems: "center",
    width,
  },
  barChartScrollView: {
    paddingVertical:20,
    paddingRight:40
  },
  tooltipText: {
    color: colorsConstant.common.white,
  },
  tooltipContainer: {
    marginLeft: -5,
    backgroundColor: colorsConstant.common.dark,
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 4,
  },
  barChartLegendContainer: {
    flexDirection: "row",
    gap: 10,
    alignItems: "center",
  },
  barChartLegendIndicator: {
    height: 15,
    width: 15,
    borderRadius: 7.5,
  },
}))
