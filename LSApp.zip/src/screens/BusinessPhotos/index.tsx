import { useState } from "react"

import { ActivityIndicator, Image, Pressable, ScrollView, Switch, View } from "react-native"

import { Button, Icon, SimpleHeader, Typography } from "@components"
import { colors, Routes } from "@utils/constants"

import { useStyles } from "./styles"
import { useStore } from "@store"
import { BusinessInfoAPI } from "@api"
import { AddImageModal, BusinessPhotoDetailModal } from "@modals"
import { Draggable } from "./draggable"
import Animated, { useAnimatedRef, useAnimatedScrollHandler, useSharedValue } from "react-native-reanimated"
import { COL, Positions, SIZE } from "./config"
import { showToast } from "@utils/helpers/common"
import { validateMediaFile } from "@utils/helpers/imagePicker"


export const BusinessPhotos = ({ navigation }: ScreenProps<Routes.BusinessPhotos>) => {

  const { navigate } = navigation

  const styles = useStyles()

  const [isSelectMode, setIsSelectMode] = useState(false);
  const [selectedImages, setSelectedImages] = useState<Set<number>>(new Set());
  const [isAddImageModalVisible, setIsAddImageModalVisible] = useState(false)
  const [isBusinessPhotoLoading, setIsBusinessPhotoLoading] = useState(false)
  const [isiPhotoDetalModalVisible, setIsPhotoDetailModalVisible] = useState(false)
  const [currentImage, setCurrentImage] = useState("")
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [isDragEnabled, setIsDragEnabled] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const { businessInfoStore, homeStore }  = useStore()
  const { businessPhotos, getBusinessPhotos } = businessInfoStore
  const { locationsItem } = homeStore

  const scrollView  = useAnimatedRef<Animated.ScrollView>()
  const scrollY  = useSharedValue(0)
  const positions = useSharedValue<Positions>(
    Object.assign(
      {},
      ...(businessPhotos?.items ?? []).map((child, index) => ({ [child?.mediaUrl ?? '']: index + 1}))
    )
  );

  const onBackPress = () => {
    navigation.goBack()
  }

  const toggleImageSelection = (index: number) => {
    if(!isSelectMode) {
        const items = businessPhotos?.items ?? []
        if(!items) return;
        setCurrentImageIndex(index)
        setCurrentImage(items[index].mediaUrl ?? "")
        setIsPhotoDetailModalVisible(true)
    }
    setSelectedImages((prevSelections) => {
      const newSelections = new Set(prevSelections);
      if (newSelections.has(index)) {
        newSelections.delete(index); 
      } else {
        newSelections.add(index);
      }
      return newSelections;
    });
}
const toggleSelectMode = async () => {
    if (isDragEnabled) {
        setIsLoading(true)
        if (!locationsItem?.id) return;

        const sortedData = Object.entries(positions.value).sort((a, b) => a[1] - b[1]);
        try {
            const updatePromises = sortedData.map(([url, orderNumber]) => {
                return BusinessInfoAPI.updateBusinessPhotosOrder(locationsItem?.id, url, orderNumber);
            });
            await Promise.all(updatePromises);
            await getBusinessPhotos(locationsItem?.id);
            setIsDragEnabled(false);
            setIsLoading(false)
            return;

        } catch (error) {
            console.log(error);
            setIsLoading(false)
            return;
        }
    }

    setIsSelectMode((prevMode) => !prevMode);
    if (isSelectMode) {
      setSelectedImages(new Set());
    }
};


  const onDeletePress = async () => {
    const items = businessPhotos?.items ?? [];
    const selectedUrls = Array.from(selectedImages).map((index) => items[index]?.mediaUrl);
    if(!locationsItem?.id) return
    try {
        await BusinessInfoAPI.deleteBusinessImages(locationsItem?.id, selectedUrls)
    } catch {
        console.log("Error deleting Images")
    }
    await getBusinessPhotos(locationsItem?.id)
    setSelectedImages(new Set());
    setIsSelectMode(false);
  }

  const onImageSelect = async (uri: string, filename:string, type:string, width: number | undefined, height: number | undefined) => {
    if(!locationsItem?.id) return
    const validationResponse = await validateMediaFile(uri, type, true, 400, 266, 30, width ?? 0, height ?? 0)
    if(!validationResponse.valid) {
        showToast(validationResponse?.error ?? '')
        return;
    }
    const data = new FormData ()
    data.append("Files" , {
        uri:uri,
        type:type,
        name:filename
    })
    setIsBusinessPhotoLoading(true)
    await BusinessInfoAPI.addBussinessImages(locationsItem?.id, data)
    await getBusinessPhotos(locationsItem?.id)
    setIsBusinessPhotoLoading(false)
  }

  const onAddImagePress = () => {
    if(isBusinessPhotoLoading) return;
    setIsAddImageModalVisible(true)
  }

  const onScroll = useAnimatedScrollHandler({
    onScroll: ({ contentOffset: { y } }) => {
      scrollY.value = y;
    },
  });

  const getButtonText = () => {
    if(isDragEnabled) 
        return 'Save'
    else if(isSelectMode)
        return 'Cancel'
    else 
        return 'Select'
  }


  return (
    <View style={styles.container}>
      <View style={styles.header}>
            <SimpleHeader title="Business Photos" onLeftPress={onBackPress} rightText={getButtonText()} onRightPress={toggleSelectMode} isRightVisible={true} isLoading={isLoading}/>
      </View>
        {
            !isSelectMode && 
            <View style={styles.toggleView}>
                <Typography style={styles.headingText}>Drag and drop to rearrange pictures.</Typography>
                <Switch onChange={() => setIsDragEnabled(!isDragEnabled)} value={isDragEnabled}></Switch>
            </View>
        }
      <Animated.ScrollView 
        onScroll={onScroll} 
        ref={scrollView} 
        contentContainerStyle={[{height: Math.ceil(((businessPhotos?.items?.length ? businessPhotos?.items?.length : 0) + 5) / COL) * SIZE}, styles.scrollContent]} 
        style={styles.itemContainer}
        showsVerticalScrollIndicator={false}>
            <View style={styles.photosView}>
                <Pressable onPress={onAddImagePress} style={styles.emptyView}>
                    <View style={styles.insideEmptyView}>
                        {
                            !isBusinessPhotoLoading ? (
                            <Icon name="attachImageBusinessInfo" /> ) : (
                                <ActivityIndicator size={"small"} color={colors.common.orangePrimary}></ActivityIndicator>
                            )
                        }    
                    </View>
                </Pressable>
                {
                    businessPhotos?.items?.map((item, index)=>(
                        <Draggable scrollY={scrollY} scrollView = {scrollView} index={index} id={item?.mediaUrl ?? ''} key={index} positions={positions} isGestureEnabled={isDragEnabled}>
                            <Pressable onPress={() => toggleImageSelection(index)} key={index}>
                                <Image
                                style={styles.photo}
                                source={{ uri: `https://mobileapi.localsplash.com/MediaThumbnails/${encodeURIComponent(item?.mediaUrl ?? '')}?height=300` }}
                                />
                                {isSelectMode && (
                                <Pressable
                                style={[styles.selectionCircle , selectedImages.has(index) && styles.selectedView]}
                                onPress={() => toggleImageSelection(index)}
                                >
                                    {
                                        selectedImages.has(index) ? ( <Icon
                                            name={"tick"}
                                            /> 
                                        ) : (
                                            <View style={styles.circleView}></View>
                                        )
                                    }
                                </Pressable>
                                )}
                            </Pressable>
                        </Draggable>
                    ))
                }
            </View>
            
      </Animated.ScrollView> 
      <View style={styles.buttonView}>
        {
            isSelectMode && selectedImages.size > 0 && (
                <Button btnStyle={{alignSelf:"center"}} label={`${selectedImages.size} photos Selected`} right="trashDark" onPress={onDeletePress}></Button>
            )
        }
      </View>
      <AddImageModal isVisible={isAddImageModalVisible} onClose={()=>setIsAddImageModalVisible(false)} onImageSelect={onImageSelect}/>
      <BusinessPhotoDetailModal imageList = {businessPhotos?.items} imageUrl={currentImage} isVisible={isiPhotoDetalModalVisible} onClose={()=>setIsPhotoDetailModalVisible(false)} imageIndex={currentImageIndex} setCurrentImage={setCurrentImage} setCurrentImageIndex={setCurrentImageIndex} type="Business Photo" />
    </View>
  )
}
