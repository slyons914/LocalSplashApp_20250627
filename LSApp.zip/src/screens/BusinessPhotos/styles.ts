import { withStyles } from "@utils/hocs"
import { SIZE } from "./config"

export const useStyles = withStyles(({ insets, colors,height }) => ({
  container: {
    flex: 1,
    gap: 8,
    paddingTop: insets.top,
    backgroundColor: colors.background,
    padding: 8
  },
  header: {
    paddingHorizontal: 16,
  },
  headingText: {
    color:colors.subText,
    marginBottom:8
  },
  itemContainer: {
    padding:8,
  },
  emptyView: {
    height: SIZE ,
    width:SIZE ,
  },
  insideEmptyView: {
    height:"93%",
    width:"94%",
    borderRadius:8,
    borderStyle:"dashed",
    borderColor:colors.orangePrimary,
    justifyContent:"center",
    alignItems:"center",
    borderWidth:1,
  },
  photo: {
    height:"98%",
    width:"95%",
    borderRadius:8
  },
  itemView: {
    width:SIZE,
    height:SIZE,
    marginBottom:8
  },
  photosView: {
    flexDirection:"row",
    gap:8,
    flexWrap:"wrap",
  },
  scrollContent: {
    paddingBottom: insets.bottom + 100,
  },
  selectionCircle: {
    position: 'absolute',
    bottom: 8,
    right: 8,
    padding: 4,
  },
  circleView: {
    width:24,
    height:24,
    borderRadius:12,
    borderWidth:1,
    borderColor:colors.white
  },
  selectedView: {
    backgroundColor: colors.white,
    borderRadius:12
  },
  buttonView: {
    position: 'absolute', 
    alignSelf:"center", 
    bottom:24
  },
  draggleStyle: {
    position:'absolute', 
    top: 0,
    left: 0,
    width: SIZE,
    height: SIZE
  },
  toggleView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 0
  }

}))
