import React, { useCallback, useEffect, useState } from "react"

import {ActivityIndicator, DeviceEventEmitter, Platform, ScrollView, useColorScheme, View} from "react-native"
import { useFocusEffect } from "@react-navigation/native"
import { observer } from "mobx-react-lite"
import { Header, HomeAlert, Icon, Logo, Typography } from "@components"
import { AnalyticsModal, AnalyticsOverTimeModal, TotalLeadsModal } from "@modals"
import { DataType, ResultsLabel, DateFilter } from "@models"
import { useStore } from "@store"
import { colors, Routes, Stacks } from "@utils/constants"
import { Analytics } from "./Analytics"
import { AnalyticsOverTime } from "./AnalyticsOverTime"
import { useStyles } from "./styles"
import { showMessage } from "react-native-flash-message"
import { useSafeAreaInsets } from "react-native-safe-area-context"
import { sendPushToken } from "@utils/helpers/common"

import messaging, {FirebaseMessagingTypes} from "@react-native-firebase/messaging"
import crashlytics from "@react-native-firebase/crashlytics"
import moment from "moment"
import {handleMissedCallNotificationActionEvent, showMissedCallNotification} from "@utils/notification/notifications"
import {registerForAndroidIncomingCall} from "@telephony/sip.service"

const Component = ({ navigation }: ScreenProps<Routes.Home>) => {
  const { homeStore } = useStore()
  const systemColorScheme = useColorScheme()
  const insets = useSafeAreaInsets()
  const styles = useStyles()

  const { setOptions, navigate } = navigation

  const isLightTheme = systemColorScheme === "light"
  const {
    analyticsData,
    getProfiles,
    profiles,
    filterAnalytics,
    unreadLeads,
    getUnreadLeads,
    analyticsOverTime,
    filterAnalyticsOverTime,
    locationsItem,
    setLocationsItem,
    isLastMessageFailed,
    checkLastSmsFailed,
    isProfileVerified,
    checkIsGoogleProfileVerified,
    error,
    setLocationsIndex,
    googleClicks,
    fbClick,
  } = homeStore

  const [analyticsDataType, setAnalyticsDataType] = useState<DataType>("LocalLeads")
  const [analyticsLabel, setAnalyticsLabel] = useState<string>("All time")
  const [resultsLabel, setResultsLabel] = useState<ResultsLabel>("Local Leads")
  const [analyticsModal, setAnalyticsModal] = useState(false)
  const [analyticsOverTimeModal, setAnalyticsOverTimeModal] = useState(false)
  const [totalLeadsModal, setTotalLeadsModal] = useState(false)
  const [dateFilter, setDateFilter] = useState<DateFilter>({
    fromDate: "1970-01-01",
    toDate: moment(new Date()).format("YYYY-MM-DD"),
  })

  useFocusEffect(
    useCallback(() => {
      if (!locationsItem?.id) return
      fetchFilterAnalytics()
    }, [locationsItem, dateFilter]),
  )

  useEffect(() => {
    setCrashlyticsData()
    setOptions({ header: () => <Header name={locationsItem?.name} /> })
  }, [locationsItem])

  useEffect(() => {
    fetchProfiles()
  }, [])

  useEffect(() =>
  {
    messaging()
      .getInitialNotification()
      .then(async (remoteMessage: FirebaseMessagingTypes.RemoteMessage | null) =>
      {
		  console.log ("got initial notification", remoteMessage);
	      processNotificationTap (remoteMessage);
      })

	  // WHEN THE APP IS OPENED FROM BACKGROUND USER USER TAPS ON REMOTE NOTIFICATION.
	  // THIS WILL NOT GET TRIGGERED IF USER TAPS ON LOCAL NOTIFICATION.
    messaging().onNotificationOpenedApp(async (remoteMessage: FirebaseMessagingTypes.RemoteMessage) =>
    {
	    console.log ("App opened by notification", remoteMessage);
	    processNotificationTap (remoteMessage);
    })
	  
    messaging().onTokenRefresh((token) => {
      console.log("FCM Token refreshed:", token)
      sendPushToken()
    })
	  
	  // PROCESS REMOTE NOTIFICATION WHEN USER TAPS ON IT. IT'S A SINGLE FUNCTION THAT WILL HANDLE BOTH CASES OF
	  // WHEN APP IS LAUNCHED BY TAPPING A NOTIFICATION OR WHEN APP IS BROUGHT TO FOREGROUND.
	  const processNotificationTap = (remoteMessage: FirebaseMessagingTypes.RemoteMessage | null) =>
	  {
		  // MAKE SURE NOTIFICATION DATA IS VALID.
		  if (remoteMessage && Object.keys (remoteMessage).length > 0)
		  {
			  let notificationType = remoteMessage.data?.type;
			  
			  // USE SWITCH TO HANDLE DIFFERENT NOTIFICATION TYPES.
			  switch (notificationType)
			  {
				  case "message":
					  changeProfile(Number(remoteMessage?.data?.profileId))
					  navigateToMessage
					  (
						  remoteMessage?.notification?.title ?? "",
						  remoteMessage?.data?.leadId.toString() ?? "",
					  )
				  break;
					 
				  // THIS WILL ONLY BE TRIGGERED IF THE USER IS ON IOS.
				  case "missed-call":
					  handleMissedCallNotificationTapForIos (remoteMessage.data);
				  break;
			  }
		  }
	  }

    const unsubscribe = messaging().onMessage(async (remoteMessage) => {
      console.log("On Message In Foreground => ", remoteMessage)
      if (remoteMessage?.data?.type === "call")
	  {
		  registerForAndroidIncomingCall (remoteMessage.data).then();
      }
	  else if (remoteMessage?.data?.type === "missed-call")
	  {
		  showMissedCallNotification (remoteMessage.data);
      }
	  else if (
        remoteMessage?.data?.type === "message" &&
        remoteMessage?.data?.fromPhone != global.currentChatNumber
      ) {
        changeProfile(Number(remoteMessage?.data?.profileId))
        showFlashMessage(
          remoteMessage?.notification?.title,
          remoteMessage?.notification?.body,
          remoteMessage?.data?.leadId,
        )
      }
    })

    return () => {
      unsubscribe()
    }
  }, [])
	
	// IF USER TAPS ON MISSED CALL NOTIFICATION ON IOS THEN REDIRECT THE USER TO CALL LOG SCREEN.
	const handleMissedCallNotificationTapForIos = (data: any) =>
	{
		let response: any = handleMissedCallNotificationActionEvent (data);
		
		// IF RESPONSE IS AN INSTRUCTION TO REDIRECT USER TO SOME SCREEN THEN DO IT.
		if (response && response.action == "navigate")
		{
			navigation.navigate (response.route, response.params);
		}
	}

  const fetchFilterAnalytics = async () => {
    if (!locationsItem || typeof locationsItem.id !== "number") return

    filterAnalytics(locationsItem.id, dateFilter.fromDate, dateFilter.toDate)
    getAnalyticsOverTime(analyticsDataType)
    getUnreadLeads(locationsItem.id)
    checkIsGoogleProfileVerified(locationsItem.id)
    checkLastSmsFailed()
  }

  const fetchProfiles = async () => {
    await getProfiles()
  }

  const getAnalyticsOverTime = (dataType: string) => {
    if(!locationsItem?.id )
        return;
    filterAnalyticsOverTime(locationsItem.id, dateFilter.fromDate, dateFilter.toDate, dataType)
  }

  const setCrashlyticsData = async () => {
    crashlytics().setAttributes({
      memberId: locationsItem?.memberId?.toString() ?? "",
      profileId: locationsItem?.id?.toString() ?? "",
    })
  }

  const changeProfile = (profileId: number) => {
    const profileWithIndex = getProfileById(profileId)
    if (profileWithIndex) {
      setLocationsItem(profileWithIndex?.profile)
      setLocationsIndex(profileWithIndex.index)
    }
  }

  const showFlashMessage = (title: any, body: any, leadId: any) => {
    showMessage({
      message: `You have a new message`,
      description: `From ${title} \n${body.slice(0, 30)}`,
      onPress: () => navigateToMessage(title ?? "", leadId.toString() ?? ""),
      position: { top: insets.top },
      style: {
        backgroundColor: isLightTheme ? colors.common.white : colors.common.darklightBackground,
        borderWidth: 1,
        borderColor: isLightTheme ? colors.common.gray6 : colors.common.blueDark,
      },
      textStyle: { color: isLightTheme ? colors.common.greyText : colors.common.greyDarkMode },
      titleStyle: { color: isLightTheme ? colors.common.black : colors.common.white },
      icon: () => <Icon style={styles.notificationIcon} height={50} width={50} name="AppIcon" />,
    })
  }

  const navigateToMessage = (number: string, leadId: string) => {
    const senderId = number.replace(/\D/g, "")
    navigate(Stacks.Messages, {
      screen: Routes.MessageDetail,
      params: {
        number: senderId,
        leadId: leadId,
      },
    })
  }

  const getProfileById = (profileId: number) => {
    if (!profiles?.profiles) {
      return null
    }
    const index = profiles.profiles.findIndex((p) => p.id === profileId)
    if (index !== -1) {
      return { profile: profiles.profiles[index], index: index }
    } else {
      return null
    }
  }

  return (
    <View style={styles.container}>
      <HomeAlert isSmsFailed={isLastMessageFailed} profileVerified={isProfileVerified}></HomeAlert>
      {analyticsData && analyticsOverTime && unreadLeads ? (
        <React.Fragment>
          <ScrollView
            contentContainerStyle={styles.content}
            showsVerticalScrollIndicator={false}
            bounces={false}
          >
            <Logo />
            <Analytics
              analyticsMock={analyticsData}
              isLightTheme={isLightTheme}
              onOpenAnalyticsModal={() => setAnalyticsModal(true)}
              onOpenTotalLeadsModal={() => setTotalLeadsModal(true)}
              analyticsLabel={analyticsLabel}
              unreadLeads={unreadLeads.totalLeadCount}
              googleAdsCount={googleClicks}
              fbAdsCount={fbClick}
            />
            <AnalyticsOverTime
              onOpenAnalyticsOverTimeModal={() => setAnalyticsOverTimeModal(true)}
              dataType={analyticsDataType}
              analyticsOverTime={analyticsOverTime}
              resultsLabel={resultsLabel}
              isLightTheme={isLightTheme}
            />
          </ScrollView>
        </React.Fragment>
      ) : (
        <View style={styles.indicatorContainer}>
          {error ? (
            <View>
              <Typography style={[styles.errorText, styles.largeText]}>{error}</Typography>
              <Typography style={styles.errorText}>{error === "Please Update App to Latest Version" ? "" : "Try Restarting App"}</Typography>
            </View>
          ) : (
            <ActivityIndicator
              color={colors.common.orangePrimary}
              style={styles.spinner}
              size={"large"}
            />
          )}
        </View>
      )}
      <AnalyticsModal
        isVisible={analyticsModal}
        onClose={() => setAnalyticsModal(false)}
        setDateFilter={setDateFilter}
        setAnalyticsLabel={setAnalyticsLabel}
      />
      <AnalyticsOverTimeModal
        isVisible={analyticsOverTimeModal}
        onClose={() => setAnalyticsOverTimeModal(false)}
        setResultsLabel={setResultsLabel}
        setDataType={setAnalyticsDataType}
        getAnalyticsOverTime={getAnalyticsOverTime}
      />
      <TotalLeadsModal isVisible={totalLeadsModal} onClose={() => setTotalLeadsModal(false)} />
    </View>
  )
}

export const HomeScreen = observer(Component)
