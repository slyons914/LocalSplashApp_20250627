import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: 24,
  },
  content: {
    alignItems: "center",
    paddingBottom: 120,
  },
  indicatorContainer: {
    justifyContent: "center",
    flex: 1,
  },
  spinner: {
    alignSelf: "center",
  },
  errorText:{
    textAlign:"center",
    color: colors.red,
    fontWeight:"500"
  },
  largeText:{
    fontSize:18
  },
  notificationIcon: {
    marginRight:16, 
    alignSelf:"center", 
    justifyContent:"center", 
    borderRadius:25
  }
}))
