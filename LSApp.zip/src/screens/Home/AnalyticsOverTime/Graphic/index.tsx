import { useEffect, useState } from "react"

import { FlatList, View, ViewStyle } from "react-native"

import { Typography } from "@components"
import {
  DataType,
  IGetProfileAnalyticsOverTimeResponseViewModel,
  IReactionsOverTimeViewModel,
} from "@models"

import { useStyles } from "./styles"
import { ITotalResultOverTimeViewModel, ITotalResultsOverTimeViewModel } from "@localsplash/mobile-api-client"

interface Props {
  analyticsOverTime: ITotalResultsOverTimeViewModel
  dataType: DataType
}

interface RenderItem {
  item: ITotalResultOverTimeViewModel
  index: number
}

export const Graphic = ({ analyticsOverTime, dataType }: Props) => {
  const styles = useStyles()

  const [maxCount, setMaxCount] = useState<number | undefined>(0)
  const [sortedData, setSortedData] = useState<IReactionsOverTimeViewModel[]>([])

  const findMax = () => {
    const maxValue = analyticsOverTime?.items?.sort((a, b) => (b.count || 0) - (a.count || 0))[0]
    maxValue && setMaxCount(maxValue.count)
  }

  useEffect(() => {
    findMax()
    const sorted = [...(analyticsOverTime?.items ?? [])].sort(
      (a, b) => new Date(b.date!).getTime() - new Date(a.date!).getTime()
    )
    setSortedData(sorted)
  }, [dataType, analyticsOverTime])

  const formatDate = (inputDate: Date) => {
    const months = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ]
    const date = new Date(inputDate)
    const month = months[date.getUTCMonth()]
    const day = date.getUTCDate()
    const year = String(date.getUTCFullYear()).substring(2)
    return `${month} ${year}`
  }

  const isDataExist = (analyticsOverTime?.items ?? []).length > 0

  const renderAnalyticsItem = ({ item, index }: RenderItem) => {
    const MAX_BAR_HEIGHT = 85
    const barStyle: ViewStyle = {
      backgroundColor: +item.count! === maxCount ? "#FF770B" : "#1E4B7F",
      height: `${(+item.count! / maxCount!) * MAX_BAR_HEIGHT}%`,
    }

    return (
      <View key={index} style={styles.item}>
        <View style={[styles.bar, barStyle]} />
        <Typography>{formatDate(item.date!)}</Typography>
      </View>
    )
  }

  return isDataExist ? (
    <View style={styles.container}>
      <View style={styles.metrics}>
        {new Array(3).fill("").map((item, index) => {
          const handleItem = () => {
            switch (index) {
              case 0:
                return maxCount
              case 1:
                return maxCount && maxCount / 2
              case 2:
                return 0
              default:
                break
            }
          }

          return <Typography key={index}>{handleItem()}</Typography>
        })}
      </View>
      <FlatList
        data={sortedData}
        renderItem={renderAnalyticsItem}
        horizontal
        contentContainerStyle={styles.listContent}
        style={styles.list}
        scrollEnabled
        showsHorizontalScrollIndicator={false}
      />
    </View>
  ) : (
    <View style={styles.placeholder}>
      <Typography>No data to display</Typography>
    </View>
  )
}
