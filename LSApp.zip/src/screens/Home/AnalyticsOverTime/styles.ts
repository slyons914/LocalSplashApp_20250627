import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 12,
    padding: 16,
    flex: 1,
    marginTop: 8,
    gap: 42,
    minWidth: 340,
    marginBottom:insets.bottom? insets.bottom + 8:24
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  filterLabel: {
    fontSize: 16,
  },
  filterBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 8,
    paddingLeft: 12,
    paddingRight: 8,
    borderWidth: 2,
    borderColor: colors.greyLight,
    borderRadius: 42,
    gap: 8,
    backgroundColor: colors.backgroundSecondary,
  },
  filterTitle: {
    maxWidth: 140,
  },
}))
