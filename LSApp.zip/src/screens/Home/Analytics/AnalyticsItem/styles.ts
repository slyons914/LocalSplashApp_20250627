import { Platform } from "react-native"

import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme, width, height }) => ({
  analyticsItem: {
    width: width * 0.41,
    height: height * 0.22,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 12,
    padding: 16,
  },
  activeAnalyticsItem: {
    backgroundColor: isDarkTheme ? colors.white : colors.blueDark,
  },
  analyticsItemTitleContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    minHeight: 48,
  },
  analyticsItemTitle: {
    fontSize: 16,
  },
  activeAnalyticsItemTitle: {
    color: colors.background,
  },
  countContainer: {
    flexDirection: "row",
    alignItems: "flex-end",
    marginBottom: 5,
  },
  count: {
    fontSize: 46,
    fontWeight: "200",
    marginBottom: Platform.OS === "ios" ? -23 : -30,
  },
  lowerFontSize: {
    fontSize: 30,
    fontWeight: "200",
    marginBottom: Platform.OS === "ios" ? -9 : -14,
    maxWidth: "90%",
  },
  activeCount: {
    color: colors.background,
  },
  unreadLeads: {
    backgroundColor: colors.blue,
    borderRadius: 25,
    paddingHorizontal: 10,
    paddingVertical: 4,
    alignSelf: "flex-start",
    marginTop: 8,
  },
  unreadText: {
    color: colors.white,
    borderRadius: 25,
    alignSelf: "flex-start",
    fontSize: 16,
  },
  iconStyle: {
    position: 'absolute',
    bottom: 10,
    right: 10
  }
}))
