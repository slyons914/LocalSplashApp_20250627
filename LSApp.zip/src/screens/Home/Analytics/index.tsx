import { TouchableOpacity, View } from "react-native"

import { Icon, Typography } from "@components"
import { IGetProfileAnalyticsResponseViewModel } from "@models"
import { useColors } from "@utils/hooks"

import { AnalyticsItem } from "./AnalyticsItem"
import { useStyles } from "./styles"
import { navigate } from "@navigation"
import { Routes, Stacks } from "@utils/constants"
import { useNavigation } from "@react-navigation/native"

interface Props {
  onOpenAnalyticsModal: () => void
  onOpenTotalLeadsModal: () => void
  isLightTheme: boolean
  analyticsMock: IGetProfileAnalyticsResponseViewModel
  analyticsLabel: string
  unreadLeads: number,
  googleAdsCount: number,
  fbAdsCount: number
}

export const Analytics = ({
  onOpenAnalyticsModal,
  onOpenTotalLeadsModal,
  isLightTheme,
  analyticsMock,
  analyticsLabel,
  unreadLeads,
  fbAdsCount,
  googleAdsCount
}: Props) => {
  const styles = useStyles()

  const arrowIcon1 = isLightTheme ? "arrowUpRight" : "arrowUpRightWhite"
  const arrowIcon2 = isLightTheme ? "helpSquare" : "helpSquareBlack"

  const { background, text } = useColors()

  const { reset } = useNavigation()

  const openLeads = () =>{
    reset({
        index:0,
        routes:[{name: Routes.Leads}]
    })
  }

  const openReviews = () => {
    navigate(Stacks.Reviews, { screen: Routes.Reviews })
  }

  const openGoogleAds = () => {
    navigate(Stacks.GoogleAds, { screen: Routes.Google_Ads })
  }
  const openGoogleInsights = () => {
    navigate(Stacks.GoogleInsghts, { screen: Routes.Google_Insights })
  }
  const openFbAds = () => {
    navigate(Stacks.Facebook, { screen: Routes.Facebook })
  }
  const openListings = () => {
    navigate(Stacks.LISTINGS, { screen: Routes.Listing })
  }

  return (
    <>
      <View style={styles.analyticsHeader}>
        <Typography style={styles.analyticsHeaderName}>Analytics</Typography>
        <TouchableOpacity onPress={onOpenAnalyticsModal} style={styles.filterBtn}>
          <Typography type={"subtext"}>{analyticsLabel}</Typography>
          <Icon name={isLightTheme ? "chevronDown" : "chevronDownWhite"} height={17} width={17} />
        </TouchableOpacity>
      </View>
      <View style={styles.analyticsContainer}>
        <AnalyticsItem
          isActive={true}
          onPress={onOpenTotalLeadsModal}
          title={"Total Results"}
          count={analyticsMock.totalResults! + fbAdsCount + googleAdsCount}
          icon={"totalResults"}
          iconFill={background}
          isLightTheme={isLightTheme}
          topIcon={arrowIcon2}
        />
        <AnalyticsItem
          title={"Local Leads"}
          onPress={openLeads}
          count={analyticsMock.localLeads!}
          icon={"mapPin"}
          iconFill={text}
          isLightTheme={isLightTheme}
          topIcon={arrowIcon1}
          unreadLeads={unreadLeads}
        />
      </View>
      <View style={styles.analyticsContainer}>
        <AnalyticsItem
          title={"Reviews"}
          onPress={openReviews}
          count={analyticsMock.reviews!}
          icon={"star"}
          iconFill={text}
          isLightTheme={isLightTheme}
          topIcon={arrowIcon1}
        />
        <AnalyticsItem
          title={"Google Profile Actions"}
          count={analyticsMock.googleProfileActions!}
          icon={"google"}
          iconFill={text}
          isLightTheme={isLightTheme}
          topIcon={arrowIcon1}
          onPress={openGoogleInsights}
        />
      </View>
      <View style={styles.analyticsContainer}>
        {
            fbAdsCount < googleAdsCount ? (
                <AnalyticsItem
                title={"Google Ads Clicks"}
                count={googleAdsCount}
                icon={"googleAds"}
                iconFill={text}
                isLightTheme={isLightTheme}
                topIcon={arrowIcon1}
                onPress={openGoogleAds}
                />
            ) : (
                <AnalyticsItem
                title={"Facebook Ads Clicks"}
                count={fbAdsCount}
                icon={"facebook"}
                iconFill=""
                isLightTheme={isLightTheme}
                topIcon={arrowIcon1}
                onPress={openFbAds}
              />
            )
        }
        <AnalyticsItem
          title={"Listings"}
          count={analyticsMock.listings!}
          icon={"list"}
          iconFill={text}
          isLightTheme={isLightTheme}
          topIcon={arrowIcon1}
          onPress={openListings}
        />
      </View>
    </>
  )
}
