import { withStyles } from "@utils/hocs"
import { Platform } from "react-native"

export const useStyles = withStyles(({ insets, colors }) => ({
  container: {
    flex: 1,
    gap: 8,
    paddingTop: insets.top + 16,
    backgroundColor: colors.background,
    paddingBottom:Platform.OS === "ios" ? 0 : 32
  },
todayStyle:{backgroundColor:'#F8FBFA' ,alignSelf:'center' ,paddingVertical:3,paddingHorizontal:7, borderRadius:6, },
InputContainer:{flexDirection:'row' , alignItems:'center',paddingHorizontal:8,paddingBottom:insets.bottom, paddingTop:10, gap:10, marginBottom:5, borderTopWidth:1, borderTopColor: colors.whiteSecondary,},
recordingContainer:{flexDirection:'row' , alignItems:'center',paddingHorizontal:12, paddingVertical:10, marginBottom:5,borderTopWidth:1, borderTopColor: colors.whiteSecondary,},

inputView:{
  flex:1,
  flexDirection:"row",
  alignItems:'center',
  backgroundColor:colors.lighBlack,
  justifyContent:"center",
  borderRadius:10,
  paddingHorizontal:10,
  },
  buttons:{padding:2, backgroundColor:"#fff", borderRadius:8},
  sendIconView:{width:18,height:18,borderRadius:8, padding:13,alignItems:'center',justifyContent:'center', backgroundColor:colors.orangePrimary,},
  inputStyle:{flex:1,padding:5,fontSize:12,fontWeight:'500'},
  cancelRecording:{color:colors.lightGrey , fontSize:14 ,fontWeight:'400'},
  cancelButton:{
    color:colors.orangePrimary,
    fontWeight:"700"
  },
  itemText:{
    fontWeight:"600"
  }
}))
