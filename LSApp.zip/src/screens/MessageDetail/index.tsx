import { useCallback, useEffect, useRef, useState } from "react"
import { ActivityIndicator, FlatList, KeyboardAvoidingView, Platform, Pressable, TextInput, View, useColorScheme } from "react-native"
import { Icon, Typography } from "@components"
import { Routes, colors, } from "@utils/constants"
import { pickImageFromGallery, takePhotoWithCamera } from "@utils/helpers"
import { ShareContactModal } from "@modals/shareContactModal/shareContactModal";
import { ChatActions } from "@modals/ChatActions/chatActions";
import { LeadsAPI, MobileAPI } from "@api"
import { backIconHitSlope } from "@utils/constants/common"
import { useStore } from "@store"
import { useFocusEffect } from "@react-navigation/native"
import { Pusher, PusherEvent } from '@pusher/pusher-websocket-react-native';
import { RecentMessage } from "@models/index"
import { useStyles } from "./styles"

import Clipboard from "@react-native-clipboard/clipboard"
import Toast from 'react-native-simple-toast';
import SendIcon from '../../../assets/icons/sendIcon.svg'
import DocumentPicker from 'react-native-document-picker'
import uuid from "react-native-uuid"
import ChatDetailHeader from "../../components/chatDetailHeader/chatDetailHeader";
import OthersMessage from "../../components/OthersMessage";
import OwnMessage from "../../components/OwnMessage";
import moment from "moment"

interface Message {
    id: string;
    body: string;
    dateCreated: number;
    isInbound: boolean;
    index: number;
    media: string | null;
    fileName: string | null;
    mediaItems: string[]
}

export const MessageDetail = ({ route, navigation }: ScreenProps<Routes.MessageDetail>) => {

    let flatListRef: any = useRef()

    const number = route.params?.number
    const updateRecentMessageList = route.params?.onMessageSent
    const leadId = route.params?.leadId

    const { homeStore } = useStore()
    const { locationsItem } = homeStore

    const styles = useStyles()
    const isDarkTheme = useColorScheme() === "dark"
    const [message, setMessage] = useState('')
    const [contactModalVible, setContactModalVisible] = useState(false)
    const [chatActionsModalVible, chatActionsModalVisible] = useState(false)
    const [inProgress, setInProgress] = useState(false)
    const [chat, setChat] = useState<Message[]>([])
    const [isLoading, setLoading] = useState(false)
    const [file, setSelectedFile] = useState<any>(null)
    const [mediaSelected, setMediaSelected] = useState(false)
    const [lastestMessageId, setLatestMessageId] = useState<String>('')
    const [currentChatRowNumber, setCurrentChatRowNumber] = useState(0)
    const [isFetchingMessage, setIsFetchingMessage] = useState(false)
    const [messageInformation, setMessageInformation] = useState<RecentMessage>()

    const onBackPress = () => {
        navigation.goBack()
    }

    const convertToFormData = (data: any) => {
        const formData = new FormData();

        Object.keys(data).forEach((key) => {
            if (Array.isArray(data[key])) {
                data[key].forEach((item) => {
                    formData.append(key, item);
                });
            } else {
                formData.append(key, data[key]);
            }
        });

        return formData;
    };

    const renderChat = ({ item }: { item: any }) => {
        if (item.type === 'date') {
            return (
                <View style={{ alignItems: 'center', marginVertical: 10 }}>
                    <Typography style={{ fontSize: 12, color: '#999' }}>{item.data}</Typography>
                </View>
            );
        }
        const message: Message = item.data;
        return message.isInbound ? (
            <OthersMessage message={message} />
        ) : (
            <OwnMessage
                message={message}
                sendingInProgress={inProgress}
                lastestMessageId={lastestMessageId}
            />
        );
    };

    const openMediaPicker = () => {
        setContactModalVisible(true)
    }

    const hideContactShareModal = () => {
        setContactModalVisible(false)
    }

    const openActionsModal = () => {
        chatActionsModalVisible(true)
    }

    const hideActionsModal = () => {
        chatActionsModalVisible(false)
    }

    const formatDateLabel = (timestamp: number) => {
        const messageDate = moment(timestamp);
        const now = moment();

        if (messageDate.isSame(now, 'day')) {
            return `Today ${messageDate.format('h:mm A')}`;
        } else if (messageDate.isSame(now.clone().subtract(1, 'day'), 'day')) {
            return `Yesterday ${messageDate.format('h:mm A')}`;
        } else if (messageDate.isAfter(now.clone().subtract(7, 'days'))) {
            return `${messageDate.format('dddd')} ${messageDate.format('h:mm A')}`;
        } else if (messageDate.isAfter(now.clone().subtract(1, 'year'))) {
            return `${messageDate.format('ddd')}, ${messageDate.format('MMM D')} at ${messageDate.format('h:mm A')}`;
        } else {
            return `${messageDate.format('MMM D, YYYY')} at ${messageDate.format('h:mm A')}`;
        }
    };

    const groupMessagesWithDateMarkers = (messages: Message[]) => {
        let grouped: { type: 'date' | 'message'; data: any }[] = [];
        let groupedByDay: Record<string, Message[]> = {};

        messages.forEach(message => {
            const dayKey = moment(message.dateCreated).startOf('day').format('YYYY-MM-DD');
            if (!groupedByDay[dayKey]) {
                groupedByDay[dayKey] = [];
            }
            groupedByDay[dayKey].push(message);
        });

        Object.keys(groupedByDay).forEach(dayKey => {
            const messagesForDay = groupedByDay[dayKey];
            messagesForDay.forEach(msg => {
                grouped.push({ type: 'message', data: msg });
            });

            grouped.push({
                type: 'date',
                data: formatDateLabel(messagesForDay[0].dateCreated),
            });
        });

        return grouped;
    };

    const sendMessage = async () => {
        setInProgress(true)
        setMediaSelected(false)
        setMessage('')
        const id = uuid.v4().toString()
        setLatestMessageId(id)
        if (updateRecentMessageList) {
            updateRecentMessageList({ leadPhone: number, body: message, dateCreated: Date.now() })
        }
        let mesg: Message = { id: id, body: message, dateCreated: Date.now(), isInbound: false, index: 0, media: mediaSelected ? file.uri : null, fileName: mediaSelected ? file.name : null, mediaItems: mediaSelected ? [file.uri] : [] }
        setChat(prevChat => [mesg, ...prevChat]);
        try {
            let payload;
            if (mediaSelected) {
                payload = {
                    To: number,
                    Body: mesg.body,
                    Media: file
                }
            } else {
                payload = {
                    To: number,
                    Body: mesg.body,
                }
            }
            const formData: FormData = convertToFormData(payload)
            const data = await MobileAPI.sendMessage(locationsItem?.id, formData)
            setInProgress(false)
        } catch {
            console.log("error while sending meesage")
            setInProgress(false)
        }
    }

    const handleCopyNumber = () => {
        Clipboard.setString(number.toString())
        Toast.showWithGravity(
            'Phone Number Copied',
            Toast.SHORT,
            Toast.BOTTOM,
        );
    }

    const handleBlockNumber = async () => {
        console.log(messageInformation?.leadId)
        try {
            const response = await LeadsAPI.setLeadStatus(locationsItem?.id, messageInformation?.leadId, { isBlocked: !messageInformation?.isBlocked })
            await getMessageInfo()
        } catch {

        }
    }

    const handleSpam = async () => {
        try {
            const response = await LeadsAPI.setLeadStatus(locationsItem?.id, messageInformation?.leadId, { isSpam: !messageInformation?.isSpam })
            await getMessageInfo()
        } catch {

        }
    }

    const handleTakePhoto = async () => {
        try {
            const response = await takePhotoWithCamera();
            if (!!response && typeof response !== "string") {
                const newAttachment = {
                    uri: response[0]?.uri || "",
                    name: response[0]?.fileName || "",
                    type: response[0]?.type || "",
                };
                setSelectedFile(newAttachment)
                setMediaSelected(true)
            }
        } catch (error) {
            console.log(error);
        }
        hideContactShareModal()
    };

    const handleChoosePhoto = async () => {
        try {
            const response = await pickImageFromGallery();
            if (!!response && typeof response !== "string") {
                const newAttachment = {
                    uri: response[0]?.uri || "",
                    name: response[0]?.fileName || "",
                    type: response[0]?.type || "",
                };
                setSelectedFile(newAttachment)
                setMediaSelected(true)
            }
        } catch (error) {
            console.log(error);
        }
        hideContactShareModal()
    };

    const handleChooseDocument = useCallback(async () => {
        try {

            const result = await DocumentPicker.pick({
                presentationStyle: 'fullScreen',
            });
            const newAttachment = {
                uri: result[0]?.uri || "",
                name: result[0]?.name || "",
                type: result[0]?.type || "",
            };
            setSelectedFile(newAttachment)
            setMediaSelected(true)
        } catch (err) {
            console.warn(err);
        }
        hideContactShareModal()
    }, []);

    const onChatListEndReached = async () => {
        if (chat.length >= currentChatRowNumber && !isFetchingMessage) {
            setIsFetchingMessage(true)
            const data = await MobileAPI.getChatByNumber(locationsItem?.id, leadId, 100, currentChatRowNumber)
            setCurrentChatRowNumber(currentChatRowNumber + 100)
            setChat((prevData) => [...prevData, ...data.data.items])
            setIsFetchingMessage(false)
        }
    }

    const getChats = async () => {
        setLoading(true)
        const data = await MobileAPI.getChatByNumber(locationsItem?.id, leadId, 100, 0)
        setCurrentChatRowNumber(100)
        setChat(data.data.items)
        setLoading(false)
    }

    const onMessageReceived = (event: PusherEvent) => {
        const eventData = JSON.parse(event.data)
        if (updateRecentMessageList) {
            updateRecentMessageList({ leadPhone: eventData.fromPhone, body: eventData.body, dateCreated: Date.now() })
        }
        if (eventData.fromPhone == number) {
            let mesg: Message = { id: eventData.id, body: eventData.body, dateCreated: Date.now(), isInbound: true, index: 0, media: eventData.media, fileName: "" }
            setChat(prevChat => [mesg, ...prevChat]);
        }
    }

    const getMessageInfo = async () => {
        const data = await MobileAPI.getMessageDetails(locationsItem?.id, leadId)
        setMessageInformation(data?.data?.items[0])
    }

    useEffect(() => {
        global.currentChatNumber = number
        getChats()
        const pusher = Pusher.getInstance()
        pusher.subscribe({
            channelName: `${locationsItem?.memberId}`,
            onEvent: (event: PusherEvent) => {
                onMessageReceived(event)
            }
        });

        return () => {
            global.currentChatNumber = ""
            pusher.unsubscribe({ channelName: `${locationsItem?.memberId}` });
        };
    }, [])

    useFocusEffect(
        useCallback(() => {
            global.currentChatNumber = number
            setCurrentChatRowNumber(0)
            getChats()
        }, [number]),
    )

    useEffect(() => {
        getMessageInfo()
    }, [leadId])

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
            style={{ flex: 1 }}
        >
            <View style={styles.container}>
                <ChatDetailHeader
                    onBackPress={onBackPress}
                    openActionsModal={openActionsModal}
                    number={number}
                    name=""
                    isBlocked={messageInformation?.isBlocked}
                    isSpam={messageInformation?.isSpam}
                />
                <View style={{ marginHorizontal: 16, flex: 1 }}>
                    {
                        isLoading ? (<View><ActivityIndicator size={"large"}></ActivityIndicator></View>) :
                            (
                                <FlatList
                                    data={groupMessagesWithDateMarkers(chat)}
                                    showsVerticalScrollIndicator={false}
                                    renderItem={renderChat}
                                    ref={flatListRef}
                                    scrollEnabled={true}
                                    keyboardShouldPersistTaps='handled'
                                    bounces={false}
                                    inverted
                                    onEndReached={onChatListEndReached}
                                    onEndReachedThreshold={50}
                                    keyExtractor={(item, index) => {
                                        if (item.type === 'date') {
                                            return `date-${item.data}-${index}`;
                                        }
                                        return `msg-${item.data.id}`;
                                    }}
                                />
                            )
                    }
                </View>
                {
                    mediaSelected ? (
                        <View style={{ paddingHorizontal: 40, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
                            <Typography style={styles.itemText}>{file.name.slice(0, 20)}</Typography>
                            <Pressable onPress={() => { setSelectedFile(null), setMediaSelected(false) }}><Typography style={styles.cancelButton}>Cancel</Typography></Pressable>
                        </View>
                    ) : (null)
                }
                <View style={styles.InputContainer}>
                    <Icon onPress={() => openMediaPicker()} name={isDarkTheme ? "mediaPickerDark" : "mediaPickerLight"} />
                    <View style={styles.inputView}>
                        <TextInput
                            placeholder="Write your message"
                            placeholderTextColor={isDarkTheme ? colors.common.white : colors.common.black}
                            value={message}
                            onChangeText={(value) => setMessage(value)}
                            multiline={true}
                            style={{ flex: 1, padding: 5, height: Math.max(25, 15 + message.split('\n').length * 20), justifyContent: "center", fontSize: 18, fontWeight: '400', color: isDarkTheme ? colors.common.white : colors.common.black }}
                        />
                        {
                            (message || mediaSelected) && <Pressable onPress={() => sendMessage()} hitSlop={backIconHitSlope} style={styles.sendIconView}>
                                <SendIcon />
                            </Pressable>
                        }
                    </View>
                    <Icon name={isDarkTheme ? "microphoneDark" : "microphoneLight"} />

                </View>

                <ShareContactModal
                    isVisible={contactModalVible}
                    handleMedia={handleChoosePhoto}
                    handleCamera={handleTakePhoto}
                    handleDocument={handleChooseDocument}
                    onClose={hideContactShareModal}
                />

                <ChatActions
                    isVisible={chatActionsModalVible}
                    handleCopyNumber={handleCopyNumber}
                    handleBlockNumber={handleBlockNumber}
                    handleSpam={handleSpam}
                    onClose={hideActionsModal}
                    isBlock={messageInformation?.isBlocked}
                    isSpam={messageInformation?.isSpam}
                />
            </View>
        </KeyboardAvoidingView>
    )
}
