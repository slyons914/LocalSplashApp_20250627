import { withStyles } from "@utils/hocs"
import { Platform } from "react-native"

const BUTTON_SIZE = 64

export const useStyles = withStyles(({ colors }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    justifyContent: "space-around",
  },
  value: {
    fontSize: 32,
    fontWeight: "400",
    textAlign: "center",
    color: colors.text,
  },
  buttons: {
    alignSelf: "center",
    gap: 24,
  },
  row: {
    flexDirection: "row",
    gap: 32,
  },
  footer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  callButton: {
    width: BUTTON_SIZE,
    height: BUTTON_SIZE,
    borderRadius: BUTTON_SIZE,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: colors.green,
  },
  eraser: {
    position: "absolute",
    right: 20,
  },
  trackingNumber:{
    color:colors.greyDarkMode,
    fontSize:14,
    fontWeight:"400",
    textAlign:"center",
  },
  modalBackground: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.dark,
    borderRadius:8,
    height:40,
    flex:1
  },
  modal: {
    position:"absolute",
    width:80,
    top: Platform.OS === "android" ? "5%" : "10%",
    left:Platform.OS === "android" ? "35%" : "37%"
  },
  pasteText: {
    color:colors.background,
    fontWeight: "500",
    fontSize: 16
  }
}))
