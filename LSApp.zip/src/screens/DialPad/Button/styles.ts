import { withStyles } from "@utils/hocs"

const CONTAINER_SIZE = 68
const CONTENT_SIZE = CONTAINER_SIZE - 2

export const useStyles = withStyles(({ colors }) => ({
  container: {
    width: CONTAINER_SIZE,
    height: CONTAINER_SIZE,
    borderRadius: CONTAINER_SIZE,
    justifyContent: "center",
    alignItems: "center",
  },
  content: {
    position: "absolute",
    zIndex: 1,
    width: CONTENT_SIZE,
    height: CONTENT_SIZE,
    borderRadius: CONTENT_SIZE,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: colors.background,
  },
  value: {
    height: CONTENT_SIZE-20,
    justifyContent:"center"
  },
  valueText: {
    fontSize: 32,
    fontWeight: "300",
  },
}))
