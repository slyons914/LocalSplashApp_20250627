import { TouchableOpacity, View } from "react-native"

import { Circle, Defs, LinearGradient, Stop, Svg } from "react-native-svg"

import { Typography } from "@components"

import { useStyles } from "./styles"

interface Props {
  value: string
  onPress: (value: string) => void
}

const RADIUS = 34

export const Button = ({ value, onPress }: Props) => {
  const styles = useStyles()

  const onButtonPress = () => {
    onPress(value)
  }

  return (
    <TouchableOpacity hitSlop={{top:15,bottom:15,left:15,right:15 }} onPress={onButtonPress} style={styles.container}>
      <Svg>
        <Defs>
          <LinearGradient id={"grad"} x1={"0"} y1={"0"} x2={"0"} y2={"100%"}>
            <Stop offset={"0%"} stopColor={"#3082E2"} stopOpacity={"1"} />
            <Stop offset={"100%"} stopColor={"#0E2284"} stopOpacity={"1"} />
          </LinearGradient>
        </Defs>
        <Circle cx={RADIUS} cy={RADIUS} r={RADIUS} fill={"url(#grad)"} />
      </Svg>
      <View style={styles.content}>
        <View style={styles.value}>
            <Typography style={[styles.valueText, value === "*" && {paddingTop: 6}]}>{value}</Typography>
        </View>
      </View>
    </TouchableOpacity>
  )
}
