import React, { useEffect, useState } from "react"

import { Pressable, TouchableOpacity, View } from "react-native"
import { TextInputMask } from "react-native-masked-text"
import Toast from 'react-native-simple-toast';
import Modal from "react-native-modal";

import { Icon, Typography } from "@components"
import { Routes } from "@utils/constants"
import { useStore } from "@store"
import { CallHelper, FormatHelper } from "@utils/helpers"
import Clipboard from "@react-native-clipboard/clipboard";

import { Button } from "./Button"
import { useStyles } from "./styles"
import { Header } from "../../navigation/CallStackNavigator/Header"
import {startLogcat} from "@utils/logcat"
import {useTelephony} from "@telephony/telephony.provider"
import { showToast } from "@utils/helpers/common";


const buttons = "123\n456\n789\n*0#".split("\n").map((row) => row.split(""))

const MAX_NUMBER_LENGTH = 10

export const DialPadScreen = ({ route }: ScreenProps<Routes.DialPad>) => {
  const [value, setValue] = useState("")
  const [trackingNumber, setTrackingNumber] = useState("")
  const [isPasteModalVisible, setIsPasteModalVisible] = useState(false)
  const {startOutboundCall} = useTelephony();

  const styles = useStyles()

  const { homeStore } = useStore()
  const { locationsItem } = homeStore
	
	useEffect (() =>
	{
		CallHelper.getSipSettingsFromProfileId(locationsItem?.id).then ((sipSettings) =>
		{
			setTrackingNumber (sipSettings?.sipUsername || "")
		})
	}, []);
  useEffect(() => {
	  console.log ("phone number", route.params?.phoneNumber, route.params);
    setValue(route.params?.phoneNumber ?? "")
  }, [route.params])

  const onButtonPress = (button: string) => {
    setValue((value) => (value.length < MAX_NUMBER_LENGTH ? value + button : value))
  }

  const onCallPress = () => {
    if(value.length<10)
    {
        showToast('Please enter a valid 10-digit phone number.')
    } 
    else
    {
        startOutboundCall (value);
    }   
  }

  const onErasePress = () => {
    setValue((value) => value.slice(0, -1))
  }

  const renderButton = (button: string, i: number) => {
    return <Button key={i} value={button} onPress={onButtonPress} />
  }

  const renderButtonRow = (row: Array<string>, i: number) => {
    return (
      <View key={i} style={styles.row}>
        {row.map(renderButton)}
      </View>
    )
  }

  const handleCopyNumber = () => {
    if(value) {
        Clipboard.setString(value)
        Toast.showWithGravity(
            'Phone number copied',
            Toast.SHORT,
            Toast.BOTTOM,
        );
    } else {
        Clipboard.setString(trackingNumber)
        Toast.showWithGravity(
            'Your tracking ID copied',
            Toast.SHORT,
            Toast.BOTTOM,
        );
    }
  }

  const handlePastePress = async () => {
    const clipBoardString = await Clipboard.getString();
    let numbersOnly = clipBoardString.replace(/\D/g, '');
    if (numbersOnly.startsWith('1') && clipBoardString.startsWith('+1')) {
      numbersOnly = numbersOnly.slice(1);
    }
    setValue(numbersOnly.length < MAX_NUMBER_LENGTH ? numbersOnly : numbersOnly.slice(0, 10));
    setIsPasteModalVisible(false);
  }
  return (
    <React.Fragment>
    <Header/>
      <View
      style={styles.container}>
      <Pressable hitSlop={{top:50, bottom:50}} onLongPress={() => setIsPasteModalVisible(true)} onPress={handleCopyNumber}>
        {value
        ?
        <TextInputMask
            type={"custom"}
            editable={false}
            value={value}
            options={{ mask: "(***) ***-****" }}
            style={styles.value}
            pointerEvents="none"
        />:
        <Typography
        type="default"
        style={styles.trackingNumber}
        >Your Tracking Number: +1 {FormatHelper.formatPhoneNumberForContact(trackingNumber)}</Typography>
        }
      </Pressable>
      <Modal
        isVisible={isPasteModalVisible}
        onBackdropPress={() => setIsPasteModalVisible(false)}
        style={styles.modal}
        backdropOpacity={0.5}
      >
        <View style={styles.modalBackground}>
            <Pressable onPress={handlePastePress}>
                <Typography style={styles.pasteText}>Paste</Typography>
            </Pressable>
        </View>
      </Modal>
      <View style={styles.buttons}>
        {buttons.map(renderButtonRow)}
        <View style={styles.footer}>
          <TouchableOpacity hitSlop={{top:15,bottom:15,left:15,right:15 }} onPress={onCallPress} style={styles.callButton}>
            <Icon name={"phone"} />
          </TouchableOpacity>
          {value && (
            <TouchableOpacity hitSlop={{top:25,bottom:25,left:25,right:25 }}  onPress={onErasePress} style={styles.eraser}>
              <Icon name={"eraser"} />
            </TouchableOpacity>
          )}
        </View>
      </View>
      </View>
    </React.Fragment>
  )
}
