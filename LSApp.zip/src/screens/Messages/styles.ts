import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ insets, colors,height }) => ({
  container: {
    flex: 1,
    gap: 8,
    paddingTop: insets.top,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: "600",
    paddingHorizontal: 16,
  },
  search: {
    marginVertical: 0,
    marginHorizontal: 16,
  },
  section: {
    fontSize: 16,
    paddingTop: 24,
    paddingBottom: 8,
    paddingHorizontal: 24,
    backgroundColor: colors.background,
  },
  message: {
    borderBottomWidth: 1,
    borderBottomColor: colors.gray6,
    paddingVertical: 16,
    paddingHorizontal: 24,
    justifyContent:"center",
    alignContent:"center"

  },
  icon: {
    width: 50,
    height: 50,
    borderRadius: 50,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "red",
  },
  initials: {
    fontSize: 16,
    fontWeight: "500",
    color: colors.white,
  },
  center: {
    flexDirection:"row",
    justifyContent: "space-between",
  },
  leftContainer:{
    flex: 1, 
    paddingRight: 10, 
  },
  rightContainer:{
    alignItems:"flex-end"
  },
  name: {
    fontSize: 16,
  },
  unreadContainer: {
    width: 20,
    height: 20,
    borderRadius: 20,
    backgroundColor: colors.orangePrimary,
    justifyContent: "center",
    alignItems: "center",
  },
  unreadText: {
    color: colors.white,
  },
  right: {
    marginLeft: "auto",
    alignItems: "flex-end",
    justifyContent: "space-between",
  },
  noMessageView:{
    marginTop:height/10,
    justifyContent:"center",
    alignItems:"center",
    gap:8
  },
  noMessageText:{
    color:colors.greyText
  },
  lightGreyText: {
    color: colors.lightGrey
  },
  errorText:{
    textAlign:"center",
    color: colors.red,
    fontWeight:"500",
    fontSize:18
  },

}))
