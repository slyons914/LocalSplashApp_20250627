import { useEffect, useMemo, useState } from "react"

import { ActivityIndicator, Pressable, View } from "react-native"

import { FlashList } from "@shopify/flash-list"

import { Button, Header, Icon, SearchBar, SimpleHeader, Typography } from "@components"
import { Routes } from "@utils/constants"

import { useStyles } from "./styles"
import { NewMessageModal } from "@modals"
import { MobileAPI } from "@api"
import { RecentMessage } from "@models/index"
import { FormatHelper } from "@utils/helpers"
import { useStore } from "@store"


export const MessagesScreen = ({ navigation }: ScreenProps<Routes.Messages>) => {
  const [noMessageModal, setNoMessageModal] = useState(false)
  const [rowNumber, setRowNumber] = useState(0)  
  const [loading, setLoading] = useState(false)
  const [isFetchingRecentMessageList, setIsFetchingRecentMessageList] = useState(false)
  const [messageList, setMessageList] = useState<RecentMessage []>([])
  const [error, setError] = useState("")
  const { navigate } = navigation

  const styles = useStyles()

  const {homeStore}  = useStore()
  const { locationsItem } = homeStore

  const onBackPress = () => {
    setLoading(true)
    navigate(Routes.Home)
    setLoading(false)
  }

  const updateRecentMessageList = (payload:any) => {
    setMessageList(prevMessages => {
        const updatedMessageIndex = prevMessages.findIndex(
            message => message.leadPhoneNumber === payload.leadPhone
        );

        if (updatedMessageIndex !== -1) {
            const updatedMessage = { 
                ...prevMessages[updatedMessageIndex], 
                ...payload 
            };

            return [
                updatedMessage,
                ...prevMessages.filter((_, index) => index !== updatedMessageIndex)
            ];
        }
        return prevMessages;
    });
};

  const onRecentMessageListEndReached = async () => {
    if ( messageList.length >= rowNumber && !isFetchingRecentMessageList ) {
        setIsFetchingRecentMessageList(true)
        const { data , error} = await MobileAPI.getRecentMessages(locationsItem?.id, 20,rowNumber)
        setRowNumber(rowNumber + 20)
        if(error){
            setError(error)
        }else{
            setMessageList((prevData) => [
                ...prevData,
                ...(data?.items ? (Array.isArray(data.items) ? data.items : [data.items]) : []),
              ]);
        }
        setIsFetchingRecentMessageList(false)
    }
  }

  const getRecentMessages =  async () =>{
    setLoading(true)
    const { data , error} = await MobileAPI.getRecentMessages(locationsItem?.id, 20,rowNumber)
    setRowNumber(20)
    if(error){
        setError(error)
    }else{
        setMessageList(data?.items || [])
    }
    
    setLoading(false)
  }

  useEffect(()=>{
    getRecentMessages()
  },[])

//   const stickyIndecies = useMemo(() => {
//     return messages.reduce<Array<number>>((acc, item, index) => {
//       if (typeof item === "string") {
//         acc.push(index)
//       }
//       return acc
//     }, [])
//   }, [])

  const renderItem = ({ item }: { item: RecentMessage }) => {
    if (typeof item === "string") {
      return <Typography style={styles.section}>{item}</Typography>
    }
    const initials = "LS"

    return (
      <Pressable
      onPress={()=>navigate(Routes.MessageDetail,{number: item.leadPhoneNumber, onMessageSent: updateRecentMessageList, leadId: item?.leadId})} 
      style={styles.message}>
        {/* <View style={styles.icon}>
          <Typography style={styles.initials}>{initials}</Typography>
        </View> */}
        <View style={styles.center}>
          <View style={styles.leftContainer} >
            <Typography style={styles.name}>{FormatHelper.formatPhoneNumber(item?.leadPhoneNumber?.toString())}</Typography>
            <View>
            { item.body && <Typography numberOfLines={1} style={styles.noMessageText}>{item.body}</Typography>}
            </View>
            
          </View>
          <View style={styles.rightContainer}>
            <Typography style={styles.lightGreyText}>{FormatHelper.formateDateForMessage(item.dateCreated)}</Typography>
            {/* {item.unreadAmount ? (
                <View style={styles.unreadContainer}>
                <Typography style={styles.unreadText}>{item.unreadAmount}</Typography>
                </View>
            ) : (
                <Icon name={"readChecks"} />
            )} */}
            </View>
        </View>
      </Pressable>
    )
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
            <SimpleHeader onLeftPress={onBackPress} rightText="+ New" onRightPress={()=>setNoMessageModal(true)} isRightVisible={true}/>
      </View> 
      <Typography style={styles.title}>Messages</Typography>
      {
         loading ? (<View><ActivityIndicator size={"large"}></ActivityIndicator></View>) : 
                   (
                    <View style={{flex:1}}>
                    {
                    messageList?.length > 0 ? (<View style={{flex:1}}>
                    <SearchBar
                        placeholder="Search by Name, Phone Number..."
                        value={""}
                        onSearch={Promise.resolve}
                        style={styles.search}
                    />
                    <FlashList
                        estimatedItemSize={20}
                        data={messageList}
                        renderItem={renderItem}
                        onEndReached={onRecentMessageListEndReached}
                        // stickyHeaderIndices={stickyIndecies}
                    />
                    </View>) :(<View style={styles.noMessageView}>
                        {
                            error ? (<View>
                                        <Typography style={styles.errorText}>{error}</Typography>
                                    </View>) : 
                                    (<View style={styles.noMessageView}>
                                        <Icon name="noChatIcon"/>
                                        <Typography style={styles.noMessageText}>No chats yet.</Typography>
                                        <Typography style={styles.noMessageText}>Get started by messaging a lead.</Typography>
                                        <Button label="New Message" onPress={()=>setNoMessageModal(true)} right="addMessageIcon"></Button>
                                    </View>)
                        }
                        
                    </View>)
                    }
                    </View>
                    )
      }
     <NewMessageModal setMessageList={setMessageList} isVisible={noMessageModal} onClose={()=>setNoMessageModal(false)}></NewMessageModal>

    </View>
  )
}
