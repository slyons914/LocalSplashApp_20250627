import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingBottom: insets.bottom,
    gap: 24,
    paddingTop: 8,
    paddingHorizontal: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: "600",
    paddingTop: 0.5,
  },
  titleContainer: {
    gap:12
  },
  heading:{
    fontSize:20,
    fontWeight:"500"
  },
  listingRow:{
    flexDirection:"row",
    justifyContent:"space-between",
  },
  listing:{
    alignItems:"center",
    gap:8,
    width:100
  },
  listingContainer:{
    gap:16,
    flexDirection:"row",
    flexWrap:"wrap",
    justifyContent:"space-between"
  },
  indicatorContainer: {
    justifyContent: "center",
    flex: 1,
  },
  spinner: {
    alignSelf: "center",
  },
  image:{
    height:80,
    width:80
  }
}))