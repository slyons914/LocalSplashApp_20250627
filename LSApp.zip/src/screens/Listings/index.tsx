import React, { useEffect, useState } from "react"
import {
  ActivityIndicator,
  Linking,
  ScrollView,
  TouchableOpacity,
  View,
  useColorScheme,
} from "react-native"
import { observer } from "mobx-react-lite"
import { Typography, Locations, Icon } from "@components"
import { colors, Routes } from "@utils/constants"
import { useStyles } from "./styles"
import { useStore } from "@store"
import { MobileAPI } from "@api"
import { Listing } from "@models/index"
import { Image } from "react-native"

const Component: React.FC<ScreenProps<Routes.Website>> = () => {
  const { homeStore } = useStore()
  const { locationsItem } = homeStore
  const styles = useStyles()
  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"
  const [loading, setLoading] = useState(false)
  const [listingData, setListingData] = useState<Listing[]>([])
  const imgUrl = "https://my.localsplash.com/Content/Images/gfx/listing/"
  const getListing = async () => {
    setLoading(true)
    try {
      const data = await MobileAPI.getListing(locationsItem?.id)
      setListingData(data.data?.items ?? [])
      setLoading(false)
    } catch {
      console.log("Error while getting listings")
      setLoading(false)
    }
  }

  const handleOpenURL = (url: string) => {
    if (!url) return
    Linking.openURL(url).catch((err) => console.error("An error occurred", err))
  }

  useEffect(() => {
    getListing()
  }, [locationsItem])
  return (
    <View style={styles.container}>
      <View style={styles.titleContainer}>
        <Typography style={styles.title}>Listings</Typography>
        <Locations />
      </View>
      <View>
        <Typography style={styles.heading}>Premium Listings Placements</Typography>
      </View>
      {!loading ? (
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.listingContainer}>
          {listingData
            .filter(item => item.permalinkUrl && item.isClientFacing)
            .map((item, index) => (
                <TouchableOpacity
                onPress={() => handleOpenURL(item.permalinkUrl)}
                key={index}
                style={styles.listing}
                >
                    <Image
                        style={styles.image}
                        source={{
                        uri: `${imgUrl}${item.logo}`,
                        }}
                    />
                    <Typography numberOfLines={1}>{item.destinationTitle}</Typography>
                </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      ) : (
        <View style={styles.indicatorContainer}>
          <ActivityIndicator
            color={colors.common.orangePrimary}
            style={styles.spinner}
            size={"large"}
          />
        </View>
      )}
    </View>
  )
}

export const ListingsScreen = observer(Component)
