import { Pressable, View } from "react-native"

import { Icon, Typography } from "@components"
import { ProfileGoogleCategories } from "@models/settings"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"

interface Props {
  value: ProfileGoogleCategories
  label: string
  onPress?: () => void
}

export const GoogleCategories = ({ value, label, onPress }: Props) => {
  const styles = useStyles()

  const { text } = useColors()

  return (
    <Pressable onPress={onPress} style={styles.container}>
      <Typography style={styles.inputLabel}>{label}</Typography>
      <View style={styles.textInput}>
        {value.googleCategories.map((item, index) => {
          return (
            <View style={styles.renderItem} key={item + index}>
              <Icon name="googelCategory" stroke={text} />
              <Typography>{item}</Typography>
            </View>
          )
        })}
      </View>
    </Pressable>
  )
}
