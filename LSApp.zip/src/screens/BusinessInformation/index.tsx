import { useCallback, useEffect, useRef, useState } from "react"

import { ActivityIndicator, FlatList, View, ViewToken } from "react-native"

import { useFocusEffect } from "@react-navigation/native"
import { observer } from "mobx-react-lite"

import { Locations, SimpleHeader, Tabs, Typography } from "@components"
import { useStore } from "@store"
import { colors, Routes } from "@utils/constants"

import { Content } from "./Content"
import { Keywords } from "./Keywords"
import { LocationInfo } from "./LocationInfo"
import { useStyles } from "./styles"
import { Media } from "./Media"
import { MobileAPI } from "@api"

const tabs = ["Location", "Keywords", "Content", "Media"]

const Component = ({ navigation }: ScreenProps<Routes.BusinessInformation>) => {
  const styles = useStyles()
  const { goBack } = navigation

  const [activeTab, setActiveTab] = useState(0)
  const [isLoading, setIsLoading] = useState(false)
  const [scrollHandlerDisabled, setScrollHandlerDisabled] = useState(false)

  const { businessInfoStore, homeStore } = useStore()
  const { profiles, locationsIndex, locationsItem } = homeStore
  const {
    getLocationInfo,
    locationInfo,
    getProfileGoogleCategories,
    profileGoogleCategories,
    getAvailableGoogleCategories,
    getAvailablePaymentMethods,
    getProfilePaymentMethods,
    getWorkingHours,
    ProfilePaymentMethods,
    getProfileTextContent,
    getContacts,
    contacts,
    ProfileTextContent,
    workingHours,
    getBusinessPhotos,
    getBusinessVideos,
    businessPhotos,
    businessVideos,
    getCoverPhoto,
    getServiceAreas,
    getLogo,
    logoUrl,
    backgroundImageUrl,
    getBusinessDocuments,
    businessDocuments
  } = businessInfoStore

//   useFocusEffect(
//     useCallback(() => {
//       const item = profiles?.profiles?.[locationsIndex]
//       if (!item?.id) return
//       getLocationInfo(item.id)
//       getProfileGoogleCategories(item.id)
//       getProfilePaymentMethods(item.id)
//       getProfileTextContent(item.id)
//       getWorkingHours(item.id)
//       getLogo(item.id)
//       getBackgroundImage(item.id)
//     }, [profiles, locationsIndex]),
//   )

  useEffect(() => {

    const fetchBusinessInformationData = async () => {
        setIsLoading(true)
        await getContacts()
        const item = profiles?.profiles?.[locationsIndex]
        if (!item?.id) return
        await getLocationInfo(item.id)
        await getProfileGoogleCategories(item.id)
        await getProfilePaymentMethods(item.id)
        await getProfileTextContent(item.id)
        await getWorkingHours(item.id)
        await getLogo(item.id)
        await getCoverPhoto(item.id)
        await getServiceAreas(item.id)
        setIsLoading(false)
        await getBusinessPhotos(item.id)
        await getBusinessDocuments(item.id)
        await getBusinessVideos(item.id)
    }
    fetchBusinessInformationData()
    
    getAvailableGoogleCategories()
    getAvailablePaymentMethods()
  }, [locationsIndex, profiles])

  const flatRef = useRef<FlatList>(null)

  const renderSection = ({
    item,
    index,
  }: {
    item: (key: number) => React.JSX.Element
    index: number
  }) => item(index)

  const onTabPress = (index: number) => {
    setScrollHandlerDisabled(true)
    flatRef.current?.scrollToIndex({ index, animated: true })

    setTimeout(() => {
      setScrollHandlerDisabled(false)
    }, 400)
  }

  const handleScroll = useCallback(
    (info: { viewableItems: Array<ViewToken>; changed: Array<ViewToken> }) => {
      info.viewableItems[0] &&
        info.viewableItems[0].index !== null &&
        setActiveTab(info.viewableItems[0].index)
    },
    [],
  )

  const sections = [
    (key: number) => <LocationInfo key={key} locationInfo={locationInfo} />,
    (key: number) => (
      <Keywords
        key={key}
        locationsItem={locationsItem}
        profileGoogleCategories={profileGoogleCategories}
      />
    ),
    (key: number) => (
        <Content
          key={key}
          locationsItem={locationsItem}
          profilePaymentMethods={ProfilePaymentMethods}
          contacts={contacts}
          profileTextContent={ProfileTextContent}
          workingHours={workingHours}
        />
    ),
    (key: number) => (
        <Media
          logo={logoUrl}
          coverPhoto={backgroundImageUrl} 
          businessPhotos={businessPhotos}
          businessVideos={businessVideos}
          businessDocuments={businessDocuments}
        />
    ),
  ]

  return (
    <View style={styles.container}>
      <SimpleHeader onLeftPress={goBack} />
      <Typography style={styles.screenTitle}>Business Information</Typography>
      <Locations />
      <Tabs
        tabs={tabs}
        onTabPress={onTabPress}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        allTabsDisabled={scrollHandlerDisabled}
      />
      {!isLoading ? (
        <FlatList
          contentContainerStyle={styles.scrollList}
          ref={flatRef}
          data={sections}
          renderItem={renderSection}
          onViewableItemsChanged={handleScroll}
          viewabilityConfig={{
            itemVisiblePercentThreshold: 20,
          }}
          keyboardShouldPersistTaps={"handled"}
        />
      ) : (
        <ActivityIndicator
          color={colors.common.orangePrimary}
          style={styles.spinner}
          size={"large"}
        />
      )}
    </View>
  )
}

export const BusinessInformationScreen = observer(Component)
