import { useState } from "react"

import { View } from "react-native"

import { Input, Typography } from "@components"
import {
  EditAddressModal,
  EditEmailModal,
  EditNameModal,
  EditPhoneModal,
  EditWebsiteModal,
} from "@modals"
import { GetProfileLocation } from "@models/settings"

import { useStyles } from "../styles"
import { InformationItem } from "../InformationItem"
import { observer } from "mobx-react-lite"

interface Props {
  locationInfo: GetProfileLocation | null
}

const Component = ({ locationInfo }: Props) => {
  const styles = useStyles()

  const [nameModal, setNameModal] = useState(false)
  const [phoneModal, setPhoneModal] = useState(false)
  const [emailModal, setEmailModal] = useState(false)
  const [websiteModal, setWebsiteModal] = useState(false)
  const [addressModal, setAddressModal] = useState(false)

  const onEditWebsitePress = () => {
    if (locationInfo?.isWebsiteEditable) {
      setWebsiteModal(true)
    } else return
  }

  return (
    locationInfo && (
          <View style={styles.sectionContent}>
              <Typography style={styles.sectionTitle}>Location Information</Typography>
              <InformationItem
                  title="Business Name"
                  onPress={() => setNameModal(true)}
                  value={locationInfo.name}
                  disabled={false}
              />
              <InformationItem
                  onPress={() => setAddressModal(true)}
                  title={"Address"}
                  value={locationInfo.address}
                  disabled={false}
              />
              <InformationItem
                  onPress={() => setPhoneModal(true)}
                  title={"Phone"}
                  value={locationInfo.phone}
                  disabled={false}
              />
              <InformationItem
                  title={"Tracking Phone Number"}
                  value={locationInfo.trackingPhone}
                  disabled={true}
              />
              <InformationItem
                  onPress={() => setEmailModal(true)}
                  title={"Email"}
                  value={locationInfo.email}
                  disabled={false}
              />
              <InformationItem
                  onPress={onEditWebsitePress}
                  title={"Website"}
                  value={locationInfo.website}
                  disabled={!locationInfo.isWebsiteEditable}
              />
              <EditNameModal isVisible={nameModal} onClose={() => setNameModal(false)} />
              <EditPhoneModal isVisible={phoneModal} onClose={() => setPhoneModal(false)} />
              <EditEmailModal isVisible={emailModal} onClose={() => setEmailModal(false)} />
              <EditWebsiteModal isVisible={websiteModal} onClose={() => setWebsiteModal(false)} />
              <EditAddressModal isVisible={addressModal} onClose={() => setAddressModal(false)} />
          </View>
    )
  )
}

export const LocationInfo = observer(Component)
