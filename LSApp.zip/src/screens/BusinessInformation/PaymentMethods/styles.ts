import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    gap: 6,
  },
  inputLabel: {
    color: colors.subText,
  },
  textInput: {
    borderWidth: 1,
    borderColor: colors.gray6,
    borderRadius: 8,
    paddingHorizontal: 24,
    paddingVertical: 16,
    color: colors.text,
    gap: 4
  },
  renderItem: {
    flexDirection: "row",
    gap: 10,
    alignItems: "center",
  },
}))
