import { Pressable, View } from "react-native"

import { Icon, Typography } from "@components"
import { PaymentMenhods, ProfilePaymentMenhod } from "@models/settings"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"

interface Props {
  value: PaymentMenhods<ProfilePaymentMenhod>
  label: string
  onPress?: () => void
}

export const PaymentMethods = ({ value, label, onPress }: Props) => {
  const styles = useStyles()

  const { text } = useColors()

  const iconMapping: Record<string, string> = {
    Mastercard: "mastercard",
    VISA: "visa",
    Discover: "discover",
    Cash: "cash",
    "Diners Card": "diners",
    Invoice: "invoice",
    "Travelers Check": "travelers_check",
    Paypal: "paypal",
    // BrandCredit: "brand_credit",
    // "Android Pay": "android_pay",
    "Apple Pay": "apple_pay",
    // "Samsung Pay": "samsung_pay",
    "Electronic Payments": "electronic_Payments",
    "Google Pay": "google_Pay",
    Financing: "financing",
    Venmo: "venmo",
    "Money Transfers": "money_Transfers",
    "Cash App": "cash_Apps",
    Zelle: "zelle",
    "American Express": "amex",
    "Check": "check",
  }

  return (
    <Pressable onPress={onPress} style={styles.container}>
      <Typography style={styles.inputLabel}>{label}</Typography>
      <View style={styles.textInput}>
        {value.paymentMethods.map((item) => {
          const iconName = iconMapping[item.title]
          return (
            <View style={styles.renderItem} key={item.paymentMethodId}>
              <Icon name={iconName as IconName} stroke={text} />
              <Typography>{item.title}</Typography>
            </View>
          )
        })}
      </View>
    </Pressable>
  )
}
