import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    gap: 6,
  },
  title: {
    color: colors.subText,
  },
  textView: {
    borderWidth: 1,
    borderColor: colors.gray6,
    borderRadius: 8,
    paddingHorizontal: 24,
    paddingVertical: 16,
    color: colors.text,
  },
  disabled: {
    backgroundColor: colors.backgroundSecondary,
  },
}))
