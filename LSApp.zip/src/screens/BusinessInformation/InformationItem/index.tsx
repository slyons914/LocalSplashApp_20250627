import { Typography } from "@components"
import React from "react"
import { Pressable, View } from "react-native"
import { useStyles } from "./styles"

interface Props {
    title: string,
    value: string,
    onPress?: () => void,
    disabled: boolean
}

export const InformationItem = ( {title, value, onPress, disabled } : Props) => {

    const styles = useStyles()
    
   return (
    <Pressable style={styles.container} onPress={onPress}>
            <Typography style={styles.title}>{title}</Typography>
            <View style={[styles.textView, disabled && styles.disabled]}>
                <Typography>{value}</Typography>
            </View>
    </Pressable>
   )
}

