import { Pressable, TouchableOpacity, View } from "react-native"

import { Icon, Typography } from "@components"

import { useStyles } from "./styles"
import { useStore } from "@store"
import { AddServiceAreaModal, EditProfileTextContentModal, UpdateServiceAreaModal } from "@modals"
import { useState } from "react"

interface Props {
}

interface ContentItemProps {
    title: string,
    isDisabled: boolean,
    content: string | undefined,
    name: string
}


export const ContentDescription = ({  }: Props) => {
  const { businessInfoStore } = useStore()  
  const { ProfileTextContent, serviceAreas } = businessInfoStore

  const styles = useStyles()

  const [isProfileEditContentModalVisible, setProfileEditContentModalVisible] = useState(false)
  const [selectedItemTitle, setSelectedItemTitle] = useState('')
  const [selectedItemDetails, setSelectedItemDetails] = useState('')
  const [selectedItemName, setSelectedItemName] = useState('')
  const [isAddServiceAreaModalVisible, setIsAddServiceAreaModalVisible] = useState(false)
  const [isUpdateServiceAreaModalVisible, setIsUpdateServiceAreaModalVisible] = useState(false)

  const onContentItemPress = (title: string, isDisabled: boolean, content: string | undefined, name:string) => {
    if(isDisabled)
        return;
    setSelectedItemDetails(content??"")
    setSelectedItemTitle(title)
    setSelectedItemName(name)
    setProfileEditContentModalVisible(true)


  }

  const ContentItem = ({ title, isDisabled, content, name }: ContentItemProps) => {
    return (
        <Pressable onPress={()=>onContentItemPress(title,isDisabled,content, name)} style={styles.contentItem}>
            <Typography style={styles.titleText}>{title}</Typography>
            <View style={[styles.itemView, isDisabled && styles.darkBackground]}>
                <Typography >{(!content || content==='') ? "No Data Available" : content}</Typography>
            </View>
        </Pressable>
    )
  }

  const ServiceArea = () => {
    return (
        <View style={styles.contentItem}>
            <Typography style={styles.titleText}>Service Area</Typography>
            {
                !serviceAreas?.serviceAreas ? (
                    <View style={styles.noServiceView}>
                        <Typography style={styles.titleText}>No Service Area Added</Typography>
                    </View> 
                ) : (
                    <Pressable onPress={() => setIsUpdateServiceAreaModalVisible(true)} style={[styles.itemView, styles.serviceView]}>
                        {
                            serviceAreas?.serviceAreas?.map((item, index)=> (
                                <View key={index} style={styles.serviceSubView}>
                                    <Typography>{item?.serviceAreaName}</Typography>
                                    <Typography style={styles.subText}>Coverage Area{item.isAdsSync && ", Ad Spend Region"}{item.isGbpSync && ", GBP Service Area"}</Typography>
                                </View>
                            ))
                        }
                    </Pressable>
                )
            }
            <TouchableOpacity onPress={() => setIsAddServiceAreaModalVisible(true)} style={styles.addBtn}>
                <Icon name="addCircle" />
                <Typography style={styles.addBtnText}>Add Service Area</Typography>
            </TouchableOpacity>
        </View>
    )
  }

  return (
    <View style={styles.container}>
        <ContentItem name={"description"} title={"Description"} isDisabled={false} content={ProfileTextContent?.description} />
        <ContentItem name={"product"} title={"Product"} isDisabled={true} content={ProfileTextContent?.product} />
        <ContentItem name={"services"} title={"Services"} isDisabled={true} content={ProfileTextContent?.service.toString()} />
        <ContentItem name={"mission"} title={"Mission"} isDisabled={false} content={ProfileTextContent?.mission} />
        <ContentItem name={"tagline"} title={"Tagline"} isDisabled={false} content={ProfileTextContent?.tagline} />
        <ServiceArea />
        <ContentItem name={"yearEstablished"} title={"Year Established"} isDisabled={false} content={ProfileTextContent?.yearEstablished} />
        <ContentItem name={"brand"} title={"Brands"} isDisabled={true} content={ProfileTextContent?.brands} />
        <ContentItem name={"licenseNumber"} title={"License Number"} isDisabled={false} content={ProfileTextContent?.licenseNumber} />
        <ContentItem name={"membership"} title={"Memberships"} isDisabled={true} content={ProfileTextContent?.memberships} />
        <ContentItem name={"disclaimer"} title={"Disclaimer"} isDisabled={false} content={ProfileTextContent?.disclaimer} />
        <EditProfileTextContentModal isVisible={isProfileEditContentModalVisible} onClose={()=>setProfileEditContentModalVisible(false)} title={selectedItemTitle} details={selectedItemDetails} name={selectedItemName} setDetails={setSelectedItemDetails}/>
        <AddServiceAreaModal isVisible={isAddServiceAreaModalVisible} onClose={() => setIsAddServiceAreaModalVisible(false)} />  
        <UpdateServiceAreaModal isVisible={isUpdateServiceAreaModalVisible}  onClose={() => setIsUpdateServiceAreaModalVisible(false)}/>   
    </View>
  )
}
