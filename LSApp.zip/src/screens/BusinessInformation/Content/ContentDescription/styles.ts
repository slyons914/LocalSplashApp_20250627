import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme }) => ({
  container: {
    gap: 24,
  },
  contentItem: {
    gap: 6,
  },
  titleText: {
    color: colors.subText,
  },
  itemView: {
    padding:16,
    borderWidth:1,
    borderColor:colors.gray6,
    borderRadius:8,
    gap:4
  },
  darkBackground: {
    backgroundColor: isDarkTheme ? colors.backgroundSecondary : colors.greyLight
  },
  noServiceView: {
    justifyContent: "center",
    alignItems: "center"
  },
  addBtn: {
    flexDirection: "row",
    gap: 8,
    padding: 10,
    alignItems: "center",
  },
  addBtnText: {
    color: colors.orangePrimary,
  },
  subText: {
    color: colors.subText,
    fontSize: 12
  },
  serviceView: {
    gap:8
  },
  serviceSubView: {
    gap:4
  }
}))
