import { View } from "react-native"

import { Typography } from "@components"
import { ProfileViewModel } from "@models"
import { ContactsModel, PaymentMenhods, ProfilePaymentMenhod, ProfileTextContents, ProfileWorkingHours } from "@models/settings"

import { Contacts } from "../Contacts"
import { PaymentMethods } from "../PaymentMethods"
import { useStyles } from "../styles"
import { useState } from "react"
import { ChangePaymentsMethodModal, EditBusinessHoursModal } from "@modals"
import { WorkingHours } from "../WorkingHours"
import { ContentDescription } from "./ContentDescription"
import { observer } from "mobx-react-lite"


interface Props {
  locationsItem: ProfileViewModel | null
  profilePaymentMethods: PaymentMenhods<ProfilePaymentMenhod> | null
  contacts: ContactsModel | null
  profileTextContent: ProfileTextContents | null
  workingHours: ProfileWorkingHours | null
}

const Component = ({ locationsItem, profilePaymentMethods, contacts, workingHours }: Props) => {
  const styles = useStyles()

  const [changePaymentsMethodModal, setChangePaymentMethodModal] = useState(false)
  const [isEditBusinessHoursModalVisible, setIsEditBusinessHoursModalVisible] = useState(false)
  const [profileWorkingHours, setWorkingHours] = useState<ProfileWorkingHours | null>(null)

  const onWorkingHoursPress = () => {
    setWorkingHours(workingHours)
    setIsEditBusinessHoursModalVisible(true)
  }
  return (
    locationsItem &&
    profilePaymentMethods && (
      <View style={styles.sectionContent}>
        <Typography style={styles.sectionTitle}>Content</Typography>
        <WorkingHours onPress={onWorkingHoursPress} value={workingHours} label={"Working Hours"} />
        <PaymentMethods onPress={()=>setChangePaymentMethodModal(true)} value={profilePaymentMethods} label={"Payments Methods"} />
        <Contacts contacts={contacts} />
        <ContentDescription />
        <ChangePaymentsMethodModal isVisible={changePaymentsMethodModal} onClose={()=>setChangePaymentMethodModal(false)}></ChangePaymentsMethodModal>
        <EditBusinessHoursModal workingHours = {profileWorkingHours} isVisible={isEditBusinessHoursModalVisible} onClose={()=>setIsEditBusinessHoursModalVisible(false)}/>
      </View>
    )
  )
}

export const Content = observer(Component)
