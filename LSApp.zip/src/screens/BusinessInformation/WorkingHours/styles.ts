import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    gap: 6,
  },
  inputLabel: {
    color: colors.subText,
  },
  textInput: {
    borderWidth: 1,
    borderColor: colors.gray6,
    borderRadius: 8,
    paddingHorizontal: 24,
    paddingVertical: 16,
    color: colors.text,
  },
  workingHoursView: {
    padding:16,
    borderWidth:1,
    borderColor:colors.gray6,
    borderRadius:8,
    gap:4
  },
  workingHoursItem: {
    flexDirection:"row",
    gap:24
  },
  dayName: {
    width:100
  },
  closed: {
    color:colors.greyDarkMode
  }
}))
