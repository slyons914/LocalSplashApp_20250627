import { Pressable, View } from "react-native"

import { Typography } from "@components"
import { ProfileWorkingHours } from "@models/settings"

import { useStyles } from "./styles"

interface Props {
  value: ProfileWorkingHours | null
  label: string
  onPress?: () => void
}

const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

export const WorkingHours = ({ value, label, onPress }: Props) => {
  const styles = useStyles()

  const formatTime = (time: number) => {
    if (time === null) return null; 
    const hours = Math.floor(time / 100);
    const minutes = time % 100;
    const period = hours >= 12 ? "PM" : "AM";
    const formattedHours = hours > 12 ? hours - 12 : hours === 0 ? 12 : hours;
    const formattedMinutes = minutes === 0 ? "00" : minutes.toString();
  
    return `${formattedHours}:${formattedMinutes} ${period}`;
  };
  
  const getDaySchedule = (day: string, data: any) => {
    const isByAppointment = data[`is${day}ByAppointment`];
    const openingTime = data[`${day.toLowerCase()}OpeningTime`];
    const closingTime = data[`${day.toLowerCase()}ClosingTime`];
  
    if (isByAppointment) {
      return <Typography>By Appointment</Typography>;
    }
  
    if (openingTime === null || closingTime === null) {
      return <Typography style={styles.closed}>Closed</Typography>;
    }
  
    const formattedOpeningTime = formatTime(openingTime);
    const formattedClosingTime = formatTime(closingTime);
    return <Typography>{`${formattedOpeningTime} to ${formattedClosingTime}`}</Typography> ;
  };

  return (
    <Pressable onPress={onPress} style={styles.container}>
      <Typography style={styles.inputLabel}>{label}</Typography>
      {
        value &&  
        <View style={styles.workingHoursView}>
            {
                days.map((day, index)=> (
                    <View style={styles.workingHoursItem} key={index}>
                        <Typography style={styles.dayName}>{day}</Typography>
                        {getDaySchedule(day, value)}
                    </View>
                ))
            }
        </View>
      }
    </Pressable>
  )
}
