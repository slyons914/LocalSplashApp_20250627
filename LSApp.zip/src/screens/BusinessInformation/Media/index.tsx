import { ActivityIndicator, Image, ImageResizeMode, Pressable, View } from "react-native"

import { useNavigation } from "@react-navigation/native"
import { Icon, Typography } from "@components"

import { useStyles } from "./styles"
import { useEffect, useState } from "react"
import { AddBusinessDocuments, AddImageModal, AddOrUpdateCoverPhotoModal, AddOrUpdateLogoModal, AddVideoModal } from "@modals"
import { GetMediaResponseViewModel } from "@localsplash/mobile-api-client"
import { BusinessInfoAPI } from "@api"
import { useStore } from "@store"
  import { colors, Routes } from "@utils/constants"
import { imagePath } from "@utils/constants/imagesPath"
import Video from "react-native-video"
import { FormatHelper } from "@utils/helpers"
import { observer } from "mobx-react-lite"
import { validateMediaFile } from "@utils/helpers/imagePicker"
import { showToast } from "@utils/helpers/common"

interface Props {
    logo: string | null
    coverPhoto: string | null
    businessPhotos: GetMediaResponseViewModel | null
    businessDocuments: GetMediaResponseViewModel | null
    businessVideos: GetMediaResponseViewModel | null
}

interface ImageItemProps {
    title:string,
    imageUrl:string | null,
    imageType: ImageResizeMode
    onPress: () => void
    isLoading: boolean
}

interface BusinessMediaItemProps {
    title:string,
    data: GetMediaResponseViewModel | null
    onAddPress: () => void,
    isLoading: boolean,
    onPress: () => void,
}

const Component = ({logo, coverPhoto, businessPhotos, businessVideos, businessDocuments}: Props) => {
    const styles = useStyles()
    const { navigate } = useNavigation()

    const { homeStore, businessInfoStore } = useStore()
    const { locationsItem } = homeStore
    const { documentTypes, getLogo, getCoverPhoto, getBusinessPhotos, getDocumentTypes, getBusinessVideos } = businessInfoStore

    const [isUpdateLogoModalVisible, setUpdateLogoModalVisible] = useState(false)
    const [isUpdateCoverPhotoModalVisible, setUpdateCoverPhotoModalVisible] = useState(false)
    const [isAddImageModalVisible, setIsAddImageModalVisible] = useState(false)
    const [isAddVideoModalVisible, setIsAddVideoModalVisible] = useState(false)
    const [addImageType, setAddImageType] = useState('')
    const [isLogoLoading, setIsLogoLoading] = useState(false)
    const [isCoverPhotoLoading, setIsCoverPhotoLoading] = useState(false)
    const [isBusinessPhotoLoading, setIsBusinessPhotoLoading] = useState(false)
    const [isBusinessVideosLoading, setIsBusinessVideosLoading] = useState(false)
    const [isBusinessDocumentAddModalVisible, setIsBusinessDocumentAddModalVisible] = useState(false)
    
    useEffect(()=> {
        if(!documentTypes) {
            getDocumentTypes()
        }
    },[])

    const ImageItemView = ({title, imageUrl, imageType, onPress, isLoading}: ImageItemProps) => {
        return (
            <Pressable onPress={onPress} style={styles.itemView}>
                <Typography style={styles.inputLabel}>{title}</Typography>
                {
                    !isLoading ? (
                        <Pressable onPress={onPress} style={[styles.imageView, imageUrl ? styles.imageAvailableView : {}]}>
                            {
                                imageUrl ? 
                                (   <Image source={{ uri: `https://mobileapi.localsplash.com/MediaThumbnails/${encodeURIComponent(imageUrl)}?height=300`}} style={styles.logo} resizeMode={imageType} />) : 
                                (   <Icon name="attachImageBusinessInfo" /> )
                            }
                        </Pressable>
                    ) : (
                        <View>
                            <ActivityIndicator size={"large"} color={colors.common.orangePrimary}></ActivityIndicator>
                        </View>
                    )
                }
            </Pressable>
        )
    }

    const BusinessMediaItem = ({title, data, onAddPress, isLoading, onPress}: BusinessMediaItemProps) => {
        const items = data?.items ?? [];

        const isVideo = (url: string) => url.endsWith('.mp4');
    
        return (
            <View style={styles.businessPhotosView}>
                <View style={styles.photosHeader}>
                    <Typography>{title}</Typography>
                    {
                        isLoading ? (<ActivityIndicator size={"small"} color={colors.common.orangePrimary}></ActivityIndicator>)
                        : (<Typography onPress={onAddPress} style={styles.orangeText}>+ New</Typography>)
                    }
                </View>
                {
                    items.length ? (
                        <Pressable onPress={onPress} style={styles.photosView}>
                            {
                                items.slice(0, 3).map((item, index) => (
                                    <View key={index} style={{ width:"33%" }}>
                                        {
                                            index === 2 && items.length > 3 && (
                                                <Typography style={styles.morePhotosText}>
                                                    {items.length - 3}+
                                                </Typography>
                                            )
                                        }
                                        {
                                            !isVideo(item?.mediaUrl ?? "" ) ? (
                                                <Image
                                                style={[styles.photo, index === 2 && items.length > 3 && styles.lightImage]}
                                                source={item.mediaUrl?.includes('.pdf') ? imagePath.pdfImage : {uri: `https://mobileapi.localsplash.com/MediaThumbnails/${encodeURIComponent(item?.mediaUrl ?? '')}?height=300` }}
                                                />
                                            ) : (
                                                <View><Typography>Video</Typography></View>
                                            )
                                        }
                                        {index === 2 && items.length > 3 && (
                                        <>
                                            <View style={styles.darkOverlay} />
                                            <View style={styles.overlayContent}>
                                                <Typography style={styles.morePhotosText}>{items.length - 3}+</Typography>
                                            </View>
                                        </>
                                        )}
                                    </View>
                                ))
                            }
                        </Pressable>
                    ) : (
                        <Pressable onPress={onAddPress} style={styles.emptyView}>
                            <Icon name="attachImageBusinessInfo" />
                        </Pressable>
                    )
                }
            </View>
        );
    }  

    const BusinessVideoItem = ({title, data, onAddPress, isLoading, onPress}: BusinessMediaItemProps) => {
        const items = data?.items ?? [];

        const [videoDurations, setVideoDurations] = useState<{ [key: number]: number }>({});
    
        return (
            <View style={styles.businessPhotosView}>
                <View style={styles.photosHeader}>
                    <Typography>{title}</Typography>
                    {
                        isLoading ? (<ActivityIndicator size={"small"} color={colors.common.orangePrimary}></ActivityIndicator>)
                        : (<Typography onPress={onAddPress} style={styles.orangeText}>+ New</Typography>)
                    }
                </View>
                {
                    items.length ? (
                        <Pressable onPress={onPress} style={styles.photosView}>
                            {
                                items.slice(0, 3).map((item, index) => (
                                    <View key={index} style={{ width:"33%" }}>
                                        
                                        <View style={styles.videoView}>
                                            <View style={styles.videoWrapper}>
                                                <Video
                                                source={{ uri: item?.mediaUrl }}
                                                style={styles.video}
                                                resizeMode="stretch"
                                                paused={true}
                                                onLoad={(data) => {
                                                if (videoDurations[index] !== data.duration) {
                                                    setVideoDurations((prev) => ({
                                                    ...prev,
                                                    [index]: data.duration,
                                                    }));
                                                }
                                                }}
                                                />
                                                {videoDurations[index] != null && (
                                                <View style={styles.durationOverlay}>
                                                    <Typography style={styles.durationText}>
                                                    {FormatHelper.formatDuration(videoDurations[index])}
                                                    </Typography>
                                                </View>
                                                )}
                                            </View>
                                        </View>
                                        {index === 2 && items.length > 3 && (
                                        <>
                                            <View style={styles.darkOverlay} />
                                            <View style={styles.overlayContent}>
                                                <Typography style={styles.morePhotosText}>{items.length - 3}+</Typography>
                                            </View>
                                        </>
                                        )}
                                    </View>
                                ))
                            }
                        </Pressable>
                    ) : (
                        <Pressable onPress={onAddPress} style={styles.emptyView}>
                            <Icon name="attachImageBusinessInfo" />
                        </Pressable>
                    )
                }
            </View>
        );
    }  
    
    const onLogoPress = () => {
        if(logo) 
            setUpdateLogoModalVisible(true)
        else {
            setAddImageType('logo')
            setIsAddImageModalVisible(true)
        }
    }

    const onCoverPhotoPress = () => {
        if(coverPhoto) 
            setUpdateCoverPhotoModalVisible(true)
        else {
            setAddImageType('cover')
            setIsAddImageModalVisible(true)
        }
    }

    const onImageSelect = async (uri: string, filename:string, type:string, width: number | undefined, height: number | undefined) => {
        const data = new FormData ()
        if(addImageType === 'logo' || addImageType === 'cover') {
            data.append("File" , {
                uri:uri,
                type:type,
                name:filename
            })
        } else { 
            data.append("Files" , {
                uri:uri,
                type:type,
                name:filename
            })
        }

        if(!locationsItem?.id)
            return;
        if(addImageType === 'logo') {
            const validationResponse = await validateMediaFile(uri, type, true, 250, 250, 10, width ?? 0, height ?? 0)
            if(!validationResponse.valid) {
                showToast(validationResponse?.error ?? '')
                return;
            }
            setIsLogoLoading(true)
            await BusinessInfoAPI.updateOrAddLogo(locationsItem?.id, data)
            await getLogo(locationsItem?.id)
            setIsLogoLoading(false)
        } else if (addImageType === 'cover') {
            const validationResponse = await validateMediaFile(uri, type, true, 400, 266, 30, width ?? 0, height ?? 0)
            if(!validationResponse.valid) {
                showToast(validationResponse?.error ?? '')
                return;
            }
            setIsCoverPhotoLoading(true)
            await BusinessInfoAPI.updateOrAddCoverPhoto(locationsItem?.id, data)
            await getCoverPhoto(locationsItem?.id)
            setIsCoverPhotoLoading(false)
        } else if (addImageType === 'photo') {
            const validationResponse = await validateMediaFile(uri, type, true, 400, 266, 30, width ?? 0, height ?? 0)
            if(!validationResponse.valid) {
                showToast(validationResponse?.error ?? '')
                return;
            }
            setIsBusinessPhotoLoading(true)
            await BusinessInfoAPI.addBussinessImages(locationsItem?.id, data)
            await getBusinessPhotos(locationsItem?.id)
            setIsBusinessPhotoLoading(false)
        } else {
            const validationResponse = await validateMediaFile(uri, type, false, 0, 0, 500, width ?? 0, height ?? 0)
            if(!validationResponse.valid) {
                showToast(validationResponse?.error ?? '')
                return;
            }
            setIsBusinessVideosLoading(true)
            await BusinessInfoAPI.addBussinessVideos(locationsItem?.id, data)
            await getBusinessVideos(locationsItem?.id)
            setIsBusinessVideosLoading(false)
        }
    }

    const onBussinessPhotoAddPress = () => {
        setAddImageType('photo')
        setIsAddImageModalVisible(true)
    }

    const onBussinessVideoAddPress = () => {
        setAddImageType('video')
        setIsAddVideoModalVisible(true)
    }

    return (
        <View style={styles.sectionContent}>
            <Typography style={styles.sectionTitle}>Media</Typography>
            <ImageItemView isLoading={isLogoLoading} onPress={onLogoPress} imageType="contain" imageUrl={logo} title="Logo" />
            <ImageItemView isLoading={isCoverPhotoLoading} onPress={onCoverPhotoPress} imageType="cover" imageUrl={coverPhoto} title="Cover Photo" />
            <BusinessMediaItem onPress={() => navigate(Routes.BusinessPhotos)} isLoading={isBusinessPhotoLoading} onAddPress={onBussinessPhotoAddPress} data={businessPhotos} title="Business Photos" /> 
            <BusinessVideoItem onPress={() => navigate(Routes.BusinessVideos)} isLoading={isBusinessVideosLoading} onAddPress={onBussinessVideoAddPress} data={businessVideos} title="Business Videos" /> 
            <BusinessMediaItem onPress={() => navigate(Routes.BusinessDocuments)} isLoading={false} onAddPress={() => setIsBusinessDocumentAddModalVisible(true)} data={businessDocuments} title="Business Documents" /> 
            <AddOrUpdateLogoModal imageUrl={logo} isVisible={isUpdateLogoModalVisible} onClose={()=>setUpdateLogoModalVisible(false)} />
            <AddOrUpdateCoverPhotoModal imageUrl={coverPhoto} isVisible={isUpdateCoverPhotoModalVisible} onClose={()=>setUpdateCoverPhotoModalVisible(false)}  />    
            <AddImageModal onImageSelect={onImageSelect} isVisible={isAddImageModalVisible} onClose={()=>setIsAddImageModalVisible(false)}/>
            <AddVideoModal onImageSelect={onImageSelect} isVisible={isAddVideoModalVisible} onClose={() => setIsAddVideoModalVisible(false)} />   
            <AddBusinessDocuments isVisible={isBusinessDocumentAddModalVisible} onClose={() => setIsBusinessDocumentAddModalVisible(false)} documentTypes={documentTypes}/>      
        </View>
    )
}

export const Media = observer(Component)
