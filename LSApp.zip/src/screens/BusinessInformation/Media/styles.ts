import { withStyles } from "@utils/hocs"
import { StyleSheet } from "react-native"

export const useStyles = withStyles(({ colors, insets, width }) => ({
  sectionContent: {
    gap: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "500",
  },
  inputLabel: {
    color: colors.text,
  },
  itemView: {
    gap:6
  },
  imageView: {
    height:116,
    width: width - 48,
    borderWidth:1,
    borderColor: colors.orangePrimary,
    borderStyle:'dashed',
    borderRadius: 8,
    alignItems:"center",
    justifyContent:"center"
  },
  logo: {
    height: "100%",
    width: "100%",
  },
  imageAvailableView: {
    borderColor: colors.gray6,
    borderStyle: "solid",
  },
  orangeText: {
    color: colors.orangePrimary
  },
  photosHeader: {
    flexDirection:"row",
    justifyContent:"space-between"
  },
  businessPhotosView: {
    gap:6
  },
  photosView: {
    flexDirection:"row",
  },
  photo: {
    height: 110,
    width: "95%",
    borderRadius:8,
  },
  lightImage: {
    opacity:0.2,
  },
  morePhotosText: {
    position: "absolute",
    top:"38%",
    left:"45%",
    color: "#fff"
  },
  darkOverlay: {
    position:'absolute',
    height:110,
    width:'95%',
    backgroundColor: 'rgba(0,0,0,0.6)',
    borderRadius: 8,
  },

  overlayContent: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
  },
  moreVideosText: {
    position: 'absolute',
    top: '40%',
    left: '40%'
  },
  videoView: {
    height:110, 
    width: '95%',
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 8
  },
  emptyView: {
    borderWidth:1,
    height: 110,
    width:"33%",
    borderRadius:8,
    borderStyle:"dashed",
    borderColor:colors.orangePrimary,
    justifyContent:"center",
    alignItems:"center"
  },
  videoWrapper: {
    position: 'relative',
    width: '100%',
    height: '100%',
    borderRadius: 8,
    overflow: 'hidden'
  },
  video: {
    height: 110, 
    width:'100%', 
    borderRadius: 8
  },
  durationOverlay: {
    position: 'absolute',
    bottom: 6,
    right: 6,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 12,
  },
  durationText: {
    color: '#fff',
    fontSize: 12,
  },
}))
