import { Pressable, TouchableOpacity, View } from "react-native"

import { Icon, Typography } from "@components"
import { Contact, ContactsModel } from "@models/settings"

import { useStyles } from "./styles"
import { useState } from "react"
import { AddOrUpdateContactsModal } from "@modals"

interface Props {
  contacts: ContactsModel | null
}

export const Contacts = ({ contacts }: Props) => {
  const styles = useStyles()

  const [isAddContactModalVisible, setIsAddContactModalVisible] = useState(false)
  const [currentContact, setCurrentContact] = useState<Contact | null>(null)
  const [contactTypeId, setContactTypeId] = useState<number | null>(null)
  const [actionType, setActionType] = useState<"edit" | "add">("edit")

  const onAddContactPress = () => {
    setCurrentContact(null)
    setContactTypeId(null)
    setActionType("add")
    setIsAddContactModalVisible(true)
  }

  const handleContactPress = (item: Contact) => {
    setCurrentContact(item)
    setActionType("edit")
    setContactTypeId(item?.contactTypeId)
    setIsAddContactModalVisible(true)
  }

  return (
    contacts && (
      <View style={styles.container}>
        <Typography style={styles.sectionTitle}>Contacts</Typography>
        {contacts.contacts.map((item) => {
          return (
            <Pressable onPress={()=>handleContactPress(item)} key={item.id} style={styles.itemContainer}>
              <Typography>{item.title || "-"}</Typography>
              <Typography style={styles.itemName}>{item.name || "-"}</Typography>
              <Typography>{item.phoneNumber || "-"}</Typography>
              <Typography>{item.emailAddress || "-"}</Typography>
              <Typography>{item.phoneExtension || "-"}</Typography>
              <Typography>Preferred Method of Contact: {item.contactType || "-"}</Typography>
            </Pressable>
          )
        })}
        <TouchableOpacity onPress={onAddContactPress} style={styles.addBtn}>
          <Icon name="addCircle" />
          <Typography style={styles.addBtnText}>Add Contacts</Typography>
        </TouchableOpacity>
        <AddOrUpdateContactsModal contactTypeId={contactTypeId} setContactTypeId={setContactTypeId} contactItem={currentContact} type={actionType} isVisible={isAddContactModalVisible} onClose={()=>setIsAddContactModalVisible(false)} />
      </View>
    )
  )
}
