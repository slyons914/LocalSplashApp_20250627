import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    gap: 6,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: "400",
    color: colors.subText,
  },
  itemContainer: {
    backgroundColor: colors.backgroundSecondary,
    padding: 16,
    gap: 4,
    borderRadius: 8,
  },
  itemName: {
    fontWeight: "500",
    fontSize: 20,
  },
  addBtn: {
    flexDirection: "row",
    gap: 8,
    padding: 10,
    alignItems: "center",
  },
  addBtnText: {
    color: colors.orangePrimary,
  },
}))
