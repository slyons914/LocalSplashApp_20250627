import { useMemo, useState } from "react"

import { Pressable, View } from "react-native"

import { Input, Typography } from "@components"
import { EditGoogleCategoriesModal, EditPrimarySeachPhrase } from "@modals"
import { ProfileViewModel } from "@models"
import { ProfileGoogleCategories } from "@models/settings"

import { GoogleCategories } from "../GoogleCategories"
import { useStyles } from "../styles"
import { observer } from "mobx-react-lite"

interface Props {
  locationsItem: ProfileViewModel | null
  profileGoogleCategories: ProfileGoogleCategories | null
}

const Component = ({ locationsItem, profileGoogleCategories }: Props) => {
  const styles = useStyles()

  const [isEditSearchPhraseModalVisible, setIsEditSearchPhraseModalVisible] = useState(false)

  const [googleCategoriesModal, setGoogleCategoriesModal] = useState(false)
  const searchTerms = useMemo((): string => {
    if (!locationsItem) return ""
    return locationsItem.searchTerms.map((item: string) => `• ${item}`).join("\n")
  }, [locationsItem])

  return (
    locationsItem &&
    profileGoogleCategories && (
      <View style={styles.sectionContent}>
        <Typography style={styles.sectionTitle}>Keywords</Typography>
        <Pressable onPress={()=>setIsEditSearchPhraseModalVisible(true)} style={{gap:6}}>
            <Typography style={styles.inputLabel}>Primary Search Phrase</Typography>
            <View style={styles.textInput}>
                <Typography>{locationsItem?.title}</Typography>
            </View>
        </Pressable>
        <GoogleCategories
          value={profileGoogleCategories}
          label={"Google Categories"}
          onPress={() => setGoogleCategoriesModal(true)}
        />
        <Input
          label={"Search Phrases"}
          onPress={Promise.resolve}
          value={searchTerms}
          editable={false}
          disabled
          multiline
        />
        <EditGoogleCategoriesModal
          isVisible={googleCategoriesModal}
          onClose={() => setGoogleCategoriesModal(false)}
        />
        <EditPrimarySeachPhrase isVisible={isEditSearchPhraseModalVisible} onClose={()=>setIsEditSearchPhraseModalVisible(false)} />
      </View>
    )
  )
}

export const Keywords = observer(Component)
