import { ActivityIndicator, Pressable, ScrollView, Switch, TextInput, View, useColorScheme } from "react-native"
import { useStyles } from "./styles"
import { Button, Checkbox, ErrorMessage, Icon, Typography } from "@components"
import { Routes, colors } from "@utils/constants"
import { useCallback, useState } from "react"
import { navigate } from "@navigation"
import DatePicker from "react-native-date-picker"
import DocumentPicker from 'react-native-document-picker'
import { pickImageFromGallery, takePhotoWithCamera } from "@utils/helpers"
import { AttachFile } from "@modals"
import { PostsAPI } from "@api"
import { useStore } from "@store"
interface Attachment {
    uri: string;
    name: string;
    type: string;
}
export const NewPost = () => {


  const systemColorScheme = useColorScheme()
  const { homeStore} = useStore()
  const { locationsItem } = homeStore
  const isLightTheme = systemColorScheme === "light"
  const [postToFb , setPostToFb] = useState(false)
  const [schedulePost , setSchedulePost] = useState(false)
  const [addButton , setAddButton] = useState(false)
  const [dateModal , setDateModal] = useState(false)
  const [timeModal , setTimeModal] = useState(false)
  const [selectedButton , setSelectedButton] = useState("")
  const [dateTime , setDateTime] = useState(new Date ());
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isImageSelected , setImageSelected] = useState(false)
  const [isAttachFileModalVisible, setIsAttachFileModalVisible] = useState(false)
  const [postText , setPostText] = useState("")
  const [postDesc , setPostDesc] = useState("")
  const [buttonLink , setButtonLink] = useState("")
  const [errorText , setErrorText] = useState("")
  const [isLoading , setIsLoading] = useState(false)
  const [postAddText , setPostAddText] = useState("")
  const styles = useStyles()
  const handleDateConfirm = (date:any) =>{
    setDateTime(date)
    setDateModal(false)
  }
  const handleTimeConfirm = (date:any) =>{
    setDateTime(date)
    setTimeModal(false)
  }
  const handleRemoveAttachment = (uri: string) => {
    setImageSelected(false)
    setAttachments(prevAttachments => prevAttachments.filter(attachment => attachment.uri !== uri));
};
  const handleTakePhoto = async () => {
    try {
        const response = await takePhotoWithCamera();
        if (!!response && typeof response !== "string") {
            const newAttachment = {
                uri: response[0]?.uri || "",
                name: response[0]?.fileName || "",
                type: response[0]?.type || "",
            };
            setImageSelected(true)
            setAttachments(prev => [...prev, newAttachment]);
        }
    } catch (error) {
        console.log(error);
    }
    setIsAttachFileModalVisible(false)
};

const handleChoosePhoto = async () => {
    try {
        const response = await pickImageFromGallery();
        if (!!response && typeof response !== "string") {
            const newAttachment = {
                uri: response[0]?.uri || "",
                name: response[0]?.fileName || "",
                type: response[0]?.type || "",
            };
            setImageSelected(true)
            setAttachments(prev => [...prev, newAttachment]);
        }
    } catch (error) {
        console.log(error);
    }
    setIsAttachFileModalVisible(false)
};

const handleChooseDocument = useCallback(async () => {
    try {
        
        const result = await DocumentPicker.pick({
            presentationStyle: 'fullScreen',
        });
        const newAttachment = {
            uri: result[0]?.uri || "",
            name: result[0]?.name || "",
            type: result[0]?.type || "",
        };
        setImageSelected(true)
        setAttachments(prev => [...prev, newAttachment]);
    } catch (err) {
        console.warn(err);
    }
    setIsAttachFileModalVisible(false)
}, []);

const onAddItem = () =>{
    if(attachments.length===0){
        setIsAttachFileModalVisible(true);
    }
    
}

const setPostDescValue = (val:string) =>{
    if(val.length > 1500){
        setErrorText("Max 1500 characters")
    }
    else if(val === ""){
        setErrorText("Description Cannot be empty")
        setPostDesc("")
    }else{
        setErrorText("")
        setPostDesc(val)
    }
}

const onPostPublish = async () =>{
    if(postDesc === ""){
        setErrorText("Description cannot be empty")
    }
    const postData = new FormData()
    if(errorText === "" && postDesc !== ""){
        setIsLoading(true)
        postData.append('Description' , postDesc)
        postData.append('title',postText)
        postData.append('IsPostedToFacebook' , postToFb)
        postData.append('IsPostScheduled' , schedulePost)
        postData.append('ScheduledOn' , dateTime.toISOString())
        if(addButton){
            postData.append('ActionType',selectedButton)
            postData.append('ActionUrl',buttonLink)
        }
        if(isImageSelected){
            postData.append('Image',{
            uri:attachments[0].uri,
            type:attachments[0].type,
            name:attachments[0].name
        })
    }
    const {data,error} = await PostsAPI.addPost(locationsItem?.id,postData)
    if(data){
        setPostAddText("Post Uploaded Successfully")
    }else{
        setPostAddText("Error in Uploading Post")
    }
    console.log("ADD POST DATA IS: ",data)
    setIsLoading(false)
    }
}
  return (
    <ScrollView contentContainerStyle={{flexGrow:1}}>
        <View style={styles.postContainer}>
        <Pressable onPress={onAddItem} style={styles.fileInputView}>
            <View style={styles.inputViewHeader}>
                <Icon name="AttachFileIcon"></Icon>
                <Typography style={styles.orangeText}>Attach File</Typography>
            </View>
            <Typography style={[styles.inputText, !isLightTheme && styles.whiteText]}>File formats: JPG, PNG</Typography>
            <Typography style={[styles.inputText, !isLightTheme && styles.whiteText]}>Minimum dimensions: 480 x 400 pixels.</Typography>
            <Typography style={[styles.inputText, !isLightTheme && styles.whiteText]}>Maximum file size: 5MB</Typography>
            <Typography style={[styles.inputText,styles.rightText , !isLightTheme && styles.whiteText]}>{attachments.length}/1</Typography>
        </Pressable>
        <View>
            {
                attachments.map((item,index)=>(
                    <View key={index} style={styles.attachmentsView}>
                        <Typography style={styles.imageUrl} numberOfLines={1} key={index}>{item.name}</Typography>
                        <Pressable onPress={() => handleRemoveAttachment(item?.uri)}>
                            <Icon name="trash" />
                        </Pressable>
                    </View>
                    
                ))
            }
        </View>
        <Typography style={styles.heading}>Custom AI Generated Text</Typography>
        <View style={styles.post}>
            <View>
                <View style={styles.aiTextView}>
                    <View style={styles.aiTextHeader}>
                        <Typography style={styles.subText}>What is the post about?</Typography>
                        <Icon name="ReloadArrow"></Icon>
                    </View>
                    <Typography style={styles.orangeColor}>Generate</Typography>
                </View>
                <TextInput
                textAlignVertical={"top"}
                placeholderTextColor={colors.common.gray4}
                placeholder={"Type here .."}
                style={styles.textInput}
                value={postText}
                onChangeText={(val)=>setPostText(val)}
                />
            </View>
            <View>
                <Typography style={styles.subText}>Description*</Typography>
                <TextInput
                textAlignVertical={"top"}
                placeholderTextColor={colors.common.gray4}
                placeholder={"Type your description here ..."}
                style={[styles.textInput,styles.descTextInput]}
                value={postDesc}
                onChangeText={(val)=>{setPostDescValue(val)}}
                multiline={true}
                />
                <Typography style={styles.lightText}>{postDesc.length}/1500 characters</Typography>
                {errorText?(<ErrorMessage message={errorText}></ErrorMessage>):(null)}
            </View>
            <View style={styles.fbToggleView}>
                <Typography style={styles.medText}>Post to Facebook</Typography>
                <Switch
                trackColor={{true: colors.common.green }}
                ios_backgroundColor="#3e3e3e"
                onValueChange={() => setPostToFb(previousState => !previousState)}
                value={postToFb}
                />
            </View>
            <View style={styles.fbToggleView}>
                <Typography style={styles.medText}>Schedule Post (CST)</Typography>
                <Switch
                trackColor={{true: colors.common.green }}
                ios_backgroundColor="#3e3e3e"
                onValueChange={() => setSchedulePost(previousState => !previousState)}
                value={schedulePost}
                />

            </View>
            {
                schedulePost ? (
                    <View style={styles.dateTimeInputView}>
                        <Typography style={styles.subText}>Schedule Time</Typography>
                        <Pressable onPress={()=>setTimeModal(true)} style={styles.dateTimeInput}>
                            <Typography>{dateTime.getHours()%12}:{dateTime.getMinutes()} {dateTime.getHours()>12?"PM":"AM"}</Typography>
                            <Icon name="PostClockIcon"></Icon>
                        </Pressable>
                        <Typography style={styles.subText}>Schedule Date</Typography>
                        <Pressable onPress={()=>setDateModal(true)} style={styles.dateTimeInput}>
                            <Typography>{dateTime.toLocaleDateString()}</Typography>
                            <Icon name="CalenderIcon"></Icon>
                        </Pressable>
                    </View>
                ):(null)
            }
            <View style={styles.addButton}>
                <Checkbox value={addButton} onPress={()=>setAddButton(prevState => !prevState)} />
                <Typography>Add Button</Typography>
            </View>
            {
                addButton ? (
                    <View style={styles.addButtonView}>
                        <Typography style={styles.subText}>Button</Typography>
                        <View style={styles.buttonView}>
                            <Pressable onPress={()=> setSelectedButton("LEARN_MORE")} style={[styles.button ,selectedButton==="LEARN_MORE" && styles.activeButton]}><Typography style={[selectedButton==="LEARN_MORE" &&styles.whiteText,styles.medText]}>Learn More</Typography></Pressable>
                            <Pressable onPress={()=> setSelectedButton("ORDER")} style={[styles.button ,selectedButton==="ORDER" && styles.activeButton]}><Typography style={[selectedButton==="ORDER" &&styles.whiteText,styles.medText]}>Order Online</Typography></Pressable>
                            <Pressable onPress={()=> setSelectedButton("SHOP")} style={[styles.button ,selectedButton==="SHOP" && styles.activeButton]}><Typography style={[selectedButton==="SHOP" &&styles.whiteText,styles.medText]}>Buy</Typography></Pressable>
                            <Pressable onPress={()=> setSelectedButton("BOOK")} style={[styles.button ,selectedButton==="BOOK" && styles.activeButton]}><Typography style={[selectedButton==="BOOK" &&styles.whiteText,styles.medText]}>Book</Typography></Pressable>
                            <Pressable onPress={()=> setSelectedButton("SIGN_UP")} style={[styles.button ,selectedButton==="SIGN_UP" && styles.activeButton]}><Typography style={[selectedButton==="SIGN_UP" &&styles.whiteText,styles.medText]}>Sign Up</Typography></Pressable>
                            <Pressable onPress={()=> setSelectedButton("CALL")} style={[styles.button ,selectedButton==="CALL" && styles.activeButton]}><Typography style={[selectedButton==="CALL" &&styles.whiteText,styles.medText]}>Call Now</Typography></Pressable>
                        </View>
                        <View >
                            <Typography style={styles.subText}>Link for your button</Typography>
                            <TextInput
                            textAlignVertical={"top"}
                            placeholderTextColor={colors.common.gray4}
                            placeholder={"Example.com"}
                            style={styles.textInput}
                            value={buttonLink}
                            onChangeText={(val)=>setButtonLink(val)}
                            />
                        </View>
                </View>
                ):(null)
            }
            {postAddText ? (<ErrorMessage style={styles.errorText} message={postAddText}></ErrorMessage>):(null)}
            <Button isLoading={isLoading} onPress={()=>onPostPublish()} label="Publish"></Button>
            <Button
            btnStyle={styles.cancelButton}
            labelStyle={styles.cancelButtonText}
            onPress={()=>navigate(Routes.Posts,{})}
            label={"Cancel"}
          />
        </View>
        <DatePicker
        modal
        date={dateTime}
        onConfirm={handleDateConfirm}
        open={dateModal}
        mode={"date"}
        onCancel={()=>setDateModal(false)}
        >    
        </DatePicker>
        <DatePicker
        modal
        date={dateTime}
        onConfirm={handleTimeConfirm}
        open={timeModal}
        mode={"time"}
        onCancel={()=>setTimeModal(false)}
        >
        </DatePicker>
        <AttachFile
                isVisible={isAttachFileModalVisible}
                onClose={() => setIsAttachFileModalVisible(false)}
                handleChooseDocument={handleChooseDocument}
                handleChoosePhoto={handleChoosePhoto}
                handleTakePhoto={handleTakePhoto}
            />
    </View>
    </ScrollView>
  )
}