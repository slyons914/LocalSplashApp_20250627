import { Pressable, ScrollView, Switch, TextInput, View, useColorScheme } from "react-native"
import { useStyles } from "./styles"
import { Button, Checkbox, ErrorMessage, Icon, Typography } from "@components"
import { Routes, colors } from "@utils/constants"
import { useCallback, useState } from "react"
import { navigate } from "@navigation"
import DatePicker from "react-native-date-picker"
import DocumentPicker from 'react-native-document-picker'
import { pickImageFromGallery, takePhotoWithCamera } from "@utils/helpers"
import { AttachFile } from "@modals"
import { PostsAPI } from "@api"
import { useStore } from "@store"
interface Attachment {
    uri: string;
    name: string;
    type: string;
}
export const EventPost = () => {


  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"
  const { homeStore} = useStore()
  const { locationsItem } = homeStore

  const [addButton , setAddButton] = useState(false)
  const [startDateModal , setStartDateModal] = useState(false)
  const [endDateModal , setEndDateModal] = useState(false)
  const [selectedButton , setSelectedButton] = useState("")
  const [startDate , setStartDate] = useState(new Date ());
  const [endDate , setEndDate] = useState(new Date ());
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isAttachFileModalVisible, setIsAttachFileModalVisible] = useState(false)
  const [postDesc , setPostDesc] = useState("")
  const [isImageSelected , setImageSelected] = useState(false)
  const [isLoading , setIsLoading] = useState(false)
  const [buttonLink, setButtonLink] = useState("")
  const [postAddText , setPostAddText] = useState("")
  const [eventTitle , setEventTitle] = useState("")
  const [descErrorText , setDescErrorText] = useState("")
  const [titleErrorText, setTitleErrorText] = useState("")
  const styles = useStyles()
  const handleStartDateConfirm = (date:any) =>{
    setStartDate(date)
    setStartDateModal(false)
  }
  const handleEndDateConfirm = (date:any) =>{
    setEndDate(date)
    setEndDateModal(false)
  }
  const handleRemoveAttachment = (uri: string) => {
    setAttachments(prevAttachments => prevAttachments.filter(attachment => attachment.uri !== uri));
};
const handleTakePhoto = async () => {
    try {
        const response = await takePhotoWithCamera();
        if (!!response && typeof response !== "string") {
            const newAttachment = {
                uri: response[0]?.uri || "",
                name: response[0]?.fileName || "",
                type: response[0]?.type || "",
            };
            setImageSelected(true)
            setAttachments(prev => [...prev, newAttachment]);
        }
    } catch (error) {
        console.log(error);
    }
    setIsAttachFileModalVisible(false)
};

const handleChoosePhoto = async () => {
    try {
        const response = await pickImageFromGallery();
        if (!!response && typeof response !== "string") {
            const newAttachment = {
                uri: response[0]?.uri || "",
                name: response[0]?.fileName || "",
                type: response[0]?.type || "",
            };
            setImageSelected(true)
            setAttachments(prev => [...prev, newAttachment]);
        }
    } catch (error) {
        console.log(error);
    }
    setIsAttachFileModalVisible(false)
};

const handleChooseDocument = useCallback(async () => {
    try {
        
        const result = await DocumentPicker.pick({
            presentationStyle: 'fullScreen',
        });
        const newAttachment = {
            uri: result[0]?.uri || "",
            name: result[0]?.name || "",
            type: result[0]?.type || "",
        };
        setImageSelected(true)
        setAttachments(prev => [...prev, newAttachment]);
    } catch (err) {
        console.warn(err);
    }
    setIsAttachFileModalVisible(false)
}, []);

const onAddItem = () =>{
    if(attachments.length===0){
        setIsAttachFileModalVisible(true);
        setImageSelected(false)
    }
    
}
const onPostPublish = async () =>{
    if(postDesc === ""){
        setDescErrorText("Description Cannot be empty")
    }
    if(eventTitle === ""){
        setTitleErrorText("Event Title cannot be empty")
    }
    if(descErrorText === "" && titleErrorText === "" && postDesc !== "" && eventTitle !== ""){
        const postData = new FormData()
        setIsLoading(true)
        postData.append('Description' , postDesc)
        postData.append('StartedOn',startDate.toISOString())
        postData.append('EndedOn',endDate.toISOString())
        if(addButton){
            postData.append('ActionTxype',selectedButton)
            postData.append('ActionUrl',buttonLink)
        }
        if(isImageSelected){
            postData.append('Image',{
            uri:attachments[0].uri,
            type:attachments[0].type,
            name:attachments[0].name
        })
        }
        const {data,error} = await PostsAPI.addPost(locationsItem?.id,postData)
        if(data){
            setPostAddText("Post Uploaded Successfully")
        }else{
            setPostAddText("Error in Uploading Post")
        }
        console.log("ADD POST DATA IS: ",data)
        setIsLoading(false)
    }
}

    const setPostTitle = (val:string) =>{
        if(val.length > 1500){
            setTitleErrorText("Max 1500 characters")
        }
        if(val === ""){
            setTitleErrorText("Event Title cannot be empty")
            setEventTitle("")
        }else{
            setTitleErrorText("")
            setEventTitle(val)
        }
    }
    const setPostDescValue = (val:string) =>{
        if(val.length > 1500){
            setDescErrorText("Max 1500 characters")
        }
        else if(val === ""){
            setDescErrorText("Description Cannot be empty")
            setPostDesc("")
        }else{
            setDescErrorText("")
            setPostDesc(val)
        }
    }
  return (
    <ScrollView contentContainerStyle={{flexGrow:1}}>
        <View style={styles.postContainer}>
        <Pressable onPress={onAddItem} style={styles.fileInputView}>
            <View style={styles.inputViewHeader}>
                <Icon name="AttachFileIcon"></Icon>
                <Typography style={styles.orangeText}>Attach File</Typography>
            </View>
                <Typography style={[styles.inputText, !isLightTheme && styles.whiteText]}>File formats: JPG, PNG</Typography>
                <Typography style={[styles.inputText, !isLightTheme && styles.whiteText]}>Minimum dimensions: 480 x 400 pixels.</Typography>
                <Typography style={[styles.inputText, !isLightTheme && styles.whiteText]}>Maximum file size: 5MB</Typography>
                <Typography style={[styles.inputText,styles.rightText, !isLightTheme && styles.whiteText]}>{attachments.length}/1</Typography>
        </Pressable>
        <View>
            {
                attachments.map((item,index)=>(
                    <View key={index} style={styles.attachmentsView}>
                        <Typography style={styles.imageUrl} key={index}>{item.name}</Typography>
                        <Pressable onPress={() => handleRemoveAttachment(item?.uri)}>
                            <Icon name="trash" />
                        </Pressable>
                    </View>
                    
                ))
            }
        </View>
        <View style={styles.post}>
            <View>
                <View style={styles.aiTextView}>
                    <View style={styles.aiTextHeader}>
                        <Typography style={styles.subText}>Event Title*</Typography>
                    </View>
                </View>
                <TextInput
                textAlignVertical={"top"}
                placeholderTextColor={colors.common.gray4}
                placeholder={"Type your title here .."}
                style={styles.textInput}
                value={eventTitle}
                onChangeText={(val)=>setPostTitle(val)}
                />
                <Typography style={styles.lightText}>{eventTitle.length}/1500 characters</Typography>
                {titleErrorText?(<ErrorMessage message={titleErrorText}></ErrorMessage>):(null)}
            </View>
            <View>
                <Typography style={styles.subText}>Description*</Typography>
                <TextInput
                textAlignVertical={"top"}
                placeholderTextColor={colors.common.gray4}
                placeholder={"Type your description here ..."}
                style={[styles.textInput,styles.descTextInput]}
                value={postDesc}
                onChangeText={(val)=>setPostDescValue(val)}
                multiline={true}
                />
                <Typography style={styles.lightText}>{postDesc.length}/1500 characters</Typography>
                {descErrorText?(<ErrorMessage message={descErrorText}></ErrorMessage>):(null)}
            </View>
            <View style={styles.eventDates}>
                <View>
                    <Typography style={styles.subText}>Start Date</Typography>
                    <Pressable onPress={()=>setStartDateModal(true)} style={styles.dateTimeInput}>
                        <Typography>{startDate.toLocaleDateString()}</Typography>
                        <Icon name="CalenderIcon"></Icon>
                    </Pressable>
                </View>
                <View>
                <Typography style={styles.subText}>End Date</Typography>
                    <Pressable onPress={()=>setEndDateModal(true)} style={styles.dateTimeInput}>
                        <Typography>{endDate.toLocaleDateString()}</Typography>
                        <Icon name="CalenderIcon"></Icon>
                    </Pressable>
                </View>
            </View>
            <View style={styles.addButton}>
                <Checkbox value={addButton} onPress={()=>setAddButton(prevState => !prevState)} />
                <Typography>Add Button</Typography>
            </View>
             {
                addButton ? (
                    <View style={styles.addButtonView}>
                        <Typography style={styles.subText}>Button</Typography>
                        <View style={styles.buttonView}>
                            <Pressable onPress={()=> setSelectedButton("LEARN_MORE")} style={[styles.button ,selectedButton==="LEARN_MORE" && styles.activeButton]}><Typography style={[selectedButton==="LEARN_MORE" &&styles.whiteText,styles.medText]}>Learn More</Typography></Pressable>
                            <Pressable onPress={()=> setSelectedButton("ORDER")} style={[styles.button ,selectedButton==="ORDER" && styles.activeButton]}><Typography style={[selectedButton==="ORDER" &&styles.whiteText,styles.medText]}>Order Online</Typography></Pressable>
                            <Pressable onPress={()=> setSelectedButton("SHOP")} style={[styles.button ,selectedButton==="SHOP" && styles.activeButton]}><Typography style={[selectedButton==="SHOP" &&styles.whiteText,styles.medText]}>Buy</Typography></Pressable>
                            <Pressable onPress={()=> setSelectedButton("BOOK")} style={[styles.button ,selectedButton==="BOOK" && styles.activeButton]}><Typography style={[selectedButton==="BOOK" &&styles.whiteText,styles.medText]}>Book</Typography></Pressable>
                            <Pressable onPress={()=> setSelectedButton("SIGN_UP")} style={[styles.button ,selectedButton==="SIGN_UP" && styles.activeButton]}><Typography style={[selectedButton==="SIGN_UP" &&styles.whiteText,styles.medText]}>Sign Up</Typography></Pressable>
                            <Pressable onPress={()=> setSelectedButton("CALL")} style={[styles.button ,selectedButton==="CALL" && styles.activeButton]}><Typography style={[selectedButton==="CALL" &&styles.whiteText,styles.medText]}>Call Now</Typography></Pressable>
                        </View>
                        <View >
                            <Typography style={styles.subText}>Link for your button</Typography>
                            <TextInput
                            textAlignVertical={"top"}
                            placeholderTextColor={colors.common.gray4}
                            placeholder={"Example.com"}
                            style={styles.textInput}
                            value={buttonLink}
                            onChangeText={(val)=>setButtonLink(val)}
                            />
                        </View>
                </View>
                ):(null)
            }
            {postAddText ? (<ErrorMessage style={styles.errorText} message={postAddText}></ErrorMessage>):(null)}
            <Button isLoading={isLoading} onPress={onPostPublish} label="Publish"></Button>
            <Button
            btnStyle={styles.cancelButton}
            labelStyle={styles.cancelButtonText}
            onPress={()=>navigate(Routes.Posts,{})}
            label={"Cancel"}
          />
        </View>
        <DatePicker
        modal
        date={startDate}
        onConfirm={handleStartDateConfirm}
        open={startDateModal}
        mode={"date"}
        onCancel={()=>setStartDateModal(false)}
        >    
        </DatePicker>
        <DatePicker
        modal
        date={endDate}
        onConfirm={handleEndDateConfirm}
        open={endDateModal}
        mode={"date"}
        onCancel={()=>setEndDateModal(false)}
        >
        </DatePicker>
        <AttachFile
                isVisible={isAttachFileModalVisible}
                onClose={() => setIsAttachFileModalVisible(false)}
                handleChooseDocument={handleChooseDocument}
                handleChoosePhoto={handleChoosePhoto}
                handleTakePhoto={handleTakePhoto}
            />
    </View>
    </ScrollView>
  )
}