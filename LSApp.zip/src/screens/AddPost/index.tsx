import { TouchableOpacity, View, useColorScheme } from "react-native"

import { observer } from "mobx-react-lite"

import { Header, Locations, Typography } from "@components"
import { Routes } from "@utils/constants"
import { useStyles } from "./styles"
import { useNavigation } from "@react-navigation/native"
import { useState } from "react"
import { NewPost } from "./NewPost"
import { OfferPost } from "./OfferPost"
import { EventPost } from "./EventPost"
import { useStore } from "@store"


const Component: React.FC<ScreenProps<Routes.AddPost>> = () => {
  const styles = useStyles()
  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"
  const { goBack } = useNavigation()
  const [postType , setPostType] = useState(1)

  const { languageStore } = useStore()
  const { languageVariables } = languageStore

  return (
    <View style={{flex:1}}>
        <Header onLeftPress={goBack} />
        <View style={styles.container}>
            <View style={styles.titleContainer}>
                <Typography style={styles.title}>New Post</Typography>
            </View>
            <View style={styles.postTextView}>
                <Typography style={styles.postText}>{languageVariables? languageVariables["App.post.wid4"] : ''}</Typography>
            </View>
            <View style={styles.postShift}>
                <TouchableOpacity onPress={()=>setPostType(1)}><Typography style={postType !== 1 && styles.postShiftText}>What's New</Typography></TouchableOpacity>
                <TouchableOpacity onPress={()=>setPostType(2)}><Typography style={postType !== 2 && styles.postShiftText}>Offer</Typography></TouchableOpacity>
                <TouchableOpacity onPress={()=>setPostType(3)}><Typography style={postType !== 3 && styles.postShiftText}>Event</Typography></TouchableOpacity>
            </View>
            <View style={{flex:1}}>
                {
                    postType === 1 ? (<NewPost />) :
                    postType === 2 ? (<OfferPost/>) :
                    (<EventPost />)
                }
            </View>
        </View>
    </View>
  )
}

export const AddPost = observer(Component)
