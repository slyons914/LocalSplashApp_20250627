import { withStyles } from "@utils/hocs"
import { styles } from "react-native-gifted-charts/src/LineChart/styles"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingBottom: insets.bottom,
    paddingTop: 8,
    paddingHorizontal: 24,
    gap: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: "600",
    paddingTop: 0.5,
  },
  heading: {
    fontSize: 20,
    fontWeight: "500",
  },
  titleContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  postTextView:{
    padding:10,
    backgroundColor:colors.lightOrange,
    borderRadius:16 
  },
  postText:{
    color:colors.red,
    fontSize:12
  },
  postShift:{
    flexDirection:"row",
    justifyContent:"space-between",
    paddingHorizontal:16
  },
  postShiftText:{
    color:colors.greyDarkMode
  },
  postContainer:{
    gap: 12,
  },
  fileInputView:{
    alignItems:"center",
    padding:12, 
    borderWidth:1,
    borderColor:colors.orangePrimary,
    borderStyle:'dashed',
    borderRadius:8,
  },
  orangeText:{
    color:colors.orangePrimary,
    fontSize:16,
    fontWeight:"500"
  },
  inputText:{
    textAlign:"center",
    fontSize:12,
    color:colors.textColor
  },
  inputViewHeader:{
    flexDirection:"row",
    gap:10,
    marginBottom:6
  },
  rightText:{
    alignSelf:"flex-end"
  },
  textInput: {
    borderWidth: 1,
    borderColor: colors.gray6,
    borderRadius: 8,
    paddingHorizontal: 24,
    paddingVertical: 16,
    color: colors.text,
  },
  aiTextView:{
    flexDirection:"row",
    justifyContent:"space-between"
  },
  aiTextHeader:{
    flexDirection:"row",
    gap:8
  },
  subText:{
    color:colors.subText
  },
  orangeColor:{
    color:colors.orangePrimary
  },
  post:{
    gap:16
  },
  descTextInput:{
    height:180
  },
  lightText:{
    color:colors.gray4
  },
  fbToggleView:{
    flexDirection:"row",
    justifyContent:"space-between",
    alignItems:"center",
    marginVertical:12
  },
  medText:{
    fontSize:16
  },
  dateTimeInput:{
    flexDirection:"row",
    justifyContent:"space-between",
    paddingVertical:16,
    paddingHorizontal:24,
    borderWidth:1,
    borderColor:colors.gray6,
    borderRadius:6,
    gap:16
  },
  dateTimeInputView:{
    gap:4
  },
  addButton:{
    flexDirection:"row",
    gap:8
  },
  buttonView:{
    flexDirection:"row",
    flexWrap:"wrap",
    gap:8
  },
  button:{
    paddingVertical:6,
    paddingHorizontal:16,
    borderWidth:1,
    borderRadius:8,
    borderColor:colors.gray6,
  },
  activeButton:{
    backgroundColor:colors.blue
  },
  whiteText:{
    color:colors.white
  },
  cancelButton: {
    width: 342,
    backgroundColor: colors.white,
    color: colors.orangePrimary,
  },
  cancelButtonText: {
    color: colors.orangePrimary,
  },
  attachmentsView:{
    flexDirection:"row",
    justifyContent:"space-between",
    gap:12
  },
  eventDates:{
    flexDirection:"row",
    justifyContent:"space-between"
  },
  addButtonView:{
    gap:12
  },
  errorText:{
    textAlign:"center"
  },
  imageUrl:{
    width:"50%"
  }
}))