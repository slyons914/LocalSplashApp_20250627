import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(() => ({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  text: {
    fontSize: 16,
  },
}))
