import React, { useRef } from "react"

import { Platform, UIManager, LayoutAnimation, View } from "react-native"

import { FlashList } from "@shopify/flash-list"

import { Typography } from "@components"
import { CallLog } from "@models/leads"

import { Call } from "./Call"
import { Placeholder } from "./Placeholder"
import { useProvider, withProvider } from "./provider"
import { useStyles } from "./styles"
import { useNavigation } from "@react-navigation/native"
import { Routes, Stacks } from "@utils/constants"

type ListItem = string | CallLog

if (Platform.OS === "android") {
  UIManager.setLayoutAnimationEnabledExperimental(true)
}

const Screen = () => {
  const styles = useStyles()

  const { isLoading, expandedCall, stickyIndecies, leads, toggleCall, onEndReached, logError, onRefresh, refreshing } = useProvider()

  const listRef = useRef<FlashList<ListItem>>(null)
  const navigation=useNavigation()

  const onItemPress = (call: CallLog) => {
    toggleCall(call)
    listRef.current?.prepareForLayoutAnimationRender()
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut)
  }


  const handleCancelPress = () => {
    if (expandedCall) {
      toggleCall(expandedCall)
      listRef.current?.prepareForLayoutAnimationRender()
      LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut)
    } else {
      navigation.navigate(Stacks.Home, { screen: Routes.Home })
    }
  }

  const keyExtractor = (item: ListItem, index: number) => {
    if (typeof item === "string") {
      return index.toString()
    }
    return item.uniqueId.toString()
  }

  const renderItem = ({ item, index }: { item: ListItem; index: number }) => {
    const isHeader = typeof item === "string"

    if (isHeader) {
      return (
        <Typography type={"subtext"} style={styles.section}>
          {item}
        </Typography>
      )
    }

    const withIndent = typeof leads[index + 1] === "string"

    return (
      <Call
        call={item}
        onToggle={() => onItemPress(item)}
        expanded={expandedCall?.uniqueId === item.uniqueId}
        style={[styles.call, withIndent && styles.last]}
      />
    )
  }

  const isPlaceholderVisible = !leads.length || isLoading

  
  return (
    <React.Fragment>
    <View
    style={styles.cancelContainer}
    >

      <Typography type={"title"} style={styles.cancelText}
      onPress={handleCancelPress} >
        Cancel
      </Typography>
    </View>
    <View style={styles.container}>
      <Typography type={"title"} style={styles.title}
      >
        Call Log
      </Typography>
      { logError ? (<View>
                    <Typography style={[styles.errorText, styles.largeText]}>{logError}</Typography>
                    <Typography style={styles.errorText}>Pull down to refresh</Typography>
                </View>) : (null)}
      <FlashList
        refreshing={refreshing}
        onRefresh={onRefresh}
        ref={listRef}
        data={logError? []:leads}
        estimatedItemSize={2000}
        renderItem={renderItem}
        keyExtractor={keyExtractor}
        extraData={{ expandedCall, styles }}
        stickyHeaderIndices={stickyIndecies}
        scrollEnabled={!isPlaceholderVisible}
        removeClippedSubviews={true}
        ListEmptyComponent={<Placeholder isLoading={false} />}
        overrideProps={{
          contentContainerStyle: isPlaceholderVisible && styles.list,
        }}
        onEndReached={onEndReached}
        onEndReachedThreshold={1}
      />
    </View>
    </React.Fragment>
  )
}

export const CallLogScreen = withProvider(Screen)
