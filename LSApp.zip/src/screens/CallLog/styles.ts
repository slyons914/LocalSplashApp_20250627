import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  mainContainer: {
    flex: 1,
    backgroundColor: colors.background,
  },
  cancelContainer: {
    paddingTop: insets.top || 16,
    backgroundColor: colors.background,
  },
  container: {
    flex: 1,
    gap: 16,
    paddingHorizontal: 24,
    backgroundColor: colors.background,
  },
  title: {
    fontSize: 24,
    fontWeight: "600",
  },
  cancelText: {
    color: colors.orangePrimary,
    alignSelf: "flex-start",
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  list: {
    flex: 1,
    justifyContent: "center",
  },
  section: {
    fontSize: 16,
    fontWeight: "400",
    paddingBottom: 8,
    backgroundColor: colors.background,
  },
  call: {
    paddingVertical: 12,
  },
  first: {
    paddingTop: 16,
  },
  last: {
    marginBottom: 28,
  },
  errorText:{
    textAlign:"center",
    color: colors.red,
    fontWeight:"500"
  },
  largeText:{
    fontSize:18
  }
}))
