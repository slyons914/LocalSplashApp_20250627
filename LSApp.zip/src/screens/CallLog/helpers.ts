import { CallLeadLog, CallLog, LeadList } from "@models/leads"
import { FormatHelper } from "@utils/helpers"

const today = new Date()
today.setHours(0, 0, 0)

const yesterday = new Date(today)
yesterday.setDate(today.getDate() - 1)


export const groupLeadsToCallSections = (leads: LeadList<CallLog> | null) => {
  let prevTitle = ""
  if (!leads?.items?.length) return []

  const callMap = new Map<number, Map<number, CallLog>>()

  leads.items.forEach((log) => {
    if (!log.dateCreated) return

    const timeStamp = new Date(log.dateCreated).setHours(0, 0, 0)

    const dayCalls = callMap.get(timeStamp) ?? new Map()
    const call = dayCalls.get(log.uniqueId)

    const leadName = FormatHelper.normalizeSpaces(log.srcCallerIdName)
    const newDayCalls = call ? dayCalls : dayCalls.set(log.uniqueId, { ...log, leadName })

    callMap.set(timeStamp, newDayCalls)
  })

  return [...callMap.entries()].flatMap(([timeStamp, map]) => {
    const date = new Date(timeStamp)

    const isToday = date === today
    const isYesterday = date === yesterday
    let title = FormatHelper.formatDate(date, { year: true })

    if (isToday) {
      title = "Today"
    } else if (isYesterday) {
      title = `${title}, Yesterday`
    }
    if ( prevTitle === title){
        return [...map.values()]
    } else {
        prevTitle = title
        return [title, ...map.values()]
    }
  })
}
