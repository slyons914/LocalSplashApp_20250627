import {
  FC,
  PropsWithChildren,
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react"

import { LeadsAPI } from "@api"
import { CallLog } from "@models/leads"
import { usePlayer } from "@providers"

import { groupLeadsToCallSections } from "./helpers"
import { useStore } from "@store"

type ListItem = string | CallLog

interface CallLogContext {
  isLoading: boolean
  leads: Array<ListItem>
  expandedCall: CallLog | null
  stickyIndecies: Array<number>
  toggleCall: (item: CallLog) => void
  onEndReached: () =>void
  logError: string | null
  onRefresh: () =>void
  refreshing: boolean
  updateLeadField: (leadId: number, field: 'isSpam' | 'isBlocked', value: boolean) => void
}

const initials: CallLogContext = {
  isLoading: false,
  leads: [],
  expandedCall: null,
  stickyIndecies: [],
  toggleCall: Promise.resolve,
  onEndReached: Promise.resolve,
  onRefresh:Promise.resolve,
  updateLeadField: Promise.resolve,
  logError : null,
  refreshing : false
}

const CallLogContext = createContext(initials)

const CallLogProvider = ({ children }: PropsWithChildren) => {
  const [isLoading, setIsLoading] = useState(false)
  const [leads, setLeads] = useState<Array<ListItem>>([])
  const [expandedCall, setExpandedCall] = useState<CallLog | null>(null)
  const [rowNumber, setRowNumber] = useState(20)
  const [logError, setLogError] = useState("")
  const [totalCount, setTotalCount] = useState<number>(0)
  const [refreshing, setRefreshing] = useState(false)

  const { homeStore } = useStore()
  const { locationsItem } = homeStore

  const { load, remove } = usePlayer()

  useEffect(() => {
    setIsLoading(true)
    setRefreshing(true)
    setLogError("")
    LeadsAPI.getCallLogs(locationsItem?.id,20,0)
      .then(({ data, error }) => { 
        if(error){
            setLogError(error)
        }else{
            setLeads(groupLeadsToCallSections(data))
            setTotalCount(data.totalCount)
        }
        }
    )
      .finally(() =>{setIsLoading(false), setRefreshing(false)})
  }, [])

  const toggleCall = (item: CallLog) => {
    const isSamePress = expandedCall?.uniqueId === item.uniqueId
    remove()

    if (isSamePress) {
      setExpandedCall(null)
    } else {
      //load(item)
      setExpandedCall(item)
    }
  }

//   const updateLead = async (item: CallLeadLog, field: keyof CallLeadLog) => {
//     let fieldValue;
//     if(item[field]){
//         fieldValue = false
//     }else{
//         fieldValue = true
//     }
//     console.log("field value is: ",fieldValue)
//     await LeadsAPI.updateLead(item.leadId, { [field]: fieldValue })

//     const newLeads = leads.map((lead) => {
//       if (typeof lead !== "string" && lead.leadId === item.leadId) {
//         return { ...lead, [field]: fieldValue }
//       }

//       return lead
//     })

//     setLeads(newLeads)
//   }

  const stickyIndecies = useMemo(() => {
    return leads.reduce<Array<number>>((acc, item, index) => {
      if (typeof item === "string") return [...acc, index]
      return acc
    }, [])
  }, [])

  const onEndReached = () =>{
    if (!isLoading && rowNumber < totalCount){
        LeadsAPI.getCallLogs(locationsItem?.id,20,rowNumber)
      .then(({ data }) => setLeads([...leads,...groupLeadsToCallSections(data)]))
      .finally(() => setRowNumber(rowNumber+20))
    }
  }
  const onRefresh = () =>{
    setRefreshing(true)
    setIsLoading(true)
    setLogError("")
    setRowNumber(20)
    LeadsAPI.getCallLogs(locationsItem?.id,20,0)
      .then(({ data, error }) => { 
        if(error){
            setLogError(error)
        }else{
            setLeads(groupLeadsToCallSections(data))
            setTotalCount(data.totalCount)
        }
        }
    )
      .finally(() => {setIsLoading(false), setRefreshing(false)})
  }

  const updateLeadField = (leadId: number, field: 'isSpam' | 'isBlocked', val: boolean) => {
    const updatedLeads = leads.map((lead) => {
      if (typeof lead !== 'string' && lead.leadId === leadId) {
        return { ...lead, [field]: val }
      }
      return lead
    })
    
    setLeads(updatedLeads)
}

  const value = { isLoading, leads, expandedCall, stickyIndecies, toggleCall, onEndReached, logError, onRefresh, refreshing, updateLeadField}

  return <CallLogContext.Provider value={value}>{children}</CallLogContext.Provider>
}

export const useProvider = () => useContext(CallLogContext)

export const withProvider = (Screen: FC) => {
  return () => {
    return (
      <CallLogProvider>
        <Screen />
      </CallLogProvider>
    )
  }
}
