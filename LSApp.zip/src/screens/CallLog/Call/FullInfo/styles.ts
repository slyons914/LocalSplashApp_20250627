import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme }) => ({
  block: {
    padding: 12,
    borderColor: `${colors.blueDark}${isDarkTheme ? "" : 20}`,
    backgroundColor: colors.backgroundSecondary,
  },
  header: {
    borderWidth: 1,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
  dots: {
    marginLeft: "auto",
  },
  body: {
    gap: 16,
    padding: 24,
    paddingTop: 16,
    borderLeftWidth: 1,
    borderRightWidth: 1,
  },
  text: {
    fontSize: 16,
    fontWeight: "400",
  },
  footer: {
    gap: 24,
    padding: 24,
    paddingTop: 16,
    borderWidth: 1,
    borderBottomLeftRadius: 12,
    borderBottomRightRadius: 12,
  },
  action: {
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
  },
}))
