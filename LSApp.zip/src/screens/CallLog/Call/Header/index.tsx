import { PropsWithChildren } from "react"

import { StyleProp, TouchableOpacity, View, ViewStyle } from "react-native"

import { Icon, Typography } from "@components"
import {  CallLog } from "@models/leads"
import { FormatHelper } from "@utils/helpers"

import { useStyles } from "./styles"
import { CallIcon } from "../Icon"

interface Props {
  title: string
  filledIcon?: boolean
  call: CallLog
  onPress: () => void
  style?: StyleProp<ViewStyle>
}

export const CallHeader = ({
  call,
  filledIcon,
  title,
  children,
  onPress,
  style,
}: PropsWithChildren<Props>) => {
  const styles = useStyles()

  const date = FormatHelper.formatDate(call.dateCreated, { time: true, year: true })

  const noAnswer = call.callAnswered === null

  const getCallStatus = () => {
    if (call.isSpam && call.isBlocked) {
        return <Typography style={styles.spam}>Spam <Typography style={styles.blocked}>Blocked</Typography></Typography>
      }
    if (call.isSpam) {
      return <Typography style={styles.spam}>Spam</Typography>
    }

    if (call.isBlocked) {
      return <Typography style={styles.blocked}>Blocked</Typography>
    }
  }

  return (
    <TouchableOpacity onPress={onPress} style={[styles.container, style]}>
      <View style={styles.left}>
        <CallIcon filled={filledIcon} call={call} />
        <View style={styles.info}>
          <View style={styles.contactNumberView}>
            <Typography style={[styles.title, noAnswer && styles.spam]}>{title}</Typography>
            {
                call?.callDestinationType == "forward" &&
                <Icon name='callForwarding'></Icon>
            }
            {
                call?.callDestinationType == "voicemail" &&
                <Icon name='voicemail'></Icon>
            }
          </View>  
          <View style={styles.subtitle}>
            {getCallStatus()}
            <Typography type={"subtext"} style={styles.date}>
              {date}
            </Typography>
          </View>
        </View>
      </View>
      {children}
    </TouchableOpacity>
  )
}
