import { TouchableOpacity, View, ViewStyle } from "react-native"

import Clipboard from "@react-native-clipboard/clipboard"
import Toast from 'react-native-simple-toast';
import Modal from "react-native-modal"

import { Icon, Typography } from "@components"
import {CallLog } from "@models/leads"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"
import { LeadsAPI } from "@api";

import { useProvider } from "../../../CallLog/provider"

interface Props {
  offset: number
  call: CallLog
  visible: boolean
  onClose: () => void
}

export const CallMenu = ({ call, visible, offset, onClose }: Props) => {
  const styles = useStyles()
  const { text, background } = useColors()

  const { updateLeadField } = useProvider()

  const onCopyNumber = () => {
    const phoneNumber = call.isDirectionInbound ? call.src.toString() : call.dst.toString()
    phoneNumber && Clipboard.setString(phoneNumber)
    Toast.showWithGravity(
        'Phone Number Copied',
        Toast.SHORT,
        Toast.BOTTOM,
      );
  }

  const onBlockPress = async () => {
    try {
        const response = await LeadsAPI.setLeadStatus(call.profileId, call.leadId, {isBlocked:!call.isBlocked})
        updateLeadField(call?.leadId, "isBlocked", !call.isBlocked)
    } catch {

    }
  }

  const onSpamPress = async () => {
    try {
        const response = await LeadsAPI.setLeadStatus(call.profileId, call.leadId, {isSpam:!call.isSpam})
        updateLeadField(call?.leadId, "isSpam", !call.isSpam)
    } catch {
        
    }
  }


  const style: ViewStyle = { top: offset }

  return (
    <Modal
      isVisible={visible}
      animationIn={"fadeIn"}
      animationOut={"fadeOut"}
      onBackdropPress={onClose}
      backdropColor={"transparent"}
    >
      <View style={[styles.modal, style]}>
        <TouchableOpacity onPress={onCopyNumber} style={styles.item}>
          <Typography>Copy Number</Typography>
          <Icon name={"copy"} stroke={text} fill={background} />
        </TouchableOpacity>
        <View style={styles.separator} />
        <TouchableOpacity
          disabled={false}
          onPress={onBlockPress}
          style={[styles.item]}
        >
          <Typography>{!!call.isBlocked ? "Unblock Number" : "Block Number"}</Typography>
          <Icon name={"block"} stroke={text} fill={background} />
        </TouchableOpacity>
        <View style={styles.separator} />
        <TouchableOpacity
          disabled={false}
          onPress={onSpamPress}
          style={[styles.item]}
        >
          <Typography>{!!call.isSpam? "Unmark as spam" : "Mark as spam"}</Typography>
          <Icon name={"info"} stroke={text} fill={background} />
        </TouchableOpacity>
      </View>
    </Modal>
  )
}
