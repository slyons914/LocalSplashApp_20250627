import { StyleProp, View, ViewStyle } from "react-native"

import { useNavigation } from "@react-navigation/native"

import { CallLog } from "@models/leads"
import { Routes, Stacks } from "@utils/constants"

import { FullInfo } from "./FullInfo"
import { ShortInfo } from "./ShortInfo"

interface Props {
  call: CallLog
  expanded: boolean
  onToggle: () => void
  style?: StyleProp<ViewStyle>
}

export const Call = ({ call, expanded, onToggle, style }: Props) => {
  const { navigate } = useNavigation()

  const phoneNumber = call.isDirectionInbound ? call.src.toString() : call.dst.toString()

  const onCallPress = () => {
    navigate(Routes.DialPad, { phoneNumber })
  }

  const onMessagePress = () => {
    navigate(Stacks.Messages, { screen: Routes.MessageDetail, params:{
        number:phoneNumber,
        leadId: call?.leadId
    } })
  }

  const props = { call, onCallPress, onMessagePress }

  return (
    <View style={style}>
      {expanded ? (
        <FullInfo onHeadPress={onToggle} {...props} />
      ) : (
        <ShortInfo onPress={onToggle} {...props} />
      )}
    </View>
  )
}
