import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(() => ({
  content: {
    flexDirection: "row",
    alignItems: "center",
    gap: 28,
  },
}))
