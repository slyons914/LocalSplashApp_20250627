import { StyleProp, View, ViewStyle } from "react-native"

import { Icon } from "@components"
import { CallLog } from "@models/leads"
import { colors } from "@utils/constants"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"

interface Props {
  filled?: boolean
  call: CallLog
  style?: StyleProp<ViewStyle>
}

export const CallIcon = ({ filled, call, style }: Props) => {
  const { dialStatus, isDirectionInbound } = call

  const styles = useStyles()

  const { background, blocked } = useColors()

  const getColor = () => {
    if (dialStatus === null || dialStatus === "NO ANSWER") {
      return colors.common.red
    }

    // if (isBlocked) {
    //   return blocked
    // }

    if (isDirectionInbound) {
      return colors.common.green
    }

    if (!isDirectionInbound) {
      return colors.common.blue
    }
  }

  const getIcon = () => {
    // if (isSpam) {
    //   const stroke = filled ? background : colors.common.red
    //   return <Icon name={"spamCall"} stroke={stroke} />
    // }

    // if (isBlocked) {
    //   const stroke = filled ? background : blocked
    //   return <Icon name={"blockedCall"} stroke={stroke} />
    // }

    if (!dialStatus || dialStatus === "NO ANSWER") {
      const stroke = filled ? background : colors.common.red
      return <Icon name={"missedCall"} stroke={stroke} />
    }

    if (isDirectionInbound) {
      const stroke = filled ? background : colors.common.green
      return <Icon name={"incomingCall"} stroke={stroke} />
    }

    if (!isDirectionInbound) {
      const stroke = filled ? background : colors.common.blue
      return <Icon name={"outcomingCall"} stroke={stroke} />
    }

    return null
  }

  const getStyle = (): ViewStyle => {
    const backgroundColor = filled ? getColor() : background

    return { backgroundColor, borderColor: getColor() }
  }

  return <View style={[styles.container, getStyle(), style]}>{getIcon()}</View>
}
