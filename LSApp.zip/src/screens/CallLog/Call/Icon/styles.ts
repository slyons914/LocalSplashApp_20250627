import { withStyles } from "@utils/hocs"

const SIZE = 50

export const useStyles = withStyles(() => ({
  container: {
    width: SIZE,
    height: SIZE,
    borderWidth: 1,
    borderRadius: SIZE,
    alignItems: "center",
    justifyContent: "center",
  },
}))
