import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme, insets }) => ({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: insets.top + 48,
    paddingBottom: insets.bottom || 16,
    backgroundColor: colors.background,
    alignItems: "center",
    justifyContent: "space-between",
  },
  content: {
    alignItems: "center",
  },
  title: {
    fontSize: 24,
    fontWeight: "600",
    marginTop: 8,
  },
  text: {
    fontSize: 16,
    marginVertical: 24,
  },
  codeFieldRoot: {
    marginTop: 20,
    gap: 8,
  },
  rightPart: {
    marginLeft: 40,
  },
  cellRoot: {
    width: 40,
    height: 60,
    justifyContent: "center",
    alignItems: "center",
    borderBottomColor: isDarkTheme ? colors.whiteSecondary : colors.black,
    borderBottomWidth: 2,
  },
  cellText: {
    color: colors.blue,
    fontSize: 36,
    textAlign: "center",
  },
  focusCell: {
    borderBottomColor: isDarkTheme ? colors.whiteSecondary : colors.black,
    borderBottomWidth: 2,
  },
  resend: {
    color: colors.orangePrimary,
    fontSize: 16,
    fontWeight: "500",
    marginBottom: 40,
  },
  error: {
    color: colors.red,
    fontSize: 16,
    marginTop: 12,
  },
  spinner: {
    marginTop: 40,
  },
}))
