import { useEffect, useState } from "react"

import { ActivityIndicator, KeyboardAvoidingView, Platform, Text, View } from "react-native"
import messaging from '@react-native-firebase/messaging';
import Clipboard from '@react-native-clipboard/clipboard';
import Toast from 'react-native-simple-toast';
import jwt_decode from "jwt-decode"
import { DecodedToken } from "@models"
import { StackActions } from "@react-navigation/native";


import {
  CodeField,
  Cursor,
  RenderCellOptions,
  useBlurOnFulfill,
  useClearByFocusCell,
} from "react-native-confirmation-code-field"

import { AuthAPI } from "@api"
import { Timer, Typography } from "@components"
import { useStore } from "@store"
import { colors, Routes , Stacks } from "@utils/constants"
import { StorageHelper } from "@utils/helpers"

import { useStyles } from "./styles"
import {observer} from "mobx-react-lite";
import { useTranslation } from "@providers";

const CELL_COUNT = 6

 const Component  = ({ navigation, route }: ScreenProps<Routes.Code>) => {
  const styles = useStyles()
  const { phoneNumber, phoneRawNumber } = route.params
  const { navigate } = navigation

  const [code, setCode] = useState("")
  const [errorText, setErrorText] = useState("")
  const [showTimer, setShowTimer] = useState(true)
  const [loading, setLoading] = useState(false)
  const [timer, setTimer] = useState<number | null>(null)
  const [copiedText, setCopiedText] = useState('');

  const { authStore, languageStore } = useStore()
  const { authState, setAccessToken , setDeviceToken, deviceToken } = authStore
  const { getLanguageVariables } = languageStore

  const { selectedLanguage } = useTranslation()
  const ref = useBlurOnFulfill({ value: code, cellCount: CELL_COUNT })
  const [props, getCellOnLayoutHandler] = useClearByFocusCell({
    value: code,
    setValue: setCode,
  })

  useEffect(() => {
    setTimer(Date.now())
  }, [])

  useEffect(() => {
    if (code.length === 6) {
      codeEntered()
    }
  }, [code.length])

  useEffect(()=>{
    async function getDeviceToken(){
      const token = await messaging().getToken();
      setDeviceToken(token)
      console.log("Firebase Token : ", token)
    }

    getDeviceToken()

    },[])

  const onResend = async () => {
    setTimer(Date.now())
    setShowTimer (true)
    setCode ("")
    setErrorText ("")
    await AuthAPI.sendMessage (phoneRawNumber)
  }

  const codeEntered = async () => {
    setLoading(true)
    setErrorText("")
    const { data, error } = await AuthAPI.Login(code, "mobile-client-id-dev", authState,"deviceToken")
    if (data) {
      setAccessToken(data.accessToken)
      StorageHelper.set<string>("accessToken", data.accessToken)
      StorageHelper.set<string>("refreshToken", data.refreshToken)
      const decoded: DecodedToken = jwt_decode(data.accessToken)
      StorageHelper.set<number>("tokenExpiry",decoded.exp*1000) 
      if(decoded.t_and_c_accepted === "true"){
        getLanguageVariables(selectedLanguage)
        navigation.dispatch(            
          StackActions.replace(Stacks.Home, {
            screen: Routes.Home
          })
        );
      }
      else{
        navigate(Routes.Terms)
      }
      
    }
    if (error) setErrorText(error)
    setLoading(false)
  }

  const renderCell = ({ index, symbol, isFocused }: RenderCellOptions) => {
    return (
      <View
        onLayout={getCellOnLayoutHandler(index)}
        key={index}
        style={[
          styles.cellRoot,
          isFocused && styles.focusCell,
          index === CELL_COUNT / 2 && styles.rightPart,
        ]}
      >
        <Typography style={styles.cellText}>{symbol || (isFocused ? <Cursor /> : null)}</Typography>
      </View>
    )
  }

  const copyToClipboard = () => {
    Clipboard.setString(deviceToken);

    Toast.showWithGravity(
      'Copied',
      Toast.SHORT,
      Toast.BOTTOM,
    );
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={styles.container}
    >
      <View style={styles.content}>
        <Typography type={"title"} style={styles.title}>
          Verification code
        </Typography>
        <Typography type={"subtext"} style={styles.text}>
          Enter the code we sent to +1 {phoneNumber}
        </Typography>
        <CodeField
          ref={ref}
          {...props}
          value={code}
          onChangeText={setCode}
          cellCount={CELL_COUNT}
          rootStyle={styles.codeFieldRoot}
          keyboardType="number-pad"
          textContentType="oneTimeCode"
          renderCell={renderCell}
        />
        {loading && (
          <ActivityIndicator
            style={styles.spinner}
            size="large"
            color={colors.common.orangePrimary}
          />
        )}
        {errorText && <Typography style={styles.error}>{errorText}</Typography>}
      </View>
      <View style={styles.content}>
      {showTimer ? (
        <Timer timer={timer} onTimerEnd={() => setShowTimer(false)} duration={60} />
      ) : (
        <Typography onPress={onResend} style={[styles.resend]}>
          Click to Resend Code
        </Typography>
      )}
      <Typography onPress={copyToClipboard} style={[styles.resend,{marginBottom:0}]}>
          Copy Token
        </Typography>
      </View>
      
    </KeyboardAvoidingView>
  )
}
export const CodeScreen = observer(Component)
