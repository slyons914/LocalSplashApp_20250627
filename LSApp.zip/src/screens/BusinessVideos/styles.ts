import { Dimensions } from "react-native";
import { withStyles } from "@utils/hocs";

const windowWidth = Dimensions.get("window").width;
const GAP = 8;
const PADDING = 16;
const NUM_COLUMNS = 3;

// Calculate width: (screenWidth - totalHorizontalPadding - totalGaps) / numColumns
const ITEM_WIDTH = (windowWidth - PADDING * 2 - GAP * (NUM_COLUMNS - 1)) / NUM_COLUMNS;

export const useStyles = withStyles(({ insets, colors }) => ({
  container: {
    flex: 1,
    gap: GAP,
    paddingTop: insets.top,
    backgroundColor: colors.background,
    paddingHorizontal: PADDING,
  },
  header: {
    paddingHorizontal: 16,
  },
  itemContainer: {
    paddingVertical: 8,
  },
  emptyView: {
    height: 120,
    width: ITEM_WIDTH,
  },
  insideEmptyView: {
    height: "93%",
    width: "94%",
    borderRadius: 8,
    borderStyle: "dashed",
    borderColor: colors.orangePrimary,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
  },
  videosView: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: GAP,
    rowGap: GAP, // RN >= 0.71 or custom spacing
  },
  scrollContent: {
    paddingBottom: insets.bottom + 100,
  },
  videoContainer: {
    height: 120,
    width: ITEM_WIDTH,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 8, // optional placeholder
    overflow: 'hidden'
  },
  videoWrapper: {
    position: 'relative',
    width: '100%',
    height: '100%',
  },
  durationOverlay: {
    position: 'absolute',
    bottom: 6,
    right: 6,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 12,
  },
  durationText: {
    color: '#fff',
    fontSize: 12,
  },
  buttonView: {
    position: 'absolute', 
    alignSelf:"center", 
    bottom:24
  },
  selectionCircle: {
    position: 'absolute',
    bottom: 8,
    right: 8,
    padding: 4,
  },
  circleView: {
    width:24,
    height:24,
    borderRadius:12,
    borderWidth:1,
    borderColor:colors.white
  },
  selectedView: {
    backgroundColor: colors.white,
    borderRadius:12
  },
}));
