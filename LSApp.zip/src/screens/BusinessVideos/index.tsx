import { useState } from "react"
import { ActivityIndicator, Pressable, ScrollView, View } from "react-native"
import { Button, Icon, SimpleHeader, Typography } from "@components"
import { colors, Routes } from "@utils/constants"
import { useStyles } from "./styles"
import { useStore } from "@store"
import Video from "react-native-video"
import { FormatHelper } from "@utils/helpers"
import { AddVideoModal, BusinessVideoDetailModal } from "@modals"
import { BusinessInfoAPI } from "@api"
import { observer } from "mobx-react-lite"
import { showToast } from "@utils/helpers/common"
import { validateMediaFile } from "@utils/helpers/imagePicker"

const Component = ({ navigation }: ScreenProps<Routes.BusinessVideos>) => {
  const { navigate } = navigation
  const styles = useStyles()
  const [isBusinessVideoLoading, setIsBusinessVideoLoading] = useState(false)
  const [videoDurations, setVideoDurations] = useState<{ [key: number]: number }>({});
  const [selectedVideos, setSelectedVideos] = useState<Set<number>>(new Set());
  const [rightText, setRightText] = useState('Select')
  const [isAddVideoModalVisible, setIsAddVideoModalVisible] = useState(false)
  const [isVideoDetailModalVisible, setIsVideoDetailModalVisible] = useState(false)
  const [currentVideo, setCurrentVideo] = useState("")
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0)
  const [isVideoDeleting, setIsVideoDeleting] = useState(false)

  const { businessInfoStore, homeStore } = useStore()
  const { businessVideos, getBusinessVideos } = businessInfoStore
  const { locationsItem } = homeStore


  const onBackPress = () => {
    navigation.goBack()
  }

  const onRightPress = () => {
    if(rightText === 'Select')
        setRightText('Cancel')
    else 
        setRightText('Select')
  }

  const onImageSelect = async (uri: string, filename:string, type:string, width: number | undefined, height: number | undefined) => {
    const data = new FormData ()
    data.append("Files" , {
        uri:uri,
        type:type,
        name:filename
    })
    if(!locationsItem?.id)
        return;
    const validationResponse = await validateMediaFile(uri, type, false, 0, 0, 500, width ?? 0, height ?? 0)
     if(!validationResponse.valid) {
        showToast(validationResponse?.error ?? '')
        return;
    }
    setIsBusinessVideoLoading(true)
    await BusinessInfoAPI.addBussinessVideos(locationsItem?.id, data)
    await getBusinessVideos(locationsItem?.id)
    setIsBusinessVideoLoading(false)
  }

  const onVideoPress = (index: number) => {
    const items = businessVideos?.items ?? []
    if(rightText === 'Select') {
        if(!items) return;
        setCurrentVideoIndex(index)
        setCurrentVideo(items[index].mediaUrl ?? "")
        setIsVideoDetailModalVisible(true)
    } else {
        setSelectedVideos((prevSelections) => {
        const newSelections = new Set(prevSelections);
        if (newSelections.has(index)) {
            newSelections.delete(index); 
        } else {
            newSelections.add(index);
        }
        return newSelections;
        });
    }
  }

  const onDeletePress = async () => {
    const items = businessVideos?.items ?? [];
    const selectedUrls = Array.from(selectedVideos).map((index) => items[index]?.mediaUrl);
    if(!locationsItem?.id) return
    setIsVideoDeleting(true)
    try {
        await BusinessInfoAPI.deleteBusinesVideos(locationsItem?.id, selectedUrls)
    } catch {
        console.log("Error deleting videos")
    } finally {
        await getBusinessVideos(locationsItem?.id)
        setSelectedVideos(new Set());
        setRightText('Select');
        setIsVideoDeleting(false)
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <SimpleHeader title="Business Videos" onLeftPress={onBackPress} rightText={rightText} isRightVisible={true} onRightPress={onRightPress}/>
      </View>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        style={styles.itemContainer}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.videosView}>
          <Pressable onPress={() => setIsAddVideoModalVisible(true)} style={styles.emptyView}>
            <View style={styles.insideEmptyView}>
              {!isBusinessVideoLoading ? (
                <Icon name="attachImageBusinessInfo" />
              ) : (
                <ActivityIndicator size={"small"} color={colors.common.orangePrimary} />
              )}
            </View>
          </Pressable>
          {
            businessVideos?.items?.map((item, index) => (
                <Pressable key={index} onPress={() => onVideoPress(index)} style={styles.videoContainer}>
                <View style={styles.videoWrapper}>
                    <Video
                    source={{ uri: item?.mediaUrl }}
                    style={styles.videoContainer}
                    resizeMode={"stretch"}
                    paused={true}
                    onLoad={(data) =>
                        setVideoDurations((prev) => ({
                        ...prev,
                        [index]: data.duration,
                        }))
                    }
                    />
                    {videoDurations[index] != null && rightText !== 'Cancel' && (
                    <View style={styles.durationOverlay}>
                        <Typography style={styles.durationText}>
                        {FormatHelper.formatDuration(videoDurations[index])}
                        </Typography>
                    </View>
                    )}
                    {rightText === 'Cancel' && (
                    <Pressable
                      style={[styles.selectionCircle , selectedVideos.has(index) && styles.selectedView]}
                      onPress={() => onVideoPress(index)}
                    >
                    {
                        selectedVideos.has(index) ? ( <Icon
                        name={"tick"}
                        /> 
                        ) : (
                        <View style={styles.circleView}></View>
                    )}
                    </Pressable>
                    )}
                </View>
                </Pressable>
            ))}
        </View>
      </ScrollView>
      <View style={styles.buttonView}>
        {
            rightText === 'Cancel' && selectedVideos.size > 0 && (
            <Button btnStyle={{alignSelf:"center"}} label={`${selectedVideos.size} video selected`} right="trashDark" onPress={onDeletePress} isLoading={isVideoDeleting}></Button>
        )}
      </View>
      <AddVideoModal 
        onImageSelect={onImageSelect} 
        isVisible={isAddVideoModalVisible} 
        onClose={() => setIsAddVideoModalVisible(false)}
      />
      <BusinessVideoDetailModal 
        isVisible={isVideoDetailModalVisible} 
        onClose={() => setIsVideoDetailModalVisible(false)}  
        videoList={businessVideos?.items}
        videoIndex={currentVideoIndex}
        setCurrentVideo={setCurrentVideo}
        setCurrentVideoIndex={setCurrentVideoIndex}
        videoUrl={currentVideo}
      />
    </View>
  )
}

export const BusinessVideos = observer(Component)
