import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  pieChartLegend: {
    justifyContent: "center",
    alignItems: "center",
  },
  legend: {
    flexDirection: "row",
    alignItems: "center",
    columnGap: 10,
  },
  circle: {
    height: 10,
    width: 10,
    borderRadius: 50,
  },
  legendTitle: {
    color: colors.black,
    fontSize: 12,
    fontWeight: "400",
  },
  legendPercentage: {
    fontSize: 16,
    fontWeight: "500",
  },
}))
