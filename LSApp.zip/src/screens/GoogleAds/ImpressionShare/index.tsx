import { Dimensions, View } from "react-native"
import { useStyles } from "./styles"
import { HeaderWithTooltip, Typography } from "@components"
import { PieChart } from "react-native-chart-kit"
import { colors } from "@utils/constants"
import { useEffect, useState } from "react"
import { useStore } from "@store"

const chartConfig = {
  color: (opacity = 1) => `rgba(26, 255, 146, ${opacity})`,
}

export const ImpressionShare = () => {
  const styles = useStyles()
  const screenWidth = Dimensions.get("window").width
  const [toolTip, setToolTip] = useState(false)
  const [pieChartData, setPieChartData] = useState([
    { name: "", percentage: 0, color: "" },
    { name: "", percentage: 0, color: "" },
    { name: "", percentage: 0, color: "" },
  ]);

  const { languageStore, googleAdsStore } = useStore()
  const { languageVariables } = languageStore
  const { googleAdsImpressionShare } = googleAdsStore

  useEffect(() => {
    if(googleAdsImpressionShare && googleAdsImpressionShare?.items) {
        if (googleAdsImpressionShare?.items?.length > 0) {
            const data = googleAdsImpressionShare?.items[0]
            if(data) {
                const pieData = [
                    {
                      name: "Lost Impression Share Rank",
                      percentage: parseFloat((data?.searchRankLostImpressionShare ?? 0 * 100).toFixed(2)), // Convert to percentage
                      color: colors.common.blueBright,
                    },
                    {
                      name: "Lost Impression Share Budget",
                      percentage: parseFloat((data?.searchBudgetLostImpressionShare ?? 0 * 100).toFixed(2)),
                      color: colors.common.skyBlue,
                    },
                    {
                      name: "Impression Share",
                      percentage: parseFloat((data.searchImpressionShare ?? 0 * 100).toFixed(2)),
                      color: colors.common.gray7,
                    },
                  ];
                 setPieChartData(pieData);
            }
    }
    
    }
  }, [googleAdsImpressionShare]);

  return (
    <View key={"impressionShare"}>
       <HeaderWithTooltip title="Impression Share" toolTip={toolTip} setToolTip={setToolTip} toolTipText={languageVariables? languageVariables["App.adw.wid7"] : ""}/>
       {
          googleAdsImpressionShare?.items ? (
            <View>
                <PieChart
                data={pieChartData}
                width={screenWidth - 40}
                height={220}
                chartConfig={chartConfig}
                accessor={"percentage"}
                backgroundColor={"transparent"}
                paddingLeft={"15"}
                absolute={false}
                hasLegend={false}
                center={[75, 5]}
                />
            <View style={styles.pieChartLegend}>
                {pieChartData?.map((legend, index) => (
                <View style={styles.legend} key={index}>
                    <View style={[styles.circle, { backgroundColor: legend?.color }]} />
                    <Typography style={styles.legendTitle}>
                    {` ${legend?.name}`}{" "}
                    <Typography style={styles.legendPercentage}>{`${(legend?.percentage * 100).toFixed(1)}%`}</Typography>
                    </Typography>
                </View>
                ))}
            </View>
        </View>
          ) : (
            <View>
                <Typography>No data found</Typography>
            </View>
          )
       }
    </View>
  )
}
