import { HeaderWithTooltip, Typography } from "@components"
import { Dimensions, FlatList, ScrollView, Text, View } from "react-native"
import { useStyles } from "./styles"
import { useEffect, useState } from "react"
import { colors } from "@utils/constants"
import { useStore } from "@store"

const screenWidth = Dimensions.get("window").width

function splitIntoSubarrays(array:any, chunkSize:number) {
    if (!array) return []
    const result = []
    for (let i = 0; i < array.length; i += chunkSize) {
      result.push(array.slice(i, i + chunkSize))
    }
    return result
}

export const Keywords = () => {
  const styles = useStyles()
  const [activePage, setActivePage] = useState(0)
  const [toolTip, setToolTip] = useState(false)
  const [keywords, setKeywords] = useState<any>()

  const { languageStore, googleAdsStore } = useStore()
  const { languageVariables } = languageStore
  const { googleAdsKeywordsReport } = googleAdsStore

    const handleScroll = (event: any) => {
        const pageIndex = Math.floor(event.nativeEvent.contentOffset.x / (screenWidth - 100))
        setActivePage(pageIndex)
    }

    useEffect(() => {
      const subArrays = splitIntoSubarrays(googleAdsKeywordsReport?.items, 8)
      setKeywords(subArrays)
    },[googleAdsKeywordsReport])

  return (
    <View key={"keywords"}>
      <HeaderWithTooltip title={`Keywords (${googleAdsKeywordsReport?.items?.length ?? 0})`} toolTip={toolTip} setToolTip={setToolTip} toolTipText={languageVariables? languageVariables["App.adw.wid3"] : ""}/>
      <View style={styles.mainContainer}>
        <View style={styles.header}>
          <Typography style={styles.headerText}>SEARCH KEYWORDS</Typography>
          <Typography style={styles.headerText}>IMPRESSIONS</Typography>
        </View>
        <ScrollView
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onScroll={handleScroll}
          scrollEventThrottle={16}
          style={styles.contentContainer}
        >
          {keywords?.map((keywords:any, pageIndex:number) => (
            <FlatList
              key={pageIndex}
              data={keywords}
              keyExtractor={(item, index) => index.toString()}
              renderItem={({ item }) => (
                <View style={styles.keywordContainer}>
                  <Typography style={styles.keyword}>{item.keywordText}</Typography>
                  <Typography style={styles.impressions}>{item.impressions}</Typography>
                </View>
              )}
              style={styles.flatList}
              showsHorizontalScrollIndicator={false}
              pagingEnabled={true}
            />
          ))}
        </ScrollView>
        <View style={styles.bulletsContainer}>
          {keywords?.map((_: any, index:number) => (
            <View
              key={index}
              style={[
                styles.bullet,
                {
                  backgroundColor: index === activePage ? colors.common.dark : colors.common.gray6,
                },
              ]}
            />
          ))}
        </View>
      </View>
    </View>
  )
}
