import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, width }) => ({
  mainContainer: {
    marginVertical: 10,
  },
  map: {
    height: 400,
  },
  stats: {
    marginVertical: 10,
  },
  statsText: {
    fontSize: 16,
  },
  statsRegion: {
    fontSize: 16,
    fontWeight: "500",
    color: colors.dark,
  },
  statsDetails: {
    color: colors.greyText,
    fontSize: 16,
  },
  linearGradient: {
    borderRadius: 5,
    height: 10,
    width: width - 120,
    marginHorizontal: 10,
  },
  contentContainer: {
    marginVertical: 10,
  },
  impressionCount: {
    color: colors.dark,
    fontWeight: "500",
    fontSize: 16,
  },
  marker: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 30,
    height: 30,
  },
  dot: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: colors.blueBright,
  },
  webView: {
    width:"200%",
    height:250
  }
}))
