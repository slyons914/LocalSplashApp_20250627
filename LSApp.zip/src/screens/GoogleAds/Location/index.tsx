import { View } from "react-native"
import { useStyles } from "./styles"
import { HeaderWithTooltip, Typography } from "@components"
import LinearGradient from "react-native-linear-gradient"
import { useState } from "react"
import { useStore } from "@store"
import WebView from "react-native-webview"

interface Props {
}

export const Location = ({} : Props) => {
  const styles = useStyles()
  const [toolTip, setToolTip] = useState(false)
  const [selectedLocation, setSelectedLocation] = useState<any>(null);

  const { languageStore, googleAdsStore } = useStore()
  const { languageVariables } = languageStore
  const { googleAdsGeoPerformanceReport  } = googleAdsStore

  const adMetrics = googleAdsGeoPerformanceReport?.items
  const impressions = adMetrics?.map((item: any) => item.impressions) || [];
  const maxImpressions = Math.max(...impressions);
  const minImpressions = Math.min(...impressions);
  const maxImpressionsIndex = impressions.indexOf(maxImpressions); 
  const itemWithMaxImpressions = adMetrics?.[maxImpressionsIndex];

  const dataTable = adMetrics?.map(item => {
    if (!item.city) {
      return null; 
    }
    const cityState = `${item.city}`; 
    return [cityState, item.impressions, item.clicks];
  }).filter(item => item !== null); 

  dataTable?.unshift(['City', 'Impressions', 'Clicks']);

  const htmlContent = `<html>
  <head>
    <script type='text/javascript' src='https://www.gstatic.com/charts/loader.js'></script>
    <script type='text/javascript'>
     google.charts.load('current', {
       'packages': ['geochart'],
       'mapsApiKey': 'AIzaSyBvouXAka2mbBgl19Tdelw8zfVS_qefcAA'
     });
     google.charts.setOnLoadCallback(drawMarkersMap);

      function drawMarkersMap() {
        // Ensure dataTable is properly formatted here
        var data = google.visualization.arrayToDataTable(${JSON.stringify(dataTable)});

        var options = {
          region: 'US',
          displayMode: 'markers',
          colorAxis: {
            colors: ['#A3CAF6', '#1F78FF'],
            legend: {position: 'none'} 
          }
        };

        var chart = new google.visualization.GeoChart(document.getElementById('chart_div'));
        google.visualization.events.addListener(chart, 'select', function(event) {
          var selectedItem = chart.getSelection()[0];
          if (selectedItem) {
            // Get the region and clicks from the dataTable (adjust based on your data structure)
            var region = data.getValue(selectedItem.row, 0);  // Assuming region is in the first column
            var impressions = data.getValue(selectedItem.row, 1);  // Assuming clicks are in the second column
            var clicks = data.getValue(selectedItem.row, 2); 
            // Send the region and clicks data to React Native
            window.ReactNativeWebView.postMessage(JSON.stringify({
              region: region,
              clicks: clicks,
              impressions: impressions,
            }));
          }
        });
        chart.draw(data, options);
      };
    </script>
    <style>
      body, html {
        width: 50vw;  
        overflow-x: auto;   
        overflow-y: hidden; /* Disable vertical scrolling */ 
      }

      #chart_div {
      }
    </style>
  </head>
  <body>
    <div id="chart_div"></div>
  </body>
</html>
`;

const handleMarkerClick = (event: any) => {
    const data = JSON.parse(event.nativeEvent.data);
    const clickedData = adMetrics?.find((item: any) => item.city == data.region && item.clicks == data.clicks && item.impressions == data.impressions);
    setSelectedLocation(clickedData)
  };

  const displayLocation = selectedLocation || itemWithMaxImpressions; 

  return (
    <View key={"location"} style={styles.mainContainer}>
      <HeaderWithTooltip title="Stats By Location" toolTip={toolTip} setToolTip={setToolTip} toolTipText={languageVariables? languageVariables["App.adw.wid3"] : ""}/>
      {
         dataTable? (
            <View>
                <WebView 
                originWhitelist={['*']}
                source={{ html: htmlContent }} 
                style={styles.webView}
                scrollEnabled
                showsHorizontalScrollIndicator={false}
                onMessage={handleMarkerClick}
                javaScriptEnabled={true}
                onLoad={() => console.log('WebView Loaded')}
                onError={(err) => console.log('WebView Error', err)}
                />
            <View style={styles.contentContainer}>
                <View style={{ flexDirection: "row", alignItems: "center" }}>
                <Typography style={styles.impressionCount}>{minImpressions}</Typography>
                <LinearGradient
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    colors={["#A3CAF6", "#1F78FF"]}
                    style={styles.linearGradient}
                />
                <Typography style={styles.impressionCount}>{maxImpressions}</Typography>
                </View>
                <View style={styles.stats}>
                <Typography style={styles.statsRegion}>{displayLocation?.city}, {displayLocation?.state}</Typography>
                <Typography style={styles.statsDetails}>Impressions: {displayLocation?.impressions}</Typography>
                <Typography style={styles.statsDetails}>Clicks: {displayLocation?.clicks}</Typography>
                </View>
            </View>
            </View>
         ) : (
            <Typography>No data found</Typography>
         )
      }
    </View>
  )
}
