import { Dimensions, FlatList, ScrollView, View } from "react-native"
import { useStyles } from "./styles"
import { useEffect, useState } from "react"
import { HeaderWithTooltip, Typography } from "@components"
import { colors } from "@utils/constants"
import { useStore } from "@store"

const screenWidth = Dimensions.get("window").width

function splitIntoSubarrays(array:any, chunkSize:number) {
    if (!array) return []
    const result = []
    for (let i = 0; i < array.length; i += chunkSize) {
      result.push(array.slice(i, i + chunkSize))
    }
    return result
}
interface Props {
}
export const City = ({ } : Props) => {
  const styles = useStyles()
  const [activePage, setActivePage] = useState(0)
  const [toolTip, setToolTip] = useState(false)
  const [cityPages, setCityPages] = useState<any>()

  const { languageStore, googleAdsStore } = useStore()
  const { languageVariables } = languageStore
  const { googleAdsGeoPerformanceReport } = googleAdsStore

  const handleScroll = (event: any) => {
    const pageIndex = Math.floor(event.nativeEvent.contentOffset.x / (screenWidth - 100))
    setActivePage(pageIndex)
  }

  useEffect(() => {
    const subArrays = splitIntoSubarrays(googleAdsGeoPerformanceReport?.items, 8)
    setCityPages(subArrays)
  },[googleAdsGeoPerformanceReport])

  return (
    <View key={"city"}>
      <HeaderWithTooltip title={`City/Zip Code (${googleAdsGeoPerformanceReport?.items?.length ?? 0})`} toolTip={toolTip} setToolTip={setToolTip} toolTipText={languageVariables? languageVariables["App.adw.wid3"] : ""}/>  
      <View style={styles.mainContainer}>
        <View style={styles.header}>
          <Typography style={styles.headerText}>SEARCH KEYWORDS</Typography>
          <Typography style={styles.headerText}>IMPRESSIONS</Typography>
        </View>
        <ScrollView
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onScroll={handleScroll}
          scrollEventThrottle={16}
          style={styles.contentContainer}
        >
          {cityPages?.map((keywords:any, pageIndex:any) => (
            <FlatList
              key={pageIndex}
              data={keywords}
              keyExtractor={(item, index) => index.toString()}
              renderItem={({ item }) => (
                <View style={styles.keywordContainer}>
                  <Typography style={styles.keyword}>{item?.city}, {item?.state}</Typography>
                  <Typography style={styles.impressions}>{item?.impressions}</Typography>
                </View>
              )}
              style={styles.flatList}
              showsHorizontalScrollIndicator={false}
              pagingEnabled={true}
            />
          ))}
        </ScrollView>
        <View style={styles.bulletsContainer}>
          {cityPages?.map((data:any, index:number) => (
            <View
              key={index}
              style={[
                styles.bullet,
                {
                  backgroundColor: index === activePage ? colors.common.dark : colors.common.gray6,
                },
              ]}
            />
          ))}
        </View>
      </View>
    </View>
  )
}
