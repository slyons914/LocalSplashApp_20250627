import { colors as commonColors } from "@utils/constants"
import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, width }) => ({
  mainContainer: {
    padding: 20,
    borderColor: commonColors.light.lighBlack,
    borderRadius: 16,
    borderWidth: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 10,
  },
  flatList: {
    width: width - 85,
    paddingHorizontal: 10,
    gap:8
  },
  keywordContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent:'center',
    gap:8
  },
  keyword: {
    fontSize: 16,
    color: colors.black,
    flex: 1,
  },
  impressions: {
    fontSize: 16,
    fontWeight: "500",
    color: colors.black,
  },
  bulletsContainer: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 10,
  },
  bullet: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginHorizontal: 5,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  headerText: {
    color: colors.gray4,
    fontWeight: "500",
    fontSize: 16,
  },
  contentContainer:{
    width:width-85
  }
}))
