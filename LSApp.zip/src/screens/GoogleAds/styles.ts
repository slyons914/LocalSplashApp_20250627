import { withStyles } from '@utils/hocs';
export const useStyles = withStyles(({ colors, insets }) => ({
    mainContainer:{
        flex: 1,
        backgroundColor:colors.background,
        padding:20,
        gap:20,
    },
    title: {
        fontSize: 24,
        fontWeight: "600",
        paddingTop: 0.5,
      },
      titleContainer: {
        flexDirection: "row",
        justifyContent: "space-between",
      },
      contentContainer:{},
      sectionHeader:{
        fontSize:20,
        fontWeight:"500",
        color:colors.text,
      },
      indicatorContainer: {
        justifyContent: "center",
        flex: 1,
      },
      spinner: {
        alignSelf: "center",
      },
}))