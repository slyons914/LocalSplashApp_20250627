import { Routes, colors } from "@utils/constants"
import { observer } from "mobx-react-lite"
import { ActivityIndicator, FlatList, Text, View, ViewToken } from "react-native"
import { useStyles } from "./styles"
import { Locations, Tabs, Typography } from "@components"
import { FilterButton } from "../../components/FilterButton"
import { useCallback, useEffect, useRef, useState } from "react"
import { Stats } from "./Stats"
import { ImpressionShare } from "./ImpressionShare"
import { City } from "./City"
import { Keywords } from "./Keywords"
import { Location } from "./Location"
import { DateFilter } from "@models/index"
import moment from "moment"
import { useStore } from "@store"

// Define the tab labels
const TABS: string[] = ["Stats", "Impression Share", "Keywords", "City/Zip Code", "Location"]

// Define the sections as functions returning JSX elements

const Component: React.FC<ScreenProps<Routes.Google_Ads>> = () => {
  const styles = useStyles()
  const flatRef = useRef<FlatList>(null)

  const [activeTab, setActiveTab] = useState(0)
  const [scrollHandlerDisabled, setScrollHandlerDisabled] = useState(false)
  const [loading, setLoading] = useState(false)
  const date = new Date()
  const currentDate = moment(date).format("YYYY-MM-DD")
  const [dateFilter, setDateFilter] = useState<DateFilter>({
    fromDate: "1970-01-01",
    toDate: currentDate,
  })

  const { googleAdsStore, homeStore } = useStore()
  const { getGoogleAdsClickAndImpressions, getGoogleAdsGeoperformanceReport, getGoogleAdsKeywordsReport, getGoogleAdsDevieBreakdown, getGoogleAdsImpressionShare, getGoogleAdsClicksAndImpressionGraphData } = googleAdsStore
  const { locationsItem } = homeStore

  const onTabPress = (index: number) => {
    setScrollHandlerDisabled(true)
    flatRef.current?.scrollToIndex({ index, animated: true })

    setTimeout(() => {
      setScrollHandlerDisabled(false)
    }, 400)
  }

  const renderSection = ({
    item,
    index,
  }: {
    item: (key: number) => React.JSX.Element
    index: number
  }) => item(index)

  const handleScroll = useCallback(
    (info: { viewableItems: Array<ViewToken>; changed: Array<ViewToken> }) => {
      info.viewableItems[0] &&
        info.viewableItems[0].index !== null &&
        setActiveTab(info.viewableItems[0].index)
    },
    [],
  )

  const getGoogleAdsData = async () =>{
    setLoading(true)
    try{
        if(locationsItem?.id) {
            await getGoogleAdsGeoperformanceReport(locationsItem?.id, dateFilter)
            await getGoogleAdsKeywordsReport(locationsItem?.id, dateFilter)
            await getGoogleAdsDevieBreakdown(locationsItem?.id, dateFilter)
            await getGoogleAdsImpressionShare(locationsItem?.id, dateFilter)
            await getGoogleAdsClickAndImpressions(locationsItem?.id, dateFilter)
            await getGoogleAdsClicksAndImpressionGraphData(locationsItem?.id, dateFilter)
            setLoading(false)
        }
    }catch{
        setLoading(false)
    }
  }
  useEffect(()=>{
    getGoogleAdsData()
  },[dateFilter, locationsItem])
  
  const sections = [
    (key: number) => <Stats selectedDate={dateFilter} key={key} />,
    (key: number) => <ImpressionShare key={key} />,
    (key: number) => <Keywords key={key} />,
    (key: number) => <City key={key} />,
    (key: number) => <Location key={key} />,
  ]
  return (
    <View style={styles.mainContainer}>
      <View style={styles.titleContainer}>
        <Typography style={styles.title}>Google Ads</Typography>
        <FilterButton
        setDateFilter={setDateFilter}
        />
      </View>
      <Locations />
      <View>
        <Tabs
          tabs={TABS}
          onTabPress={onTabPress}
          activeTab={activeTab}
          allTabsDisabled={scrollHandlerDisabled}
          setActiveTab={setActiveTab}
        />
      </View>
      { loading ? (
            <View style={styles.indicatorContainer}>
            <ActivityIndicator
            color={colors.common.orangePrimary}
            style={styles.spinner}
            size={"large"}
            />
        </View> ) : (
            <FlatList
            ref={flatRef}
            data={sections}
            renderItem={renderSection}
            onViewableItemsChanged={handleScroll}
            viewabilityConfig={{
              itemVisiblePercentThreshold: 30,
            }}
            scrollEnabled={true}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          />
        )}
    </View>
  )
}
export const GoogleAdsScreen = observer(Component)
