import { Pressable, View } from "react-native"

import { CustomTooltip, Icon, Typography } from "@components"

import { useStyles } from "./styles"
import { colors } from "@utils/constants"

interface Props {
  title: string
  count: number
  icon: IconName
  topIcon: IconName
  iconFill: string
  onPress?: () => void
  isLightTheme:boolean
  isActive?: boolean
  tooltip:boolean,
  setTooltip:(val:boolean) => void
  tooltipText:string
}

export const StatsCard = ({
  title,
  count,
  icon,
  iconFill,
  onPress,
  isActive,
  topIcon,
  isLightTheme,
  tooltip,
  setTooltip,
  tooltipText,
}: Props) => {
  const styles = useStyles()
  const lowerFontSize = count > 999
  let numberCount = count?.toLocaleString()

  return (
    <Pressable
      onPress={onPress}
      style={[styles.analyticsItem, isActive && styles.activeAnalyticsItem]}
    >
      <View style={styles.analyticsItemTitleContainer}>
        <View style={styles.titleContainer}>
          <Typography
            style={[styles.analyticsItemTitle, isActive && styles.activeAnalyticsItemTitle]}
            type="default"
          >
            {title}
          </Typography>
        </View>
        <Pressable onPress={()=>setTooltip(true)}>
        <CustomTooltip isVisible={tooltip} onClose={()=>setTooltip(false)} location={"top"} Text={tooltipText}>
            <Icon name={topIcon} />
        </CustomTooltip>
        </Pressable>
      </View>
      <View style={styles.countContainer}>
        <Typography
          style={[
            styles.count,
            isActive && styles.activeCount,
            lowerFontSize && styles.lowerFontSize,
          ]}
          type="default"
        >
          {numberCount}
        </Typography>
        <Icon name={icon} fill={iconFill} />
      </View>
    </Pressable>
  )
}
