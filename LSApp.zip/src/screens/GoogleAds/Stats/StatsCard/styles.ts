import { Platform } from "react-native"

import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme, width, height }) => ({
  analyticsItem: {
    width: width * 0.42,
    height: height * 0.29,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 12,
    padding: 15,
  },
  titleContainer: {
    width: "90%",
    minHeight: 50,
  },
  activeAnalyticsItem: {
    backgroundColor: colors.blueBright,
    // backgroundColor: isDarkTheme ? colors.white : colors.blueBright,
  },
  analyticsItemTitleContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 20,
  },
  analyticsItemTitle: {
    fontSize: 16,
  },
  activeAnalyticsItemTitle: {
    color: colors.white,
  },
  countContainer: {
    flexDirection: "row",
    gap: 8,
    alignItems: "flex-end",
    padding: 8,
  },
  count: {
    fontSize: 56,
    fontWeight: "200",
    marginBottom: Platform.OS === "ios" ? -23 : -36,
  },
  lowerFontSize: {
    fontSize: 36,
    fontWeight: "200",
    marginBottom: Platform.OS === "ios" ? -23 : -24,
  },
  activeCount: {
    color: colors.white,
  },
}))
