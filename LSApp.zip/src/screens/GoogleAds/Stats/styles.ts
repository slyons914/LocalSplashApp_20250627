import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  mainContainer: {
    flex: 1,
    backgroundColor: colors.background,
    paddingBottom: insets.bottom,
    gap: 12,
  },
  title: {
    fontWeight: "500",
    fontSize: 20,
  },
  statsContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  impressionContent: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 10,
  },
  impressionTitle: {
    fontWeight: "500",
    fontSize: 20,
  },
  graphPointers: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  circle: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.blueBright,
  },
  graphContainer: {},
}))
