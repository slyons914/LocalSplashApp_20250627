import { View, useColorScheme } from "react-native";
import { Typography } from "@components";
import { colors } from "@utils/constants";
import { useStyles } from "./styles";
import { DevicePercantages } from "..";
import { CircularProgress } from "react-native-circular-progress";

interface Props {
  devicePercentages?: DevicePercantages;
}

export const CircularProgressChart = ({ devicePercentages }: Props) => {
  const styles = useStyles();
  const systemColorScheme = useColorScheme();
  const isLightTheme = systemColorScheme === "light";

  if (!devicePercentages || Object.keys(devicePercentages).length === 0) {
    return <View><Typography>No data available</Typography></View>;
  }
  return (
    <View style={styles.mainContainer}>
      <View style={styles.contentContainer}>
        {Object?.keys(devicePercentages)?.map((device) => {
          let percentage = devicePercentages[device as keyof DevicePercantages];
          percentage = parseFloat(percentage.toFixed(2));
          return (
            <View key={device}>
              <Typography style={styles.title}>{device}</Typography>
              <CircularProgress
                    fill={percentage}
                    backgroundColor={colors.common.superLightBlue}
                    width={3.5}
                    size={60}
                    tintColor={colors.common.blueBright}
                >
                    {
                        (fill: number) => (
                            <Typography style={styles.text}>{fill}%</Typography>
                        )
                    }
            </CircularProgress>
            </View>
          );
        })}
      </View>
    </View>
  );
};
