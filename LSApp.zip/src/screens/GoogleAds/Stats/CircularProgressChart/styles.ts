import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme }) => ({
  mainContainer: {
    padding: 10,
  },
  contentContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
  text: {
    color: isDarkTheme ? colors.white : colors.black,
  },
  title: { textAlign: "center", fontSize: 12, marginBottom: 10 },
}))
