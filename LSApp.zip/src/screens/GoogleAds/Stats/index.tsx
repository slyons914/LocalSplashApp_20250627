import React, { useEffect, useState } from "react"
import { Dimensions, ScrollView, View, useColorScheme } from "react-native"
import { useStyles } from "./styles"
import { HeaderWithTooltip, Typography } from "@components"
import { colors } from "@utils/constants"
import { StatsCard } from "./StatsCard"
import { LineChart } from "react-native-chart-kit"
import { CircularProgressChart } from "./CircularProgressChart"
import { useStore } from "@store"
import { LineChartData } from "react-native-chart-kit/dist/line-chart/LineChart"
import { DateFilter } from "@models/index"

export interface DevicePercantages {
    DESKTOP: number
    MOBILE: number
    TABLET: number
}

interface AggregatedData {
    impressions: number;
    clicks: number;
  }
  
interface Props {
    selectedDate: DateFilter
}

export const Stats = ({ selectedDate }:Props) => {
  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"
  const reviewIcon = isLightTheme ? "helpSquare" : "helpSquareBlack"
  const reviewIconDark = isLightTheme ? "helpSquareBlack" : "helpSquare"
  const styles = useStyles()
  const [clickTooltip, setClickTooltip] = useState(false)
  const [impressionTooltip, setImpressionTooltip] = useState(false)
  const [clickOverTimeToolTip, setClickOverTimeToolTip] = useState(false)
  const [deviceBreakDownTooltip, setDeviceBreakDownTooltip] = useState(false)
  const [devicePercentages, setDevicePercentages] = useState<DevicePercantages>()
  const [chartData, setChartData] = useState<LineChartData>()
  const { languageStore, googleAdsStore } = useStore()
  const { languageVariables } = languageStore
  const { googleAdsClicksAndImpressions, googleAdsDeviceBreakdown, googleAdsClickImpressionGraphData } = googleAdsStore


  function calculateDeviceImpressions() {
    const deviceTotals = {
      TABLET: 0,
      MOBILE: 0,
      DESKTOP: 0
    };
  
    googleAdsDeviceBreakdown?.items?.forEach(entry => {
      const device = entry.device;
      const impressions = entry.impressions || 0; 
      
      if (device && deviceTotals.hasOwnProperty(device)) {
        deviceTotals[device as keyof typeof deviceTotals] += impressions;
      }
    });
  
    const totalImpressions = deviceTotals.TABLET + deviceTotals.MOBILE + deviceTotals.DESKTOP;

    const devicePercentages = {
      TABLET: totalImpressions === 0 ? 0 : (deviceTotals.TABLET / totalImpressions) * 100,
      MOBILE: totalImpressions === 0 ? 0 : (deviceTotals.MOBILE / totalImpressions) * 100,
      DESKTOP: totalImpressions === 0 ? 0 : (deviceTotals.DESKTOP / totalImpressions) * 100
    };
    setDevicePercentages(devicePercentages)
  
    return {
      deviceTotals,
      devicePercentages
    };
  }

  const makelineChartData = () => {
    const fromDate = new Date (selectedDate.fromDate)
    const toDate = new Date (selectedDate.toDate)
    const monthDifference = (toDate.getFullYear() - fromDate.getFullYear()) * 12 + toDate.getMonth() - fromDate.getMonth();
    const dayDifference = Math.floor((toDate.getTime() - fromDate.getTime()) / (1000 * 3600 * 24));

    let labelType: 'daily' | '6 months' | 'year';

    if (dayDifference <= 60) {
        labelType = 'daily'; 
    } else if (monthDifference > 6) {
        labelType = 'year';  
    } else {
        labelType = '6 months'; 
    }
    const aggregatedData: { [monthYear: string]: AggregatedData } = (googleAdsClickImpressionGraphData?.items ?? []).reduce((acc, entry) => {
        const date = new Date(entry.date ?? '');
    
        let key: string = '';
    
        if (labelType === 'daily') {
          if (date < fromDate || date > toDate) return acc;
    
          key = `${date.getDate()} ${date.toLocaleString('default', { month: 'short' })} ${date.getFullYear()}`;
        
        } else if (labelType === '6 months') {
          if (date < fromDate || date > toDate) return acc;
    
          key = `${date.toLocaleString('default', { month: 'short' })} ${date.getFullYear()}`;
        
        } else if (labelType === 'year') {
          if (date < fromDate || date > toDate) return acc;
    
          key = date.getFullYear().toString();
        }
    
        if (!acc[key]) {
          acc[key] = { impressions: 0, clicks: 0 };
        }
    
        acc[key].impressions += entry.impressions ?? 0;
        acc[key].clicks += entry.clicks ?? 0;
    
        return acc;
    }, {} as { [key: string]: AggregatedData });
  
    const labels = Object.keys(aggregatedData);
    const impressionsData = labels.map(monthYear => aggregatedData[monthYear].impressions);
    const clicksData = labels.map(monthYear => aggregatedData[monthYear].clicks);
  
    const chartData: LineChartData = {
      labels,
      datasets: [
        {
          data: impressionsData,
          color: () => `${colors?.common?.blueBright}`,
        },
        {
          data: clicksData,
          color: () => `${colors?.common?.yellow}`,
        },
      ],
    };
  
    setChartData(chartData);
  };
  

  useEffect(()=> {
    calculateDeviceImpressions()
    makelineChartData()
  },[googleAdsDeviceBreakdown])

  return (
    <View style={styles.mainContainer} key={"stats"}>
      <Typography style={styles.title}>Statistics</Typography>
      <View style={styles.statsContainer}>
        <StatsCard
          isActive={true}
          title={"Clicks"}
          count={googleAdsClicksAndImpressions?.clicks ?? 0}
          icon={"googleAdsOutlined"}
          iconFill={colors.common.blueBright}
          isLightTheme={isLightTheme}
          topIcon={reviewIcon}
          tooltip = {clickTooltip}
          setTooltip = {setClickTooltip}
          tooltipText = {languageVariables? languageVariables["App.adw.wid1"] : ""}
        />
        <StatsCard
          isActive={false}
          title={"Impressions"}
          count={googleAdsClicksAndImpressions?.impressions ?? 0}
          icon={"eye"}
          iconFill={colors.common.white}
          isLightTheme={isLightTheme}
          topIcon={reviewIconDark}
          tooltip = {impressionTooltip}
          setTooltip = {setImpressionTooltip}
          tooltipText = {languageVariables? languageVariables["App.adw.wid4"] : ""}
        />
      </View>
      <HeaderWithTooltip title="Impressions/Clicks Over time" toolTip={clickOverTimeToolTip} setToolTip={setClickOverTimeToolTip} toolTipText={languageVariables? languageVariables["App.adw.wid2"] : ""}/>
      <View style={styles.graphPointers}>
        <View style={styles.circle} />
        <Typography>Impressions</Typography>
        <View style={[styles.circle, { backgroundColor: colors.common.yellow }]} />
        <Typography>Clicks</Typography>
      </View>
      <ScrollView horizontal={true}>
        {
            chartData && chartData?.datasets[0]?.data && chartData?.datasets[0]?.data.length > 1 &&
            <LineChart
            data={chartData}
            width={Dimensions.get("window").width}
            height={220}
            yAxisInterval={1} 
            chartConfig={{
              backgroundColor: colors.common.black,
              backgroundGradientFrom: colors.common.white,
              backgroundGradientTo: colors.common.whiteSecondary,
              decimalPlaces: 0, 
              color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
              labelColor: (opacity = 1) => `${colors.common.black}`,
              style: {
                borderRadius: 16,
              },
              propsForDots: {
                r: "4",
                stroke: colors.common.whiteSecondary,
              },
            }}
            bezier
            style={{
              marginVertical: 8,
              borderRadius: 16,
            }}
          />
        }
      </ScrollView>
      <HeaderWithTooltip title="Device Breakdown" toolTip={deviceBreakDownTooltip} setToolTip={setDeviceBreakDownTooltip} toolTipText={languageVariables? languageVariables["App.adw.wid6"] : ""}/>
      <CircularProgressChart devicePercentages={devicePercentages} />
    </View>
  )
}
