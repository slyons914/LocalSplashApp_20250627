import { useMemo, useState } from "react"

import { Image, Pressable, ScrollView, View } from "react-native"

import { Button, Icon, SimpleHeader, Typography } from "@components"
import { Routes } from "@utils/constants"

import { useStyles } from "./styles"
import { AddBusinessDocuments, BusinessPhotoDetailModal, DeletionConfirmationModal } from "@modals"
import { useStore } from "@store"
import { imagePath } from "@utils/constants/imagesPath"
import { MediaViewModel } from "@localsplash/mobile-api-client"
import { BusinessInfoAPI } from "@api"

type GroupedDocuments = {
    [key: string]: MediaViewModel[];
}

export const BusinessDocuments = ({ navigation }: ScreenProps<Routes.BusinessDocuments>) => {

    const { navigate } = navigation

    const styles = useStyles()

    const { businessInfoStore, homeStore } = useStore()
    const { documentTypes, businessDocuments, getBusinessDocuments } = businessInfoStore
    const { locationsItem } = homeStore

    const [isAddBusinessDocumentModalVisible, setIsAddBusinessDocumentModalVisible] = useState(false)
    const [isSelectMode, setIsSelectMode] = useState(false);
    const [selectedDocuments, setSelectedDocuments] = useState<Set<string>>(new Set());
    const [isDeleteButtonLoading, setIsDeleteButtonLoading] = useState(false)
    const [isPhotoDetailModalVisible, setIsPhotoDetailModalVisible] = useState(false)
    const [currentDoc, setCurrentDoc] = useState("")
    const [currentDocIndex, setCurrentDocIndex] = useState(0)
    const [currentSelectedDocs, setCurrentSelectedDocs] = useState<MediaViewModel[]>([])
    const [isDeletionConfirmationModalVisible, setIsDeletionConfirmationModalVisible] = useState(false)

    const onBackPress = () => {
        navigation.goBack()
    }

    const getDocumentTypeName = (documentTypeId: number | undefined) => {
        const documentType = documentTypes?.items?.find(doc => doc.documentTypeId === documentTypeId)
        return documentType ? documentType.name : 'Unknown'
    }


  const toggleImageSelection = (item: MediaViewModel, index: number) => {
    if(!isSelectMode) {
        setCurrentDoc(item?.mediaUrl ?? '')
        setCurrentDocIndex(index)
        const documentTypeName = getDocumentTypeName(item.documentType);
        const documentsOfType = businessDocuments?.items?.filter(item => getDocumentTypeName(item.documentType) === documentTypeName);
        setCurrentSelectedDocs(documentsOfType || []);
        setIsPhotoDetailModalVisible(true)
        return;
    }
    setSelectedDocuments((prevSelections) => {
        const newSelections = new Set(prevSelections);
        if (newSelections.has(item?.mediaUrl ?? '')) {
            newSelections.delete(item?.mediaUrl ?? ''); 
        } else {
            newSelections.add(item?.mediaUrl ?? '');
        }
        return newSelections;
        });
    }

    const onDeletePress = async () => {
        setIsDeleteButtonLoading(true);
        const selectedUrls = Array.from(selectedDocuments);
        if(!locationsItem?.id) return
        try {
            await BusinessInfoAPI.deleteBusinesDocuments(locationsItem?.id, selectedUrls)
        } catch {
            console.log("Error deleting documents")
            setIsDeleteButtonLoading(false)
        }
        await getBusinessDocuments(locationsItem?.id)
        setSelectedDocuments(new Set());
        setIsSelectMode(false);
        setIsDeleteButtonLoading(false)
    }

    const groupedDocuments: GroupedDocuments = useMemo(() => {
        return businessDocuments?.items?.reduce((acc, item) => {
            const documentTypeName = getDocumentTypeName(item.documentType) || 'unknown'

            if (!acc[documentTypeName]) {
                acc[documentTypeName] = []
            }

            acc[documentTypeName].push(item)
            return acc
        }, {} as GroupedDocuments) || {}
    }, [businessDocuments?.items, documentTypes?.items])

    return (
        <View style={styles.container}>
            <SimpleHeader title="" onLeftPress={onBackPress} rightText={"+ New Document"} onRightPress={() => setIsAddBusinessDocumentModalVisible(true)} isRightVisible={true} />
            <View style={styles.header}>
                <Typography style={styles.title}>Business Documents</Typography>
                <Typography onPress={() => setIsSelectMode(!isSelectMode)} style={styles.cancelText}>{isSelectMode ? 'Cancel' : 'Select'}</Typography>
            </View>
            <ScrollView
                contentContainerStyle={styles.scrollContent}
                showsVerticalScrollIndicator={false}>
                {
                    Object.keys(groupedDocuments ?? {})?.map((groupName, index) => (
                        <View key={index} style={styles.documentTypeView}>
                            <Typography style={styles.documentTypeText}>{groupName}</Typography>
                            <View style={styles.photosView}>
                            {
                                groupedDocuments && groupedDocuments[groupName]?.map((item, index) => (
                                    <Pressable onPress={() => toggleImageSelection(item, index)} key={index}>
                                        <Image
                                            style={styles.photo}
                                            source={item.mediaUrl?.includes('.pdf') ? imagePath.pdfImage : {uri: `https://mobileapi.localsplash.com/MediaThumbnails/${encodeURIComponent(item?.mediaUrl ?? '')}?height=300` }}
                                        />
                                        {isSelectMode && (
                                            <Pressable
                                                style={[styles.selectionCircle , selectedDocuments.has(item?.mediaUrl ?? '') && styles.selectedView]}
                                                onPress={() => toggleImageSelection(item, index)}>
                                            {
                                                selectedDocuments.has(item?.mediaUrl ?? '') ? 
                                                ( <Icon name={"tick"}/> ) : 
                                                ( <View style={styles.circleView}></View>)
                                            }
                                            </Pressable>
                                        )}
                                    </Pressable>))
                            }
                            </View>
                        </View>
                    ))
                }
            </ScrollView>
            <View style={styles.buttonView}>
                {
                    isSelectMode && selectedDocuments.size > 0 && (
                        <Button isLoading={isDeleteButtonLoading} btnStyle={{alignSelf:"center"}} label={`${selectedDocuments.size} documents selected`} right="trashDark" onPress={() => setIsDeletionConfirmationModalVisible(true)}></Button>
                    )
                }
            </View>
            <AddBusinessDocuments 
              isVisible={isAddBusinessDocumentModalVisible}
              onClose={() => setIsAddBusinessDocumentModalVisible(false)}
              documentTypes={documentTypes}/>
            <BusinessPhotoDetailModal 
              imageList = {currentSelectedDocs} 
              imageUrl={currentDoc} 
              isVisible={isPhotoDetailModalVisible} 
              onClose={()=>setIsPhotoDetailModalVisible(false)} 
              imageIndex={currentDocIndex} 
              setCurrentImage={setCurrentDoc} 
              setCurrentImageIndex={setCurrentDocIndex} 
              type={"Business Document"}
            />
            <DeletionConfirmationModal 
              isVisible={isDeletionConfirmationModalVisible}
              onClose={() => setIsDeletionConfirmationModalVisible(false)}
              onDeletePress={onDeletePress}
              confirmationMessage="Are you sure you want to delete this business document?"
            />
        </View>
    )
}
