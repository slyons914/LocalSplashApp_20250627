import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ insets, colors,height, width }) => ({
  container: {
    flex: 1,
    gap: 8,
    paddingTop: insets.top,
    backgroundColor: colors.background,
    paddingHorizontal: 16,
  },
  insideEmptyView: {
    height:"93%",
    width:"94%",
    borderRadius:8,
    borderStyle:"dashed",
    borderColor:colors.orangePrimary,
    justifyContent:"center",
    alignItems:"center",
    borderWidth:1,
  },
  emptyView: {
    height: width / 3 - 8,
    width: width / 3 - 8
  },
  photo: {
    height: width / 3.2 - 8,
    width: width / 3.2 - 8,
    borderRadius:8
  },
  photosView: {
    flexDirection:"row",
    gap:8,
    flexWrap:"wrap",
  },
  scrollContent: {
    paddingBottom: insets.bottom + 100,
  },
  selectionCircle: {
    position: 'absolute',
    bottom: 8,
    right: 8,
    padding: 4,
  },
  title: {
    fontWeight: "600",
    fontSize: 24
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center"
  },
  cancelText: {
    color:colors.orangePrimary,
    fontSize: 16,
    fontWeight: "500"
  },
  documentTypeView: {
    gap: 6,
    marginBottom:20
  },
  documentTypeText: {
    color: colors.subText,
  },
  circleView: {
    width:24,
    height:24,
    borderRadius:12,
    borderWidth:1,
    borderColor:colors.white
  },
  selectedView: {
    backgroundColor: colors.white,
    borderRadius:12
  },
  buttonView: {
    position: 'absolute', 
    alignSelf:"center", 
    bottom:24
  },

}))
