import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingBottom: insets.bottom,
    paddingTop: 8,
    paddingHorizontal: 24,
    gap: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: "600",
    paddingTop: 0.5,
  },
  titleContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  header:{
    backgroundColor: colors.background,
    flexDirection:"row",
    justifyContent:"space-between",
    paddingTop: 16,
    paddingHorizontal: 16,
  },
  headerText:{
    color:colors.orangePrimary,
    fontWeight:"500"
  }
}))