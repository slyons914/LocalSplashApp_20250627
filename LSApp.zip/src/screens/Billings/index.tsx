import React, { useCallback, useRef, useState } from "react"

import { FlatList, Pressable, View, ViewToken, useColorScheme } from "react-native"

import { observer } from "mobx-react-lite"

import { Icon, Tabs, Typography } from "@components"
import { Routes } from "@utils/constants"
import { useStyles } from "./styles"
import { navigate } from "@navigation"

const TABS: string[] = [
  "Next Billing",
  "Past Invoices",
]


const Component: React.FC<ScreenProps<Routes.Billings>> = () => {
  const styles = useStyles()
  const flatRef = useRef<FlatList>(null)

  const [activeTab, setActiveTab] = useState(0)
  const [scrollHandlerDisabled, setScrollHandlerDisabled] = useState(false)
  const sections:any = []
  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"
  const onTabPress = (index: number) => {
    setScrollHandlerDisabled(true)
    flatRef.current?.scrollToIndex({ index, animated: true })

    setTimeout(() => {
      setScrollHandlerDisabled(false)
    }, 400)
  }

  const handleScroll = useCallback((info: {
    viewableItems: Array<ViewToken>;
    changed: Array<ViewToken>;
  }) => {
    info.viewableItems[0] &&
      info.viewableItems[0].index !== null &&
      setActiveTab(info.viewableItems[0].index)
  }, [])

  const renderSection = ({
    item,
    index,
  }: {
    item: (key: number) => React.JSX.Element
    index: number
  }) => item(index)
  const onBackPress = () => {
    navigate(Routes.Settings,{})
  }
  return (
    <View style={{flex:1}}>
        <View style={styles.header}>
            <Pressable hitSlop={5} onPress={onBackPress}>
                <Icon name={isLightTheme ? "backIcon" : "bacIconWhite"} />
            </Pressable>
            <Pressable>
                <Typography style={styles.headerText}>
                    Payment Info
                </Typography>
            </Pressable>
        </View>
        <View style={styles.container}>
            <View style={styles.titleContainer}>
            <Typography style={styles.title}>Billings</Typography>
        </View>
        <View>
            <Tabs
            tabs={TABS}
            onTabPress={onTabPress}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            allTabsDisabled={scrollHandlerDisabled}
            />
        </View>
        <FlatList
        ref={flatRef}
        data={sections}
        renderItem={renderSection}
        onViewableItemsChanged={handleScroll}
        viewabilityConfig={{
          itemVisiblePercentThreshold: 30,
        }}
      />
        </View>
    </View>
  )
}

export const BillingsScreen = observer(Component)
