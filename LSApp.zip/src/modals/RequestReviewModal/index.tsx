import React, { useState } from "react"

import { Keyboard, KeyboardAvoidingView, Platform, Pressable, TouchableWithoutFeedback, View } from "react-native"

import Modal from "react-native-modal"

import { Button, Icon, Input, Typography } from "@components"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"
import { MobileAPI } from "@api"
import { backIconHitSlope } from "@utils/constants/common"
import { FeedbackSentModal } from "@modals"
import { Formik } from "formik"
import { ReviewRequestSchema, reviewRequestSchema } from "./requestReviewSchema"
import { showMessage } from "react-native-flash-message"
import { Lead } from "@models/leads"
import { FormatHelper } from "@utils/helpers"
interface Props {
  isVisible: boolean
  onClose: () => void
  profileId?: number | undefined
  leadDetails?: Lead | null
}

export const RequestReviewModal = ({ isVisible, onClose, profileId, leadDetails }: Props) => {
  const [responseText, setResponseText] = useState("")
  const [isFeedbackSentModalVisible, setIsFeedbackSentModalVisible] = useState(false)
  const [isSendingReview, setIsSendingReview] = useState(false)
  const styles = useStyles()

  const { text } = useColors()

  const sendReviewRequest = async (values: ReviewRequestSchema) => {
    setIsSendingReview(true)
    try {
      const { data, error } = await MobileAPI.sendReviewRequest(
        profileId,
        values.name ?? '',
        values.email ?? '',
        values.phone ?? '',
      )
      if (data) {
        setIsFeedbackSentModalVisible(true)
      } else {
            onClose()
            Keyboard.dismiss()
            showMessage({
                message: 'You are not allowed to request review',
                type: 'danger',
                duration: 2500,
                floating: true,
                titleStyle: {fontSize: 16, fontWeight: "500"},
                style:{justifyContent:"center", alignItems: 'center'},
                icon: () => <Icon style={styles.notificationIcon} height={50} width={50} name="AppIcon" />,
            })
      }
    } catch {
      setResponseText("Error while sending review request")
    }
    setIsSendingReview(false)
  }
  const onFeedbackSendClose = () => {
    setIsFeedbackSentModalVisible(false)
    setResponseText("")
  }
  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.container}
      >
        <View style={styles.dash} />
        <Typography style={styles.title}>Request Review</Typography>
        <Pressable hitSlop={backIconHitSlope} style={styles.close} onPress={onClose}>
          <Icon name={"remove"} stroke={text} />
        </Pressable>
        <Formik
            validationSchema={reviewRequestSchema}
            initialValues={{ name: leadDetails?.name, email: leadDetails?.email, phone: FormatHelper.formatPhoneNumber(leadDetails?.phoneNumber?.toString()) }}
            onSubmit={(values, {resetForm}) => sendReviewRequest(values).then(()=> resetForm())}
        >
        {({ handleChange, handleSubmit, values, errors, touched }) => (
        <React.Fragment>
        <View style={styles.inputContainer}>
            <Input label={'Name*'} value={values.name ?? ''} onChange={handleChange('name')} placeholder={'Type name here..'} error={touched.name && errors.name ? errors.name : ''}/>
            <Input label={'Phone Number*'} value={values.phone ?? ''} onChange={handleChange('phone')} placeholder={'Type number here..'} error={touched.phone && errors.phone ? errors.phone : ''} type="phone" />
            <Input label={'Customer Email'} value={values.email ?? ''} onChange={handleChange('email')} placeholder={'Type email here..'} error={touched.email && errors.email ? errors.email : ''}/>
        </View>
        <View>{responseText ? <Typography style={styles.redText}>{responseText}</Typography> : null}</View>
        <View>
          <Button onPress={handleSubmit} btnStyle={styles.button} label={"Send"} isLoading={isSendingReview} />
          <Button
            btnStyle={styles.cancelButton}
            labelStyle={styles.cancelButtonText}
            onPress={onClose}
            label={"Cancel"}
          />
        </View>
        </React.Fragment>
        )}
        </Formik>
      </KeyboardAvoidingView>
      </TouchableWithoutFeedback>
      <FeedbackSentModal title="Request Review" message="Review request sent successfully" isVisible={isFeedbackSentModalVisible} onClose={()=>onFeedbackSendClose()}></FeedbackSentModal>
    </Modal>
  )
}
