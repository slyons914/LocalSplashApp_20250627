import { phone } from '@assets/icons'
import * as yup from 'yup'

export interface ReviewRequestSchema {
    name: string | undefined,
    email: string | undefined,
    phone: string | undefined,
}

export const reviewRequestSchema = yup.object().shape({
  name: yup
    .string().required('Name is required'),
  phone: yup
    .string().required('Phone number is required')
})