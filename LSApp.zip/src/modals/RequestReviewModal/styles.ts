import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: colors.background,
    minHeight: height * 0.4,
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    alignItems: "center",
    paddingTop: 29,
    paddingHorizontal: 24,
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
    marginBottom: 24,
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
  },
  close: {
    position: "absolute",
    top: 29,
    right: 24,
  },
  inputContainer: {
    width: "100%",
    gap: 24,
    marginBottom:7
  },
  button: {
    marginTop: 20,
    width: 342,
  },
  cancelButton: {
    marginTop: 10,
    width: 342,
    backgroundColor: colors.white,
    color: colors.orangePrimary,
    marginBottom:8
  },
  cancelButtonText: {
    color: colors.orangePrimary,
  },
  redText: {
    fontWeight: "500",
    color: colors.redText
  },
  notificationIcon: {
    marginRight:16, 
    alignSelf:"center", 
    justifyContent:"center", 
    borderRadius:25
  }
}))
