import { Pressable, ScrollView, View } from "react-native"

import Modal from "react-native-modal"

import { Button, Icon, Typography } from "@components"
import { useStyles } from "./styles"
import moment from "moment"
import { WebsiteLead, WebsiteLeads } from "@models/index"
import { useState } from "react"
import { MobileAPI } from "@api"
import { backIconHitSlope } from "@utils/constants/common"

interface Props {
  allLeads: any,
  setAllLeads:(leads:any)=>void   
  setLead: (websiteLead:WebsiteLead)=> void  
  isVisible: boolean
  onClose: () => void
  lead:WebsiteLead | undefined,
  profileId: number | undefined
}

export const LeadDetailModal = ({ isVisible, onClose, lead, setLead, allLeads, setAllLeads, profileId }: Props) => {
  const styles = useStyles()
  const [loading, setLoading] = useState(false)
  const formatDateTime = (dateTimeString:string | undefined) => {
    const parsedDate = moment(dateTimeString, "YYYY-MM-DDTHH:mm:ss");
    return parsedDate.format("MMM D, YYYY h:mm A");
  };
  const updateLeadStatus = async() =>{
    setLoading(true)
    const response = await MobileAPI.updateWebsiteLead(lead?.id,!lead?.isResponded, profileId)
    if(response.error === null){
        setLead({...lead, isResponded:!lead?.isResponded})
    const updatedLeads:WebsiteLeads = allLeads?.websiteLeads.map((item:WebsiteLead) => {
        if (item.id === lead?.id) {
          return { ...item, isResponded: !item.isResponded }; // Update name of matching item
        }
        return item; // Return unchanged item if not matching id
      });
     setAllLeads({websiteLeads:updatedLeads, totalLeadCount:allLeads.totalLeadCount}) 
    }
    setLoading(false)
  }
  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <View style={styles.titleContainer}>
         <Pressable onPress={onClose}  style={styles.icon} hitSlop={backIconHitSlope}>
            <Icon name="backIconSmall"></Icon>
        </Pressable>   
        <Typography style={styles.title}>Lead Details</Typography>
        </View>
        <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.leadItemDetail}>
            <Typography style={[styles.greyText, styles.smallText]}>{formatDateTime(lead?.date)}</Typography>
            {
                lead?.isResponded? (
                <Typography style={styles.greenText}>Responded</Typography>
                ) : (
                 <Typography style={styles.redText}>Not Responded</Typography>
                )
            }
        </View>
        <View>
            <Typography style={styles.subText}>{lead?.message}</Typography>
        </View>
        <View style={styles.detailView}>
            <Typography style={styles.subText}>{lead?.firstName}</Typography>
            <Typography style={[styles.subText, styles.orangeText]}>{`(${(lead?.phoneNumber??"").substring(0, 3)}) ${(lead?.phoneNumber??"").substring(3, 6)}-${(lead?.phoneNumber??"").substring(6)}`}</Typography>
            <Typography style={[styles.subText, styles.orangeText]}>{lead?.emailAddress}</Typography>
        </View>
        <View>
          <Button isLoading={loading} btnStyle={styles.button} onPress={()=>updateLeadStatus()} label={lead?.isResponded?"Mark as Not Responded":"Mark as Responded"} />
        </View>
        </ScrollView>
      </View>
    </Modal>
  )
}
