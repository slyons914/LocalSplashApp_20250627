import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: colors.background,
    maxHeight:height,
    minHeight: height * 0.4,
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    paddingTop: 29,
    paddingHorizontal: 24,
    gap:14
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
    marginBottom: 24,
    alignSelf:"center"
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
    alignSelf:"center"
  },
  button: {
    marginTop: 8,
    width: 342,
    marginBottom:12
  },
  smallText:{
    fontSize:12
  },
  greyText:{
    color:colors.greyText
  },
  leadItemDetail:{
    flexDirection:"row",
    justifyContent:"space-between"
  },
  redText:{
    color:colors.red,
    fontWeight:'500'
  },
  greenText:{
    color:colors.green,
    fontWeight:'500'
  },
  subText:{
    fontSize:16
  },
  textInput: {
    borderWidth: 1,
    borderColor: colors.gray6,
    borderRadius: 8,
    paddingHorizontal: 24,
    paddingVertical: 16,
    color: colors.text,
    height:180
  },
  lightText:{
    color:colors.gray4,
    marginTop:5
  },
  titleContainer:{
    flexDirection:"row",
    justifyContent:"center"
  },
  icon:{
    marginTop:7,
    position:"absolute",
    left:0
  },
  orangeText:{
    color:colors.orangePrimary
  },
  detailView:{
    marginBottom:12,
    gap:1
  }
}))
