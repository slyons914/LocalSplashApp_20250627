import { withStyles } from "@utils/hocs"
import { Platform } from "react-native"

export const useStyles = withStyles(({ colors, insets, height, width }) => ({
  modal: {
    alignSelf: "flex-end",
    margin: 0,
  },
  container: {
    backgroundColor: colors.background,
    height: height,
    width: width * 0.8,
    alignItems: "center",
    paddingTop: insets.top || 20,
    paddingHorizontal: 24,
  },
  logoBlock: {
    flexDirection: "row",
    alignItems: "center",
    gap: 48,
    marginBottom: 16,
  },
  itemContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: Platform.OS === 'android' ? 14 : 16,
    paddingHorizontal: 12,
    width: "100%",
  },
  itemText: {
    fontSize: 16,
    fontWeight: "400",
  },
  button: {
    width: 130,
  },
  buttonContainer: {
    marginTop: 16,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 10
  },
  feedbackButton: {
    width: 130,
    backgroundColor: colors.white
  },
  feedbackButtonText: {
    color: colors.orangePrimary
  },
}))
