import { Pressable, View } from "react-native"
import { useNavigation } from "@react-navigation/native"
import Modal from "react-native-modal"

import { Button, Icon } from "@components"
import { Routes, Stacks } from "@utils/constants"

import { ModalItem } from "./ModalItem"
import { useStyles } from "./styles"
import { FeedbackModal } from "@modals/FeedbackModal"
import { useState } from "react"

interface Props {
  isVisible: boolean
  onClose: () => void
  setBurgerMenu: (val:boolean) => void
}

export const BurgerMenuModal = ({ isVisible, onClose, setBurgerMenu }: Props) => {
  const styles = useStyles()
  const { navigate } = useNavigation()
  const [isFeedbackModalVisible, setIsFeedbackModalVisible] = useState(false)

  const onLeadsPress = () => {
    onClose()
    navigate(Stacks.Home, { screen: Routes.Leads })
  }

  const onFacebookPress = () => {
    onClose()
    navigate(Stacks.Facebook, { screen: Routes.Facebook })
  }

  const onBusinessInfoPress = () => {
    onClose()
    navigate(Stacks.Settings, { screen: Routes.BusinessInformation })
  }
  const onGoogleInsightsPress = () => {
    onClose()
    navigate(Stacks.GoogleInsghts, { screen: Routes.Google_Insights })
  }
  const onReviewsPress = () => {
    onClose()
    navigate(Stacks.Reviews, { screen: Routes.Reviews })
  }
  const onGoogleAdsPress = () => {
    onClose()
    navigate(Stacks.GoogleAds, { screen: Routes.Google_Ads })
  }

  const onContactUsPress = () => {
    onClose()
    navigate(Stacks.CONTACT_US, { screen: Routes.ContactUs })
  }
  const onWebsitePress = () => {
    onClose()
    navigate(Stacks.WEBSITE, { screen: Routes.Website })
  }
  const onListingsPress = async () => {
    onClose()
    navigate(Stacks.LISTINGS,{screen: Routes.Listing})
  }
  const onPostsPress = () => {
    onClose()
    navigate(Stacks.POSTS, { screen: Routes.Posts })
  }
  const onHomePress = () => {
    onClose()
    navigate(Stacks.Home, { screen: Routes.Home })
  }

  const onFeedbackPress = () =>{
    onClose()
    setTimeout(()=>{
        setIsFeedbackModalVisible(true)
    },400)
  }

  const onFeedbackClose = () =>{
    setIsFeedbackModalVisible(false)
    setTimeout(()=>{
        setBurgerMenu(true)
    },400)
  }


  return (
    <>
      <Modal
        isVisible={isVisible}
        animationIn={"fadeInRight"}
        animationOut={"fadeOutRight"}
        onBackdropPress={onClose}
        onBackButtonPress={onClose}
        style={styles.modal}
      >
        <View style={styles.container}>
          <View style={styles.logoBlock}>
            <Icon name={"burgerLogo"} />
            <Pressable onPress={onClose}>
              <Icon name={"remove"} />
            </Pressable>
          </View>
          <ModalItem onPress={onHomePress} label={"Home"} />
          <ModalItem onPress={onLeadsPress} label={"Leads"} />
          <ModalItem label={"Website"} onPress={onWebsitePress} />
          <ModalItem label={"Reviews"} onPress={onReviewsPress} />
          <ModalItem label={"Google Insights"} onPress={onGoogleInsightsPress} />
          <ModalItem onPress={onFacebookPress} label={"Facebook Ads"} />
          <ModalItem label={"Google Ads"} onPress={onGoogleAdsPress} />
          <ModalItem label={"Listings"} onPress={onListingsPress} />
          <ModalItem label={"Posts"} onPress={onPostsPress} />
          <ModalItem label={"Business Info"} onPress={onBusinessInfoPress} />
          <View
            style={styles.buttonContainer}
          >
            <Button
              btnStyle={styles.feedbackButton}
              onPress={() => onFeedbackPress()}
              icon={"happy_emoji_orange"}
              label={"Feedback"}
              labelStyle={styles.feedbackButtonText}
            />
            <Button
              btnStyle={styles.button}
              onPress={onContactUsPress}
              icon={"customerService"}
              label={"Contact Us"}
            />
          </View>
        </View>
      </Modal>
      <FeedbackModal
        setFeedbackModal={setIsFeedbackModalVisible}
        isVisible={isFeedbackModalVisible}
        onClose={() => onFeedbackClose()}
      />
    </>
  )
}
