import { Pressable, View } from "react-native"

import Modal from "react-native-modal"


import { useStyles } from "./styles"
import { Button, Typography } from "@components"
import { usePermissions } from "../../screens/Permissions/use-permissions"
import { pickVideoFromGallery, takeVideoWithCamera } from "@utils/helpers"

import Toast from 'react-native-simple-toast';

interface Props {
  isVisible: boolean
  onClose: () => void
  onImageSelect: (uri:string, filename: string, type:string, width: number | undefined, height: number | undefined) => void
}

export const AddVideoModal = ({ isVisible, onClose, onImageSelect }: Props) => {

  const {permissions, requestPermission} = usePermissions()  
  const styles = useStyles()
  const showInvalidTypeToast = () => {
    Toast.showWithGravity(
        'Only MP4, MOV, and WEBM videos are allowed',
        Toast.LONG,
        Toast.BOTTOM,
      );
}
const isValidFileType = (type: string) => {
    const validTypes = ['video/mp4', 'video/quicktime', 'video/webm']; // MOV = quicktime
    return validTypes.includes(type);
}
  const handleTakePhoto = async () => {
    try {
        if (!permissions.camera) {
            await requestPermission("camera")
        }
        const response = await takeVideoWithCamera();
        if (!!response && typeof response !== "string") {
            if (!isValidFileType(response[0].type??""))
            {
                showInvalidTypeToast()
                return;
            }
            const newAttachment = {
                uri: response[0]?.uri || "",
                name: response[0]?.fileName || "",
                type: response[0]?.type || "",
                width: response[0]?.width,
                height: response[0]?.height
            };
            onImageSelect(newAttachment.uri, newAttachment.name, newAttachment.type, newAttachment.width, newAttachment.height)
            onClose()
        }
    } catch (error) {
        console.log(error);
    }
};

const handleChoosePhoto = async () => {
    try {
        const response = await pickVideoFromGallery();
        if (!!response && typeof response !== "string") {
            if (!isValidFileType(response[0].type??""))
            {
                showInvalidTypeToast()
                return;
            }
            const newAttachment = {
                uri: response[0]?.uri || "",
                name: response[0]?.fileName || "",
                type: response[0]?.type || "",
                width: response[0]?.width,
                height: response[0]?.height
            };
            onImageSelect(newAttachment.uri, newAttachment.name, newAttachment.type, newAttachment.width, newAttachment.height)
            onClose()
        }
    } catch (error) {
        console.log(error);
    }
};


  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      onSwipeComplete={onClose}
      style={styles.modal}
      avoidKeyboard
      animationIn={"slideInUp"}
      animationOut={"slideOutDown"}
      swipeDirection={["down"]}
      propagateSwipe
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <Button onPress={handleTakePhoto} label="Take a Video" />
        <Button onPress={handleChoosePhoto} label="Select from gallery" />
        <Pressable onPress={onClose} style={styles.cancelButton}>
            <Typography style={styles.cancelText}>Cancel</Typography>
        </Pressable>
      </View>
    </Modal>
  )
}

