import { TouchableOpacity } from "react-native"

import { Icon, Typography } from "@components"

import { useStyles } from "./styles"

interface Props {
  label: string
  onPress?: () => void
  active?: boolean
}

export const ModalItem = ({ label, onPress, active }: Props) => {
  const styles = useStyles()

  return (
    <TouchableOpacity onPress={onPress} style={styles.itemContainer}>
      <Typography style={styles.itemText}>{label}</Typography>
      {active && <Icon name={"checkBlue"} />}
    </TouchableOpacity>
  )
}
