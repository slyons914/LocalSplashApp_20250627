import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height }) => ({
  modal: {
    margin: 0,
    marginTop: 40,
  },
  container: {
    backgroundColor: colors.background,
    minHeight: height * 0.85,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    padding: 16,
    paddingBottom: 24,
  },
  scrollContainer: {
    gap: 16,
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
    alignSelf: "center",
  },
  warningText: {
    color: colors.red,
    backgroundColor: colors.warningBackground,
    borderRadius: 16,
    padding: 10,
    overflow: "hidden",
  },
  hideContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 16,
  },
}))
