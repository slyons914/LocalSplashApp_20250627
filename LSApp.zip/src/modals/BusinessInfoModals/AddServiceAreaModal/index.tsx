import { ActivityIndicator, Pressable, ScrollView, View } from "react-native"

import { GooglePlacesInput, Typography } from "@components"
import { useStore } from "@store"

import Modal from "react-native-modal"

import { useStyles } from "./styles"
import { observer } from "mobx-react-lite"
import { useState } from "react"
import { Address } from "@models/settings"
import { IProfileServiceAreaViewModel } from "@localsplash/mobile-api-client"
import { BusinessInfoAPI } from "@api"
import { colors } from "@utils/constants"

interface Props {
    isVisible: boolean
    onClose: () => void
}

const Component = ({ isVisible, onClose, }: Props) => {
    const styles = useStyles()

    const [address, setAddress] = useState<Address | null>(null)
    const [serviceAreas, setServiceAreas] = useState<IProfileServiceAreaViewModel[] | null>(null)
    const [isLoading, setIsLoading] = useState(false)

    const { homeStore, businessInfoStore } = useStore()
    const { locationsItem } = homeStore
    const { getServiceAreas  } = businessInfoStore
    const closeModal = () => {
        setServiceAreas(null)
        setIsLoading(false)
        onClose()
    }

    const onAddingLocation = (placesId: string, address: string) => {
        const newServiceArea: IProfileServiceAreaViewModel = {
            serviceAreaName : address,
            serviceAreaPlaceId: placesId,
            isGbpSync: false, 
            isAdsSync: false,
          };
      
        setServiceAreas((prevServiceAreas) => [
            ...(prevServiceAreas || []), 
            newServiceArea,
        ]);
    }

    const setGbpSync = (placeId: string, isSync: boolean) => {
        setServiceAreas((prevServiceAreas) =>
          (prevServiceAreas || []).map((area) =>
            area.serviceAreaPlaceId === placeId
              ? { ...area, isGbpSync: isSync } 
              : area
          )
        );
      };
    
      const setAdsSync = (placeId: string, isSync: boolean) => {
        setServiceAreas((prevServiceAreas) =>
          (prevServiceAreas || []).map((area) =>
            area.serviceAreaPlaceId === placeId
              ? { ...area, isAdsSync: isSync }
              : area
          )
        );
      };

    const onSavePress = async() => {
        if(!serviceAreas || !locationsItem?.id) {
            closeModal()
            return
        }
        setIsLoading(true)
        for (const area of serviceAreas) {
            try {
                await BusinessInfoAPI.postServiceAreas(locationsItem?.id, area)
            }
            catch {
                console.log("Error while Adding Service Areas")
                setIsLoading(false)
                closeModal()
            }
        }
        await getServiceAreas(locationsItem?.id)
        setIsLoading(false)
        closeModal()
    }
    
    const RenderItem = ({ item, index }: { item: IProfileServiceAreaViewModel, index:number }) => (
        <Pressable key={index} style={styles.methodView}>
            <Typography style={styles.methodText}>
                {item?.serviceAreaName}
            </Typography>
            <Pressable style={styles.methodItemView}>
                <Pressable style={[styles.methodItem, styles.selectedItem]}>
                    <Typography style={[styles.methodItemText, styles.selectedItemText]}>Website</Typography>
                </Pressable>
                <Pressable
                    onPress={() => setGbpSync(item.serviceAreaPlaceId ?? '', !item.isGbpSync)}
                    style={[styles.methodItem, item.isGbpSync && styles.selectedItem]}
                >
                    <Typography style={[styles.methodItemText, item.isGbpSync && styles.selectedItemText]}>Google</Typography>
                </Pressable>
                <Pressable
                    onPress={() => setAdsSync(item.serviceAreaPlaceId ?? '', !item.isAdsSync)}
                    style={[styles.methodItem, item.isAdsSync && styles.selectedItem]}
                >
                    <Typography style={[styles.methodItemText, item.isAdsSync && styles.selectedItemText]}>Ads</Typography>
                </Pressable>
            </Pressable>
        </Pressable>
    );

    const ListHeader = () => (
            <GooglePlacesInput
                setAddress={setAddress}
                label={"Location"}
                type="service"
                onSubmit={onAddingLocation}
            />
    );

    return (
        <Modal
            isVisible={isVisible}
            onBackdropPress={closeModal}
            onBackButtonPress={closeModal}
            onSwipeComplete={closeModal}
            style={styles.modal}
        >
            <View style={styles.container}>
                <View style={styles.dash} />
                <View style={styles.header}>
                    <Typography onPress={closeModal} style={styles.headerItem}>Cancel</Typography>
                    <Typography style={styles.title}>Service Area</Typography>
                    {
                        isLoading ? ( <ActivityIndicator size={"small"} color={colors.common.orangePrimary}></ActivityIndicator> ) : (
                            <Typography onPress={onSavePress} style={styles.headerItem}>Add</Typography>
                        )
                    }
                </View>
                <ScrollView 
                    style={styles.googlePlacesView}
                    keyboardShouldPersistTaps = 'handled'
                >
                    <ListHeader />
                    {
                        serviceAreas?.map((item, index) => (
                            <RenderItem item={item} index={index} />
                        ))
                    }
                </ScrollView>
                {/* <FlatList
                    data={serviceAreas}
                    renderItem={renderItem}
                    keyExtractor={(item, index) => item?.serviceAreaPlaceId ?? index.toString()}  // Key for each list item
                    //ListHeaderComponent={ListHeader} 
                    showsVerticalScrollIndicator={false}
                    style={styles.scrollContainer}
                    keyboardShouldPersistTaps ='handled'
                    automaticallyAdjustKeyboardInsets
                /> */}
            </View>
        </Modal>
    )
}

export const AddServiceAreaModal = observer(Component)

