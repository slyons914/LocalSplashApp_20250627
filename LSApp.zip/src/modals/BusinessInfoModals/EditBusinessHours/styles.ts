import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height }) => ({
  modal: {
    margin: 0,
    justifyContent:"flex-end",
  },
  container: {
    minHeight: height * 0.85,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    paddingBottom: 24,
    backgroundColor: colors.background
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
    alignSelf: "center",
  },
  header:{
    marginTop:8,
    flexDirection:"row",
    justifyContent: "space-between",
    borderBottomWidth:1,
    borderBottomColor:colors.grey,
    paddingBottom:8,
    alignItems:"center",
    marginBottom:18,
    padding: 16,
  },
  headerItem:{
    color:colors.orangePrimary,
    fontWeight:"500",
    fontSize:16
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
  },
  daysList: { 
    marginTop:16,
    flexDirection:"row",
    maxHeight:40,
    marginBottom:24
  },
  dayContainer: {
    paddingHorizontal: 24,
    paddingVertical: 5,
  },
  dayText: { 
    color:colors.subText
  },
  selectedDay: { 
    color:colors.dark,
    fontWeight:"500"
  },
  optionRow: {
    flexDirection: 'row',
    marginVertical: 10,
    justifyContent:"space-between"
  },
  optionText: { 
    fontSize:16
  },
  content: {
    paddingHorizontal: 24,
  },
  timePickerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 20,
  },
  label: { 
    color:colors.subText
  },
  timeText: { 
    fontSize: 40,
    fontWeight:"300", 
    textDecorationLine:"underline"
  },
  timeView: {
    gap:16
  },
  hourText: {
    fontSize: 20,
    fontWeight: "300"
  }
}))
