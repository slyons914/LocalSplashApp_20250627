import { FlatList, Pressable, ScrollView, Switch, TouchableOpacity, View } from "react-native"

import { CustomDropdown, Typography } from "@components"

import Modal from "react-native-modal"

import { useStyles } from "./styles"
import { observer } from "mobx-react-lite"
import { useEffect, useState } from "react"
import DatePicker from "react-native-date-picker"
import { ProfileWorkingHours } from "@models/settings"
import { capitalizeFirstLetter, updateWorkingHours } from "@utils/helpers/common"
import { BusinessInfoAPI } from "@api"
import { useStore } from "@store"

const days = ['Apply to All Days', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

const options = [
    { label: 'Open', value: 'open' },
    { label: 'Close', value: 'close' },
];

interface Props {
    isVisible: boolean
    onClose: () => void,
    workingHours: any
}

const Component = ({ isVisible, onClose, workingHours }: Props) => {
    const styles = useStyles()

    const { homeStore, businessInfoStore } = useStore()
    const { locationsItem } = homeStore
    const { getWorkingHours } = businessInfoStore

    const [selectedDay, setSelectedDay] = useState('monday');
    const [hideWorkingHours, setHideWorkingHours] = useState(false);
    const [dropdownValue, setDropdownValue] = useState('open')
    const [startTime, setStartTime] = useState<Date>(new Date());
    const [endTime, setEndTime] = useState<Date>(new Date());
    const [bookingByAppointment, setBookingByAppointment] = useState(false)
    const [showStartPicker, setShowStartPicker] = useState<boolean>(false);
    const [showEndPicker, setShowEndPicker] = useState<boolean>(false);

    const renderDay = ({ item }: { item: string }) => (
        <TouchableOpacity key={item} onPress={() => setSelectedDay(item)} style={styles.dayContainer}>
            <Typography style={[styles.dayText, selectedDay === item && styles.selectedDay]}>
                {capitalizeFirstLetter(item)}
            </Typography>
        </TouchableOpacity>
    );

    const onSavePress = async () => {
        const data = updateWorkingHours(workingHours, selectedDay, startTime, endTime, bookingByAppointment, dropdownValue === "open" ? true : false, hideWorkingHours)
        if(locationsItem?.id) {
                await BusinessInfoAPI.addOrEditWorkingHours(locationsItem?.id,data)
                await getWorkingHours(locationsItem?.id)
        }
        onClose()
    }

    useEffect(() => {
        if (!workingHours || !selectedDay) return;
        if(selectedDay === "Apply to All Days") return;

        const openingKey = `${selectedDay}OpeningTime`;
        const closingKey = `${selectedDay}ClosingTime`;
        const appointmentKey = `is${capitalizeFirstLetter(selectedDay)}ByAppointment`;
    
        const openingTime = workingHours[openingKey];
        const closingTime = workingHours[closingKey];
        const isAppointment = workingHours[appointmentKey];
    
        if (openingTime && closingTime) {
          const startDate = new Date();
          const endDate = new Date();
          startDate.setHours(Math.floor(openingTime / 100), openingTime % 100);
          endDate.setHours(Math.floor(closingTime / 100), closingTime % 100);
          setStartTime(startDate);
          setEndTime(endDate);
        }
    
        setBookingByAppointment(isAppointment);
        setHideWorkingHours(workingHours.areHoursHidden || false);
        
        setDropdownValue(isAppointment ? 'close' : 'open');
      }, [selectedDay, workingHours]);

    return (
        <Modal
            isVisible={isVisible}
            onBackdropPress={onClose}
            onBackButtonPress={onClose}
            onSwipeComplete={onClose}
            style={styles.modal}
            avoidKeyboard
            animationIn={"slideInUp"}
            animationOut={"slideOutDown"}
            swipeDirection={["down"]}
            propagateSwipe
        >
            <View style={styles.container}>
                <View style={styles.dash} />
                <View style={styles.header}>
                    <Typography onPress={onClose} style={styles.headerItem}>cancel</Typography>
                    <Typography style={styles.title}>Working Hours</Typography>
                    <Typography onPress={onSavePress} style={styles.headerItem}>Save</Typography>
                </View>
                <ScrollView showsHorizontalScrollIndicator={false} horizontal style={styles.daysList}>
                    {days.map((item) => renderDay({ item }))}
                </ScrollView>
                <View style={styles.content}>
                    <View style={styles.optionRow}>
                        <Typography style={styles.optionText}>Hide my Working Hours</Typography>
                        <Switch value={hideWorkingHours} onValueChange={setHideWorkingHours} />
                    </View>
                    <CustomDropdown options={options} onValueChange={setDropdownValue} value={dropdownValue} placeholder="Select Open or Close" />
                    {
                        dropdownValue === "open" && !bookingByAppointment &&
                        <View style={styles.timePickerRow}>
                            <View style={styles.timeView}>
                                <Typography style={styles.label}>Start</Typography>
                                <Pressable onPress={() => setShowStartPicker(true)}>
                                    <TimeDisplay time={startTime} />
                                </Pressable>
                            </View>
                            <View style={styles.timeView} >
                                <Typography style={styles.label}>End</Typography>
                                <TouchableOpacity onPress={() => setShowEndPicker(true)}>
                                    <TimeDisplay time={endTime} />
                                </TouchableOpacity>
                            </View>
                        </View>
                    }
                    {
                        dropdownValue === "open" &&
                        <View style={styles.optionRow}>
                            <Typography style={styles.optionText}>By Appointment</Typography>
                            <Switch value={bookingByAppointment} onValueChange={setBookingByAppointment} />
                        </View>
                    }
                </View>
                {showStartPicker && (
                    <DatePicker
                        modal
                        open={showStartPicker}
                        date={startTime}
                        mode="time"
                        onConfirm={(date?: Date) => {
                            setShowStartPicker(false);
                            if (date) setStartTime(date);
                        }}
                        onCancel={()=>setShowStartPicker(false)}
                    />
                )}
                {showEndPicker && (
                    <DatePicker
                        modal
                        open={showEndPicker}
                        date={endTime}
                        mode="time"
                        onConfirm={( date?: Date) => {
                            setShowEndPicker(false);
                            if (date) setEndTime(date);
                        }}
                        onCancel={()=>setShowEndPicker(false)}
                    />
                )}
            </View>
        </Modal>
    )
}

export const EditBusinessHoursModal = observer(Component)


interface TimeDisplayProps {
    time: Date;
}

const TimeDisplay = ({ time }: TimeDisplayProps) => {
    const styles = useStyles()

    const hours = time.getHours() % 12 || 12; // 12-hour format
    const minutes = time.getMinutes().toString().padStart(2, "0"); // Ensure two digits
    const ampm = time.getHours() >= 12 ? "PM" : "AM"; // AM or PM

    return (
        <View style={{flexDirection:"row", justifyContent:"center", alignItems:"flex-end", gap:16}} >
            <Typography style={styles.timeText}>
                {hours}:{minutes}
            </Typography>
            <Typography style={styles.hourText}>
                {ampm}
            </Typography>
        </View>
    );
};
