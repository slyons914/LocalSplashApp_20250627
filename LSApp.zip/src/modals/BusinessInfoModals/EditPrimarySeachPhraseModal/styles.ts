import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: colors.background,
    maxHeight: height * 0.9,
    minHeight: height * 0.8,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    gap: 16,
    overflow: "hidden",
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
    alignSelf: "center",
  },
  header:{
    marginTop:8,
    flexDirection:"row",
    justifyContent: "space-between",
    borderBottomWidth:1,
    borderBottomColor:colors.grey,
    paddingBottom:8,
    alignItems:"center",
    marginBottom:18,
    padding: 16,
  },
  headerItem:{
    color:colors.orangePrimary,
    fontWeight:"500",
    fontSize:16
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
  },
  city: {
    alignSelf: "flex-end",
  },
  spinner: {
    flex: 1,
  },
  phraseContainer: {
    padding:16
  }
}))
