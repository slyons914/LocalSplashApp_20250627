import { useEffect, useState } from "react"

import { ActivityIndicator, View } from "react-native"

import { observer } from "mobx-react-lite"
import Modal from "react-native-modal"
import { Typography } from "@components"
import { useStyles } from "./styles"
import { AvailableCategory } from "@models/settings"
import { useStore } from "@store"
import { SearchPhraseDropdown } from "../../../screens/PrimarySearchPhrase/SearchPhraseDropdown"
import { colors } from "@utils/constants"

interface Props {
    isVisible: boolean
    onClose: () => void
}

const Component = ({ isVisible, onClose }: Props) => {
    const styles = useStyles()
    const { businessInfoStore, homeStore } = useStore()
    const { locationsItem, locationsIndex, getProfiles, setLocationsItem } = homeStore
    const { availableCategories, getAvailableCategories, isLoading, changeAvailableCategories } = businessInfoStore
  
    const [value, setValue] = useState(locationsItem?.title)
    const [selectedItem, setSelectedItem] = useState<AvailableCategory | null>(null)
    const [customTitle, setCustomTitle] = useState("")

    const onSubmit = async () => {
        if (locationsItem !== null && locationsItem.id && selectedItem !== null && selectedItem.id) {
          customTitle.length > 0 &&
            await changeAvailableCategories(locationsItem.id, selectedItem!.id, customTitle)
          !customTitle && await changeAvailableCategories(locationsItem.id, selectedItem!.id)
          const updatedProfiles = await getProfiles()
          if(updatedProfiles?.profiles) {
            setLocationsItem(updatedProfiles?.profiles[locationsIndex])
          }
        }
        onClose()
    }

    useEffect(()=> {
        getAvailableCategories()
    },[])
    return (
        <Modal
            isVisible={isVisible}
            onBackdropPress={onClose}
            onBackButtonPress={onClose}
            style={styles.modal}
            avoidKeyboard
            animationIn={"slideInUp"}
            animationOut={"slideOutDown"}
            useNativeDriver={true}
            propagateSwipe
        >
            <View style={styles.container}>
                <View style={styles.dash} />
                    <View style={styles.header}>
                        <Typography onPress={onClose} style={styles.headerItem}>cancel</Typography>
                        <Typography style={styles.title}>Primary Search Phrase</Typography>
                        <Typography onPress={onSubmit} style={styles.headerItem}>Save</Typography>
                    </View>
                {locationsItem && !isLoading ? (
                    <View style={styles.phraseContainer}>
                        <Typography
                            style={styles.city}
                        >{`${locationsItem.city} ${locationsItem.state}`}</Typography>
                        {availableCategories && value && (
                            <SearchPhraseDropdown
                                data={availableCategories}
                                value={value}
                                setValue={setValue}
                                setSelectedItem={setSelectedItem}
                                setCustomTitle={setCustomTitle}
                                customTitle={customTitle}
                            />
                        )}
                    </View>
                ) : (
                    <ActivityIndicator
                        color={colors.common.orangePrimary}
                        style={styles.spinner}
                        size={"large"}
                    />
                )}
            </View>
        </Modal>
    )
}

export const EditPrimarySeachPhrase = observer(Component)
