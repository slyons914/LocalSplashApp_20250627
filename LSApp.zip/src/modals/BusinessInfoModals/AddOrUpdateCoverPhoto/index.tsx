import { ActivityIndicator, Image, Pressable, useColorScheme, View } from "react-native"

import { observer } from "mobx-react-lite"
import Modal from "react-native-modal"


import { useStyles } from "./styles"
import { Icon, Typography } from "@components"
import { backIconHitSlope } from "@utils/constants/common"
import { useEffect, useState } from "react"
import { useStore } from "@store"
import { BusinessInfoAPI } from "@api"
import { colors } from "@utils/constants"
import { AddImageModal } from "@modals/AddImageModal"
import { showToast } from "@utils/helpers/common"
import { validateMediaFile } from "@utils/helpers/imagePicker"

interface Props {
  isVisible: boolean
  onClose: () => void
  imageUrl: string | null
}

const Component = ({ isVisible, onClose, imageUrl }: Props) => {
  const styles = useStyles()

  const systemColorScheme  = useColorScheme()
  const isLightTheme = systemColorScheme === "light"

  const { homeStore, businessInfoStore }  = useStore()
  const { locationsItem } = homeStore
  const { getCoverPhoto } = businessInfoStore

  const [coverPhoto, setCoverPhoto] = useState(imageUrl)
  const [isLoading, setIsLoading] = useState(false)
  const [isAddImageModalVisible, setIsAddImageModalVisible] = useState(false)
  const [isImageLoading, setIsImageLoading] = useState(false)

  useEffect(()=> {
    setCoverPhoto(imageUrl)
  },[imageUrl])

  const onImageSelect = async (uri:string, filename:string, type:string, width: number | undefined, height: number | undefined) => {
    setIsLoading(true)
    const validationResponse = await validateMediaFile(uri, type, true, 400, 266, 30, width ?? 0, height ?? 0)
    if(!validationResponse.valid) {
        showToast(validationResponse?.error ?? '')
        setIsLoading(false)
        return;
    }
    const data = new FormData ()
    data.append("File" , {
        uri:uri,
        type:type,
        name:filename
    })
    if(!locationsItem?.id)
        return;
    setCoverPhoto(uri)
    await BusinessInfoAPI.updateOrAddCoverPhoto(locationsItem?.id, data)
    await getCoverPhoto(locationsItem?.id)
    setIsLoading(false)
    onClose()
  }

  const onIconDelete = async () => {
    if(!locationsItem?.id || !coverPhoto) return;
    try {
        await BusinessInfoAPI.deleteCoverPhoto(locationsItem?.id, coverPhoto)
        await getCoverPhoto(locationsItem?.id)
        onClose()
    } catch {

    }
  }

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      onSwipeComplete={onClose}
      style={styles.modal}
      avoidKeyboard
      animationIn={"slideInUp"}
      animationOut={"slideOutDown"}
      swipeDirection={["down"]}
      propagateSwipe
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <View style={styles.header}>
            <Pressable hitSlop={backIconHitSlope} onPress={onClose}>
                <Icon name={ !isLightTheme ? "bacIconWhite" :"backIcon"} />
            </Pressable>
            <Typography style={styles.title}>Cover Photo</Typography>
            <Pressable onPress={onIconDelete}>
                <Icon name="trashOrange" />
            </Pressable>
        </View>
        <View style={styles.mainView}>
            <View style={styles.imageView}>
                {
                    coverPhoto? (
                        <Image onLoadStart={() => setIsImageLoading(true)} onLoadEnd={() => setIsImageLoading(false)} style={styles.image} source={{uri:`https://mobileapi.localsplash.com/MediaThumbnails/${encodeURIComponent(coverPhoto)}?height=300`}} />
                        
                    ) : (
                        <View style={styles.changeLogoView}>
                            <Icon name="OrangeAddIcon" />
                            <Typography style={styles.changeLogoText}>Add Cover Photo</Typography>
                        </View>
                    )
                }
                {
                    isImageLoading && <ActivityIndicator size={"large"} color={colors.common.orangePrimary} style={styles.loader}></ActivityIndicator>
                }
            </View>
            {
                coverPhoto && !isLoading &&
                <Pressable onPress={()=> setIsAddImageModalVisible(true)} style={styles.changeLogoView}>
                    <Icon name="changeOrange" />
                    <Typography style={styles.changeLogoText}>Change Cover Photo</Typography>
                </Pressable>
            }  
            { 
                isLoading && 
                <View style={styles.changeLogoView}>
                    <ActivityIndicator size={"large"} color={colors.common.orangePrimary}></ActivityIndicator>
                </View>
            }
        </View>

      </View>
      <AddImageModal onImageSelect={onImageSelect} isVisible={isAddImageModalVisible} onClose={() => setIsAddImageModalVisible(false)} />
    </Modal>
  )
}

export const AddOrUpdateCoverPhotoModal = observer(Component)
