import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height }) => ({
  modal: {
    margin: 0,
    marginTop: 40,
  },
  container: {
    backgroundColor: colors.background,
    minHeight: height * 0.96,
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    paddingBottom: 24,
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
    alignSelf: "center",
  },
  header:{
    marginTop:8,
    flexDirection:"row",
    justifyContent: "space-between",
    borderBottomWidth:1,
    borderBottomColor:colors.grey,
    paddingBottom:8,
    alignItems:"center",
    marginBottom:18,
    padding: 16,
  },
  headerItem:{
    color:colors.orangePrimary,
    fontWeight:"500",
    fontSize:16
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
  },
  mainView: {
    padding:16,
    alignItems:"center",
    gap:48
  },
  imageView: {
    height:"80%",
    width:"100%",
    borderRadius: 8,
    borderWidth: 1,
    borderColor:colors.gray6,
    justifyContent:"center",
    alignItems:"center"
  },
  changeLogoView: {
    flexDirection:"row",
    gap:8
  },
  changeLogoText: {
    color: colors.orangePrimary,
    fontWeight:"500",
    fontSize:16
  },
  image: {
    height:"100%",
    width:"100%",
    resizeMode: "contain"
  },
  loader: {
    position: "absolute"
  }
}))
