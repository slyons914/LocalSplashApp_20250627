import { ActivityIndicator, Image, Pressable, useColorScheme, View } from "react-native"
import Modal from "react-native-modal"
import { useStyles } from "./styles"
import { Icon, Typography } from "@components"
import { backIconHitSlope } from "@utils/constants/common"
import { useState } from "react"
import { colors } from "@utils/constants"
import { MediaViewModel } from "@localsplash/mobile-api-client"
import { useStore } from "@store"
import { BusinessInfoAPI } from "@api"
import Pdf from "react-native-pdf"


interface Props {
    isVisible?: boolean
    onClose?: () => void
    imageUrl: string,
    imageList: MediaViewModel [] | undefined,
    imageIndex: number,
    setCurrentImage: (val:string) => void,
    setCurrentImageIndex: (val:number) => void
    type: string,
}

export const BusinessPhotoDetailModal = ({
    isVisible,
    onClose = () => { },
    imageUrl,
    imageList,
    imageIndex,
    setCurrentImage,
    setCurrentImageIndex,
    type,
}: Props) => {

    const systemColorScheme = useColorScheme()
    const styles = useStyles()

    const isLightTheme = systemColorScheme === "light"

    const [isImageLoading, setIsImageLoading] = useState(false)
    const [isDeleting, setIsDeleting] = useState(false)

    const { homeStore, businessInfoStore } = useStore()
    const { locationsItem } = homeStore
    const { getBusinessPhotos, getBusinessDocuments } = businessInfoStore

    const isPdf = imageUrl?.includes('.pdf');

    const onNextPress = () => {
        if(!imageList) return
        if(imageIndex + 1 < imageList.length ) {
            setCurrentImage(imageList[imageIndex + 1]?.mediaUrl ?? "")
            setCurrentImageIndex(imageIndex + 1)
        }
    }

    const onBackPress = () => {
        if(!imageList) return
        if(imageIndex > 0 ) {
            setCurrentImage(imageList[imageIndex - 1]?.mediaUrl ?? "")
            setCurrentImageIndex(imageIndex - 1)
        }
    }

    const onDeletePress = async () => {
        setIsDeleting(true)
        const selectedImage = [imageUrl]
        
        if(!locationsItem?.id) return
        try {
            if(type === 'Business Photo') {
                await BusinessInfoAPI.deleteBusinessImages(locationsItem?.id, selectedImage)
                await getBusinessPhotos(locationsItem?.id)
                onClose()
            } else {
                await BusinessInfoAPI.deleteBusinesDocuments(locationsItem?.id, selectedImage)
                await getBusinessDocuments(locationsItem?.id)
                onClose()
            }
        } catch {
            console.log("Error deleting Images")
            setIsDeleting(false)
            onClose()
        }
        setIsDeleting(false)

    }
    return (
        <Modal
            isVisible={isVisible}
            style={styles.modal}
            onBackButtonPress={onClose}
            onBackdropPress={onClose}
            animationIn={"slideInUp"}
            animationOut={"slideOutDown"}
        >
            <View style={styles.container}>
            <View style={styles.dash} />
                <View style={styles.headerView}>
                    <Pressable onPress={onClose}  style={styles.icon} hitSlop={backIconHitSlope}>
                        <Icon name={isLightTheme ? "backIcon" : "bacIconWhite"}></Icon>
                    </Pressable>
                    <Typography style={styles.headerTitle}>{type}</Typography>
                    <Pressable hitSlop={backIconHitSlope} onPress={onDeletePress}>
                    {
                        isDeleting ? (
                            <View>
                                <ActivityIndicator size={"small"} color={colors.common.orangePrimary} />
                            </View>
                        ) : (
                            <Icon name="trashOrange"></Icon>
                        )
                    }
                    </Pressable>
                </View>
                {
                    isPdf ? (
                        <View style={styles.imageView}>
                            <Pdf 
                                source={{uri:imageUrl, cache:true}}  
                                style={styles.pdf}/>
                        </View>
                    ) : (
                        <View style={styles.imageView}>
                            <Image 
                                style={styles.image} 
                                source={{uri: `https://mobileapi.localsplash.com/MediaThumbnails/${encodeURIComponent(imageUrl)}?height=300`}} 
                                onLoadStart={() => setIsImageLoading(true)}
                                onLoadEnd={() => setIsImageLoading(false)}
                                resizeMode="contain"
                            /> 
                            {isImageLoading && <ActivityIndicator color={colors.common.orangePrimary} style={styles.imageLoader} size={"large"}/>}
                        </View>
                    )
                }
                <View style={styles.buttonView}>
                    <Pressable onPress={onBackPress}>
                        <Icon name={"photoLeft"}></Icon>
                    </Pressable>
                    <Typography>{imageIndex + 1}/{imageList?.length}</Typography>
                    <Pressable onPress={onNextPress}>
                        <Icon name={"photoRight"}></Icon>
                    </Pressable>
                </View>
            </View>
        </Modal>

    )
}

