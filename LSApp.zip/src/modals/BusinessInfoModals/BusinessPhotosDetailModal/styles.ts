import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height, width, insets }) => ({
    keyboardAvoidingView: {
        overflow: "hidden",
    },
    container: {
        height:height - (insets.top + 20),
        backgroundColor: colors.background,
        borderTopLeftRadius: 40,
        borderTopRightRadius: 40,
        marginTop: 20,
    },
    modal: {
        margin: 0,
        justifyContent:"flex-end"
    },
    icon:{
        paddingVertical:12,
        paddingLeft:12
    },
    image: {
        height:"80%",
        width:"100%",
        resizeMode:"cover"
    },
    imageView: {
        height:"70%",
        width:"90%",
        borderWidth: 1,
        borderColor: colors.gray6,
        justifyContent:"center",
        alignSelf:"center"
    },
    imageLoader: {
        color:colors.orangePrimary,
        bottom:"45%",
        left: "45%",
        position:"absolute"
    },
    headerView: {
        justifyContent: "space-between",
        flexDirection:"row",
        alignItems:"center",
        padding:16,
    },
    headerTitle: {
        fontWeight: "500",
        fontSize: 16
    },
    dash: {
        backgroundColor: colors.grey,
        height: 5,
        width: 36,
        borderRadius: 20,
        top: 5,
        alignSelf: "center",
    },
    buttonView: {
        flexDirection: "row",
        justifyContent:"center",
        gap:16,
        marginTop:16
    },
    pdf: {
        flex: 1,
        width: '100%',
        height: '100%',
    },
}))
