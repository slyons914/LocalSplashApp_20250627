import { ActivityIndicator, Image, Pressable, useColorScheme, View } from "react-native"

import { observer } from "mobx-react-lite"
import Modal from "react-native-modal"


import { useStyles } from "./styles"
import { Icon, Typography } from "@components"
import { backIconHitSlope } from "@utils/constants/common"
import { useEffect, useState } from "react"
import { AddImageModal } from "@modals/AddImageModal"
import { BusinessInfoAPI } from "@api"
import { useStore } from "@store"
import { colors } from "@utils/constants"
import { validateMediaFile } from "@utils/helpers/imagePicker"
import { showToast } from "@utils/helpers/common"

interface Props {
  isVisible: boolean
  onClose: () => void
  imageUrl: string | null
}

const Component = ({ isVisible, onClose, imageUrl }: Props) => {
  const styles = useStyles()

  const systemColorScheme  = useColorScheme()
  const isLightTheme = systemColorScheme === "light"

  const { homeStore, businessInfoStore }  = useStore()
  const { locationsItem } = homeStore
  const { getLogo } = businessInfoStore

  const [logo, setLogo] = useState(imageUrl)
  const [isAddImageModalVisible, setIsAddImageModalVisible] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [isImageLoading, setIsImageLoading] = useState(false)

  useEffect(()=> {
    setLogo(imageUrl)
  },[imageUrl])

  const onModalClose = () => {
    setIsAddImageModalVisible(false)
    onClose()
  }

  const onImageSelect = async (uri:string, filename:string, type:string, width: number | undefined, height: number | undefined) => {
    setIsLoading(true)
    const data = new FormData ()
    const validationResponse = await validateMediaFile(uri, type, true, 250, 250, 10, width ?? 0, height ?? 0)
    if(!validationResponse.valid) {
        showToast(validationResponse?.error ?? '')
        setIsLoading(false)
        return;
    }
    data.append("File" , {
        uri:uri,
        type:type,
        name:filename
    })
    if(!locationsItem?.id)
        return;
    setLogo(uri)
    await BusinessInfoAPI.updateOrAddLogo(locationsItem?.id, data)
    await getLogo(locationsItem?.id)
    setIsLoading(false)
    onClose()
  }

  const onIconDelete = async () => {
    if(!locationsItem?.id || !logo) return;
    try {
        await BusinessInfoAPI.deleteLogo(locationsItem?.id, logo)
        await getLogo(locationsItem?.id)
        onClose()
    } catch {

    }
  }
  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onModalClose}
      onBackButtonPress={onModalClose}
      onSwipeComplete={onModalClose}
      style={styles.modal}
      avoidKeyboard
      animationIn={"slideInUp"}
      animationOut={"slideOutDown"}
      swipeDirection={["down"]}
      propagateSwipe
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <View style={styles.header}>
            <Pressable hitSlop={backIconHitSlope} onPress={onModalClose}>
                <Icon name={ !isLightTheme ? "bacIconWhite" :"backIcon"} />
            </Pressable>
            <Typography style={styles.title}>Logo</Typography>
            <Pressable onPress={onIconDelete}>
                <Icon name="trashOrange" />
            </Pressable>
        </View>
        <View style={styles.mainView}>
            <View style={styles.imageView}>
                {
                    logo? (
                        <Image onLoadStart={() => setIsImageLoading(true)} onLoadEnd={() => setIsImageLoading(false)} style={styles.image} source={{uri:`https://mobileapi.localsplash.com/MediaThumbnails/${encodeURIComponent(logo)}?height=300`}} />
                    ) : (
                        <View style={styles.changeLogoView}>
                            <Icon name="OrangeAddIcon" />
                            <Typography style={styles.changeLogoText}>Add Logo</Typography>
                        </View>
                    )
                }
                {
                    isImageLoading && <ActivityIndicator size={"large"} color={colors.common.orangePrimary} style={styles.loader}></ActivityIndicator>
                }
            </View>
            {
                logo && !isLoading &&
                <Pressable onPress={()=> setIsAddImageModalVisible(true)} style={styles.changeLogoView}>
                    <Icon name="changeOrange" />
                    <Typography style={styles.changeLogoText}>Change Logo</Typography>
                </Pressable>
            }  
            { 
                isLoading && 
                <View style={styles.changeLogoView}>
                    <ActivityIndicator size={"large"} color={colors.common.orangePrimary}></ActivityIndicator>
                </View>
            }
        </View>
        <AddImageModal onImageSelect={onImageSelect} isVisible={isAddImageModalVisible} onClose={() => setIsAddImageModalVisible(false)} />
      </View>
    </Modal>
  )
}

export const AddOrUpdateLogoModal = observer(Component)
