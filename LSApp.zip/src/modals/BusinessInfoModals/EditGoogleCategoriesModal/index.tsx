import { useState } from "react"

import { ScrollView, TouchableOpacity, useColorScheme, View } from "react-native"

import { observer } from "mobx-react-lite"
import Modal from "react-native-modal"

import { BusinessInfoAPI } from "@api"
import { Icon, SimpleHeader, Typography } from "@components"
import { AvailableGoogleCategory } from "@models/settings"
import { useStore } from "@store"
import { useColors } from "@utils/hooks"

import { CategoiesInput } from "./CategoriesInput"
import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
}

const Component = ({ isVisible, onClose }: Props) => {
  const styles = useStyles()
  const { text } = useColors()

  const { businessInfoStore, homeStore } = useStore()
  const { locationsItem } = homeStore
  const { availableGoogleCategories, profileGoogleCategories, getProfileGoogleCategories } =
    businessInfoStore

  const [profileCategories, setProfileCategories] = useState(
    profileGoogleCategories?.googleCategories,
  )

  const [selectedItem, setSelectedItem] = useState<AvailableGoogleCategory | null>(null)
  const [categoryName, setCategoryName] = useState<string>("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string>("")

  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"
  
  const onModalWillShow = () => {
    if (!profileGoogleCategories) return
    setCategoryName("")
    setProfileCategories(profileGoogleCategories.googleCategories)
  }

  const onSubmit = async () => {
    setIsLoading(true)
    const id = locationsItem?.id
    if (!id || !profileCategories) return
    const { data, error } = await BusinessInfoAPI.changeProfileGoogleCategories(id, {
      googleCategories: profileCategories,
    })
    if (data === true) {
      onClose()
      getProfileGoogleCategories(id)
    } else if (error) {
      setError(error.GoogleCategories[0])
    }
    setIsLoading(false)
  }

  const onAddItem = (selectedItem: AvailableGoogleCategory) => {
    if (!selectedItem || !categoryName) return
    setProfileCategories((prev) => {
      if (!prev) return
      return [...prev, selectedItem.name]
    })
    setCategoryName("")
    setSelectedItem(null)
  }

  const onDeleteItem = (index: number) => {
    setProfileCategories((prev) => {
      if (!prev) return prev
      const updatedCategories = [...prev]
      updatedCategories.splice(index, 1)
      return updatedCategories
    })
    setError("")
  }

  const renderItem = (item: string, index: number) => {
    return (
      <View key={item + index} style={styles.itemContainer}>
        <View style={styles.itemName}>
          <Icon name="googelCategory" stroke={text} />
          <Typography style={styles.itemText}>{item}</Typography>
        </View>
        <TouchableOpacity onPress={() => onDeleteItem(index)}>
          <Icon name={isLightTheme? "deleteIcon" : "trashDark"}stroke={text} />
        </TouchableOpacity>
      </View>
    )
  }

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      onModalWillShow={onModalWillShow}
      style={styles.modal}
      avoidKeyboard
      animationIn={"slideInUp"}
      animationOut={"slideOutDown"}
      useNativeDriver={true}
      propagateSwipe
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <SimpleHeader
          onLeftPress={onClose}
          onRightPress={onSubmit}
          rightText={"Save"}
          isRightVisible
          title={"Edit Google Categories"}
          isLoading={isLoading}
        />
        <ScrollView
          contentContainerStyle={styles.list}
          keyboardShouldPersistTaps={"always"}
          bounces={false}
          showsVerticalScrollIndicator={false}
        >
          <Typography style={styles.warningText}>
            Changes to your core business information such as business name, address, phone number
            or Google Categories could possibly trigger a PIN re-verification process through
            Google.
          </Typography>
          <Typography style={styles.categories}>Google Categories</Typography>
          {profileCategories && profileCategories.map((item, index) => renderItem(item, index))}
        </ScrollView>
        {availableGoogleCategories && (
          <CategoiesInput
            data={availableGoogleCategories}
            setSelectedItem={setSelectedItem}
            value={categoryName}
            setValue={setCategoryName}
          />
        )}
        {error && <Typography style={styles.error}>{error}</Typography>}
        <TouchableOpacity onPress={() => onAddItem(selectedItem!)} style={styles.addBtn}>
          <Icon name="addCircle" />
          <Typography style={styles.addBtnText}>Add Category</Typography>
        </TouchableOpacity>
      </View>
    </Modal>
  )
}

export const EditGoogleCategoriesModal = observer(Component)
