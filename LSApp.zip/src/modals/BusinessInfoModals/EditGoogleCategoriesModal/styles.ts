import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: colors.background,
    maxHeight: height * 0.97,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    padding: 16,
    gap: 16,
    overflow: "hidden",
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
    alignSelf: "center",
  },
  warningText: {
    color: colors.red,
    backgroundColor: colors.warningBackground,
    borderRadius: 16,
    padding: 10,
    overflow: "hidden",
  },
  categories: {
    color: colors.subText,
  },
  list: {
    gap: 8,
  },
  itemContainer: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderRadius: 8,
    borderColor: colors.gray6,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  itemText: {
    textAlign: "justify",
    fontSize: 16,
  },
  itemName: {
    flexDirection: "row",
    gap: 10,
  },
  addBtn: {
    flexDirection: "row",
    gap: 8,
    padding: 10,
    alignItems: "center",
  },
  addBtnText: {
    color: colors.orangePrimary,
  },
  error: {
    color: colors.red,
    textAlign: "center",
  },
}))
