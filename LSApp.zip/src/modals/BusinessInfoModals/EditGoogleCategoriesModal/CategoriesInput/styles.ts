import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    gap: 10,
    flexDirection: "row",
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: colors.gray6,
    borderRadius: 8,
    alignItems: "center",
  },
  textInput: {
    color: colors.text,
    padding: 0,
    fontSize: 16,
  },
  listContainer: {
    height: 200,
    borderWidth: 1,
    borderColor: colors.backgroundSecondary,
    borderRadius: 8,
  },
  list: {
    backgroundColor: colors.background,
  },
  listItem: {
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  separator: {
    borderWidth: 1,
    borderColor: colors.backgroundSecondary,
  },
  emptyList: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    alignSelf: "center",
  },
}))
