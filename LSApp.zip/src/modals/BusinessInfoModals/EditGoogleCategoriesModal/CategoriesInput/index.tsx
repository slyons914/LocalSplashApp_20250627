import { useState } from "react"

import { Keyboard, Pressable, TextInput, TouchableOpacity, View } from "react-native"

import { FlashList } from "@shopify/flash-list"

import { Icon, Typography } from "@components"
import { AvailableGoogleCategories, AvailableGoogleCategory } from "@models/settings"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"

interface Props {
  data: AvailableGoogleCategories
  setSelectedItem: (item: AvailableGoogleCategory) => void
  value: string
  setValue: (text: string) => void
}

export const CategoiesInput = ({ data, setSelectedItem, value, setValue }: Props) => {
  const styles = useStyles()
  const { text } = useColors()

  const [isExpanded, setIsExpanded] = useState(false)

  const onItemPress = (item: AvailableGoogleCategory) => {
    setValue(item.name)
    setSelectedItem(item)
    setIsExpanded(!isExpanded)
    Keyboard.dismiss()
  }

  const renderItem = ({ item }: { item: AvailableGoogleCategory }) => {
    return (
      <TouchableOpacity style={styles.listItem} onPress={() => onItemPress(item)}>
        <Typography>{item.name}</Typography>
      </TouchableOpacity>
    )
  }
  const itemSeparator = () => {
    return <View style={styles.separator} />
  }

  const onInputPress = () => {
    setIsExpanded(!isExpanded)
  }

  const filteredCategories = data.googleCategories.filter((category) =>
    category.name.toLowerCase().includes(value.toLowerCase()),
  )

  const listEmptyComponent = () => {
    return (
      <View style={styles.emptyList}>
        <Typography>No categoies found</Typography>
      </View>
    )
  }

  return (
    <>
      <Pressable style={styles.container}>
        <Icon name="googelCategory" />
        <TextInput
          style={styles.textInput}
          placeholder={"Start typing to see category"}
          placeholderTextColor={text}
          value={value}
          onChangeText={setValue}
          onPressOut={onInputPress}
        />
      </Pressable>
      {isExpanded && (
        <View style={styles.listContainer}>
          <FlashList
            contentContainerStyle={styles.list}
            data={filteredCategories}
            renderItem={renderItem}
            ItemSeparatorComponent={itemSeparator}
            estimatedItemSize={50}
            ListEmptyComponent={listEmptyComponent}
            keyboardShouldPersistTaps={"handled"}
          />
        </View>
      )}
    </>
  )
}
