import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height }) => ({
  modal: {
    margin: 0,
    justifyContent:"flex-end"
  },
  container: {
    maxHeight: height * 0.9,
    minHeight: height * 0.9,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    paddingBottom: 24,
    backgroundColor: colors.background,
    flex:1
  },
  scrollContainer: {
    gap: 16,
    padding: 16,
    flex:1,
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
    alignSelf: "center",
  },
  header:{
    marginTop:8,
    flexDirection:"row",
    justifyContent: "space-between",
    borderBottomWidth:1,
    borderBottomColor:colors.grey,
    paddingBottom:8,
    alignItems:"center",
    marginBottom:18,
    padding: 16,
  },
  headerItem:{
    color:colors.orangePrimary,
    fontWeight:"500",
    fontSize:16
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
  },
  methodView: {
    flex:1
  },
  methodText: {
    color: colors.subText,
    width:"90%"
  },
  methodItem: {
    paddingVertical:6,
    paddingHorizontal:28,
    alignContent:"center",
    borderWidth:1,
    borderRadius:8,
    borderColor:colors.gray6
  },
  methodItemView: {
    paddingVertical: 8,
    flexDirection:"row",
    justifyContent:"space-between",
    alignItems:"center"
  },
  methodItemText: {
  },
  selectedItem: {
    backgroundColor:colors.blue
  },
  selectedItemText: {
    color:colors.white
  },
  serviceHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap:8
  }
}))
