import { ActivityIndicator, Alert, FlatList, Pressable, View } from "react-native"

import { Icon, Typography } from "@components"
import { useStore } from "@store"

import Modal from "react-native-modal"

import { useStyles } from "./styles"
import { observer } from "mobx-react-lite"
import { useEffect, useState } from "react"
import { IProfileServiceAreaViewModel } from "@localsplash/mobile-api-client"
import { BusinessInfoAPI } from "@api"
import { colors } from "@utils/constants"

interface Props {
    isVisible: boolean
    onClose: () => void
}

const Component = ({ isVisible, onClose, }: Props) => {
    const styles = useStyles()

    const [serviceAreasList, setServiceAreasList] = useState<IProfileServiceAreaViewModel[] | null>(null)
    const [isLoading, setIsLoading] = useState(false)

    const { homeStore, businessInfoStore } = useStore()
    const { locationsItem } = homeStore
    const { getServiceAreas, serviceAreas  } = businessInfoStore
    const closeModal = () => {
        setIsLoading(false)
        onClose()
    }


    const setGbpSync = (placeId: string, isSync: boolean) => {
        setServiceAreasList((prevServiceAreas) =>
          (prevServiceAreas || []).map((area) =>
            area.serviceAreaPlaceId === placeId
              ? { ...area, isGbpSync: isSync } 
              : area
          )
        );
      };
    
      const setAdsSync = (placeId: string, isSync: boolean) => {
        setServiceAreasList((prevServiceAreas) =>
          (prevServiceAreas || []).map((area) =>
            area.serviceAreaPlaceId === placeId
              ? { ...area, isAdsSync: isSync }
              : area
          )
        );
      };

    const onSavePress = async() => {
        if(!serviceAreasList || !locationsItem?.id) {
            closeModal()
            return
        }
        setIsLoading(true)
        for (const area of serviceAreasList) {
            try {
                await BusinessInfoAPI.postServiceAreas(locationsItem?.id, area)
            }
            catch {
                console.log("Error while Adding Service Areas")
                setIsLoading(false)
                closeModal()
            }
        }
        await getServiceAreas(locationsItem?.id)
        setIsLoading(false)
        closeModal()
    }

    const onItemDelete = async (item: IProfileServiceAreaViewModel) => {
        if(!locationsItem?.id)
            return
        try {
            await BusinessInfoAPI.deleteServiceArea(locationsItem?.id, item)
            await getServiceAreas(locationsItem?.id)
        }
        catch {
            console.log("Error while deleting Service Areas")
        }
    }

    const showDeleteAlert = (item: IProfileServiceAreaViewModel) => {
        Alert.alert(
            `Are you sure you want to delete `,
            `"${item.serviceAreaName}" from Service Area?`,
            [
              {
                text: "Cancel",
                onPress: () => console.log("cancelled"),
                style: 'cancel'
              },
              {
                text: "Delete",
                onPress: () => onItemDelete(item),
              },
            ],
          )
    }
    
    const renderItem = ({ item }: { item: IProfileServiceAreaViewModel }) => (
        <Pressable style={styles.methodView}>
            <View style={styles.serviceHeader}>
                <Typography style={styles.methodText}>
                    {item?.serviceAreaName}
                </Typography>
                <Pressable onPress={() => showDeleteAlert(item)}>
                    <Icon name="redTrashIcon" />
                </Pressable>
            </View>
            <Pressable style={styles.methodItemView}>
                <Pressable style={[styles.methodItem, styles.selectedItem]}>
                    <Typography style={[styles.methodItemText, styles.selectedItemText]}>Website</Typography>
                </Pressable>
                <Pressable
                    onPress={() => setGbpSync(item.serviceAreaPlaceId ?? '', !item.isGbpSync)}
                    style={[styles.methodItem, item.isGbpSync && styles.selectedItem]}
                >
                    <Typography style={[styles.methodItemText, item.isGbpSync && styles.selectedItemText]}>Google</Typography>
                </Pressable>
                <Pressable
                    onPress={() => setAdsSync(item.serviceAreaPlaceId ?? '', !item.isAdsSync)}
                    style={[styles.methodItem, item.isAdsSync && styles.selectedItem]}
                >
                    <Typography style={[styles.methodItemText, item.isAdsSync && styles.selectedItemText]}>Ads</Typography>
                </Pressable>
            </Pressable>
        </Pressable>
    );

    useEffect(() => {
        setServiceAreasList(serviceAreas?.serviceAreas ?? null)
    }, [serviceAreas])

    return (
        <Modal
            isVisible={isVisible}
            onBackdropPress={closeModal}
            onBackButtonPress={closeModal}
            onSwipeComplete={closeModal}
            style={styles.modal}
            animationIn={"slideInUp"}
            animationOut={"slideOutDown"}
            swipeDirection={["down"]}
            propagateSwipe
        >
            <View style={styles.container}>
                <View style={styles.dash} />
                <View style={styles.header}>
                    <Typography onPress={closeModal} style={styles.headerItem}>Cancel</Typography>
                    <Typography style={styles.title}>Service Area</Typography>
                    {
                        isLoading ? ( <ActivityIndicator size={"small"} color={colors.common.orangePrimary}></ActivityIndicator> ) : (
                            <Typography onPress={onSavePress} style={styles.headerItem}>Save</Typography>
                        )
                    }
                </View>
                <FlatList
                    data={serviceAreasList}
                    renderItem={renderItem}
                    keyExtractor={(item, index) => item?.serviceAreaPlaceId ?? index.toString()}  // Key for each list item
                    showsVerticalScrollIndicator={false}
                    style={styles.scrollContainer}

                />
            </View>
        </Modal>
    )
}

export const UpdateServiceAreaModal = observer(Component)

