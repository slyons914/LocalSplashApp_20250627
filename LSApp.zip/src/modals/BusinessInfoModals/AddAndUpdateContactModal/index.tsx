import { useState } from "react"
import { Pressable, ScrollView, View } from "react-native"

import { Button, Input, Typography } from "@components"
import { useStore } from "@store"

import Modal from "react-native-modal"

import { useStyles } from "./styles"
import { observer } from "mobx-react-lite"
import { Formik } from "formik"
import { AddContactSchema, addContactSchema } from "./validationSchema"
import { ICreateOrUpdateContactRequestViewModel } from "@localsplash/mobile-api-client"
import { BusinessInfoAPI } from "@api"
import { Contact } from "@models/settings"

interface Props {
    isVisible: boolean
    onClose: () => void
    contactItem: Contact | null
    type: "edit" | "add"
    contactTypeId: number | null
    setContactTypeId: (val: number | null) => void
}

const Component = ({ isVisible, onClose, contactItem, type, contactTypeId, setContactTypeId }: Props) => {
    const styles = useStyles()

    const { businessInfoStore } = useStore()
    const { getContacts } = businessInfoStore

    const handleSelectedItemChange = (value: number) => {
        setContactTypeId(value)
    }

    const closeModal = () => {
        setContactTypeId(null)
        onClose()
    }

    const deleteContact = async () => {
        if(!contactItem)
            return
        try {
            await BusinessInfoAPI.deleteContact(contactItem?.id)
            getContacts()
            onClose()
        } catch {
            onClose()
        }
    }

    const onSubmit = async (values: AddContactSchema) => {
        const contactObject: ICreateOrUpdateContactRequestViewModel = {
            title: values.title || undefined,
            name: values.name || undefined,
            phoneNumber: values.phoneNumber || undefined,
            phoneExtension: values.phoneExtension ? parseInt(values.phoneExtension) : undefined, 
            emailAddress: values.emailAddress || undefined,
            notes: values.notes || undefined, 
            contactTypeId: contactTypeId? contactTypeId : undefined,
          };
          if(type === "add") {
            try { 
                await BusinessInfoAPI.AddContact(contactObject)
                getContacts()
                onClose()
            } catch {
                onClose()
            }
        } else {
            if(!contactItem)
                return
            try { 
                await BusinessInfoAPI.editContact(contactItem?.id, contactObject)
                getContacts()
                onClose()
            } catch {
                onClose()
            }
        }
    }

    return (
        <Modal
            isVisible={isVisible}
            onBackdropPress={closeModal}
            onBackButtonPress={closeModal}
            onSwipeComplete={closeModal}
            style={styles.modal}
            avoidKeyboard
            animationIn={"slideInUp"}
            animationOut={"slideOutDown"}
            swipeDirection={["down"]}
            propagateSwipe
        >
            <Formik
                validationSchema={addContactSchema}
                initialValues={{ emailAddress: contactItem?.emailAddress, notes: contactItem?.notes, title: contactItem?.title, name: contactItem?.name, phoneNumber: contactItem?.phoneNumber, phoneExtension: contactItem?.phoneExtension, }}
                onSubmit={values => onSubmit(values)}
            >
                {({ handleChange, handleBlur, handleSubmit, values, errors }) => (
                    <View style={styles.container}>
                        <View style={styles.dash} />
                        <View style={styles.header}>
                            <Typography onPress={closeModal} style={styles.headerItem}>cancel</Typography>
                            <Typography style={styles.title}>Contact</Typography>
                            <Typography onPress={handleSubmit} style={styles.headerItem}>Save</Typography>
                        </View>
                        <ScrollView
                            contentContainerStyle={styles.scrollContainer}
                            keyboardShouldPersistTaps={"handled"}
                            bounces={false}
                            showsVerticalScrollIndicator={false}
                        >
                            <Input error={errors.title} onChange={handleChange('title')} placeholder="Type Title" label={"Title"} value={values.title ?? ''} />
                            <Input error={errors.name} onChange={handleChange('name')} placeholder="Type Name" label={"Name"} value={values.name ?? ''} />
                            <View style={styles.phoneNumberView}>
                                <View style={{ width: "58%" }}>
                                    <Input type="phone" error={errors.phoneNumber} onChange={handleChange('phoneNumber')} placeholder="Type Phone Number" label={"Phone Number"} value={values.phoneNumber ?? ''} />
                                </View>
                                <View style={{ width: "40%" }}>
                                    <Input keyboardType="number-pad" error={errors.phoneExtension} onChange={handleChange('phoneExtension')} placeholder="Extension" label={"Extension"} value={values.phoneExtension ?? ''} />
                                </View>
                            </View>
                            <Input error={errors.emailAddress} onChange={handleChange('emailAddress')} placeholder="Type Email Address" label={"Email Address"} value={values.emailAddress ?? ''} />
                            <Input error={errors.notes} onChange={handleChange('notes')} placeholder="Type Notes" label={"Notes"} value={values.notes ?? ''} />
                            <View style={styles.methodView}>
                                <Typography style={styles.methodText}>
                                    Preferred Method of Contact
                                </Typography>
                                <View style={styles.methodItemView}>
                                    <Pressable onPress={() => handleSelectedItemChange(1)} style={[styles.methodItem, contactTypeId === 1 && styles.selectedItem]}>
                                        <Typography style={[styles.methodItemText, contactTypeId === 1 && styles.selectedItemText]}>Phone</Typography>
                                    </Pressable>
                                    <Pressable onPress={() => handleSelectedItemChange(2)} style={[styles.methodItem, contactTypeId === 2 && styles.selectedItem]}>
                                        <Typography style={[styles.methodItemText, contactTypeId === 2 && styles.selectedItemText]}>Email</Typography>
                                    </Pressable>
                                    <Pressable onPress={() => handleSelectedItemChange(4)} style={[styles.methodItem, contactTypeId === 4 && styles.selectedItem]}>
                                        <Typography style={[styles.methodItemText, contactTypeId === 4 && styles.selectedItemText]}>SMS</Typography>
                                    </Pressable>
                                </View>
                            </View>
                            {
                                type === "edit" &&
                                <Button onPress={deleteContact} label="Delete Permanent" />
                            }
                        </ScrollView>
                    </View>
                )}
            </Formik>
        </Modal>
    )
}

export const AddOrUpdateContactsModal = observer(Component)

