import * as yup from 'yup'

export interface AddContactSchema {
    emailAddress: string | undefined,
    name: string | undefined,
    notes: string | undefined,
    title: string | undefined,
    phoneNumber: string | undefined,
    phoneExtension: string | undefined,
}

export const addContactSchema = yup.object().shape({
  emailAddress: yup
    .string()
    .email("Please enter valid email"),
  name: yup
    .string(),
  notes: yup
    .string(),
  title: yup
    .string(),
  phoneNumber: yup
    .string(),
  phoneExtension: yup
    .string(),

})