import { View } from "react-native"

import { useNavigation } from "@react-navigation/native"
import Modal from "react-native-modal"

import { Button, Typography } from "@components"

import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
  onLogOut: () => void
  isLoading: boolean
}

export const LogOutModal = ({ isVisible, onClose, onLogOut, isLoading }: Props) => {
  const styles = useStyles()
  const { reset } = useNavigation()
  const navigation = useNavigation()

  const onEnable = async () => {
    onLogOut()
    
  }

  const onDecline = () => {
    onClose()
  }

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <Typography type={"title"} style={styles.title}>
          Log Out
        </Typography>
        <Typography type={"subtext"} style={styles.text}>
          Are you sure you would like to log out of your Local Splash account?
        </Typography>
        <Button isLoading={isLoading} label={"Yes, Log Out"} onPress={onEnable} />
        <Typography onPress={onDecline} style={styles.anotherTime}>
          No, Cancel
        </Typography>
      </View>
    </Modal>
  )
}
