import { withStyles } from "@utils/hocs"
import { styles } from "react-native-gifted-charts/src/Components/AnimatedThreeDBar/styles"

export const useStyles = withStyles(({ colors, height, insets }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: colors.background,
    minHeight: height * 0.2,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight:height - 48
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    alignSelf:"center"
  },
  header:{
    marginTop:8,
    flexDirection:"row",
    justifyContent: "center",
    borderBottomWidth:1,
    borderBottomColor:colors.grey,
    paddingBottom:8,
    alignItems:"center",
    marginBottom:18
  },
  headerItem:{
    color:colors.orangePrimary,
    fontWeight:"500",
    position: "absolute",
    left:10
  },
  itemList:{
    paddingHorizontal:24,
    flexDirection:"row",
    justifyContent:"space-between",
    marginBottom:16
  },
  item:{
    flexDirection:"row",
    gap:8
  }

}))

