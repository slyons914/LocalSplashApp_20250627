
import { View } from "react-native"

import Modal from "react-native-modal"

import { Checkbox, Icon, Typography } from "@components"
import { useStore } from "@store"
import { useStyles } from "./styles"
import { ScrollView } from "react-native-gesture-handler"
import { useState } from "react"
import { PaymentMenhods, ProfilePaymentMenhod } from "@models/settings"
import { BusinessInfoAPI } from "@api"
interface Props {
  isVisible: boolean
  onClose: () => void
}



export const ChangePaymentsMethodModal = ({ isVisible, onClose }: Props) => {
    const { businessInfoStore, homeStore } = useStore()
    const { AvailablePaymentMethods, ProfilePaymentMethods, getProfilePaymentMethods } = businessInfoStore
    const { locationsItem } = homeStore

    const styles = useStyles()
    const [selectedPaymentMethods, setSelectedPaymentMethods] = useState<PaymentMenhods<ProfilePaymentMenhod> | null>(ProfilePaymentMethods)
    const iconMapping: Record<string, string> = {
    Mastercard: "mastercard",
    VISA: "visa",
    Discover: "discover",
    Cash: "cash",
    "Diners Card": "diners",
    Invoice: "invoice",
    "Travelers Check": "travelers_check",
    Paypal: "paypal",
    BrandCredit: "brand_credit",
    "Android Pay": "android_pay",
    "Apple Pay": "apple_pay",
    "Samsung Pay": "samsung_pay",
    "Electronic Payments": "electronic_Payments",
    "Google Pay": "google_Pay",
    Financing: "financing",
    Venmo: "venmo",
    "Money Transfers": "money_Transfers",
    "Cash App": "cash_Apps",
    Zelle: "zelle",
    "American Express": "amex",
    "Check": "check",
  }

  const isChecked = (paymentMethodTitle: string) => {
    return selectedPaymentMethods?.paymentMethods.some(
      (profilePaymentMethod) => profilePaymentMethod.title === paymentMethodTitle
    )
  }

  const handleCheckboxPress = async (paymentMethodTitle: string, paymentMethodId: number) => {
    const isSelected = isChecked(paymentMethodTitle)

    let updatedPaymentMethods: any

    if (isSelected) {
      try {
        const response = await BusinessInfoAPI.deleteProfilePaymentMethod(locationsItem?.id, paymentMethodId)
      }  catch {
        console.log("error while deleting payment method")
      }
      updatedPaymentMethods = selectedPaymentMethods?.paymentMethods.filter(
        (method) => method.title !== paymentMethodTitle
      ) || []
    } else {
        try {
            const response = await BusinessInfoAPI.addProfilePaymentMethod(locationsItem?.id, paymentMethodId)
        }  catch {
            console.log("error while adding payment method")
        }
      const selectedPaymentMethod = AvailablePaymentMethods?.paymentMethods.find(
        (method) => method.title === paymentMethodTitle
      )
      updatedPaymentMethods = [...(selectedPaymentMethods?.paymentMethods || []), selectedPaymentMethod]
    }
    setSelectedPaymentMethods({
      ...selectedPaymentMethods,
      paymentMethods: updatedPaymentMethods,
    })
    getProfilePaymentMethods(locationsItem?.id)
  }

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <View style={styles.header}>
            <Typography onPress={onClose} style={styles.headerItem}>Close</Typography>
            <Typography style={styles.title}>Payments Methods</Typography>
        </View>
        <ScrollView>
            {
                AvailablePaymentMethods?.paymentMethods.map((item, index)=>{
                    let iconName = iconMapping[item.title]
                    if(iconName === "brand_credit" || iconName === "android_pay" || iconName === "samsung_pay"){
                        iconName = "mastercard"
                    }
                    const checked = isChecked(item.title) ?? false
                    return (<View style={styles.itemList} key={index}>
                                <View style={styles.item}>
                                    <Checkbox value={checked} onPress={()=>handleCheckboxPress(item.title, item.id)}></Checkbox>
                                    <Typography>{item.title}</Typography>
                                </View>
                                <Icon name={iconName as IconName}></Icon>
                            </View>
                            )})
            }
        </ScrollView>
      </View>
    </Modal>
  )
}
