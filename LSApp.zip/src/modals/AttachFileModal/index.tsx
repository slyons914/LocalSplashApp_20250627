import { Icon, Typography } from '@components'
import { withStyles } from '@utils/hocs'
import React from 'react'
import { Pressable, View } from 'react-native'
import Modal from "react-native-modal"


interface Props {
    isVisible?: boolean
    onClose?: () => void,
    handleChoosePhoto: () => void;
    handleTakePhoto: () => void;
    handleChooseDocument: () => void;
}


export const AttachFile = ({ isVisible, onClose = () => { }, handleChoosePhoto, handleTakePhoto, handleChooseDocument }: Props) => {
    const styles = useStyles();

    return (
        <Modal
            style={styles.modal}
            isVisible={isVisible}
            onBackdropPress={onClose}
            onBackButtonPress={onClose}
        >
            <View style={styles.mainContainer}>
                <Pressable style={styles.listItem} onPress={handleChoosePhoto}>
                    <Typography
                        type='default'
                    >Photo Library</Typography>
                    <Icon name='gallery' />
                </Pressable>
                <Pressable style={styles.listItem} onPress={handleTakePhoto}>
                    <Typography type='default' >Take Photo or Video</Typography>
                    <Icon name='camera_icon' />
                </Pressable>
                <Pressable style={styles.listItem} onPress={handleChooseDocument}>
                    <Typography type='default' >Choose File</Typography>
                    <Icon name='folder' />
                </Pressable>
            </View>
        </Modal>
    );
};



const useStyles = withStyles(({ colors, width }) => ({
    modal: {
        justifyContent: "center",
        alignItems: "center",
        flex: 1,
    },
    mainContainer: {
        borderRadius: 12,
        backgroundColor: colors.background,
        width: width * 0.5

    },
    listItem: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        borderBottomColor: "rgba(60, 60, 67, 0.36)",
        borderBottomWidth: 1,
        padding: 10
    }
}))