import { useEffect, useState } from "react"

import { View } from "react-native"
import Modal from "react-native-modal"

import { Input, SimpleHeader } from "@components"
import { useStore } from "@store"

import { useStyles } from "./styles"
import { BusinessInfoAPI } from "@api"
import { ICreateOrUpdateProfileTextContentRequestViewModel } from "@localsplash/mobile-api-client"

interface Props {
  isVisible: boolean
  onClose: () => void,
  title:string,
  details: string,
  name: string,
  setDetails: (val:string) => void
}

export const EditProfileTextContentModal = ({ isVisible, onClose, title, details, name, setDetails }: Props) => {
  const styles = useStyles()

  const { businessInfoStore, homeStore } = useStore()
  const { locationsItem } = homeStore
  const { getProfileTextContent } = businessInfoStore

  const [value, setValue] = useState<string | undefined>()
  const [error, setError] = useState<string | undefined>()
  const [isLoading, setIsLoading] = useState(false)

  const onSubmit = async () => {
    const profileData: ICreateOrUpdateProfileTextContentRequestViewModel = {};
    profileData[name as keyof ICreateOrUpdateProfileTextContentRequestViewModel] = details;
    profileData.propertyName = name

    if(locationsItem?.id) {
        setIsLoading(true)
        try {
            const response = await BusinessInfoAPI.updateProfileTextContent(locationsItem?.id, profileData)
            setIsLoading(false)
            getProfileTextContent(locationsItem?.id)
            onClose()
        } catch {
            setIsLoading(false)
        }
    }

  }

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      onSwipeComplete={onClose}
      style={styles.modal}
      avoidKeyboard
      swipeDirection={["down"]}
      propagateSwipe
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <SimpleHeader
          onLeftPress={onClose}
          onRightPress={onSubmit}
          rightText={"Save"}
          isRightVisible
          title={`Edit ${title}`}
          isLoading={isLoading}
        />
        <Input
          label={`${title}`}
          value={details}
          onChange={setDetails}
          onSubmitEditing={onSubmit}
          type={'default'}
          error={error}
          setError={setError}
          multiline={true}
        />
      </View>
    </Modal>
  )
}
