import { useState } from "react"

import { View } from "react-native"

import { DateFilter } from "@models"
import { FormatHelper } from "@utils/helpers"

import { ModalItem } from "../ModalItem"

interface Props {
  setPeriodLabel: (tabName: string) => void
  setDateFilter: (date: DateFilter) => void
  goBack: () => void
  setStartItem:(val:any) => void
  active:number,
  setActive:(val:number) => void
}

const enum activeTabEnum {
  AllTime = 1,
  Last7Days = 2,
  Last30Days = 3,
  Last3Month = 4,
  Last6Month = 5,
}

export const TimePeriodElement = ({ setDateFilter, setPeriodLabel, goBack,setStartItem, active, setActive }: Props) => {

  const getLastNDaysDateRange = (days: number) => {
    const today = new Date()
    const fromDate = new Date()
    const toDate = new Date()

    fromDate.setDate(today.getDate() - days + 1)

    return {
      fromDate: FormatHelper.formatDateString(fromDate),
      toDate: FormatHelper.formatDateString(toDate),
    }
  }

  const getLastNMonthsDateRange = (months: number) => {
    const today = new Date()
    const fromDate = new Date(today.getFullYear(), today.getMonth() - months, 1)
    const toDate = new Date(today.getFullYear(), today.getMonth() + 1, 0)

    return {
      fromDate: FormatHelper.formatDateString(fromDate),
      toDate: FormatHelper.formatDateString(toDate),
    }
  }

  const getAllTime = () => {
    const today = new Date()
    const toDate = new Date(today.getFullYear(), today.getMonth() + 1, 0)

    return { fromDate: "1970-01-01", toDate: FormatHelper.formatDateString(toDate) }
  }

  const pickDateRange = (activeTab: number) => {
    switch (activeTab) {
      case activeTabEnum.AllTime:
        setStartItem(1)
        setDateFilter(getAllTime())
        break
      case activeTabEnum.Last7Days:
        setStartItem(1)
        setDateFilter(getLastNDaysDateRange(7))
        break
      case activeTabEnum.Last30Days:
        setStartItem(1)
        setDateFilter(getLastNDaysDateRange(30))
        break
      case activeTabEnum.Last3Month:
        setStartItem(1)
        setDateFilter(getLastNMonthsDateRange(3))
        break
      case activeTabEnum.Last6Month:
        setStartItem(1)
        setDateFilter(getLastNMonthsDateRange(6))
        break

      default:
        break
    }
  }

  const onItemPress = (activeTab: number, tabName: string) => {
    setPeriodLabel(tabName)
    pickDateRange(activeTab)
    setActive(activeTab)
    goBack()
  }

  return (
    <View>
      <ModalItem
        label={"All time"}
        active={active === activeTabEnum.AllTime}
        onPress={() => onItemPress(activeTabEnum.AllTime, "All time")}
      />
      <ModalItem
        label={"Last 7 day"}
        active={active === activeTabEnum.Last7Days}
        onPress={() => onItemPress(activeTabEnum.Last7Days, "Last 7 day")}
      />
      <ModalItem
        label={"Last 30 days"}
        active={active === activeTabEnum.Last30Days}
        onPress={() => onItemPress(activeTabEnum.Last30Days, "Last 30 days")}
      />
      <ModalItem
        label={"Last 3 months"}
        active={active === activeTabEnum.Last3Month}
        onPress={() => onItemPress(activeTabEnum.Last3Month, "Last 3 months")}
      />
      <ModalItem
        label={"Last 6 months"}
        active={active === activeTabEnum.Last6Month}
        onPress={() => onItemPress(activeTabEnum.Last6Month, "Last 6 months")}
      />
      <ModalItem
          label={"Custom Range"}
          active={active === 6}
          onPress={() => onItemPress(activeTabEnum.Last6Month, "Last 6 months")}
        /> 
    </View>
  )
}
