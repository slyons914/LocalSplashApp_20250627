import { useState } from "react"

import { View } from "react-native"

import { DateFilter } from "@models"

import { ModalItem } from "../ModalItem"

interface Props {
  setSortLabel: (tabName: string) => void
  setDateFilter: (date: DateFilter) => void
  goBack: () => void
  setStartItem:(val:any) => void
  setLeadsFilter:(val:any) => void
  active:number,
  setActive:(val:number) => void
}

const enum activeTabEnum {
  new = 1,
  old = 2,
  az= 3,
  za = 4,
  responded = 5,
  notresponded = 6
}

export const SortElement = ({ setDateFilter, setSortLabel, goBack, setStartItem,setLeadsFilter, active, setActive }: Props) => {

  const onItemPress = (activeTab: number, tabName: string) => {
    setStartItem(1)
    setSortLabel(tabName)
    setActive(activeTab)
    if(activeTab === 1){
        setLeadsFilter((prevData:any)=>({
            ...prevData,
            SortByColumn:1,
            SortOrder:"desc",
        }))
    }else if(activeTab === 2){
        setLeadsFilter((prevData:any)=>({
            ...prevData,
            SortByColumn:1,
            SortOrder:"desc",
        }))
    }else if(activeTab === 3){
        setLeadsFilter((prevData:any)=>({
            ...prevData,
            SortByColumn:2,
            SortOrder:"asc",
        }))
    }else if(activeTab === 4){
        setLeadsFilter((prevData:any)=>({
            ...prevData,
            SortByColumn:2,
            SortOrder:"asc",
        }))
    }else if(activeTab === 5){
        setLeadsFilter((prevData:any)=>({
            ...prevData,
            SortByColumn:3,
            SortOrder:"desc",
        }))
    }else{
        setLeadsFilter((prevData:any)=>({
            ...prevData,
            SortByColumn:3,
            SortOrder:"asc",
        }))
    }
    goBack()
  }

  return (
    <View>
      <ModalItem
        label={"Newest First"}
        active={active === activeTabEnum.new}
        onPress={()=>onItemPress(1,"Newest First")}
      />
      <ModalItem
        label={"Oldest First"}
        active={active === activeTabEnum.old}
        onPress={()=>onItemPress(2,"Oldest First")}
      />
      <ModalItem
        label={"Name (A - Z)"}
        active={active === activeTabEnum.az}
        onPress={()=>onItemPress(3,"Name (A - Z)")}
      />
      <ModalItem
        label={"Name (Z - A)"}
        active={active === activeTabEnum.za}
        onPress={()=>onItemPress(4,"Name (Z - A)")}
      />
      <ModalItem
        label={"Responded"}
        active={active === activeTabEnum.responded}
        onPress={()=>onItemPress(5,"Responded")}
      />
      <ModalItem
        label={"Not Responded"}
        active={active === activeTabEnum.notresponded}
        onPress={()=>onItemPress(6,"Not Responded")}
      />
    </View>
  )
}
