import { useCallback, useEffect, useState } from "react"

import {
  Animated,
  Dimensions,
  Pressable,
  TouchableOpacity,
  View,
  useAnimatedValue,
} from "react-native"

import Modal from "react-native-modal"

import { Button, Icon, Typography } from "@components"
import { DateFilter } from "@models/index"
import { useStore } from "@store"
import { colors } from "@utils/constants"
import { useColors } from "@utils/hooks"

import { TimePeriodElement } from "./TimePeriodElement"
import { useStyles } from "./styles"
import { SortElement } from "./SortElement"

interface Props {
  isVisible: boolean
  onClose: () => void
  setLeadsFilter:(val:any)=>void
  dateFilter:DateFilter,
  setDateFilter:(val:any)=>void
  setStartItem:(val:any)=>void
}

interface MenuItem {
  title: string
  subTitle: string
  onPress: () => void
}

type Section ="period"|"sort"

const { width } = Dimensions.get("screen")
const translateX = width

export const WebsiteLeadsFilterModal = ({ isVisible, onClose, setLeadsFilter, dateFilter, setDateFilter,setStartItem }: Props) => {
  const [currentSection, setCurrentSection] = useState<Section | null>(null)
  const [periodLabel, setPeriodLabel] = useState<string>("All time")
  const [sortLabel, setSortLabel] = useState<string>("Newest First")
  const [activePeriod , setActivePeriod] = useState(1)
  const [activeSort , setActiveSort] = useState(1)
  const menuValue = useAnimatedValue(0)

  const sectionValue = useAnimatedValue(translateX)

  const { homeStore } = useStore()

  const [overflow, setOverflow] = useState<"hidden" | "visible">("hidden")

  const move = useCallback((direction: "forward" | "backward") => {
    setOverflow("hidden")
    const settings = { duration: 400, useNativeDriver: true }
    Animated.parallel([
      Animated.timing(menuValue, {
        toValue: direction === "forward" ? -translateX : 0,
        ...settings,
      }),
      Animated.timing(sectionValue, {
        toValue: direction === "forward" ? 0 : translateX,
        ...settings,
      }),
    ]).start(() => {
      direction === "backward" && setCurrentSection(null)
      setOverflow("visible")
    })
  }, [])

  const goBack = useCallback(() => {
    move("backward")
  }, [move])

  useEffect(() => {
    currentSection && move("forward")
  }, [currentSection])

  const menuItems: Array<MenuItem> = [
    {
      title: "Time Period",
      onPress: () => setCurrentSection("period"),
      subTitle: periodLabel,
    },
    {
        title: "Sort by",
        onPress: () => setCurrentSection("sort"),
        subTitle: sortLabel,
    }
  ]

  const sections = [
    {
      name: "period",
      component: (
        <TimePeriodElement
          active={activePeriod}
          setActive={setActivePeriod}
          setStartItem={setStartItem}  
          setPeriodLabel={setPeriodLabel}
          setDateFilter={setDateFilter}
          goBack={goBack}
        />
      ),
    },
    {
        name: "sort",
        component: (
          <SortElement
            active={activeSort}
            setActive={setActivePeriod}
            setLeadsFilter={setLeadsFilter}  
            setStartItem={setStartItem}  
            setSortLabel={setSortLabel}
            setDateFilter={setDateFilter}
            goBack={goBack}
          />
        ),
      },
  ]

  const styles = useStyles()

  const { text } = useColors()

  return (
    <Modal
      useNativeDriverForBackdrop
      isVisible={isVisible}
      onBackdropPress={onClose}
      onModalHide={goBack}
      style={styles.modal}
    >
      <View style={[styles.container, { overflow }]}>
        <View style={styles.dash} />
        {currentSection && (
          <Pressable style={styles.back} onPress={goBack}>
            <Icon name="chevronLeft" stroke={text} />
          </Pressable>
        )}

        <Typography style={styles.title}>Filters</Typography>
        <Pressable style={styles.close} onPress={onClose}>
          <Icon name={"remove"} stroke={text} />
        </Pressable>
        <Animated.View style={[styles.content, { transform: [{ translateX: menuValue }] }]}>
          {
            <View style={currentSection ? styles.hidden : styles.flexed}>
              {menuItems.map((item) => (
                <TouchableOpacity key={item.title} onPress={item.onPress} style={styles.menuItem}>
                  <View>
                    <Typography style={styles.menuItemTitle} type="title">
                      {item.title}
                    </Typography>
                    <Typography type="title" style={styles.menuItemSubTitle}>
                      {item.subTitle}
                    </Typography>
                  </View>
                  <Icon name="chevronRight" stroke={colors.common.dark} />
                </TouchableOpacity>
              ))}
              <Button btnStyle={styles.button} onPress={onClose} label={"View Leads"} />
            </View>
          }
        </Animated.View>
        <Animated.View style={[styles.section, { transform: [{ translateX: sectionValue }] }]}>
          {sections.map(({ component, name }, i) => (
            <View key={i} style={currentSection === name ? styles.flexed : styles.hidden}>
              {component}
            </View>
          ))}
        </Animated.View>
      </View>
    </Modal>
  )
}
