import { Alert, Linking, Pressable, View } from "react-native"

import Modal from "react-native-modal"

import { Button, Typography } from "@components"

import { useStyles } from "./styles"
import { useStore } from "@store"

interface Props {
  isVisible: boolean
  onClose: () => void
  isFromLead: boolean,
  callNumber?: string
}

export const CallAlertModal = ({ isVisible, onClose, isFromLead, callNumber}: Props) => {
  const styles = useStyles()

  const { settingsStore, homeStore} = useStore()
  const { locationsItem } = homeStore
  const { requestSipSettings } = settingsStore

  const onCallTrackingPress = () => {
    if(locationsItem?.id)
        requestSipSettings(locationsItem?.id)
    onClose()
    Alert.alert("Submitted", "Someone will contact you shortly.")
  }

  const onCallPress = () => {
    const phoneNumber = `tel:+ ${callNumber}`;
    Linking.openURL(phoneNumber)
      .catch((err) => console.error('Error opening dialer', err));
    onClose()  
  }
  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.textView}>
            <Typography style={styles.title}>Want to make a call?</Typography>
            <Typography type={"subtext"} style={styles.text}>
                This feature is not available with your current subscription, please contact us to enable.
            </Typography>
        </View>
        <Pressable onPress={onCallTrackingPress} style={styles.buttonTextView}>
            <Typography style={[styles.blueText, styles.title]}>Request Call Tracking</Typography>
        </Pressable>
        { isFromLead &&
            <Pressable onPress={onCallPress} style={styles.buttonTextView}>
                <Typography style={styles.blueText}>Call {callNumber}</Typography>
            </Pressable>
        }
      </View>
    </Modal>
  )
}
