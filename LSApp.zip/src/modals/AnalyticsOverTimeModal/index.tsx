import { useState } from "react"

import { Pressable, View } from "react-native"

import Modal from "react-native-modal"

import { Icon, Typography } from "@components"
import { ResultsLabel, DataType } from "@models"
import { useColors } from "@utils/hooks"

import { ModalItem } from "./ModalItem"
import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
  setResultsLabel: (label: ResultsLabel) => void
  setDataType: (label: DataType) => void
  getAnalyticsOverTime: (label: string) => void
}

export const AnalyticsOverTimeModal = ({
  isVisible,
  onClose,
  setResultsLabel,
  setDataType,
  getAnalyticsOverTime
}: Props) => {
  const styles = useStyles()

  const { text } = useColors()

  const [active, setActive] = useState(1)

  const onItemPress = (activeTab: number, label: ResultsLabel, dataType: DataType) => {
    getAnalyticsOverTime(dataType)
    setResultsLabel(label)
    setDataType(dataType)
    setActive(activeTab)
    onClose()
  }

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
      onSwipeComplete={onClose}
      animationIn={"slideInUp"}
      animationOut={"slideOutDown"}
      swipeDirection={["down"]}
      propagateSwipe
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <Typography style={styles.title}>Results Over Time</Typography>
        <Pressable style={styles.close} onPress={onClose}>
          <Icon name={"remove"} stroke={text} />
        </Pressable>
        <ModalItem
          label={"Local Leads"}
          active={active === 1}
          onPress={() => {
            onItemPress(1, "Local Leads", "LocalLeads")
          }}
        />
        <ModalItem
          label={"Google Profile Actions"}
          active={active === 2}
          onPress={() => onItemPress(2, "Google Profile Actions", "GoogleProfileActions")}
        />
        <ModalItem
          label={"Google Ads Clicks"}
          active={active === 3}
          onPress={() => onItemPress(3, "Google Ads Clicks", "GoogleAdsClicks")}
        />
        <ModalItem
          label={"Reviews"}
          active={active === 4}
          onPress={() => onItemPress(4, "Reviews", "Reviews")}
        />
        <ModalItem
          label={"Listings Clicks"}
          active={active === 5}
          onPress={() => onItemPress(5, "Listings Clicks", "ListingClicks")}
        />
      </View>
    </Modal>
  )
}
