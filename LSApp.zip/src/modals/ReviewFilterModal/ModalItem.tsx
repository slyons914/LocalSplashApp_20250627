import { TouchableOpacity, useColorScheme } from "react-native"

import { Icon, Typography } from "@components"

import { useStyles } from "./styles"

interface Props {
  label: string
  onPress?: () => void
  active?: boolean
}

export const ModalItem = ({ label, onPress, active }: Props) => {
  const styles = useStyles()
  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"

  return (
    <TouchableOpacity onPress={onPress} style={[styles.itemContainer, active && styles.activeBackground, !isLightTheme && active && styles.darkBackground]}>
      <Typography style={styles.itemText}>{label}</Typography>
      {active && <Icon name={"checkBlue"} />}
    </TouchableOpacity>
  )
}
