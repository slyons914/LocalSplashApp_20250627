
import { View } from "react-native"

import { ModalItem } from "../ModalItem"

interface Props {
  setResponseLabel: (tabName: string) => void
  goBack: () => void
  active:number,
  setActive:(val:number) => void
}

const enum activeTabEnum {
  all = 1,
  responded = 2,
  notresponded = 3
}

export const ResponseElement = ({  setResponseLabel, goBack, active, setActive }: Props) => {

  const onItemPress = (activeTab: number, tabName: string) => {
    setResponseLabel(tabName)
    setActive(activeTab)
    goBack()
  }

  return (
    <View>
      <ModalItem
        label={"All"}
        active={active === activeTabEnum.all}
        onPress={()=>onItemPress(1,"All")}
      />
      <ModalItem
        label={"Responded"}
        active={active === activeTabEnum.responded}
        onPress={()=>onItemPress(2,"Responded")}
      />
      <ModalItem
        label={"Not Responded"}
        active={active === activeTabEnum.notresponded}
        onPress={()=>onItemPress(3,"Not Responded")}
      />
    </View>
  )
}
