
import { View } from "react-native"

import { ModalItem } from "../ModalItem"

interface Props {
  setSortLabel: (tabName: string) => void
  goBack: () => void
  active:number,
  setActive:(val:number) => void
}

const enum activeTabEnum {
  new = 1,
  old = 2,
}

export const SortElement = ({  setSortLabel, goBack, active, setActive }: Props) => {

  const onItemPress = (activeTab: number, tabName: string) => {
    setSortLabel(tabName)
    setActive(activeTab)
    goBack()
  }

  return (
    <View>
      <ModalItem
        label={"Newest First"}
        active={active === activeTabEnum.new}
        onPress={()=>onItemPress(1,"Newest First")}
      />
      <ModalItem
        label={"Oldest First"}
        active={active === activeTabEnum.old}
        onPress={()=>onItemPress(2,"Oldest First")}
      />
    </View>
  )
}
