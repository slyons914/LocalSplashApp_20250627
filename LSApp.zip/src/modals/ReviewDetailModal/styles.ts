import { Icon } from "@components"
import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height, insets }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: colors.background,
    minHeight: height * 0.3,
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    paddingHorizontal: 24,
    gap:8,
    paddingBottom: insets.bottom ? insets.bottom : 12,
    marginTop: insets.top ? insets.top : 20
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
    marginBottom: 24,
    alignSelf:"center",
    textAlign:"center"
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
    alignSelf:"center"
  },
  button: {
    marginTop: 8,
    width: 342,
  },
  smallText:{
    fontSize:12
  },
  greyText:{
    color:colors.greyText
  },
  reviewItemDetail:{
    flexDirection:"row",
    justifyContent:"space-between"
  },
  redText:{
    color:colors.red,
    fontWeight:'500'
  },
  greenText:{
    color:colors.green,
    fontWeight:'500'
  },
  reviewItemHeader:{
    flexDirection:"row",
    justifyContent:"space-between"
  },
  reviewType:{
    flexDirection:"row",
    gap:5,
    alignItems:"center"
  },
  subText:{
    fontSize:16
  },
  textInput: {
    borderWidth: 1,
    borderColor: colors.gray6,
    borderRadius: 8,
    paddingHorizontal: 24,
    paddingVertical: 16,
    color: colors.text,
    height:180
  },
  lightText:{
    color:colors.gray4,
    marginTop:5
  },
  titleContainer:{
    flexDirection:"row",
    alignItems:"center",
    marginTop:18
  },
  iconView: {
    alignSelf:"flex-start"
  },
  titleWrapper: {
    flexGrow: 1,
    alignItems: "center",
    justifyContent: "center", 
  },
}))
