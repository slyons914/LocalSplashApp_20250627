import { useEffect, useState } from "react"

import { ScrollView, TouchableOpacity, useColorScheme, View } from "react-native"

import Modal from "react-native-modal"

import { Button, Icon, Input, Typography } from "@components"
import { useStyles } from "./styles"
import { StarsCompoment } from "../../../src/components/Stars"
import { colors } from "@utils/constants"
import { TextInput } from "react-native-gesture-handler"
import { ReveiwItem } from "@models/index"
import moment from "moment"
import { MobileAPI } from "@api"
import { backIconHitSlope } from "@utils/constants/common";

interface Props {
  isVisible: boolean
  onClose: () => void
  data:ReveiwItem | undefined
}

export const ReviewDetailModal = ({ isVisible, onClose, data }: Props) => {
  const [responseValue , setResponseValue] = useState(data?.responseText)
  const [apiResponse , setApiResponse] = useState(false)
  const [apiResponseValue , setApiResponseValue] = useState("")
  const styles = useStyles()

  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"

  const formatDateTime = (dateTimeString:string) => {
    const parsedDate = moment(dateTimeString, "YYYY-MM-DDTHH:mm:ss");
    return parsedDate.format("MMM D, YYYY h:mm A");
  };
  const onChangeHandler = (value: string) => {
    setResponseValue(value)
  }
  const sendResponse = async () =>{
    console.log("review is", data)
    const response = await MobileAPI.sendReviewResponse(data?.reviewId , responseValue)
    if(response.data){
        setApiResponseValue("Response Sent Successfully")
    }else{
        setApiResponseValue("Error while Sendind Response")
    }
    setApiResponse(true)
    console.log(response)
    console.log("Sending Response")
  }

  useEffect(()=>{
    setApiResponse(false)
    setResponseValue(data?.responseText)
  },[data])
  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
      <ScrollView contentContainerStyle={{gap:8}}>
        <View style={styles.dash} />
        <View style={styles.titleContainer}>
         <TouchableOpacity style={styles.iconView} onPress={onClose} hitSlop={backIconHitSlope}><Icon name={isLightTheme ? "backIcon" : "bacIconWhite"}></Icon></TouchableOpacity>   
         <View style={styles.titleWrapper}>
              <Typography style={styles.title}>{data?.reviewerName}</Typography>
        </View>
        </View>
        <View style={styles.reviewItemDetail}>
            <Typography style={[styles.greyText, styles.smallText]}>{formatDateTime(data?.reviewedOn??'0')}</Typography>
            {
                !data?.responseText ? (<Typography style={styles.redText}>NOT RESPONDED</Typography>):
                (<Typography style={styles.greenText}>RESPONDED</Typography>)
            }
        </View>
        <View style={styles.reviewItemHeader}>
            <StarsCompoment data={data?.score??0} ></StarsCompoment>
            <View style={styles.reviewType}>
                <Icon name="google" fill={colors.common.greyText}></Icon>
                <Typography style={styles.smallText}>Google</Typography>
            </View>
        </View>
        <View>
            <Typography style={styles.subText}>{data?.comments}</Typography>
        </View>
        <View>
            <TextInput
            style={styles.textInput}
            value={responseValue}
            onChangeText={onChangeHandler}
            multiline={true}
            placeholder={"Type your response here .."}
            textAlignVertical="top"
            placeholderTextColor={colors.common.gray4}
            maxLength={1500}
          />
          <Typography style={styles.lightText}>0/1500 characters</Typography>
        </View>
        {
            apiResponse? (<Typography style={styles.redText}>{apiResponseValue}</Typography>):(
                null )
        }
        <View>
          <Button btnStyle={styles.button} onPress={sendResponse} label={"Respond"} />
        </View>
        </ScrollView>
      </View>
    </Modal>
  )
}
