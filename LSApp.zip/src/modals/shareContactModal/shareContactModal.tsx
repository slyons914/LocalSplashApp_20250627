import {Pressable, View} from "react-native"

import Modal from "react-native-modal"

import { Typography } from "@components"

import {useStyles} from "./styles"

import CloseIcon from '../../../assets/icons/removeBlack.svg'
import Camera from '../../../assets/icons/camerBGBlue.svg'
import Document from '../../../assets/icons/docBGBlue.svg'
import Media from '../../../assets/icons/mediaBGBlue.svg'
interface Props
{
  isVisible: boolean
  onClose: () => void
  handleCamera:()=>void
  handleDocument:()=>void
  handleMedia:()=>void
  
}

 export const ShareContactModal: React.FC<Props> = (props) =>
{
  const {isVisible, onClose ,handleCamera , handleDocument ,handleMedia} = props
  const styles = useStyles()

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />

        <View style={{marginTop: 10}}>
          <Typography style={styles.title}>Share Content</Typography>
          <View style={{marginRight: 20, position: 'absolute', right: 0}}>
            <CloseIcon onPress={onClose} />
          </View>
        </View>

        <View style={styles.buttonContainer}>
          <Pressable onPress={handleCamera}  style={styles.row}>
            <Camera />
            <Typography style={[styles.title,{fontWeight:'400'}]}>Camera</Typography>
          </Pressable>

          <Pressable onPress={handleDocument} style={styles.row}>
            <Document/>
            <View>
            <Typography style={[styles.title,styles.font400]}>Documents</Typography>
            <Typography style={[styles.title,styles.font14]}>Share your files</Typography>
            </View>
          </Pressable>


          <Pressable onPress={handleMedia} style={{flexDirection: 'row', alignItems: "center", gap: 15}}>
            <Media/>
            <View>
            <Typography style={[styles.title,styles.font400]}>Media</Typography>
            <Typography style={[styles.title,styles.font14]}>Share photos and videos</Typography>
            </View>
          </Pressable>

        </View>

      </View>
    </Modal>
  )
}
