import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: colors.background,
    minHeight: height * 0.3,
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
    textAlign:'center',
  },
  
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    marginTop:10,
    alignSelf:'center',
  },
  buttonContainer:{marginTop: 20, marginLeft: 20, rowGap:30 , marginBottom:20},
  row:{flexDirection: 'row', alignItems: "center", gap: 15},
  font400: {fontWeight:'400', textAlign:'left'},
  font14:{fontWeight:'400',fontSize:14},

}))
