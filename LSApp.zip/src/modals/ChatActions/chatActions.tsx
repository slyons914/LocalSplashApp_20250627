import {Pressable, TouchableOpacity, View} from "react-native"

import Modal from "react-native-modal"

import { Typography } from "@components"

import {useStyles} from "./styles"

import CloseIcon from '../../../assets/icons/removeBlack.svg'
import { backIconHitSlope } from "@utils/constants/common"

interface Props
{
  isVisible: boolean
  onClose: () => void
  handleCopyNumber:()=>void
  handleBlockNumber:()=>void
  handleSpam:()=>void,
  isSpam: boolean | undefined
  isBlock:boolean | undefined
  
}

 export const ChatActions: React.FC<Props> = (props) =>
{
  const {isVisible, onClose ,handleCopyNumber , handleBlockNumber ,handleSpam, isBlock, isSpam} = props
  const styles = useStyles()

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />

        <View style={{marginTop: 10}}>
          <Typography style={styles.title}>Chat Actions</Typography>
          <View style={{marginRight: 20, position: 'absolute', right: 0}}>
            <Pressable hitSlop={backIconHitSlope} onPress={onClose}>
                <CloseIcon/>
            </Pressable>
          </View>
        </View>

        <View style={styles.buttonContainer}>
            <TouchableOpacity onPress={handleCopyNumber}>
                <Typography style={[styles.title,styles.font400]}>Copy Number</Typography>
            </TouchableOpacity>
            <TouchableOpacity onPress={handleBlockNumber}>
                <Typography style={[styles.title,styles.font400]}>{isBlock? "UnBlock Number" : "Block Number"}</Typography>
            </TouchableOpacity>
            <TouchableOpacity onPress={handleSpam}>
                <Typography style={[styles.title,styles.font400]}>{isSpam? "Unmark as Spam" : "Mark as spam"}</Typography>
            </TouchableOpacity>
        </View>

      </View>
    </Modal>
  )
}
