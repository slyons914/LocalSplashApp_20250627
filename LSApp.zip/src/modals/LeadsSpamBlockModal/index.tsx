import { Pressable, TouchableOpacity, View } from "react-native"

import Modal from "react-native-modal"

import { Icon, Typography } from "@components"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
  isSpam?: boolean
  isBlocked?: boolean
  handleLeadSpamMarking : (isSpam: boolean) => void
  handleLeadBlocking : (isSpam: boolean) => void
}

export const LeadsSpamBlockModal = ({
  isVisible,
  onClose,
  isSpam,
  isBlocked,
  handleLeadSpamMarking,
  handleLeadBlocking,
}: Props) => {
  const styles = useStyles()

  const { text } = useColors()

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <Typography style={styles.title}>Leads Actions</Typography>
        <Pressable style={styles.close} onPress={onClose}>
          <Icon name={"remove"} stroke={text} />
        </Pressable>
        <View>
          <TouchableOpacity
            style={styles.buttonContainer}
            onPress={() => handleLeadBlocking(!isBlocked)}
          >
            <Typography style={styles.buttonText}>{`${
              isBlocked ? "Unblock" : "Block"
            } Lead`}</Typography>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.buttonContainer}
            onPress={() => handleLeadSpamMarking(!isSpam)}
          >
            <Typography style={styles.buttonText}>{`${
              isSpam ? "Mark as Not spam" : "Mark as spam"
            }`}</Typography>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  )
}
