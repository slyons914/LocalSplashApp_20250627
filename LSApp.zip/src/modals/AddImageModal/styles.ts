import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height }) => ({
  modal: {
    margin: 0,
    marginTop: 40,
    justifyContent:"flex-end"
  },
  container: {
    backgroundColor: colors.background,
    minHeight: height * 0.3,
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    paddingBottom: 24,
    padding:16,
    paddingTop:32,
    gap:8
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
    alignSelf: "center",
  },
  cancelButton: {
    justifyContent: "center",
    padding:16
  },
  cancelText: {
    color:colors.orangePrimary,
    fontWeight:"500",
    textAlign:"center",
    fontSize:16
  }
}))
