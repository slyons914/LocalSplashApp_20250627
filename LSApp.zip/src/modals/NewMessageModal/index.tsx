import {  FlatList, Pressable, View } from "react-native"

import Modal from "react-native-modal"

import { useStyles } from "./styles"
import { SearchBar, Typography } from "@components"
import { NewChatModal } from "@modals/NewChatModal"
import { useEffect, useState } from "react"
import { LeadsAPI } from "@api"
import { FormatHelper } from "@utils/helpers"
import { navigate } from "@navigation"
import { Routes } from "@utils/constants"
import { useStore } from "@store"

interface Props {
  isVisible: boolean
  onClose: () => void
  setMessageList: (val : any) => void
}

export const NewMessageModal = ({ isVisible, onClose, setMessageList }: Props) => {
  const styles = useStyles()

  const { homeStore } = useStore()
  const { locationsItem } = homeStore

  const [newChatModal, setNewChatModal] = useState(false)
  const [recentLeads, setRecentLeads] = useState<any>()

  const getRecentLeads = async () =>{{
    if(!locationsItem?.id)
        return;
    const data = await LeadsAPI.getRecentLeads(locationsItem?.id)
    setRecentLeads(data.data?.items)
  }}

  const updateRecentMessageList = (payload: any) => {
    setMessageList((prevMessages: any) => 
        prevMessages.map((message: any) => 
            message.leadPhone == payload.leadPhone
                ? { ...message, ...payload }
                : message
        )
    );
  }

  useEffect(()=>{
    getRecentLeads()
  },[])

  const renderItem = ({ item }: { item: any }) => {
    const words = item.name.split(" ");
    const initials = words.map((word: any) => word.charAt(0)).join("");

   return (
     <Pressable
      onPress={()=>{onClose(), navigate(Routes.MessageDetail, {number: item.phoneNumber, leadId:item.id, onMessageSent: updateRecentMessageList})}} 
      style={styles.message}>
        <View style={styles.icon}>
          <Typography style={styles.initials}>{initials}</Typography>
        </View>
        <View style={styles.center}>
          <Typography style={styles.name}>{item.name}</Typography>
          <Typography>{FormatHelper.formatPhoneNumber(item.phoneNumber.toString())}</Typography>
        </View>
      </Pressable>
    )
  }
  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      avoidKeyboard={true}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <View style={styles.header}>
            <Typography>               </Typography>
            <Typography style={styles.newMessageText}>New Message</Typography>
            <Typography onPress={onClose} style={styles.cancelText}>Cancel</Typography>
        </View>
        <SearchBar
         style={{width:"90%", margin:16,height:50}}
          placeholder="Search by Name, Phone Number..."
          value={""}
          onSearch={Promise.resolve}
        />
        <View style={styles.bar}></View>
        <View style={styles.recentLeads}>
            <Typography style={styles.boldText}>Recent Leads</Typography>
        </View>
        <View style={styles.recentLeadsView}>
            <FlatList
            data={recentLeads}
            scrollEnabled
            renderItem={renderItem}
            showsVerticalScrollIndicator={false} />
        </View>
      </View>
      <NewChatModal closeMessageModal = {onClose} isVisible={newChatModal} onClose={()=>setNewChatModal(false)}></NewChatModal>
    </Modal>
  )
}
