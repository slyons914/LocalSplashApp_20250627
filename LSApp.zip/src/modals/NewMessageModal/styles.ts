import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height, width,insets }) => ({
  modal: {
    margin: 0,
    justifyContent:"flex-start"
  },
  container: {
    backgroundColor: colors.background,
    minHeight: height,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    alignItems: "center",
    marginTop:insets.top? insets.top+ 30 : 30
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top:5
  },
  cancelText:{
    fontSize:16,
    fontWeight:"500",
    textAlign:"center",
    color:colors.orangePrimary,
    padding:8
  },
  header:{
    width:"100%",
    paddingHorizontal: 16,
    paddingTop:16,
    flexDirection:"row",
    justifyContent:"space-between",
    alignItems:"center"
  },
  newMessageText:{
    fontWeight:"500",
    fontSize:16,
    textAlign:"center"
  },
  addNewChat:{
    flexDirection:"row",
    justifyContent:"space-around",
    paddingVertical:16,
    backgroundColor:colors.lightBlue,
    borderRadius:16,
    width:"90%",
    marginHorizontal:16,
    marginTop:48,
    marginBottom:12

  },
  bar:{
    borderBottomWidth:1,
    width:"100%",
    borderBottomColor:colors.grey,
    marginBottom:8
  },

  boldText:{
    fontSize:18,
    fontWeight:"600",
  },
  recentLeadsView:{
    alignSelf:"flex-start",
    flex:1,
    paddingBottom: insets.bottom + 40
  },
  recentLeads:{
    alignSelf:"flex-start",
    marginLeft:24,
  },
  message: {
    paddingLeft:24,
    width:width,
    alignSelf:"flex-start",
    gap: 12,
    flexDirection: "row",
    borderBottomWidth: 1,
    borderBottomColor: colors.gray6,
    paddingVertical: 16,
    marginBottom:16
  },
  icon: {
    width: 50,
    height: 50,
    borderRadius: 50,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "red",
  },
  initials: {
    fontSize: 16,
    fontWeight: "500",
    color: colors.white,
  },
  center: {
  },
  name: {
    fontSize: 16,
  },

}))
