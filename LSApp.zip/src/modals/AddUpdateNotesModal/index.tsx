import { ActivityIndicator, View } from "react-native"
import { Input, Typography } from "@components"
import { useStyles } from "./styles"
import { observer } from "mobx-react-lite"
import { useEffect, useState } from "react"
import { colors } from "@utils/constants"
import Modal from "react-native-modal"
import { Lead } from "@models/leads"

interface Props {
    isVisible: boolean
    onClose: () => void
    lead: Lead | null
    onSavePress: (val:string) => Promise<void>
}

const Component = ({ isVisible, lead, onClose, onSavePress }: Props) => {
    const styles = useStyles()
    const [isLoading, setIsLoading] = useState(false)
    const [leadNotes, setLeadNotes] = useState(lead?.customerNotes)

    const handleAddPress = async () => {
        setIsLoading(true)
        try {
            await onSavePress(leadNotes ?? '')
        } catch {
            setIsLoading(false)
        } finally {
            setIsLoading(false)
            onClose()
        }
    }

    useEffect(() => {
        setLeadNotes(lead?.customerNotes)
    },[lead])

    return (
        <Modal
            isVisible={isVisible}
            onBackdropPress={onClose}
            onBackButtonPress={onClose}
            onSwipeComplete={onClose}
            style={styles.modal}
            avoidKeyboard
        >
            <View style={styles.container}>
                <View style={styles.dash} />
                <View style={styles.header}>
                    <Typography onPress={onClose} style={styles.headerItem}>Cancel</Typography>
                    <Typography style={styles.title}>{lead?.customerNotes ? "Edit Notes" : "Add Notes"}</Typography>
                    <View style={styles.loaderView}>
                    {
                        isLoading ? ( <ActivityIndicator size={"small"} color={colors.common.orangePrimary}></ActivityIndicator> ) : (
                            <Typography onPress={handleAddPress} style={styles.headerItem}>{lead?.customerNotes ? "Save" : "Add"}</Typography>
                        )
                    }
                    </View>
                </View>
                <View style={styles.textInputView}>
                    <Input 
                        label="Note*"
                        value={leadNotes ?? ''}
                        onChange={setLeadNotes}
                        placeholder="Enter Notes"
                        multiline
                        style={styles.textInput}
                    />
                </View>
            </View>
        </Modal>
    )
}

export const AddUpdateNotesModal = observer(Component)

