import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  modal: {
    margin: 0,
    justifyContent:"flex-end"
  },
  container: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingBottom: 24,
    backgroundColor: colors.background,
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
    alignSelf: "center",
  },
  header:{
    marginTop:8,
    flexDirection:"row",
    justifyContent: "space-between",
    borderBottomWidth:1,
    borderBottomColor:colors.grey,
    paddingBottom:8,
    alignItems:"center",
    marginBottom:18,
    padding: 24,
  },
  headerItem:{
    color:colors.orangePrimary,
    fontWeight:"500",
    fontSize:16,
    textAlign:"center"
  },
  loaderView: {
    width: "15%"
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
  },
  textInputView: {
    padding: 24
  },
  textInput: {
    paddingTop:14
  }
}))
