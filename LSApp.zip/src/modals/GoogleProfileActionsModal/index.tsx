import { Pressable, View } from "react-native"

import Modal from "react-native-modal"

import { Icon, Typography } from "@components"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"
import { useStore } from "@store"

interface Props {
  isVisible: boolean
  onClose: () => void
}

export const GoogleProfileActionsModal = ({ isVisible, onClose }: Props) => {
  const styles = useStyles()

  const { languageStore } = useStore()
  const { languageVariables } = languageStore
  const { text } = useColors()

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <Typography style={styles.title}>Google Profile Actions</Typography>
        <Pressable style={styles.close} onPress={onClose}>
          <Icon name={"remove"} stroke={text} />
        </Pressable>
        <View style={styles.textContainer}>
          <Typography type={"subtext"} style={styles.text}>{languageVariables? languageVariables["App.ins.wid1"] : ''}</Typography>
        </View>
      </View>
    </Modal>
  )
}
