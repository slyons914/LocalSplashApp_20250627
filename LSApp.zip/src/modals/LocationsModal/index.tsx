import { FlatList, Pressable, View } from "react-native"

import Modal from "react-native-modal"
import { ProfileViewModel } from "src/models/localsplash-mobile-api.service"

import { Icon, Typography } from "@components"
import { useStore } from "@store"
import { useColors } from "@utils/hooks"

import { ModalItem } from "./ModalItem"
import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
  setLocationsLabel: (label: string) => void
  setLocationsIndex: (index: number) => void
  setLocationsItem: (index: ProfileViewModel) => void
  locationsIndex: number
}

export const LocationsModal = ({
  isVisible,
  onClose,
  setLocationsLabel,
  setLocationsIndex,
  setLocationsItem,
  locationsIndex,
}: Props) => {
  const styles = useStyles()

  const { text } = useColors()

  const { homeStore, languageStore } = useStore()
  const { profiles } = homeStore
  const { languageVariables } = languageStore

  const filteredData = profiles?.profiles?.filter((entry) => entry?.status !== "Deleted")

  const onItemPress = (activeTab: number, item: ProfileViewModel) => {
    setLocationsItem(item)
    setLocationsLabel(item.title!)
    setLocationsIndex(activeTab)
    onClose()
  }


  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
      onSwipeComplete={onClose}
      animationIn={"slideInUp"}
      animationOut={"slideOutDown"}
      swipeDirection={["down"]}
      propagateSwipe
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <Typography style={styles.title}>{languageVariables? languageVariables["App.fb.wid8"] : ""}</Typography>
        <Pressable style={styles.close} onPress={onClose}>
          <Icon name={"remove"} stroke={text} />
        </Pressable>
        <FlatList
          data={filteredData}
          contentContainerStyle={styles.list}
          scrollEnabled
          showsVerticalScrollIndicator={false}
          renderItem={({ item, index }) => (
            <ModalItem
              label={item.title!}
              active={locationsIndex === index}
              onPress={() => onItemPress(index, item)}
            />
          )}
        />
      </View>
    </Modal>
  )
}
