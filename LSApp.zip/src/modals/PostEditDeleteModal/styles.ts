import { withStyles } from '@utils/hocs'
export const useStyles = withStyles(({ colors, width }) => ({
    modal: {
        justifyContent: "center",
        alignItems: "center",
        flex: 1,
    },
    mainContainer: {
        borderRadius: 12,
        backgroundColor: colors.background,
        width: width * 0.6

    },
    listItem: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        borderBottomColor: "rgba(60, 60, 67, 0.36)",
        borderBottomWidth: 1,
        padding: 10
    }
}))