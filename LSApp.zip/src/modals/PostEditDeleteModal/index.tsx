import { Icon, Typography } from '@components'
import { useStyles } from './styles'
import React, { useState } from 'react'
import { Pressable, View } from 'react-native'
import Modal from "react-native-modal"


interface Props {
    isVisible: boolean
    onClose: () => void,
    onDeletePress: () => void
}


export const PostEditDeleteModal = ({ isVisible, onClose, onDeletePress}: Props) => {
    const styles = useStyles();
    const deletePress = () =>{
        onDeletePress()
        onClose()
    }
    return (
        <Modal
            style={styles.modal}
            isVisible={isVisible}
            onBackdropPress={onClose}
            onBackButtonPress={onClose}
        >
            <View style={styles.mainContainer}>
                <Pressable style={styles.listItem} >
                    <Typography
                        type='default'
                    >Edit</Typography>
                    <Icon name='editIcon' />
                </Pressable>
                <Pressable style={styles.listItem} onPress={deletePress} >
                    <Typography type='default' >Delete</Typography>
                    <Icon name='deleteIcon' />
                </Pressable>
            </View>
        </Modal>
    );
};
