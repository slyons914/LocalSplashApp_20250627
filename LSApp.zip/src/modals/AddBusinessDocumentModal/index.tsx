import { FlatList, ListRenderItemInfo, Pressable, useColorScheme, View } from "react-native"
import { useStyles } from "./styles"
import { pickImageFromGallery, takePhotoWithCamera } from "@utils/helpers"
import { Button, CustomDropdown, Icon, Typography } from "@components"
import { useColors } from "@utils/hooks"
import { useCallback, useState } from "react"
import DocumentPicker from 'react-native-document-picker'
import Modal from "react-native-modal"
import Toast from 'react-native-simple-toast';
import { AttachFile } from "@modals/AttachFileModal"
import { DocumentTypesViewModel } from "@localsplash/mobile-api-client"
import { BusinessInfoAPI } from "@api"
import { useStore } from "@store"
interface Attachment {
    uri: string;
    name: string;
    type: string;
    size: number;
}
interface Props {
  isVisible: boolean
  onClose: () => void
  documentTypes: DocumentTypesViewModel | null
}

const dropdownItems = [
    {value: "Business Registration", label: "Business Registration"},
    {value: "Business license and/or insurance documentation", label: "Business license and/or insurance documentation"},
    {value: "Tools and equipment use to carry out work", label: "Tools and equipment use to carry out work"},
    {value: "Business Card", label: "Business Card"},
    {value: "Invoice", label: "Invoice"},
    {value: "Workplace and Signage", label: "Workplace and Signage"},
    {value: "Utility Bill", label: "Utility Bill"},
    {value: "DBA (Doing Business As)", label: "DBA (Doing Business As)"},
    {value: "Tax Documentation (IRS)", label: "Tax Documentation (IRS)"}
]

export const AddBusinessDocuments = ({ isVisible, onClose, documentTypes }: Props) => {

  const [dropdownValue, setDropdownValue] = useState("")  
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isAttachFileModalVisible, setIsAttachFileModalVisible] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const { homeStore, businessInfoStore } = useStore()
  const { locationsItem } = homeStore
  const { getBusinessDocuments } = businessInfoStore

  const isDarkMode = useColorScheme() === "dark"


  const { text, redText } = useColors()
  const styles = useStyles()

    const showInvalidTypeToast = () => {
        Toast.showWithGravity(
            'Only images and pdf are allowed',
            Toast.LONG,
            Toast.BOTTOM,
        );
    }

    const showFileSizeToast= () => {
        Toast.showWithGravity(
            'Maximum file size is 5MB',
            Toast.LONG,
            Toast.BOTTOM,
        );
    }

    const isValidFileType = (type: string) => {
        return type.includes('jpg') || type.includes('jpeg') || type.includes('pdf') || type.includes('png')
    }

    const isImage = (type: string) : IconName => {
        if (type.includes('jpg') || type.includes('jpeg') || type.includes('png')) {
            if(isDarkMode)
                return "addImageBusinessDocumentsDark"
            return "addImageBusinessDocument"
        }
        return "pdfRed"
    }

    const handleRemoveAttachment = (uri: string) => {
        setAttachments(prevAttachments => prevAttachments.filter(attachment => attachment.uri !== uri));
    };

    const handleFilenameLength = (name: string | undefined) => {
        const filename = name;
        const extension = filename?.split('.').pop();
        const filenameWithoutExtension = filename?.slice(0, filename?.lastIndexOf('.')); 
        const shortenedFilename = filenameWithoutExtension?.slice(0, 12) + '.' + extension;
        return shortenedFilename
    }

    const convertFileSizeToMb = (size:number ) => {
        if(size === 0)
            return 0;
        const fileSizeInMB = (size/ (1024 * 1024)).toFixed(2);
        return Number(fileSizeInMB);
    }

    const handleUploadPress = async () => {
        setIsLoading(true)
        const data = new FormData();
        attachments.forEach((attachment) => {
        data.append('Files', {
            uri: attachment.uri,
            type: attachment.type,
            name: attachment.name,
        });
      });
      data.append('DocumentTypeId', dropdownValue)
      try {
        if(locationsItem?.id) {
            const response = await BusinessInfoAPI.addBussinessDocuments(locationsItem?.id, data)
            await getBusinessDocuments(locationsItem?.id)
          }    
      } catch {
        setIsLoading(false)
      } finally {
        setIsLoading(false)
        onClose()
      }
    }

    const handleTakePhoto = async () => {
        try {
            const response = await takePhotoWithCamera();
            if (!!response && typeof response !== "string") {
                if(!isValidFileType(response[0]?.type ?? '')){
                    showInvalidTypeToast();
                    return;
                }
                const fileSize = convertFileSizeToMb(response[0]?.fileSize ?? 0)
                if(fileSize > 5) {
                    showFileSizeToast();
                    return;
                }
                const newAttachment = {
                    uri: response[0]?.uri || "",
                    name: handleFilenameLength(response[0]?.fileName ?? ""),
                    type: response[0]?.type || "",
                    size: fileSize
                };
                setAttachments(prev => [newAttachment, ...prev]);
            }
        } catch (error) {
            console.log(error);
        }
        setIsAttachFileModalVisible(false)
    };
    
    const handleChoosePhoto = async () => {
        try {
            const response = await pickImageFromGallery();
            if (!!response && typeof response !== "string") {
                if(!isValidFileType(response[0]?.type ?? '')){
                    showInvalidTypeToast();
                    return;
                }
                const fileSize = convertFileSizeToMb(response[0]?.fileSize ?? 0)
                if(fileSize > 5) {
                    showFileSizeToast();
                    return;
                }
                const newAttachment = {
                    uri: response[0]?.uri || "",
                    name: handleFilenameLength(response[0]?.fileName ?? ""),
                    type: response[0]?.type || "",
                    size: fileSize
                };
                setAttachments(prev => [newAttachment, ...prev]);
            }
        } catch (error) {
            console.log(error);
        }
        setIsAttachFileModalVisible(false)
    };
    
    const handleChooseDocument = useCallback(async () => {
        try {
            const result = await DocumentPicker.pick({
                presentationStyle: 'fullScreen',
            });
            if(!isValidFileType(result[0]?.type ?? '')){
                showInvalidTypeToast();
                return;
            }
            const fileSize = convertFileSizeToMb(result[0]?.size ?? 0)
            if(fileSize > 5) {
                showFileSizeToast();
                return;
            }
            const newAttachment = {
                uri: result[0]?.uri || "",
                name: handleFilenameLength(result[0]?.name ?? ""),
                type: result[0]?.type || "",
                size: fileSize 
            };
            setAttachments(prev => [newAttachment, ...prev]);
        } catch (err) {
            console.warn(err);
        }
        setIsAttachFileModalVisible(false)
    }, []);

    const RenderItem = (item: ListRenderItemInfo<Attachment>) => {
        return (
            <View key={item.index} style={styles.itemsView}>
                <View style={styles.itemLeftView}>
                    <Icon name={isImage(item.item.type)} />
                    <View>
                        <Typography style={styles.greyText}>{item.item.name}</Typography>
                        <Typography style={[styles.lightGreyText, styles.smallFontSize]}>Size: {item.item.size}MB</Typography>
                    </View>
                </View>
                <Icon onPress={() => {handleRemoveAttachment(item.item.uri)}} name="remove" height={28} width={28} strokeWidth={2} stroke={redText} />
            </View>
        )
    }

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <View style={styles.headerView}>
            <Typography style={styles.title}>Add New Document</Typography>
            <Pressable hitSlop={10} onPress={onClose} style={styles.crossIcon}>
                <Icon name="remove" stroke={text} />
            </Pressable>
        </View>
        <View>
            <Typography style={styles.greyText}>Select Document type*</Typography>
            <CustomDropdown 
            options={documentTypes?.items?.map((item) => { return {value: item.documentTypeId.toString(), label: item.name ?? ''}}) ?? []}
            value={dropdownValue}
            placeholder="Business Card"
            onValueChange={setDropdownValue}/>
        </View>
        <FlatList 
          data={attachments}
          renderItem={RenderItem}
          showsVerticalScrollIndicator={false}
        /> 
        <Pressable onPress={() => setIsAttachFileModalVisible(true)} style={styles.inputContainer}>
            <Icon name="OrangeAddIcon" />
            <View style={styles.inputSubContainer}>
                <Typography style={[styles.greyText, styles.centerText]}>Drag & drop any file here or choose a  file</Typography>
                <Typography style={[styles.lightGreyText, styles.smallFontSize]}>Accept file formats: JPG, PNG, PDF</Typography>
                <Typography style={[styles.lightGreyText, styles.smallFontSize]}>Max file size: 5MB</Typography>
            </View>
        </Pressable>
        <View style={styles.buttonView}>
            <Button disabled={attachments.length < 1 || !dropdownValue} onPress={handleUploadPress} isLoading={isLoading} label="Upload" />
            <Pressable onPress={onClose} style={styles.cancelButtonView}>
                <Typography style={styles.cancelButtonText}>Cancel</Typography>
            </Pressable>
        </View>
      </View>
      <AttachFile 
         isVisible={isAttachFileModalVisible}
         handleChooseDocument={handleChooseDocument}
         handleChoosePhoto={handleChoosePhoto}
         handleTakePhoto={handleTakePhoto}
         onClose={() => setIsAttachFileModalVisible(false)}
      />
    </Modal>
  )
}

