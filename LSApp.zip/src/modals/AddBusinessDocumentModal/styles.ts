import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height }) => ({
  modal: {
    margin: 0,
    marginTop: 40,
    justifyContent:"flex-end"
  },
  container: {
    backgroundColor: colors.background,
    minHeight: height * 0.3,
    maxHeight: height * 0.9,
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    paddingBottom: 24,
    padding:16,
    paddingTop:32,
    gap:16,
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
    alignSelf: "center",
  },
  headerView: {
  },
  title: {
    alignSelf: "center",
    fontWeight: "500",
    fontSize: 16
  },
  crossIcon: {
    alignSelf: "flex-end",
    position:"absolute",
  },
  greyText: {
    color: colors.subText
  },
  inputContainer: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderWidth: 1,
    borderColor: colors.orangePrimary,
    alignItems:"center",
    borderRadius: 8,
    borderStyle: "dashed",
    gap:10
  },
  inputSubContainer: {
    gap: 4,
    alignItems:"center",
  },
  lightGreyText: {
    color: colors.greyDarkMode
  },
  boldText: {
    fontWeight: "500",
    textDecorationLine: "underline"
  },
  buttonView: {
    gap:16
  },
  centerText: {
    textAlign: "center"
  },
  cancelButtonView: {
    alignItems: "center",
    padding: 10
  },
  cancelButtonText: {
    color: colors.orangePrimary,
    fontSize: 16,
    fontWeight: "500"
  },
  itemsView: {
    flexDirection: "row",
    paddingVertical: 8,
    paddingHorizontal: 16,
    justifyContent: "space-between",
    borderWidth: 1,
    borderRadius: 8,
    borderColor: colors.gray6,
    alignItems: "center",
    marginBottom: 16
  },
  itemLeftView: {
    flexDirection: "row",
    alignItems:"center",
    gap: 12
  },
  smallFontSize: {
    fontSize: 12
  }
}))
