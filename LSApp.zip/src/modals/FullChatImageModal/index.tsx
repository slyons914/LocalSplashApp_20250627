import { ActivityIndicator, Image, Pressable, useColorScheme, View } from "react-native"
import Modal from "react-native-modal"
import { useStyles } from "./styles"
import { Icon } from "@components"
import { backIconHitSlope } from "@utils/constants/common"
import { useState } from "react"
import { colors } from "@utils/constants"


interface Props {
    isVisible?: boolean
    onClose?: () => void
    imageUrl: string
}

export const FullChatImageModal = ({
    isVisible,
    onClose = () => { },
    imageUrl
}: Props) => {

    const systemColorScheme = useColorScheme()
    const styles = useStyles()

    const isLightTheme = systemColorScheme === "light"

    const [isImageLoading, setIsImageLoading] = useState(false)
    return (
        <Modal
            isVisible={isVisible}
            style={styles.modal}
            onBackButtonPress={onClose}
            onBackdropPress={onClose}
            animationIn={"zoomIn"}
        >
            <View style={styles.container}>
                <Pressable onPress={onClose}  style={styles.icon} hitSlop={backIconHitSlope}>
                    <Icon name={isLightTheme ? "backIcon" : "bacIconWhite"}></Icon>
                </Pressable>
                <Image 
                    style={styles.image} 
                    source={{uri: imageUrl}} 
                    onLoadStart={() => setIsImageLoading(true)}
                    onLoadEnd={() => setIsImageLoading(false)}
                    resizeMode="contain"
                /> 
                {isImageLoading && <ActivityIndicator color={colors.common.orangePrimary} style={styles.imageLoader} size={"large"}/>}
            </View>
        </Modal>

    )
}

