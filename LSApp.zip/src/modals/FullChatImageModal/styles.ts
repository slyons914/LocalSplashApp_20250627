import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height, width, insets }) => ({
    keyboardAvoidingView: {
        overflow: "hidden",
    },
    container: {
        height:height - (insets.top + 20),
        backgroundColor: colors.background,
        borderTopLeftRadius: 40,
        borderTopRightRadius: 40,
        marginTop: 20,
        paddingVertical: 10,
    },
    modal: {
        margin: 0,
    },
    icon:{
        position: 'absolute',
        top: 14,
        left: 14,
        padding:10,
        zIndex: 1000,
    },
    image: {
        height:"100%",
        width:"100%",
        resizeMode:"cover",
        alignSelf:'center',
    },
    imageLoader: {
        position:"absolute",
        color:colors.orangePrimary,
        top:"50%",
        left:"50%"
    }
}))
