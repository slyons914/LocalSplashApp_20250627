import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height, width }) => ({
    keyboardAvoidingView: {
        overflow: "hidden",
    },
    container: {
        minHeight:height*0.8,
        backgroundColor: colors.background,
        borderTopLeftRadius: 40,
        borderTopRightRadius: 40,
        marginTop: 20,
        paddingVertical: 10,
    },
    contentContainer: {
        marginVertical: 10,
    },
    modal: {
        margin: 0,
        justifyContent:"flex-end"
    },
    dash: {
        height: 5,
        width: 36,
        backgroundColor: colors.gray4,
        alignSelf: "center",
        borderRadius: 5,
        marginVertical: 5,
    },
    header: {
         alignItems: "center",
         borderBottomWidth: 1,
         borderBottomColor: "rgba(0, 0, 0, 0.3)",
         padding: 10,
    },
    horizontalLine: {},
    closeBtn: {
        color: colors.orangePrimary,
        fontSize: 16,
        fontWeight: "500",
    },
    title: {
        color: colors.text,
        fontSize: 16,
        fontWeight: "500",
    },
    leftContainer: {
        // width: 70,
        alignItems:"center"
    },
    experienceHeader: {
        textAlign: "center",
        fontWeight: "600",
        fontSize: 24,
        marginVertical: 30,
    },
    feedbackIcon:{
        alignItems:"center"
    },
    feedbackContainer:{
        alignItems:"center",
        gap:16
    },
    buttonContainer: {
        position:"absolute",
        bottom:20,
        left:width/13
    },
}))
