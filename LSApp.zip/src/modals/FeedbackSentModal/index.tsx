import { ActivityIndicator, Keyboard, KeyboardAvoidingView, Platform, ScrollView, TouchableWithoutFeedback, View } from "react-native"

import { Button, Icon, Typography } from "@components"
import { colors } from "@utils/constants"
import Modal from "react-native-modal"
import { useStyles } from "./styles"


interface Props {
    isVisible?: boolean
    onClose?: () => void
    message: string,
    title: string
}

interface SimpleHeaderProps {
    onRightPress?: () => void
    rightText?: string
    title?: string
    isLoading?: boolean
}

const SimpleHeader = ({
    onRightPress,
    rightText,
    title,
    isLoading,
}: SimpleHeaderProps) => {
    const styles = useStyles()

    const right = isLoading ? (
        <ActivityIndicator color={colors.common.orangePrimary} />
    ) : (
        <Typography type="title" onPress={onRightPress} style={styles.closeBtn}>
            {rightText}
        </Typography>
    )

    return (
        <View style={styles.header}>
            <View style={styles.leftContainer} />
            {!!title && <Typography style={styles.title}>{title}</Typography>}
            {!!rightText ? right : <View />}
        </View >
    )
}

export const FeedbackSentModal = ({
    isVisible,
    onClose = () => { },
    message,
    title
}: Props) => {
    const styles = useStyles()
    return (
        <Modal
            isVisible={isVisible}
            style={styles.modal}
            onBackButtonPress={onClose}
            onBackdropPress={onClose}
        >
            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                style={styles.container}>
                <TouchableWithoutFeedback onPress={Keyboard.dismiss} >
                    <ScrollView style={styles.keyboardAvoidingView}  >
                        <View style={styles.dash} />
                        <SimpleHeader
                            title={title}
                            onRightPress={onClose}
                        />
                        <View style={styles.horizontalLine} />
                        <Typography type="title" style={styles.experienceHeader} >Thank You!</Typography>
                        <View style={styles.feedbackContainer}>
                            <View style={styles.feedbackIcon}>
                                <Icon name="FeedbackIcon"></Icon>
                            </View>
                            <Typography>{message}</Typography>
                        </View>
                    </ScrollView>
                </TouchableWithoutFeedback>
                <View style={styles.buttonContainer} >
                    <Button
                        label="Done"
                        onPress={onClose}/>
                </View>
            </KeyboardAvoidingView>
        </Modal>

    )
}

