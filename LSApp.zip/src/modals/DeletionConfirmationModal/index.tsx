import { Pressable, View } from "react-native"

import Modal from "react-native-modal"

import { Typography } from "@components"

import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
  confirmationMessage: string,
  onDeletePress: () => void
}

export const DeletionConfirmationModal = ({ isVisible, onClose, confirmationMessage, onDeletePress}: Props) => {

  const styles = useStyles()

  const handleDeletePress = () => {
    onClose()
    onDeletePress() 
  }
  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.textView}>
            <Typography type={"subtext"} style={styles.text}>
                {confirmationMessage}
            </Typography>
        </View>
        <View style={styles.mainView}>
            <Pressable onPress={onClose} style={styles.buttonTextView}>
                <Typography style={[styles.blueText, styles.title]}>Cancel</Typography>
            </Pressable>
            <Pressable onPress={handleDeletePress} style={styles.buttonTextView}>
                <Typography style={[styles.title, styles.blueText]}>Delete</Typography>
            </Pressable>
        </View>
      </View>
    </Modal>
  )
}
