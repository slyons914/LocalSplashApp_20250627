import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height,width }) => ({
  modal: {
    margin: 0,
    alignSelf:"center"
  },
  container: {
    backgroundColor: colors.background,
    borderRadius:14,
    alignItems: "center",
    width: 280,
  },
  title: {
    fontSize: 16,
    marginBottom:4,
    textAlign:'center',
    fontWeight: "400"
  },
  text: {
    fontSize: 14,
    textAlign: "center",
    paddingHorizontal: 16,
    color:colors.subText,
    lineHeight:21
  },
  blueText: {
    fontSize:16,
    color:colors.blue,
    fontWeight: "600",
  },
  buttonTextView: {
    paddingVertical: 11,
    paddingHorizontal: 8,
    borderTopWidth:0.5,
    borderTopColor:colors.grey,
    textAlign:"center",
    width:"50%"
  },
  textView: {
    padding:8,
    alignItems:"center"
  },
  mainView: {
    flexDirection:"row", 
    width:"100%", 
    justifyContent:"space-between"
  }
}))
