import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height,width }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: colors.background,
    minHeight: height * 0.2,
    maxHeight:height*0.93,
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    paddingTop: 29,
    gap:8
  },
  title: {
    alignSelf:"center",
    fontSize: 16,
    fontWeight: "500",
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
    alignSelf:"center"
  },
  reviewType:{
    flexDirection:"row",
    gap:5,
    alignItems:"center"
  },
  lightText:{
    color:colors.gray4,
    marginTop:5
  },
  largeText:{
    fontSize:20,
    fontWeight:"500",
    paddingHorizontal: 24,
  },
  reviewItem:{
    flexDirection:"row",
  },
  reviewItemKey:{
    width:width*0.30,
    color:colors.greyText,
    fontSize:12
  },
  reviewItemValue:{
    fontSize:12,
    width:width*0.6
  },
  mediumText:{
    fontSize:14
  },
  reviews:{
    gap:5,
    paddingTop:10,
    paddingBottom:10,
    paddingHorizontal: 24,
  },
  lightBackground:{
    backgroundColor:colors.greyLight
  },
  titleHeader:{
    borderBottomWidth:0.2,
    marginBottom: 24,
  },
  cancelButton: {
    width: 74,
    color: colors.orangePrimary,
    position:"absolute",
    right:0,
  },
  cancelButtonText: {
    color: colors.orangePrimary,
  },
  blackText:{
    color:colors.greyText
  }
}))
