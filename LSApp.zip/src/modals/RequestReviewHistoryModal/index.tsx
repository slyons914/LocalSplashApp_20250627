import { Pressable, View } from "react-native"

import Modal from "react-native-modal"

import { Button, Typography } from "@components"
import { useStyles } from "./styles"
import { ScrollView } from "react-native-gesture-handler"
import { ReviewReqeusts } from "@models/index"
import moment from "moment"
interface Props {
  isVisible: boolean
  onClose: () => void
  isLightTheme:boolean
  reviewData:ReviewReqeusts | null
}

export const RequestReviewHistoryModal = ({ isVisible, onClose, isLightTheme,reviewData }: Props) => {
  const styles = useStyles()
  const displayRelativeTime = (dateTimeString:string) => {
    const parsedDate = moment(dateTimeString, "YYYY-MM-DDTHH:mm:ss");
    return parsedDate.fromNow();
  };
  return (
    
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <View style={styles.titleHeader}>
        <Pressable style={styles.cancelButton} onPress={onClose}>
            <Typography style={styles.cancelButtonText}>Cancel</Typography>
        </Pressable>
        <Typography style={styles.title}>Request Review History</Typography>
        </View>
            <Typography style={styles.largeText}>Request Reviews ({reviewData?.requests.length ?? 0})</Typography>
        <ScrollView 
        contentContainerStyle={{flexGrow:1, marginBottom:16}}>
        {reviewData?.requests.map((item,index)=>(
            <View key={index} style={[styles.reviews, index%2===0 && styles.lightBackground]}>
            <View style={styles.reviewItem}>
                <Typography style={[styles.reviewItemKey, index%2===0 && styles.blackText]}>Name</Typography>
                <Typography style={[styles.mediumText, index%2===0 && !isLightTheme && styles.blackText]}>{item.name}</Typography>
            </View>
            <View style={styles.reviewItem}>
                <Typography style={styles.reviewItemKey}>Email</Typography>
                <Typography style={[styles.reviewItemValue, index%2===0 && !isLightTheme && styles.blackText]}>{item.email}</Typography>
            </View>
            <View style={styles.reviewItem}>
                <Typography style={styles.reviewItemKey}>Phone</Typography>
                <Typography style={[styles.reviewItemValue, index%2===0 && !isLightTheme && styles.blackText]}>{item.phone}</Typography>
            </View>
            <View style={styles.reviewItem}>
                <Typography style={styles.reviewItemKey}>Date Created</Typography>
                <Typography style={[styles.reviewItemValue, index%2===0 && !isLightTheme && styles.blackText]}>{displayRelativeTime(item.dateCreated)}</Typography>
            </View>
            <View style={styles.reviewItem}>
                <Typography style={styles.reviewItemKey}>Location</Typography>
                <Typography style={[styles.reviewItemValue, index%2===0 && !isLightTheme && styles.blackText]}>{item.businessName + item.businessCity + item.businessState}</Typography>
            </View>
        </View>
        ))}
        </ScrollView>
      </View>
    </Modal>
    
  )
}
