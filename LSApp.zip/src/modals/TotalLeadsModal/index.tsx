import { Linking, Pressable, View } from "react-native"

import Modal from "react-native-modal"

import { Icon, Typography } from "@components"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
}

export const TotalLeadsModal = ({ isVisible, onClose }: Props) => {
  const styles = useStyles()

  const { text } = useColors()

  const onPhonePress = () => {
    Linking.openURL("tel:1-800-423-3367")
  }

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <Typography style={styles.title}>Total Leads</Typography>
        <Pressable style={styles.close} onPress={onClose}>
          <Icon name={"remove"} stroke={text} />
        </Pressable>
        <View style={styles.textContainer}>
          <Typography type={"subtext"} style={styles.text}>
            This section shows the total number of activities we have collected for your business,
            which is the sum of the following: Website Leads + Call Tracking + Google Actions +
            Google Ads Clicks + Facebook Ads Clicks + Listings Clicks.
          </Typography>
          <Typography type={"subtext"} style={styles.text}>
            You may not see data on some of the sections if the product is not activated or your
            Google profile is not verified.
          </Typography>
          <Typography type={"subtext"} style={styles.text}>
            If you do not see data, please contact our support team today at{" "}
            <Typography onPress={onPhonePress} style={[styles.text, styles.orangeText]}>
              877-635-6225
            </Typography>
            .
          </Typography>
        </View>
      </View>
    </Modal>
  )
}
