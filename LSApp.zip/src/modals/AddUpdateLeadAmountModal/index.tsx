import { ActivityIndicator, View } from "react-native"
import { Input, Typography } from "@components"
import { useStyles } from "./styles"
import { observer } from "mobx-react-lite"
import { useEffect, useState } from "react"
import { colors } from "@utils/constants"
import Modal from "react-native-modal"
import { Lead } from "@models/leads"

interface Props {
    isVisible: boolean
    onClose: () => void
    lead: Lead | null
    onSavePress: (val: string) => Promise<void>
}

const Component = ({ isVisible, onClose, lead, onSavePress }: Props) => {
    const styles = useStyles()
    const [isLoading, setIsLoading] = useState(false)
    const [leadAmount, setLeadAmount] = useState(lead?.customerAmount?.toString())

    const handleSavePress = async () => {
        setIsLoading(true)
        try {
            await onSavePress(leadAmount ?? '')
        } catch {
            setIsLoading(false)
        } finally {
            setIsLoading(false)
            onClose()
        }
    }

    useEffect(() => {
        setLeadAmount(lead?.customerAmount?.toString())
    },[lead])

    return (
        <Modal
            isVisible={isVisible}
            onBackdropPress={onClose}
            onBackButtonPress={onClose}
            onSwipeComplete={onClose}
            style={styles.modal}
            avoidKeyboard
        >
            <View style={styles.container}>
                <View style={styles.dash} />
                <View style={styles.header}>
                    <Typography onPress={onClose} style={styles.headerItem}>Cancel</Typography>
                    <Typography style={styles.title}>{lead?.customerAmount ? "Edit Amount" : "Add Amount"}</Typography>
                    <View style={styles.loaderView}>
                    {
                        isLoading ? ( <ActivityIndicator size={"small"} color={colors.common.orangePrimary}></ActivityIndicator> ) : (
                            <Typography onPress={handleSavePress} style={styles.headerItem}>Add</Typography>
                        )
                    }
                    </View>
                </View>
                <View style={styles.textInputView}>
                    <Input 
                        label="Amount *"
                        value={leadAmount ?? ''}
                        onChange={setLeadAmount}
                        keyboardType="number-pad"
                        placeholder="Enter Amount"
                    />
                </View>
            </View>
        </Modal>
    )
}

export const AddUpdateLeadAmountModal = observer(Component)

