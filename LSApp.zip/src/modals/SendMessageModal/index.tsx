import { ActivityIndicator, Keyboard, KeyboardAvoidingView, Platform, Pressable, ScrollView, TouchableWithoutFeedback, View } from "react-native"

import Modal from "react-native-modal"
import DocumentPicker from 'react-native-document-picker'


import { AppTextInput, CustomDropdown, ErrorMessage, Icon, SimpleHeader, Typography } from "@components"
import { useFormik } from 'formik'
import * as Yup from 'yup'
import { useStyles } from "./styles"
import React, { useCallback, useState } from "react"
import { FormatHelper, pickImageFromGallery, takePhotoWithCamera } from "@utils/helpers"
import { useStore } from "@store"
import { DecodedToken } from "@models/index"
import jwt_decode from "jwt-decode"
import { MobileAPI } from "@api"
import { FeedbackSentModal } from "@modals/FeedbackSentModal"
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view"

interface Props {
    isVisible?: boolean
    onClose?: () => void
}

interface Attachment {
    uri: string;
    name: string;
    type: string;
}

const validationSchema = Yup.object().shape({
    firstName: Yup.string().required('First Name is required'),
    lastName: Yup.string().required('Last Name is required'),
    email: Yup.string().email('Invalid email').required('Email is required'),
    phone: Yup.string().required('Phone number is required'),
    message: Yup.string().required("Message is required").max(1500, 'Message must be at most 1500 characters'),
    subject: Yup.string().required('Subject is required'),
});

export const SendMessageModal = ({
    isVisible,
    onClose = () => { },
}: Props) => {
    const styles = useStyles()
    const maxLength = 1500;
    const [isAttachFileModalVisible, setIsAttachFileModalVisible] = useState(false)
    const [attachments, setAttachments] = useState<Attachment[]>([]);
    const [loading , setLoading] = useState(false)
    const [errorText , setErrorText] = useState("")
    const [responseText, setResponseText] = useState("")
    const [isMessageSentModalVisible, setIsMessageSentModalVisible] = useState(false)
    const { authStore } = useStore()
    const { accessToken } = authStore
    const decoded: DecodedToken = jwt_decode(accessToken)

    const options = [
        { label: 'Billing', value: 'Billing' },
        { label: 'Verification', value: 'Verification' },
        { label: 'Website', value: 'Website' },
        { label: 'Google', value: 'Google' },
        { label: 'Facebook', value: 'Facebook' },
        { label: 'Google Guaranteed', value: 'Google_Guaranteed' },
        { label: 'Business Information', value: 'Business_Information' },
        { label: 'Cancellation', value: 'Cancellation' },
        { label: 'General Question', value: 'General_Question' },
    ];

    const handleRemoveAttachment = (uri: string) => {
        setAttachments(prevAttachments => prevAttachments.filter(attachment => attachment.uri !== uri));
    };

    const initialValues = {
        firstName: decoded?.given_name,
        lastName: decoded?.family_name,
        email: decoded?.email,
        phone: decoded?.phone_number,
        message: "",
        subject: "",
    }

    const { handleBlur, handleChange, handleSubmit, touched, errors, values, setFieldValue, resetForm } = useFormik({
        initialValues: initialValues,
        validationSchema: validationSchema,
        onSubmit: async (values) => {
            setErrorText("")
            setResponseText("")
            setLoading(true)
            const formData = new FormData()
            formData.append("FirstName", values.firstName)
            formData.append("LastName", values.lastName)
            formData.append("Email", values.email)
            formData.append("Phone",  FormatHelper.formatPhoneNumberForContact(values.phone))
            formData.append("Subject", values.subject)
            formData.append("Message", values.message)
            formData.append("Files", attachments)
            try{
                const response = await MobileAPI.ContactUs(formData)
                if(response.data){
                    setErrorText("")
                    setAttachments([])
                    resetForm()
                    setIsMessageSentModalVisible(true)
                }
            }catch{
                    setErrorText("Error while sending message")
                    setResponseText("")
            }finally{
                setLoading(false)
            }
        }
    })

    const handleTakePhoto = async () => {
        try {
            setIsAttachFileModalVisible(false)
            const response = await takePhotoWithCamera();
            if (!!response && typeof response !== "string") {
                const newAttachment = {
                    uri: response[0]?.uri || "",
                    name: response[0]?.fileName || "",
                    type: response[0]?.type || "",
                };
                setAttachments(prev => [...prev, newAttachment]);
            }
        } catch (error) {
            console.log(error);
        }
    };

    const handleChoosePhoto = async () => {
        try {
            setIsAttachFileModalVisible(false)
            const response = await pickImageFromGallery();
            if (!!response && typeof response !== "string") {
                const newAttachment = {
                    uri: response[0]?.uri || "",
                    name: response[0]?.fileName || "",
                    type: response[0]?.type || "",
                };
                setAttachments(prev => [...prev, newAttachment]);
            }
        } catch (error) {
            console.log(error);
        }
    };

    const handleChooseDocument = useCallback(async () => {
        try {
            setIsAttachFileModalVisible(false)
            const result = await DocumentPicker.pick({
                presentationStyle: 'fullScreen',
            });
            const newAttachment = {
                uri: result[0]?.uri || "",
                name: result[0]?.name || "",
                type: result[0]?.type || "",
            };
            setAttachments(prev => [...prev, newAttachment]);
        } catch (err) {
            console.warn(err);
        }
    }, []);

    const onCloseMessageModal = () =>{
        setErrorText("")
        setResponseText("")
        setAttachments([])
        onClose()
    }

    const onFeedbackSendClose = () =>{
        onClose()
        setIsMessageSentModalVisible(false)
    }

    return (
        <React.Fragment>
            <Modal
                isVisible={isVisible}
                style={styles.modal}
                onBackButtonPress={onCloseMessageModal}
                onBackdropPress={onCloseMessageModal}
            >
                <KeyboardAvoidingView
                    style={styles.container}>
                    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
                        <View style={styles.keyboardAvoidingView}>
                            <SimpleHeader
                                onLeftPress={onCloseMessageModal}
                                title="Contact Us"
                                rightText="Send"
                                isRightVisible={true}
                                onRightPress={handleSubmit}
                                isLoading={loading}
                            />
                            <KeyboardAwareScrollView
                                style={styles.contentContainer}
                                scrollEnabled={true}
                                keyboardShouldPersistTaps="handled"
                                showsVerticalScrollIndicator={false}
                                extraHeight={150}
                            >
                                <AppTextInput
                                    title="First Name*"
                                    placeholder="Type your First name ..."
                                    value={values?.firstName}
                                    onChangeText={handleChange("firstName")}
                                    onBlur={handleBlur("firstName")}
                                />
                                {touched?.firstName && errors?.firstName && (
                                    <ErrorMessage message={errors?.firstName} />
                                )}
                                <AppTextInput
                                    title="Last Name*"
                                    placeholder="Type your Last name ..."
                                    value={values?.lastName}
                                    onChangeText={handleChange("lastName")}
                                    onBlur={handleBlur("lastName")}
                                />
                                {touched?.lastName && errors?.lastName && (
                                    <ErrorMessage message={errors?.lastName} />
                                )}
                                <AppTextInput
                                    title="Email*"
                                    placeholder="Type your email ..."
                                    value={values?.email}
                                    onChangeText={handleChange("email")}
                                    onBlur={handleBlur("email")}
                                />
                                {touched?.email && errors?.email && (
                                    <ErrorMessage message={errors?.email} />
                                )}
                                <AppTextInput
                                    title="Phone*"
                                    placeholder="Type your phone number ..."
                                    value={values?.phone}
                                    onChangeText={handleChange("phone")}
                                    onBlur={handleBlur("phone")}
                                />
                                {touched?.phone && errors?.phone && (
                                    <ErrorMessage message={errors?.phone} />
                                )}
                                <View
                                    style={styles.dropdownContainer}
                                >
                                    <Typography>Subject*</Typography>
                                    <CustomDropdown
                                        options={options}
                                        placeholder="Select subject"
                                        value={values.subject}
                                        onValueChange={(value) => setFieldValue('subject', value)}
                                    />
                                    {touched?.subject && errors?.subject && (
                                        <ErrorMessage message={errors?.subject} />
                                    )}
                                </View>
                                <AppTextInput
                                    title="Message"
                                    placeholder="Type your message here ..."
                                    multiline
                                    maxLength={maxLength}
                                    style={styles.multilineText}
                                    value={values?.message}
                                    onChangeText={handleChange("message")}
                                    onBlur={handleBlur("message")}
                                />
                                {touched?.message && errors?.message && (
                                    <ErrorMessage message={errors?.message} />
                                )}
                                <Typography
                                    type="default"
                                    style={styles.counter}
                                >{`${values?.message?.length} / 1500 characters`}</Typography>
                                {attachments?.map((attachment) => (
                                    <View key={attachment?.uri} style={styles.attachedFilesContainer}>
                                        <Icon name={attachment?.type.includes('image') ? 'jpg' : 'pdf'} />
                                        <Typography type="default" style={styles.documentName}>{attachment?.name}</Typography>
                                        <Pressable onPress={() => handleRemoveAttachment(attachment?.uri)}>
                                            <Icon name="trash" />
                                        </Pressable>
                                    </View>
                                ))}
                                {
                                   errorText? (<Typography style={[styles.errorMessage,styles.centerText]}>{errorText}</Typography>):(null)
                                }
                                {
                                   responseText? (<Typography style={[styles.green,styles.centerText]}>{responseText}</Typography>):(null)
                                }
                                <View style={styles.fileUploadContainer} >
                                    <Icon name="file_upload" />
                                    <Typography type="default"
                                        onPress={() => setIsAttachFileModalVisible(true)}
                                        style={styles.attachFileText} >Attach File</Typography>
                                </View>
                            </KeyboardAwareScrollView>
                        </View>
                    </TouchableWithoutFeedback>
                    <FeedbackSentModal title="Contact Us" message={"Your message has been successfully submitted."} isVisible={isMessageSentModalVisible} onClose={()=>onFeedbackSendClose()}></FeedbackSentModal>
                </KeyboardAvoidingView>
                {
                                isAttachFileModalVisible ? (
                                <Pressable onPress={()=>setIsAttachFileModalVisible(false)} style={styles.blur}>   
                                <View style={styles.inputContainer}>
                                    <Pressable style={styles.listItem} onPress={handleChoosePhoto}>
                                        <Typography
                                            type='default'
                                            >Photo Library</Typography>
                                        <Icon name='gallery' />
                                    </Pressable>
                                    <Pressable style={styles.listItem} onPress={handleTakePhoto}>
                                        <Typography type='default' >Take Photo or Video</Typography>
                                        <Icon name='camera_icon' />
                                    </Pressable>
                                    <Pressable style={styles.listItem} onPress={handleChooseDocument}>
                                        <Typography type='default' >Choose File</Typography>
                                        <Icon name='folder' />
                                    </Pressable>
                                </View>
                                </Pressable>
                                ):(null)
                            }
            </Modal>
        </React.Fragment>
    )
}