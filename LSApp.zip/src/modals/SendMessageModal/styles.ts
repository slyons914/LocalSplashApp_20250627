import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height, width, insets }) => ({
    keyboardAvoidingView: {
        flex: 1,
    },
    container: {
        backgroundColor: colors.background,
        borderTopLeftRadius: 40,
        borderTopRightRadius: 40,
        paddingTop: 29,
        paddingHorizontal: 24,
        flex: 1,
        marginTop: insets.top||20,
    },
    helpText: {
        fontWeight: "600",
        fontSize: 24,
    },
    contentContainer: {
        flex: 1,
        marginVertical: 10,
    },
    modal: {
        margin: 0,
        justifyContent: "flex-end",
        flex: 1,
    },
    dropdownContainer: {},
    dropdown: {
        flexDirection: "row",
        borderColor: colors.gray6,
        borderWidth: 1,
        borderRadius: 8,
        paddingHorizontal: 24,
        paddingVertical: 16,
    },
    dropdownTitle: {
        flex: 1,
        color: colors.grey6,
        fontWeight: "400",
    },
    multilineText: {
        minHeight: 150,
        maxHeight:150,
        textAlignVertical: "top",
    },
    counter: {
        color: colors.gray4,
    },
    fileUploadContainer: {
        flexDirection: "row",
        marginVertical: 10,
        gap: 10,
        alignItems: "center",
    },
    attachFileText: {
        color: colors.orangePrimary,
        fontWeight: "500",
        fontSize: 16,
    },
    errorMessage: {
        color: colors.red
    },
    attachedFilesContainer: {
        flexDirection: "row",
        marginVertical: 5,
        alignItems: "center",
    },
    green:{
        color:colors.green
    },
    centerText:{
        textAlign:"center"
    },
    documentName: { flex: 1, marginLeft: 10 },
    inputContainer: {
        position:"absolute",
        borderRadius: 12,
        backgroundColor: colors.background,
        width: width * 0.5,
        top:"40%",
        left:"25%",
    },
    listItem: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        borderBottomColor: "rgba(60, 60, 67, 0.36)",
        borderBottomWidth: 1,
        padding: 10
    },
    blur:{
        position:"absolute",
        height:"100%",
        width:"100%",
        backgroundColor:"rgb(0, 0, 0)",
        opacity:0.92
    }
}))
