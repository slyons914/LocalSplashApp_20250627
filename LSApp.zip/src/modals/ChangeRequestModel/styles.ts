import { Input } from "@components"
import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: colors.background,
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    paddingHorizontal:20,
    paddingTop:4,
    paddingBottom:16,
    minHeight: height * 0.65,
    maxHeight: height * 0.9
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    alignSelf:"center",
    marginBottom:16
  },
  close: {
    position :"absolute",
    right:10
  },
  modalHeader:{
    flexDirection:"row",
    gap:5,
    alignItems:"center",
    marginBottom:12,
    justifyContent:"center"
  },
  headerTextView: {
    borderRadius:16,
    marginBottom:10,
    backgroundColor:colors.orangeLight,
    padding:10,
  },

  redText:{
    fontSize:12,
    color:colors.red,
  },
  textInput: {
    borderWidth: 1,
    borderColor: colors.gray6,
    borderRadius: 8,
    paddingHorizontal: 24,
    paddingVertical: 16,
    color: colors.text,
    height:170
  },
  lightText:{
    color:colors.gray4,
    marginTop:5,
    marginBottom:16
  },
  button: {
    marginTop: 20,
    width: 342,
  },
  cancelButton: {
    marginTop: 10,
    width: 342,
    backgroundColor: colors.white,
    color: colors.orangePrimary,
  },
  cancelButtonText: {
    color: colors.orangePrimary,
  },
  inputView:{
    alignItems:"center",
    padding:12, 
    borderWidth:1,
    borderColor:colors.orangePrimary,
    borderStyle:'dashed',
    borderRadius:8
  },
  orangeText:{
    color:colors.orangePrimary,
    fontSize:16,
    fontWeight:"500"
  },
  inputText:{
    color:colors.subText,
    textAlign:"center",
    fontSize:12
  },
  inputViewHeader:{
    flexDirection:"row",
    gap:10,
    marginBottom:6
  },
  countText: {
    alignSelf:"flex-end", 
    marginTop:8
  },
  attachedFilesContainer: {
    flexDirection: "row",
    marginVertical: 5,
    alignItems: "center",
    gap:8
   },
   documentName: { 
    flex: 1,
    marginLeft: 10 
   },

}))
