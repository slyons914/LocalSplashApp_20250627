import { useCallback, useEffect, useState } from "react"

import { Pressable, TextInput, useColorScheme, View } from "react-native"

import Modal from "react-native-modal"

import { Button, Icon, Typography } from "@components"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"
import { colors } from "@utils/constants"
import { backIconHitSlope } from "@utils/constants/common"
import { ScrollView } from "react-native-gesture-handler"
import { AttachFile } from "@modals/AttachFileModal"
import { pickImageFromGallery, takePhotoWithCamera } from "@utils/helpers"
import DocumentPicker from 'react-native-document-picker'
import Toast from 'react-native-simple-toast';

import { usePermissions } from "../../screens/Permissions/use-permissions"


interface Attachment {
    uri: string;
    name: string;
    type: string;
}
interface Props {
  isVisible: boolean
  onClose: () => void
}

export const ChangeRequestModal = ({ isVisible, onClose }: Props) => {
  const [value, setValue] = useState("")  
  const styles = useStyles()
  const { text } = useColors()

  const {permissions, requestPermission} = usePermissions()

  const [isAttachFileModalVisible, setIsAttachFileModalVisible] = useState(false)
  const [attachments, setAttachments] = useState<Attachment[]>([]);

  const isDarkTheme = useColorScheme() === "dark"
  
    const icons = { 
            jpg: isDarkTheme ? "jpgWhite" : "jpg",
            mp4: isDarkTheme ? "mp4Dark" : "mp4White", 
            trash: isDarkTheme ? "trashDark" : "trash"
    }

    const onChangeHandler = (value: string) => {
        setValue(value)
    }

    const isValidFileType = (type: string) => {
        const validTypes = ['image/jpeg','image/jpg',  'image/png', 'video/mp4'];
        return validTypes.includes(type);
    }

    const showInvalidTypeToast = () => {
        Toast.showWithGravity(
            'Only JPG, PNG and MP4 is allowed',
            Toast.LONG,
            Toast.BOTTOM,
          );
        setIsAttachFileModalVisible(false)
    }

    const handleTakePhoto = async () => {
        try {
            if (!permissions.camera) {
                await requestPermission("camera")
            }
            const response = await takePhotoWithCamera();
            if (!!response && typeof response !== "string") {
                if(!isValidFileType(response[0].type ?? "")) {
                    showInvalidTypeToast()
                    return ;
                }
                const newAttachment = {
                    uri: response[0]?.uri || "",
                    name: response[0]?.fileName || "",
                    type: response[0]?.type || "",
                };
                setAttachments(prev => [...prev, newAttachment]);
            }
        } catch (error) {
            console.log(error);
        }
        setIsAttachFileModalVisible(false)
    };

    const handleChoosePhoto = async () => {
        try {
            const response = await pickImageFromGallery();
            if (!!response && typeof response !== "string") {
                if(!isValidFileType(response[0].type ?? "")) {
                    showInvalidTypeToast()
                    return;
                }
                const newAttachment = {
                    uri: response[0]?.uri || "",
                    name: response[0]?.fileName || "",
                    type: response[0]?.type || "",
                };
                setAttachments(prev => [...prev, newAttachment]);
            }
        } catch (error) {
            console.log(error);
        }
        setIsAttachFileModalVisible(false)
    };

    const handleChooseDocument = useCallback(async () => {
        try {

            const result = await DocumentPicker.pick({
                presentationStyle: 'fullScreen',
            });
            if(!isValidFileType(result[0].type ?? "")) {
               showInvalidTypeToast()
               return ;
            }
            const newAttachment = {
                uri: result[0]?.uri || "",
                name: result[0]?.name || "",
                type: result[0]?.type || "",
            };
            setAttachments(prev => [...prev, newAttachment]);
        } catch (err) {
            console.warn(err);
        }
        setIsAttachFileModalVisible(false)
    }, []);

    const handleRemoveAttachment = (uri: string) => {
        setAttachments(prevAttachments => prevAttachments.filter(attachment => attachment.uri !== uri));
    };

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
          <View style={styles.dash} />
          <ScrollView showsVerticalScrollIndicator={false}>
          <View>
            <View style={styles.modalHeader}>
            <Typography style={styles.title}>Request Changes</Typography>
            <Icon name={!isDarkTheme ? "helpSquareBlack" : "helpSquare"}></Icon>
            <Pressable hitSlop={backIconHitSlope} style={styles.close} onPress={onClose}>
                <Icon name={"remove"} stroke={text} />
            </Pressable>
        </View>
        <View style={styles.headerTextView}>
            <Typography style={styles.redText}>Frequent changes to your Ad may have a negative impact on Ad performance & results.</Typography>
        </View>
        </View>
        <Typography>Description*</Typography>
        <TextInput
              value={value}
              textAlignVertical={"top"}
              placeholderTextColor={colors.common.gray4}
              onChangeText={onChangeHandler}
              placeholder={"Type Your message here .."}
              style={styles.textInput}
              multiline={true}
              
            />
        <Typography style={styles.lightText}>0/1500 characters</Typography>    
        {attachments?.map((attachment) => 
            (
                <View key={attachment?.uri} style={styles.attachedFilesContainer}>
                    <Icon name={attachment?.type.includes('image') ? icons.jpg : icons.mp4} />
                    <Typography type="default" style={styles.documentName}>{attachment?.name}</Typography>
                    <Pressable onPress={() => handleRemoveAttachment(attachment?.uri)}>
                        <Icon name={icons.trash} />
                    </Pressable>
                </View>
            ))}    
        <Pressable onPress={()=> setIsAttachFileModalVisible(true)} style={styles.inputView}>
            <View style={styles.inputViewHeader}>
                <Icon name="AttachFileIcon"></Icon>
                <Typography style={styles.orangeText}>Attach File</Typography>
            </View>
            <Typography style={styles.inputText}>Click or Drag photo here to upload image</Typography>
            <Typography style={styles.inputText}>File formats: JPG, PNG, MP4</Typography>
            <Typography style={styles.inputText}>Minimum dimensions: 600 x 600 pixels.</Typography>
            <Typography style={styles.inputText}>Maximum dimensions: No limit</Typography>
            <Typography style={styles.inputText}>Maximum photo file size: 30MB</Typography>
            <Typography style={styles.inputText}>Maximum video file size: 2GB</Typography>
            <Typography style={styles.inputText}>Maximum number of media files (photos and videos combined): 10</Typography>
            <Typography style={styles.inputText}>Maximum combined media file size: 2GB</Typography>
            <Typography style={[styles.inputText, styles.countText]}>{attachments.length}/10</Typography>
        </Pressable>
        <Button onPress={()=>console.log("hello")} btnStyle={styles.button} label={"Submit"} />
        <Button
            btnStyle={styles.cancelButton}
            labelStyle={styles.cancelButtonText}
            onPress={onClose}
            label={"Cancel"}
          />
          </ScrollView>
      <AttachFile 
        isVisible={isAttachFileModalVisible} 
        onClose={() => setIsAttachFileModalVisible(false)}
        handleChooseDocument={handleChooseDocument}
        handleChoosePhoto={handleChoosePhoto}
        handleTakePhoto={handleTakePhoto}/>    
      </View>
    </Modal>
  )
}
