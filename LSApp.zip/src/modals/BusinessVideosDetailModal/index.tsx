import { ActivityIndicator, Image, Pressable, useColorScheme, View } from "react-native"
import Modal from "react-native-modal"
import { useStyles } from "./styles"
import { Icon, Typography } from "@components"
import { backIconHitSlope } from "@utils/constants/common"
import { useState } from "react"
import { colors } from "@utils/constants"
import { MediaViewModel } from "@localsplash/mobile-api-client"
import { useStore } from "@store"
import { BusinessInfoAPI } from "@api"
import Pdf from "react-native-pdf"
import Video from "react-native-video"


interface Props {
    isVisible?: boolean
    onClose?: () => void
    videoUrl: string,
    videoList: MediaViewModel [] | undefined,
    videoIndex: number,
    setCurrentVideo: (val:string) => void,
    setCurrentVideoIndex: (val:number) => void
}

export const BusinessVideoDetailModal = ({
    isVisible,
    onClose = () => { },
    videoUrl,
    videoList,
    videoIndex,
    setCurrentVideo,
    setCurrentVideoIndex,
}: Props) => {

    const systemColorScheme = useColorScheme()
    const styles = useStyles()

    const isLightTheme = systemColorScheme === "light"

    const [isImageLoading, setIsImageLoading] = useState(false)
    const [isDeleting, setIsDeleting] = useState(false)

    const { homeStore, businessInfoStore } = useStore()
    const { locationsItem } = homeStore
    const { getBusinessVideos } = businessInfoStore

    const onNextPress = () => {
        if(!videoList) return
        if(videoIndex + 1 < videoList.length ) {
            setCurrentVideo(videoList[videoIndex + 1]?.mediaUrl ?? "")
            setCurrentVideoIndex(videoIndex + 1)
        }
    }

    const onBackPress = () => {
        if(!videoList) return
        if(videoIndex > 0 ) {
            setCurrentVideo(videoList[videoIndex - 1]?.mediaUrl ?? "")
            setCurrentVideoIndex(videoIndex - 1)
        }
    }

    const onDeletePress = async () => {
        if(!locationsItem?.id)
            return;
        const selectedVideo = [videoUrl]
        try {
            setIsDeleting(true)
            await BusinessInfoAPI.deleteBusinesVideos(locationsItem.id, selectedVideo)
            await getBusinessVideos(locationsItem.id)
        } catch {
            console.log('Error deleting Video')
        } finally {
            setIsDeleting(false)
            onClose()
        }
    }
    return (
        <Modal
            isVisible={isVisible}
            style={styles.modal}
            onBackButtonPress={onClose}
            onBackdropPress={onClose}
            animationIn={"slideInUp"}
            animationOut={"slideOutDown"}
        >
            <View style={styles.container}>
            <View style={styles.dash} />
                <View style={styles.headerView}>
                    <Pressable onPress={onClose}  style={styles.icon} hitSlop={backIconHitSlope}>
                        <Icon name={isLightTheme ? "backIcon" : "bacIconWhite"}></Icon>
                    </Pressable>
                    <Typography style={styles.headerTitle}>Business Video</Typography>
                    <Pressable hitSlop={backIconHitSlope} onPress={onDeletePress}>
                    {
                        isDeleting ? (
                            <View>
                                <ActivityIndicator size={"small"} color={colors.common.orangePrimary} />
                            </View>
                        ) : (
                            <Icon name="trashOrange"></Icon>
                        )
                    }
                    </Pressable>
                </View>
                <View style={styles.imageView}>
                    <Video 
                    style={styles.image} 
                    source={{uri: videoUrl}} 
                    controls
                    controlsStyles={{
                        hideNext:true,
                        hidePrevious:true
                    }}
                    resizeMode='none'
                    /> 
                    {isImageLoading && <ActivityIndicator color={colors.common.orangePrimary} style={styles.imageLoader} size={"large"}/>}
                </View>
                <View style={styles.buttonView}>
                    <Pressable onPress={onBackPress}>
                        <Icon name={"photoLeft"}></Icon>
                    </Pressable>
                    <Typography>{videoIndex + 1}/{videoList?.length}</Typography>
                    <Pressable onPress={onNextPress}>
                        <Icon name={"photoRight"}></Icon>
                    </Pressable>
                </View>
            </View>
        </Modal>

    )
}

