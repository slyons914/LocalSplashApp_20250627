import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height, width,insets }) => ({
  modal: {
    margin: 0,
    justifyContent:"flex-start"
  },
  container: {
    backgroundColor: colors.background,
    minHeight: height,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    alignItems: "center",
    marginTop:insets.top? insets.top+ 30 : 30
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top:5
  },
  cancelText:{
    fontSize:16,
    textAlign:"center",
    color:colors.orangePrimary,
    padding:8
  },
  header:{
    width:"100%",
    paddingHorizontal: 16,
    paddingTop:16,
    flexDirection:"row",
    justifyContent:"space-between",
    alignItems:"center"
  },
  newMessageText:{
    fontWeight:"500",
    fontSize:16,
    textAlign:"center"
  },
  enterNumber:{
    marginTop:40,
    fontSize:16
  },
  bar:{
    borderBottomWidth:1,
    width:"100%",
    borderBottomColor:colors.grey
  },
  input:{
    width:"90%",
    marginTop:16,
    height:56,
    paddingHorizontal:16,
    borderRadius:8,
    borderWidth:1,
    borderColor:colors.grey,
    marginBottom:32
  }

}))
