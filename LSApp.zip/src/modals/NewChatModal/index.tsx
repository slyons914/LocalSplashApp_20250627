import {Pressable, View } from "react-native"

import Modal from "react-native-modal"

import { useStyles } from "./styles"
import { Button, Icon, SearchBar, Typography } from "@components"
import { backIconHitSlope } from "@utils/constants/common"
import { TextInputMask } from "react-native-masked-text"
import { useState } from "react"
import { Routes } from "@utils/constants"
import { navigate } from "@navigation"

interface Props {
  isVisible: boolean
  onClose: () => void
  closeMessageModal : () => void
}

export const NewChatModal = ({ isVisible, onClose,closeMessageModal }: Props) => {
  const styles = useStyles()
  const [val, setVal] = useState("+1 ")

  const onContinuePress = () =>{
    closeMessageModal()
    onClose()
    navigate(Routes.MessageDetail, {number: val})
  }
  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      avoidKeyboard={true}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <View style={styles.header}>
            <Pressable onPress={onClose}><Icon hitSlop={backIconHitSlope} name="chevronLeftWhite"></Icon></Pressable>
            <Typography style={styles.newMessageText}>              New Message</Typography>
            <Typography onPress={onClose} style={styles.cancelText}>Cancel</Typography>
        </View>
        <View style={styles.bar}></View>
        <Typography style={styles.enterNumber}>Enter Phone Number</Typography>
        <TextInputMask
        onChangeText={(val)=>setVal(val)}
        type={"custom"}
        editable={true}
        value={val}
        options={{ mask: "+1  (***) ***-****" }}
        keyboardType="numeric"
        style={styles.input}
      />
      <Button label="Continue" onPress={onContinuePress}></Button>
      </View>
    </Modal>
  )
}
