import { Typography } from '@components'
import { useStyles } from './styles'
import React from 'react'
import { Pressable, View } from 'react-native'
import Modal from "react-native-modal"


interface Props {
    isVisible: boolean
    onClose: () => void,
    setAutomatedPost: (val:boolean) => void
}



export const DisableAutomatedPostModal = ({ isVisible, onClose, setAutomatedPost}: Props) => {
    const styles = useStyles();

    const disableAndClose = () =>{
        setAutomatedPost(false)
        onClose()
    }

    return (
        <Modal
            style={styles.modal}
            isVisible={isVisible}
            onBackdropPress={onClose}
            onBackButtonPress={onClose}
        >
            <View style={styles.mainContainer}>
                <Typography style={[styles.centerText,styles.blackText]}>Are you disabling automated posts?</Typography>
                <Typography style={[styles.centerText,styles.greyText]}>Would you like to delete your 4 future scheduled posts or just turn this feature off?</Typography>
                <View style={styles.buttonView}>
                    <Pressable onPress={disableAndClose} style={styles.button} >
                        <Typography style={styles.blueText} type='default'>Yes, Delete</Typography>
                    </Pressable>
                    <Pressable onPress={disableAndClose} style={styles.button} >
                        <Typography style={styles.blueText} type='default'>Turn Off</Typography>
                    </Pressable>
                    <Pressable onPress={onClose} style={styles.button} >
                        <Typography style={styles.redText} type='default'>Cancel</Typography>
                    </Pressable>
                </View>
            </View>
        </Modal>
    );
};
