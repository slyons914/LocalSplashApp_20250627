import { withStyles } from '@utils/hocs'
export const useStyles = withStyles(({ colors, width }) => ({
    modal: {
        justifyContent: "center",
        alignItems: "center",
        flex: 1,
    },
    mainContainer: {
        borderRadius: 12,
        backgroundColor: colors.background,
        width: width * 0.7,
    },
    centerText:{
        marginTop:12,
        marginHorizontal:12,
        textAlign:"center"
    },
    blackText:{
        color:colors.darkBlack,
        fontSize:16,
        fontWeight:"500"
    },
    greyText:{
        color:colors.greyText,
        marginBottom:12
    },
    buttonView:{
    },
    button:{
        borderTopWidth:0.5,
        paddingHorizontal:16,
        paddingVertical:16,
        alignItems:"center"
    },
    blueText:{
        color:colors.lightBlue2,
        fontSize:16,
        fontWeight:"500"
    },
    boldText:{
        fontWeight:"600"
    },
    redText:{
        color:colors.red,
        fontSize:16,
        fontWeight:"500"
    }
}))