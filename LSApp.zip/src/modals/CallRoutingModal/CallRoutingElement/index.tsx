import { ActivityIndicator, View } from "react-native"

import { useStyles } from "../styles"
import { useState } from "react"
import { CustomDropdown, Input, Typography } from "@components"
import { colors } from "@utils/constants"
import { useStore } from "@store"
import { UpdateCallRoutingSettingsRequestViewModel } from "@localsplash/mobile-api-client"
import { MobileAPI } from "@api"

interface Props {
  goBack: () => void,
  title: string,
  selectedRouteDestination: string | undefined,
  selectedRouteAction: string | undefined,
  setSelectedRouteDestination: (val:string) => void
  setSelectedRouteAction: (val:string) => void
}

export const CallRoutingElement = ({ goBack, title, selectedRouteAction, selectedRouteDestination, setSelectedRouteAction, setSelectedRouteDestination }: Props) => {
  const { settingsStore, homeStore } = useStore()  
  const { callRoutingActions, getCallRoutingSettings } = settingsStore
  const { locationsItem } = homeStore

  const [isLoading, setIsLoading] = useState(false)  

  const styles = useStyles()

  const options = callRoutingActions?.items?.map(action => ({
    label: action.name ?? '',
    value: action.callActionTypeId?.toString() ?? '',  
  }));

  const onSavePress = async () => {
    setIsLoading(true)
    const updatedCallRoutingSettings = new UpdateCallRoutingSettingsRequestViewModel()
    switch (title) {
        case "Call Rejected":
            if(selectedRouteAction === "4")
                updatedCallRoutingSettings.rejectedDestination = Number(selectedRouteDestination)
            updatedCallRoutingSettings.callActionTypeIdRejected = Number(selectedRouteAction)
            break;
        case "Call Missed":
            if(selectedRouteAction === "4")
                updatedCallRoutingSettings.missedDestination = Number(selectedRouteDestination)
            updatedCallRoutingSettings.callActionTypeIdMissed = Number(selectedRouteAction)
            break;
        case "Call Failed":
            if(selectedRouteAction === "4")
                updatedCallRoutingSettings.failedDestination = Number(selectedRouteDestination)
            updatedCallRoutingSettings.callActionTypeIdFailed = Number(selectedRouteAction)
            break;
        case "Call Blocked":
            if(selectedRouteAction === "4")
                updatedCallRoutingSettings.blockedDestination = Number(selectedRouteDestination)
            updatedCallRoutingSettings.callActionTypeIdBlocked = Number(selectedRouteAction)
            break;
        case "Call Busy":
            if(selectedRouteAction === "4")
                updatedCallRoutingSettings.busyDestination = Number(selectedRouteDestination)
            updatedCallRoutingSettings.callActionTypeIdBusy = Number(selectedRouteAction)
            break;
    }
    try {
        if(!locationsItem?.id)
            return;
        await MobileAPI.updateUserCallRoutingDetails(locationsItem?.id, updatedCallRoutingSettings)
        await getCallRoutingSettings(locationsItem?.id)
    } catch(error) {
        console.log("Error while updating call routing")
    } finally {
        setIsLoading(false)
    }
    goBack()
  }

  return (
    <View >
        <View style={styles.elementHeader}>
            <Typography onPress={goBack} style={styles.elementHeaderItem}>Cancel</Typography>
            <Typography style={styles.title}>{title}</Typography>
            {
                isLoading ? ( <ActivityIndicator size={"small"} color={colors.common.orangePrimary}></ActivityIndicator> ) : (
                <Typography onPress={onSavePress} style={styles.elementTitle}>Save</Typography>
                )
            }
         </View>
         <Typography style={styles.label}>Choose action</Typography>
         <CustomDropdown options={options ?? []} placeholder="Choose Action" value={selectedRouteAction ?? ''} onValueChange={setSelectedRouteAction}></CustomDropdown>
         {
            selectedRouteAction === "4" &&
            <Input placeholder="Enter Destination" value={selectedRouteDestination ?? ''} onChange={setSelectedRouteDestination} label="Destination"></Input>
         }
    </View>
  )
}
