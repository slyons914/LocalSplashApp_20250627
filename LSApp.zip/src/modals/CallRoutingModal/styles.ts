import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height, isDarkTheme }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: isDarkTheme?  colors.backgroundSecondary : colors.background,
    minHeight: height * 0.3,
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    alignItems: "center",
    paddingTop: 29,
    paddingHorizontal: 24,
    paddingBottom:32
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
    marginBottom: 24,
    textAlign:'center'
  },
  label: {
    color: colors.subText,
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
  },
  close: {
    position: "absolute",
    right:0
  },
  content: {
    width: "100%",
  },
  menuItem: {
    paddingVertical: 16,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  menuItemTitle: {
    fontSize: 16,
  },
  menuItemSubTitle: {
    color: colors.blue,
  },
  section: {
    width: "100%",
  },
  hidden: {
    display: "none",
  },
  flexed: {
    display: "flex",
  },
  elementHeader:{
    flexDirection:"row",
    justifyContent: "space-between",
  },
  elementHeaderItem:{
    color:colors.orangePrimary,
    fontWeight:"500",
    fontSize:16
  },
  elementTitle: {
    fontSize: 16,
    fontWeight: "500",
    color:colors.orangePrimary
}
}))
