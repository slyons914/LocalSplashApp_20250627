import { Animated, Dimensions, Pressable, TouchableOpacity, useAnimatedValue, View } from "react-native"

import Modal from "react-native-modal"

import { useStyles } from "./styles"
import { Icon, Typography } from "@components"
import { colors } from "@utils/constants"
import { useColors } from "@utils/hooks"
import { FormatHelper } from "@utils/helpers"
import { CallRoutingElement } from "./CallRoutingElement"
import { useCallback, useEffect, useState } from "react"
import { useStore } from "@store"

interface Props {
    isVisible: boolean
    onClose: () => void
}

interface MenuItem {
    title: string
    subTitle: string
    onPress: () => void
}

type Section = "routingElement"

const { width } = Dimensions.get("screen")
const translateX = width

export const CallRoutingModal = ({ isVisible, onClose }: Props) => {

    const { settingsStore } = useStore()
    const { callRoutingActions, callRoutingSettings } = settingsStore

    const styles = useStyles()
    const { text } = useColors()

    const [overflow, setOverflow] = useState<"hidden" | "visible">("hidden")
    const [currentSection, setCurrentSection] = useState<Section | null>(null)
    const [title, setTitle] = useState('')
    const [selectedRouteAction, setSelectedRouteAction] = useState<string>()
    const [selectedRouteDestination, setSelectedRoutDesination] = useState<string>()

    const menuValue = useAnimatedValue(0)
    const sectionValue = useAnimatedValue(translateX)

    const move = useCallback((direction: "forward" | "backward") => {
        setOverflow("hidden")
        const settings = { duration: 400, useNativeDriver: true }
        Animated.parallel([
            Animated.timing(menuValue, {
                toValue: direction === "forward" ? -translateX : 0,
                ...settings,
            }),
            Animated.timing(sectionValue, {
                toValue: direction === "forward" ? 0 : translateX,
                ...settings,
            }),
        ]).start(() => {
            direction === "backward" && setCurrentSection(null)
            setOverflow("visible")
        })
    }, [])

    const goBack = useCallback(() => {
        move("backward")
    }, [move])

    const handleMenuItemPress = (val: Section, title:string) => {
        switch (title) {
            case "Call Rejected":
                setSelectedRoutDesination(callRoutingSettings?.rejectedDestination?.toString())
                setSelectedRouteAction(callRoutingSettings?.callActionTypeIdRejected?.toString() ?? '')
                break;
            case "Call Missed":
                setSelectedRoutDesination(callRoutingSettings?.missedDestination?.toString())
                setSelectedRouteAction(callRoutingSettings?.callActionTypeIdMissed?.toString() ?? '')
                break;
            case "Call Failed":
                setSelectedRoutDesination(callRoutingSettings?.failedDestination?.toString())
                setSelectedRouteAction(callRoutingSettings?.callActionTypeIdFailed?.toString() ?? '')
                break;
            case "Call Blocked":
                setSelectedRoutDesination(callRoutingSettings?.blockedDestination?.toString())
                setSelectedRouteAction(callRoutingSettings?.callActionTypeIdBlocked?.toString() ?? '')
                break;
            case "Call Busy":
                setSelectedRoutDesination(callRoutingSettings?.busyDestination?.toString())
                setSelectedRouteAction(callRoutingSettings?.callActionTypeIdBusy?.toString() ?? '')
                break;
        }
        setTitle(title)
        setCurrentSection(val)
    }

    const createMenuItemSubtitle = (callActionId: number, callActionDestination: number) => {
        switch (callActionId) {
            case 1:
                return "Hangup"
            case 2:
                return "Voicemail"
            case 4:
                return `Forward to ${FormatHelper.formatPhoneNumber(callActionDestination.toString())}`
            case 8:
                return "Extension"
            default:
                return ""
        }
    }

    const menuItems: Array<MenuItem> = [
        {
            title: "Call Rejected",
            onPress: () => handleMenuItemPress("routingElement", "Call Rejected"),
            subTitle: createMenuItemSubtitle(callRoutingSettings?.callActionTypeIdRejected ?? 0, callRoutingSettings?.rejectedDestination ?? 0),
        },
        {
            title: "Call Missed",
            onPress: () => handleMenuItemPress("routingElement", "Call Missed"),
            subTitle: createMenuItemSubtitle(callRoutingSettings?.callActionTypeIdMissed ?? 0, callRoutingSettings?.missedDestination ?? 0),
        },
        {
            title: "Call Failed",
            onPress: () => handleMenuItemPress("routingElement", "Call Failed"),
            subTitle: createMenuItemSubtitle(callRoutingSettings?.callActionTypeIdFailed ?? 0, callRoutingSettings?.failedDestination ?? 0),
        },
        {
            title: "Call Blocked",
            onPress: () => handleMenuItemPress("routingElement", "Call Blocked"),
            subTitle: createMenuItemSubtitle(callRoutingSettings?.callActionTypeIdBlocked ?? 0, callRoutingSettings?.blockedDestination ?? 0),
        },
        {
            title: "Call Busy",
            onPress: () => handleMenuItemPress("routingElement", "Call Busy"),
            subTitle: createMenuItemSubtitle(callRoutingSettings?.callActionTypeIdBusy ?? 0, callRoutingSettings?.busyDestination ?? 0),
        },
    ]

    const sections = [
        {
            name: "routingElement",
            component: <CallRoutingElement 
                        selectedRouteDestination={selectedRouteDestination} 
                        selectedRouteAction={selectedRouteAction} 
                        title={title} 
                        goBack={goBack}
                        setSelectedRouteDestination={setSelectedRoutDesination} 
                        setSelectedRouteAction={setSelectedRouteAction}/>,
        },
    ]

    useEffect(() => {
        currentSection && move("forward")
    }, [currentSection])

    return (
        <Modal
            useNativeDriverForBackdrop
            isVisible={isVisible}
            onBackdropPress={onClose}
            onModalHide={onClose}
            style={styles.modal}
            avoidKeyboard
        >
            <View style={[styles.container, { overflow }]}>
                <View style={styles.dash} />
                <View style={[currentSection? styles.hidden : styles.flexed, {width:"100%"}]}>
                    <Typography style={styles.title}>Call Routing</Typography>
                    <Pressable style={styles.close} onPress={onClose}>
                        <Icon name={"remove"} stroke={text} />
                    </Pressable>
                </View>
                <Animated.View style={[styles.content, { transform: [{ translateX: menuValue }] }]}>
                    <View style={currentSection? styles.hidden : styles.flexed}>
                    {
                        menuItems?.map((item, index) => (
                            <TouchableOpacity key={index} onPress={item.onPress} style={styles.menuItem}>
                                <View>
                                    <Typography style={styles.menuItemTitle} type="title">
                                        {item.title}
                                    </Typography>
                                    <Typography type="title" style={styles.menuItemSubTitle}>
                                        {item.subTitle}
                                    </Typography>
                                </View>
                                <Icon name="chevronRight" stroke={colors.common.dark} />
                            </TouchableOpacity>
                        ))
                    }
                    </View>
                </Animated.View>    
                <Animated.View style={[styles.section, { transform: [{ translateX: sectionValue }] }]}>
                    {sections.map(({ component, name }, i) => (
                        <View key={i} style={currentSection === name ? styles.flexed : styles.hidden}>
                            {component}
                        </View>
                    ))}
                </Animated.View>
            </View>
        </Modal>
    )
}
