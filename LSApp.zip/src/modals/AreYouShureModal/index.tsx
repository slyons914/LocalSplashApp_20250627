import { View } from "react-native"

import Modal from "react-native-modal"

import { Button, Typography } from "@components"

import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
  onEnable: () => void
  onDecline: () => void
  text: string
}

export const AreYouShureModal = ({ isVisible, text, onClose, onEnable, onDecline }: Props) => {
  const styles = useStyles()

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <Typography style={styles.title}>Are you sure?</Typography>
        <Typography type={"subtext"} style={styles.text}>
          {text}
        </Typography>
        <Button icon={"bell"} label={"Enable"} onPress={onEnable} />
        <Typography onPress={onDecline} style={styles.anotherTime}>
          No, another time
        </Typography>
      </View>
    </Modal>
  )
}
