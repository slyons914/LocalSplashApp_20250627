import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: colors.background,
    minHeight: height * 0.3,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    alignItems: "center",
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: "600",
  },
  text: {
    fontSize: 16,
    textAlign: "center",
    paddingHorizontal: 16,
    marginTop: 8,
    marginBottom: 24,
  },
  anotherTime: {
    fontSize: 16,
    fontWeight: "500",
    color: colors.orangePrimary,
    marginVertical: 16,
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
  },
}))
