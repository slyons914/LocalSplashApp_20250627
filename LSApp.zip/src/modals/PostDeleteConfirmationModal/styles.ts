import { withStyles } from '@utils/hocs'
export const useStyles = withStyles(({ colors, width }) => ({
    modal: {
        justifyContent: "center",
        alignItems: "center",
        flex: 1,
    },
    mainContainer: {
        borderRadius: 12,
        backgroundColor: colors.background,
        width: width * 0.7,
    },
    centerText:{
        marginTop:12,
        marginHorizontal:12,
        textAlign:"center"
    },
    blackText:{
        color:colors.darkBlack
    },
    greyText:{
        color:colors.greyText,
        marginBottom:12
    },
    buttonView:{
        flexDirection:'row',
        justifyContent:"space-between",
        borderTopWidth:0.5
    },
    button:{
        paddingHorizontal:16,
        paddingVertical:11,
        borderRightWidth:0.5,
        width:"50%",
        alignItems:"center"
    },
    blueText:{
        color:colors.lightBlue2
    },
    boldText:{
        fontWeight:"600"
    }
}))