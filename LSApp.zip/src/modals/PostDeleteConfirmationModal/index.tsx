import { Icon, Typography } from '@components'
import { useStyles } from './styles'
import React from 'react'
import { ActivityIndicator, Pressable, View } from 'react-native'
import Modal from "react-native-modal"


interface Props {
    isVisible: boolean
    onClose: () => void,
    onYesPress: () => void,
    isLoading:boolean
}


export const PostDeletionConfirmationModal = ({ isVisible, onClose, onYesPress, isLoading}: Props) => {
    const styles = useStyles();

    return (
        <Modal
            style={styles.modal}
            isVisible={isVisible}
            onBackdropPress={onClose}
            onBackButtonPress={onClose}
        >
            <View style={styles.mainContainer}>
                <Typography style={[styles.centerText,styles.blackText]}>Delete Post</Typography>
                <Typography style={[styles.centerText,styles.greyText]}>Are you sure you want to delete this post?</Typography>
                {
                    isLoading ? (<ActivityIndicator style={{padding:10}} size={'large'} />) : (null)
                }
                <View style={styles.buttonView}>
                    <Pressable onPress={onClose} style={styles.button} >
                        <Typography style={styles.blueText} type='default'>No</Typography>
                    </Pressable>
                    <Pressable onPress={onYesPress} style={styles.button} >
                        <Typography style={[styles.blueText, styles.boldText]} type='default' >Yes</Typography>
                    </Pressable>
                </View>
            </View>
        </Modal>
    );
};
