import { Linking, Pressable, View } from "react-native"

import Modal from "react-native-modal"

import { Icon, Typography } from "@components"
import { DudaUrls } from "@models/home"
import { useColors } from "@utils/hooks"

import { ModalItem } from "./ModalItem"
import { useStyles } from "./styles"

import { navigate } from "@navigation"
import { Routes, Stacks } from "@utils/constants"
import { ProfileViewModel } from "@models/localsplash-mobile-api.service"
import InAppBrowser from "react-native-inappbrowser-reborn"
import { InAppBrowserStyle, LsConfig } from "@utils/constants/common"

interface Props {
  isVisible: boolean
  onClose: () => void
  dudaLinks: DudaUrls | null
  profile: ProfileViewModel | null
}

export const ProfileActionsModal = ({ isVisible, onClose, dudaLinks, profile }: Props) => {
  const styles = useStyles()

  const { text } = useColors()

  const onWebsitePress = () => {
    if (!profile?.promotedWebsite) return onClose()
    InAppBrowser.open(profile?.promotedWebsite, {...InAppBrowserStyle}).then(onClose)
  }

  const onEditorPress = () => {
    if(!dudaLinks?.ssoUrl)
        return onClose()
    InAppBrowser.close()
    InAppBrowser.open(dudaLinks.ssoUrl, InAppBrowserStyle)
    onClose()
  }

  const onEditInfoPress = () =>{
    navigate(Stacks.Settings , {screen: Routes.BusinessInformation})
    onClose()
  }

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
      onSwipeComplete={onClose}
      animationIn={"slideInUp"}
      animationOut={"slideOutDown"}
      swipeDirection={["down"]}
      propagateSwipe
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <Typography style={styles.title}>Profile Actions</Typography>
        <Pressable style={styles.close} onPress={onClose}>
          <Icon name={"remove"} stroke={text} />
        </Pressable>

        <ModalItem label={"View Website"} onPress={onWebsitePress} />
        <ModalItem label={"Edit Website"} onPress={onEditorPress} />
        <ModalItem label={"Edit Business Info"} onPress={onEditInfoPress} />
      </View>
    </Modal>
  )
}
