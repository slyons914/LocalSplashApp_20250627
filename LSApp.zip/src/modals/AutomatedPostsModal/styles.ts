import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: colors.background,
    minHeight: height * 0.3,
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    padding: 16,
    paddingTop:4
  },
  title: {
    textAlign:"center",
    fontSize: 24,
    fontWeight: "600",
  },
  dash: {
    alignSelf:"center",
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
  },
  subText:{
    color:colors.subText
  },
  dateTimeInput:{
    flexDirection:"row",
    justifyContent:"space-between",
    paddingVertical:16,
    paddingHorizontal:24,
    borderWidth:1,
    borderColor:colors.gray6,
    borderRadius:6,
    gap:16
  },
  mainView:{
    marginTop:8,
    gap:16
  },
  cancelButton: {
    width: 342,
    backgroundColor: colors.white,
    color: colors.orangePrimary,
  },
  cancelButtonText: {
    color: colors.orangePrimary,
  },
}))
