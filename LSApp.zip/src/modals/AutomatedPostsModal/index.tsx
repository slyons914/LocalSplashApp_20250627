import { Pressable, View } from "react-native"

import Modal from "react-native-modal"

import { Button, CustomDropdown, Icon, Typography } from "@components"

import { useStyles } from "./styles"
import DatePicker from "react-native-date-picker"
import { useState } from "react"

interface Props {
  isVisible: boolean
  onClose: () => void
  setAutomatedPost: (val: boolean) => void
}

const options = [
    { label: 'Monthly (1st of every month)', value: 'Monthly (1st of every month)' },
    { label: 'Weekly (every Wed)', value: 'Weekly (every Wed)' },
    { label: 'Weekly (every Tues & Thurs)', value: 'Weekly (every Tues & Thurs)' },
    { label: 'Weekly (every Mon, Wed & Fri)', value: 'Weekly (every Mon, Wed & Fri)' },
];

export const AutomatedPostsModal = ({ isVisible, onClose, setAutomatedPost }: Props) => {
  const styles = useStyles()
  const [dateModal, setDateModal] = useState(false)
  const [dateTime , setDateTime] = useState(new Date ());
  const [postFrequency, setPostFrequency] = useState("")

  const handleDateConfirm = (date:any) =>{
    setDateTime(date)
    setDateModal(false)
  }

  const onSubmitPress = () =>{
    setAutomatedPost(true)
    onClose()
  }
  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <Typography type={"title"} style={styles.title}>
          Set Frequency
        </Typography>
        <View style={styles.mainView}>
            <View>
                <Typography style={styles.subText}>Frequency</Typography>
                <CustomDropdown
                options={options}
                placeholder="Select Frequency"
                value={postFrequency}
                onValueChange={(value) => setPostFrequency(value)}
                />
            </View>
            <View>
                <Typography style={styles.subText}>Start Date</Typography>
                <Pressable onPress={()=>setDateModal(true)} style={styles.dateTimeInput}>
                    <Typography>{dateTime.toLocaleDateString()}</Typography>
                    <Icon name="CalenderIcon"></Icon>
                </Pressable>
            </View>
            <Button label="Confirm" onPress={onSubmitPress}></Button>
            <Button
            btnStyle={styles.cancelButton}
            labelStyle={styles.cancelButtonText}
            onPress={onClose}
            label={"Cancel"}
          />
        </View>
      </View>
      <DatePicker
        modal
        date={dateTime}
        onConfirm={handleDateConfirm}
        open={dateModal}
        mode={"date"}
        onCancel={()=>setDateModal(false)}
        ></DatePicker>
    </Modal>
  )
}
