import { ActivityIndicator, FlatList, TouchableOpacity, View } from "react-native"
import { Icon, Typography } from "@components"
import { useStyles } from "./styles"
import { observer } from "mobx-react-lite"
import { useEffect, useState } from "react"
import { colors } from "@utils/constants"
import { Lead } from "@models/leads"
import { DispositionStatusesViewModel, DispositionStatusViewModel } from "@localsplash/mobile-api-client"
import Modal from "react-native-modal"
import { leadStatusColors } from "@utils/constants/common"

interface Props {
    isVisible: boolean
    onClose: () => void
    lead: Lead | null
    onSavePress: (val:number) => Promise<void>
    customerStatusTypes: DispositionStatusesViewModel | null
}

const Component = ({ isVisible, onClose, lead, onSavePress, customerStatusTypes }: Props) => {
    const styles = useStyles()
    const [isLoading, setIsLoading] = useState(false)
    const [selectedStatusId, setSelectedStatusId] = useState(lead?.dispositionStatus ?? 1)

    useEffect(() => {
        setSelectedStatusId(lead?.dispositionStatus ?? 1)
    },[lead])

    const onItemPress = (id:number) => {
        setSelectedStatusId(id)
    }

    const handleSavePress = async () => {
        setIsLoading(true)
        try {
            await onSavePress(selectedStatusId)
        } catch {
            setIsLoading(false)
        } finally {
            setIsLoading(false)
            onClose()
        }
    }
    const renderItem = ({ item }: { item: DispositionStatusViewModel }) => {
        return (
          <TouchableOpacity onPress={() => {onItemPress(item?.id ?? 1)}} style={[styles.itemContainer, item.id === selectedStatusId && styles.selectedItem]}>
            {
                item.id === 2 ? (
                    <View style={styles.headingView}>
                        <View style={styles.menuItemContainer}>
                            <Typography style={[styles.itemText, item.id === selectedStatusId && styles.selectedItemText]}>Select..</Typography>
                        </View>
                    </View>
                ) : (
                    <View style={styles.headingView}>
                        <View style={[styles.dotView, leadStatusColors[item?.id ?? 1]]}>
                        </View>
                        <View style={styles.menuItemContainer}>
                            <Typography style={[styles.itemText, item.id === selectedStatusId && styles.selectedItemText]}>{item.statusName}</Typography>
                        </View>
                    </View>
                )
            }
    
            {item.id === selectedStatusId && <Icon name={"checkBlue"} />}
          </TouchableOpacity>
        )
    }

    return (
        <Modal
            isVisible={isVisible}
            onBackdropPress={onClose}
            onBackButtonPress={onClose}
            onSwipeComplete={onClose}
            style={styles.modal}
            avoidKeyboard
        >
            <View style={styles.container}>
                <View style={styles.dash} />
                <View style={styles.header}>
                    <Typography onPress={onClose} style={styles.headerItem}>Cancel</Typography>
                    <Typography style={styles.title}>Status</Typography>
                    <View style={styles.loaderView}>
                    {
                        isLoading ? (   <ActivityIndicator size={"small"} color={colors.common.orangePrimary}></ActivityIndicator>) : (
                            <Typography onPress={handleSavePress} style={styles.headerItem}>Apply</Typography>
                        )
                    }
                    </View>
                </View>
                <FlatList
                    data={customerStatusTypes?.items ?? []}
                    contentContainerStyle={styles.list}
                    scrollEnabled
                    renderItem={renderItem}
                />
            </View>
        </Modal>
    )
}

export const AddUpdateLeadStatusModal = observer(Component)

