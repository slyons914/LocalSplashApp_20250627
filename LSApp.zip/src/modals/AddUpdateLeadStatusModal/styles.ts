import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme }) => ({
  modal: {
    margin: 0,
    justifyContent:"flex-end",
  },
  container: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingBottom: 24,
    backgroundColor: isDarkTheme ? colors.backgroundSecondary : colors.background
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
    alignSelf: "center",
  },
  header:{
    marginTop:8,
    flexDirection:"row",
    justifyContent: "space-between",
    borderBottomWidth:1,
    borderBottomColor:colors.grey,
    paddingBottom:8,
    alignItems:"center",
    marginBottom:18,
    padding: 24,
  },
  headerItem:{
    color:colors.orangePrimary,
    fontWeight:"500",
    fontSize:16,
    textAlign:"center"
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
  },
  loaderView: {
    width: "15%"
  },
  list: {
    maxWidth: "100%",
    padding:16
  },
  itemContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 16,
    paddingHorizontal: 12,
    width: "100%",
    marginBottom:4,
    borderRadius:12,

  },
  selectedItem : {
    backgroundColor: isDarkTheme ? colors.background : colors.superLightBlue
  },
  selectedItemText : {
    fontWeight: "500",
  },
  itemText: {
    fontSize: 16,
    fontWeight: "400",
  },
  menuItemContainer: {
    flexDirection: "row",
    gap: 8,
  },
  headingView: {
    flexDirection: "row",
    gap: 24,
    alignItems: 'center'
  },
  dotView: {
    height: 12, 
    width: 12,
    borderRadius: 6
  }
}))
