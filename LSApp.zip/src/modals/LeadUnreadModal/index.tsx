import {
  Dimensions,
  Pressable,
  TouchableOpacity,
  View,
} from "react-native"

import Modal from "react-native-modal"

import { Icon, Typography } from "@components"
import { useColors } from "@utils/hooks"
import { useStyles } from "./styles"
import { useState } from "react"

interface Props {
  isVisible: boolean
  onClose: () => void
  updateLeadStatus: () => void
  isRead: boolean
}

export const LeadUnreadModal = ({ isVisible, onClose, updateLeadStatus, isRead}: Props) => {

  const styles = useStyles()
  const { text } = useColors()

  const [isLeadRead, setIsLeadRead] = useState(isRead)

  return (
    <Modal
      useNativeDriverForBackdrop
      isVisible={isVisible}
      onBackdropPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <Typography style={styles.title}>History Lead Actions</Typography>
        <Pressable style={styles.close} onPress={onClose}>
            <Icon name={"remove"} stroke={text} />
        </Pressable>
        <TouchableOpacity onPress={updateLeadStatus} style={[styles.itemContainer, styles.activeContainer]}>
            <Typography style={styles.itemText}>{ isLeadRead ? "Mark as Unread" : "Mark as Read"}</Typography>
        </TouchableOpacity>
      </View>
    </Modal>
  )
}
