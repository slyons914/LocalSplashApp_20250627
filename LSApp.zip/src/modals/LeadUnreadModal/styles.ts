import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height, isDarkTheme }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: isDarkTheme?  colors.backgroundSecondary : colors.background,
    minHeight: height * 0.2,
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    alignItems: "center",
    paddingTop: 29,
    paddingHorizontal: 24,
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
    marginBottom: 24,
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
  },
  back: {
    position: "absolute",
    top: 29,
    left: 24,
  },
  close: {
    position: "absolute",
    top: 29,
    right: 24,
  },
  itemContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 16,
    paddingHorizontal: 12,
    width: "100%",
    borderRadius:12,
  },
  itemText: {
    fontSize: 16,
    fontWeight: "400",
  },
  activeContainer: {
    backgroundColor: isDarkTheme ? colors.background : colors.superLightBlue 
  }
}))
