import { ActivityIndicator, Keyboard, KeyboardAvoidingView, Platform, Pressable, ScrollView, TextInput, TouchableWithoutFeedback, View } from "react-native"

import { Button, Icon, Typography } from "@components"
import { colors, Routes, Stacks } from "@utils/constants"
import { useEffect, useState } from "react"
import Modal from "react-native-modal"
import { useStyles } from "./styles"
import { MobileAPI } from "@api"
import { FeedbackSentModal } from "@modals/FeedbackSentModal"
import { navigate } from "@navigation"


interface Props {
    isVisible?: boolean
    onClose?: () => void
    setFeedbackModal: (val: boolean) => void
}

interface HeaderProps {
    onRightPress?: () => void
    rightText?: string
    title?: string
    isLoading?: boolean
}

const emojis = [
    { gray_outline: 'angry', yellow_outline: "angry_yellow", title: "Terrible" },
    { gray_outline: 'sad', yellow_outline: "sad_yellow", title: "Poor" },
    { gray_outline: 'neutral', yellow_outline: "neutral_yellow", title: "Fair" },
    { gray_outline: 'smile', yellow_outline: "smile_yellow", title: "Like" },
    { gray_outline: 'in_love', yellow_outline: "in_love_yellow", title: "Excellent" },
];

const maxLength = 1500

const SimpleHeader = ({
    onRightPress,
    rightText,
    title,
    isLoading,
}: HeaderProps) => {
    const styles = useStyles()

    const right = isLoading ? (
        <ActivityIndicator color={colors.common.orangePrimary} />
    ) : (
        <Typography type="title" onPress={onRightPress} style={styles.closeBtn}>
            {rightText}
        </Typography>
    )

    return (
        <View style={styles.header}>
            <View style={styles.leftContainer} />
            {!!title && <Typography style={styles.title}>{title}</Typography>}
            {!!rightText ? right : <View />}
        </View >
    )
}



export const FeedbackModal = ({
    isVisible,
    onClose = () => { },
    setFeedbackModal
}: Props) => {
    const styles = useStyles()
    const [rating, setRating] = useState(null)
    const [feedback, setFeedback] = useState("")
    const [response, setResponse] = useState("")
    const [loading, setLoading] = useState(false)
    const [feedbackSend, setFeedbackSent] = useState(false)
    const sendFeedback = async () =>{
        setLoading(true)
        try{
    
            const data = await MobileAPI.sendFeedback(feedback,rating+1)
            if(data){
                setFeedbackSent(true)
                
            }else{
                setResponse("Error in sending feedback! Try again")
            }
        }catch{
            setResponse("Error in sending feedback! Try again")
        }finally{
            setLoading(false)
        }
    }
    const onModalClose = () =>{
        onClose()
        setResponse("")
    }

    const onFeedbackSendClose = () =>{
        setFeedbackModal(false)
        setFeedbackSent(false)
        navigate(Stacks.Home, {screen: Routes.Home})
    }
    return (
        <Modal
            isVisible={isVisible}
            style={styles.modal}
            onBackButtonPress={onModalClose}
            onBackdropPress={onModalClose}
        >
            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                style={styles.container}>
                <TouchableWithoutFeedback onPress={Keyboard.dismiss} >
                    <ScrollView style={styles.keyboardAvoidingView}  >
                        <View style={styles.dash} />
                        <SimpleHeader
                            title="Feedback"
                            rightText="Cancel"
                            onRightPress={onModalClose}
                        />
                        <View style={styles.horizontalLine} />
                        <Typography type="title" style={styles.experienceHeader} >Rate your Experience</Typography>
                        <View style={styles.ratingContainer}>
                            {emojis?.map((emoji, index) =>
                            (
                                <View key={index}>
                                    <Pressable
                                        key={index}
                                        onPress={() => setRating(index)}
                                        style={styles.emojiButton}
                                    >
                                        <Icon
                                            name={rating == index ? emoji?.yellow_outline : emoji?.gray_outline}
                                            height={45}
                                            width={45}
                                        />
                                    </Pressable>
                                    {rating == index && <Typography style={{ textAlign: "center" }} type="default" >{emoji.title}</Typography>}
                                </View>
                            ))}
                        </View>
                        {!rating && rating != 0 &&
                        <View style={styles.ratingLabelContainer} >
                            <Typography style={styles.ratingLabel} >Not good at all</Typography>
                            <Typography style={styles.ratingLabel}>Very good</Typography>
                        </View>}
                        {
                            rating || rating === 0 ? (<View>
                                        <View style={styles.textInputContainer} >
                                            <TextInput
                                            placeholder="Tell us about your experience..."
                                            placeholderTextColor={colors.common.gray4}
                                            style={styles.textInputField}
                                            multiline={true}
                                            onChangeText={(text) => setFeedback(text)}
                                            maxLength={maxLength}
                                            />
                                        </View>
                                        <Typography type="default" style={styles.counter}>{feedback?.length } / 1500 characters</Typography>
                                    </View>):(null)
                        }
                        {
                            response ? (<View style={styles.feedback}>
                                            <Typography style={styles.error}>{response}</Typography>
                                        </View>) : (null)
                        }
                    </ScrollView>
                </TouchableWithoutFeedback>
                <Pressable onPress={Keyboard.dismiss} style={styles.buttonContainer} >
                    <Button
                        disabled = {(!rating && rating!==0) || !feedback}
                        isLoading={loading}
                        label="Send"
                        onPress={sendFeedback}/>
                </Pressable>
                <FeedbackSentModal title="Feedback" message="Your feedback has been received." isVisible={feedbackSend} onClose={()=>onFeedbackSendClose()}></FeedbackSentModal>
            </KeyboardAvoidingView>
        </Modal>

    )
}

