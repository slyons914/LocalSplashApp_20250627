import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height, width }) => ({
    keyboardAvoidingView: {
        overflow: "hidden",
    },
    container: {
        minHeight:height-60,
        backgroundColor: colors.background,
        borderTopLeftRadius: 40,
        borderTopRightRadius: 40,
        marginTop: 20,
        paddingVertical: 10,
    },
    contentContainer: {
        marginVertical: 10,
    },
    modal: {
        margin: 0,
        justifyContent:"flex-end"
    },
    dash: {
        height: 5,
        width: 36,
        backgroundColor: colors.gray4,
        alignSelf: "center",
        borderRadius: 5,
        marginVertical: 5,
    },
    header: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingVertical: 8,
        borderBottomWidth: 1,
        borderBottomColor: "rgba(0, 0, 0, 0.3)",
        padding: 10,
    },
    horizontalLine: {},
    closeBtn: {
        color: colors.orangePrimary,
        fontSize: 16,
        fontWeight: "500",
    },
    title: {
        color: colors.text,
        fontSize: 16,
        fontWeight: "500",
    },
    leftContainer: {
        width: 70,
    },
    experienceHeader: {
        textAlign: "center",
        fontWeight: "500",
        fontSize: 20,
        marginVertical: 30,
    },
    ratingContainer: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginBottom: 20,
        paddingHorizontal: 20,
    },
    emojiButton: {
        padding: 10,
    },
    ratingLabelContainer: {
        flexDirection: "row",
        justifyContent: "space-between",
        paddingHorizontal: 25,
    },
    ratingLabel: {
        fontWeight: "400",
        fontSize: 14,
        color:colors.blocked
    },
    textInputContainer: {
        borderColor: colors.gray6,
        borderWidth: 1,
        borderRadius: 8,
        margin: 20,
    },
    counter: {
        color: colors.gray4,
        marginHorizontal: 20,
        marginBottom:20
    },
    textInputField: {
        padding:10,
        height: 200,
        textAlignVertical: "top",
        color: colors.text
    },
    buttonContainer: {
        position:"absolute",
        bottom:20,
        left:width/13
    },
    success: {
        color:colors.green
    },
    error:{
        color:colors.red
    },
    feedback:{
        alignItems:"center",
    }
}))
