export enum MakeCalls {
  wifi = "Prefer Wi-Fi and Mobile data",
  carrier = "Use carrier only",
}

export enum RingerBehavior {
  default = "Default (the device may ring)",
  vibrate = "Vibrate",
  silent = "Silent",
}
