export interface GetProfileLocation {
  profileId: number
  name: string
  address: string
  address2: string
  city: string
  state: string
  zip: string
  countryCode: string
  phone: string
  email: string
  latitude: number
  longitude: number
  timeZone: string
  isHidden: boolean
  trackingPhone: string
  website: string
  isWebsiteEditable: boolean
}

export interface PatchProfileLocation {
  propertyName: PropertyName
  name?: string
  address?: Address
  phone?: string
  email?: string
  website?: string
}

export interface Address {
  address?: string
  address2?: string
  city?: string
  state?: string
  zip?: string
  countryCode?: string
  latitude?: number
  longitude?: number
  isHidden?: boolean
  placesId?: string
}

export type PropertyName = "name" | "address" | "phone" | "email" | "website"

export interface ChangeBusinessInfoError {
  Name: Array<string>
  Phone: Array<string>
  Email: Array<string>
  Website: Array<string>
  Address: Array<string>
  GoogleCategories: Array<string>
}

export interface AvailableCategory {
  id: number
  name: string
  parentId: number
  updatedOn: string
  isEnabled: boolean
}
export interface AvailableCategories {
  categories: Array<AvailableCategory>
}
export interface AvailableGoogleCategory {
  id: number
  googleCategoryId: string
  name: string
  language: string
  region: string
  isActive: boolean
}
export interface AvailableGoogleCategories {
  googleCategories: Array<AvailableGoogleCategory>
}

export interface ProfileGoogleCategories {
  googleCategories: Array<string>
}

export interface ProfileWorkingHours {
  profileId: number
  mondayOpeningTime: number
  mondayClosingTime: number
  tuesdayOpeningTime: number
  tuesdayClosingTime: number
  wednesdayOpeningTime: number
  wednesdayClosingTime: number
  thursdayOpeningTime: number
  thursdayClosingTime: number
  fridayOpeningTime: number
  fridayClosingTime: number
  saturdayOpeningTime: number
  saturdayClosingTime: number
  sundayOpeningTime: number
  sundayClosingTime: number
  isSaturdayByAppointment: boolean
  isSundayByAppointment: boolean
  isMondayByAppointment: boolean
  isTuesdayByAppointment: boolean
  isWednesdayByAppointment: boolean
  isThursdayByAppointment: boolean
  isFridayByAppointment: boolean
  areHoursHidden: boolean
}

export interface AvailablePaymentMenhod {
  id: number
  title: PaymentTitle
  googlePaymentType: PaymentType
  abbreviation: string
}
export interface ProfilePaymentMenhod {
  profileId: number
  title: PaymentTitle
  paymentMethodId: number
}
export interface PaymentMenhods<T> {
  paymentMethods: Array<T>
}

export type PaymentTitle =
  | "Mastercard"
  | "VISA"
  | "Discover"
  | "Cash"
  | "Diners Card"
  | "Invoice"
  | "Travelers Check"
  | "Paypal"
  | "BrandCredit"
  | "Android Pay"
  | "Apple Pay"
  | "Samsung Pay"
  | "Electronic Payments"
  | "Google Pay"
  | "Financing"
  | "Venmo"
  | "Money Transfers"
  | "Cash App"
  | "Zelle"
  | "American Express"
  | "Checking Account"

export type PaymentType =
  | "mastercard"
  | "visa"
  | "discover"
  | "cash"
  | "diners"
  | "invoice"
  | "travelers_check"
  | "paypal"
  | "brand_credit"
  | "android_pay"
  | "apple_pay"
  | "samsung_pay"
  | "Electronic_Payments"
  | "Google_Pay"
  | "Financing"
  | "Venmo"
  | "Money_Transfers"
  | "Cash_Apps"
  | "Zelle"
  | "amex"
  | "check"

export interface ProfileTextContents {
  profileId: number
  description: string
  product: string
  service: Array<string>
  mission: string
  tagline: string
  yearEstablished: string
  brands: string
  licenseNumber: string
  memberships: string
  disclaimer: string
}

export interface ContactsModel {
  contacts: Array<Contact>
}

export interface Contact {
  id: number
  memberId: number
  title: string
  name: string
  phoneNumber: string
  phoneExtension: string
  emailAddress: string
  notes: string
  contactTypeId: number
  contactType: string
}
