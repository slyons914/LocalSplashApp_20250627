export interface UserCallTrackingSipSettingsList {
  items: UserCallTrackingSipSettings []
}

export interface UserCallTrackingSipSettings {
  sipHost: string
  sipUsername: string
  sipPassword: string
  profileId: number,
	trackingPhone?: string,
}

export interface DudaUrls {
  permalinkUrl: string
  ssoUrl: string
}
