export * from "./localsplash-mobile-api.service"

export interface SendMessageSuccessResponse {
  state: string
}
export interface SendMessageErrorResponse {
  title: string
}
export interface LoginSuccess {
  accessToken: string
  refreshToken: string
  accessTokenLifetime: number
  scope: string
}

export interface RefreshToken {
  accessToken: string
  idToken: string
  refreshToken: string
  scope: string
  tokenType: string
}

export interface AverageReviewRating {
  averageRating?: number
  totalReviewCount?: number
}

export interface ReviewDateCount {
  dateReviewed?: string
  reviewCount?: number
}

export interface ReviewDestinationTitleCount {
  destinationTitle?: string
  reviewCount?: number
}

export interface ReviewStarCount {
  reviewCount?: number
  star1Count?: number
  star2Count?: number
  star3Count?: number
  star4Count?: number
  star5Count?: number
}

export interface ReviewData {
  countsByDate:{}  
  averageReviewRating?: AverageReviewRating
  reviewDateCounts?: ReviewDateCount[]
  reviewDestinationTitleCounts?: ReviewDestinationTitleCount[]
  reviewStarCount?: ReviewStarCount
}

export interface Reviews {
  remainingReviewCount: number
  reviews?: ReveiwItem[]
}
export interface ReveiwItem {
  comments?: string
  reviewedOn?: string
  reviewerName?: string
  responseText?: string
  score?: number
  reviewId?: number
}

export interface ReviewReqeusts {
  requests: Request[]
}

export interface Request {
  name?: string
  email?: string
  dateCreated: string
  phone: string
  businessName: string
  businessTitle: string
  businessAddress: string
  businessCity: string
  businessState: string
}

export interface DecodedToken {
  amr: Array<string>
  aud: string
  auth_time: number
  client_id: string
  email: string
  exp: number
  family_name: string
  given_name: string
  iat: number
  idp: string
  iss: string
  jti: string
  name: string
  nbf: number
  phone_number: string
  scope: Array<string>
  sub: string
  t_and_c_accepted: string
}

export interface UnreadLeads {
  totalLeadCount: number
}

export type DataType = "LocalLeads" | "GoogleProfileActions" | "GoogleAdsClicks" | "Reviews" | "ListingClicks"

export type ResultsLabel =
  | "Local Leads"
  | "Google Profile Actions"
  | "Google Ads Clicks"
  | "Reviews"
  | "Listings Clicks"

export type Analytics = {
  googleAdsClicks: number
  googleProfileActions: number
  listings: number
  localLeads: number
  reviews: number
  totalResults: number
}

export type DateFilter = {
  fromDate: string
  toDate: string
}

export interface GoogleAdsInsights {
  insights: Insights
  googleListingMessage: string
  googlePlacementPermalinkUrl: string
}

export interface Insights {
  actions: number
  directionRequests: number
  callsYou: number
  websiteVisits: number
  searchViews: number
  mapViews: number
  photoViews: number
  photoCountCustomers: number
  photoCountMerchant: number
  directionAndCallAndWebVisits: DirectionAndCallAndWebVisit[]
  views: SearchAndMapView[]
}

export interface MonthlyKeywords {
    keywordsImpressionsMonthlyList: MonthlyKeyword[]
}
export interface DirectionAndCallAndWebVisit {
  directions: number
  calls: number
  webVisits: number
  directQueries: number
  inDirectQueries: number
  photoViews: number
  dateRecorded: string
}

export interface SearchAndMapView {
  searchViews: number
  mapsViews: number
  dateRecorded: string
}

export interface MonthlyKeyword {
  impressions: number
  keyword: string
}

export interface FacebookAdsPreview {
  Success: boolean;
  ErrorMessage?: string;
  DetailedError?: string;
  AuthenticationRequired: boolean;
  Preview: string;
}
export interface Insight {
  account_id?: string;
  campaign_id?: string;
  date_start?: string;
  date_stop?: string;
  clicks?: string;
  inline_link_clicks?: string;
  spend?: string;
  impressions?: string;
  actions?: string;
  calls_count?: string;
  message_count?: string;
  facebook_leads_count?: string;
  reach?: string;
  inline_post_engagement?: string;
  gender?: string;
  leads?: string;
  age?: string;
  region?: string;
  calls?: string;
  messages?: string;
}

export interface FacebookAdsInterface {
  success: boolean;
  errorMessage: string;
  detailedError: string;
  authenticationRequired: boolean;
  insights: Insight[];
}

export interface Posts{
    googlePostText:string;
    createdOn:string;
    searchViews:number;
    actions:number;
    mediaUrl:string;
    searchUrl:string;
    postId:string
}

export interface PostsInterface{
    totalCount:number;
    posts: Posts[]
    countsByDate:{}
}  
export interface PostsFilter{
    profileId?:number,
    FromRowNumber?:number,
    Length?:number,
    FromDate:string,
    ToDate:string
}

export interface Listing{
    logo:string,
    destinationTitle:string,
    permalinkUrl:string,
    isClientFacing: boolean
}

export interface Listings{
    items:Listing[]
}

export interface WebsiteLead{
    id?:number | undefined
    firstName?:string | undefined
    emailAddress?:string | undefined
    phoneNumber?:string | undefined
    message?:string | undefined
    date?:string | undefined
    isResponded?:boolean | undefined
}

export interface WebsiteLeads{
    websiteLeads:WebsiteLead[]
    totalLeadCount:number
}

export interface RecentMessage{
    rowNumber: number,
    trackingPhone: number,
    leadPhoneNumber: number,
    isInbound: boolean,
    memberId: number,
    body: string,
    media: string,
    dateCreated: string,
    leadId: number,
    profileId: number,
    leadName: string,
    isSpam: boolean,
    isBlocked: boolean
}


export interface RecentMessagesList{
    items: RecentMessage []
}




