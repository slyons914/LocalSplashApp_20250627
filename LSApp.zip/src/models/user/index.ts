interface Member{
  id: number
  userName: string
  firstName: string
  lastName: string
  emailAddress: string
  role: number
  closerId: number
  brandId: number
  contactPhone: string
  timeZone: string
  primaryProfileId: number
}
interface AuthenticatedMember{
    id: number
    userName: string
    firstName: string
    lastName: string
    emailAddress: string
    role: number
    closerId: number
    brandId: number
    contactPhone: string
    timeZone: string
    primaryProfileId: number
  }
export interface getUserData {
  member:Member
  authenticatedMember:AuthenticatedMember
}
