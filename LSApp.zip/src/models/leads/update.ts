export interface LeadUpdate {
  isBlocked: boolean
  isRead: boolean
  isSpam: boolean
  isResponded: boolean
}
