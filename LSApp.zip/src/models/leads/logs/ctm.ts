import { LeadLog, LeadLogType } from "./base"

export const enum CallStatus {
  Answered = "answered",
  Completed = "completed",
  HangUp = "hangup",
  NoAnswer = "no answer",
}

export const enum CallDirection {
  Inbound = "inbound",
  OutBound = "outbound",
  Agent = "agent",
}

export const enum CallDisposition {
  Completed = "completed",
  Answered = "answered",
  NoAnswer = "no answer",
  ANoAnswer = "no-answer",
}

export const enum MessageStatus {
  Delivered = "delivered",
  Failed = "failed",
  Received = "received",
  Sent = "sent",
}

export const enum MessageDirection {
  Inbound = "msg_inbound",
}

interface BaseCtmLeadLog extends LeadLog {
  trackingNumber?: string
  callerNumber?: string
  tagList?: string
}

export interface CallLeadLog extends BaseCtmLeadLog {
  isSpam?: boolean
  isBlocked?: boolean
  leadName?: string
  audioPath?: string
  callDuration: number
  leadStructure: LeadLogType.Call
  callDisposition?: CallDisposition
  callStatus?: CallStatus
  direction?: CallDirection
}

export interface MessageLeadLog extends BaseCtmLeadLog {
  messageId: string
  messageMedia?: string
  leadStructure: LeadLogType.Sms
  callDisposition?: MessageStatus
  callStatus?: MessageStatus
  direction?: MessageDirection
}

export interface CallLog{
    uniqueId: string,
    dst: number,
    isDirectionInbound: boolean,
    src: number,
    srcCallerIdName: string,
    intentTag: string,
    dialStatus: string,
    duration: number,
    memberId: number,
    profileId: number,
    isNotificationSent: boolean,
    notificationMessage: "string",
    isMediaAvailable: boolean,
    callStart: number,
    callAnswered: number,
    callTerminated: number,
    dateCreated:Date ,
    dateUpdated: Date,
    rowNumber: number,
    leadId: number,
    isSpam: boolean,
    isBlocked: boolean,
    audioUrl: string,
    callDestinationType: string | null,
    callDestination: string | null,
}

export type CtmLeadLog = CallLeadLog | MessageLeadLog
