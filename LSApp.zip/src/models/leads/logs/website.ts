import { LeadLog, LeadLogType } from "./base"

export interface WebsiteFormLeadLog extends LeadLog {
  leadStructure: LeadLogType.Website
  ipAddress?: string
  httpReferrer?: string
  profileId: number
}
