export const enum LeadLogType {
  Website = 1,
  Call = 2,
  Sms = 4,
  GoogleGuaranteedAds = 8,
  FacebookMessenger = 16,
  FacebookForm = 32,
  PulseCall = 64,
  GoogleGuaranteedMessage = 256,
  GoogleGuaranteedBooking = 512,
  TychromSms = 1024,
  Disposition = 2048
}

export interface LeadLog {
  id: number
  leadId: number
  isRead: boolean
  createdAt?: Date
  message?: string
}
