export interface LeadFilters {
  isSpam?: boolean | null
  isBlocked?: boolean | null
  isRead?: boolean | null
  isBooked?: boolean | null
  ProfileId?: number | null
  FromDate?: string | null
  isResponded?: boolean | null
  ToDate?: string | null
  Search?: string
  AreCallLeadLogsIncluded?:boolean,
  AreGoogleLeadLogsIncluded?:boolean,
  AreSmsLeadLogsIncluded?:boolean,
  AreWebsiteFormLeadLogsIncluded?: boolean
  AreFacebookLeadLogsIncluded?: boolean
  FromRowNumber?:number
  Length?:number,
  customerAmount?: number,
  customerNotes?: string,
  dispositionStatus?: number,
  AreScheduledLeadsIncluded?: boolean,
  AreFollowUpNeededLeadsIncluded?: boolean,
  AreCompletedLeadsIncluded?: boolean,
  AreNotaValidLeadsIncluded?: boolean,
  AreNoAnswerLeadsIncluded?: boolean,
  AreNotInterestedLeadsIncluded?: boolean,
}
