import { LeadLogType } from "./logs"

export interface Lead {
  id: number
  profileId?: number
  name?: string
  streetAddress?: string
  phoneNumber: number
  email?: string
  lastInOn: Date
  updatedAt?: Date
  isSpam?: boolean
  isBooked?: boolean
  lastLeadStructure: LeadLogType
  isBlocked?: boolean
  isResponded?: boolean
  requestedReviewAt?: Date
  customerAmount: number | null
  customerNotes: string | null
  dispositionStatus: number,
  lastLeadLogId: number

}

