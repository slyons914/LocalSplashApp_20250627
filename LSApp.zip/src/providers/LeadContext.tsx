import { LeadFilters } from '@models/leads';
import React, { createContext, useState, useContext, Dispatch, SetStateAction, Children, ReactNode } from 'react';

interface LeadContextProps {
  filters: LeadFilters
  setFilters: Dispatch<SetStateAction<LeadFilters>>
  activeDate: number,
  setActiveDate: Dispatch<SetStateAction<number>>
}

interface LeadProviderProps {
    children: ReactNode
}

const LeadContext = createContext<LeadContextProps | undefined>(undefined);

export const useLeadContext = () => {
  const context = useContext(LeadContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};

export const LeadProvider: React.FC<LeadProviderProps> = ({ children }) => {
  const [filters, setFilters] = useState<LeadFilters>({
    isSpam: false,
    isBlocked: false,
    isRead: null,
    FromDate: null,
    ToDate: null,
    Search: "",
    Length:30,
    AreCallLeadLogsIncluded:false,
    AreGoogleLeadLogsIncluded:false,
    AreSmsLeadLogsIncluded:false,
    AreFacebookLeadLogsIncluded:false,
    AreWebsiteFormLeadLogsIncluded:false,
    AreScheduledLeadsIncluded: false,
    AreFollowUpNeededLeadsIncluded: false,
    AreCompletedLeadsIncluded: false,
    AreNotaValidLeadsIncluded: false,
    AreNoAnswerLeadsIncluded: false,
    AreNotInterestedLeadsIncluded: false,
});
const [activeDate, setActiveDate] = useState(1)

  return (
    <LeadContext.Provider value={{ filters, setFilters, activeDate, setActiveDate }}>
      {children}
    </LeadContext.Provider>
  );
};