import { MobileAPI } from "@api"
import { createContext, useContext, useEffect, useState } from "react"
import { useStore } from "@store"

interface Translation{
    selectedLanguage:string
    setSelectedLanguage:(lan:string)=>void
}
const initials: Translation = {
    selectedLanguage:"en",
    setSelectedLanguage:Promise.resolve
}
const TranslationContext = createContext(initials)

const useTranslation = () => {
	return useContext(TranslationContext);
};

const TranslationProvider = ({ children }: any) => {
  const { languageStore } = useStore() 
  const { getLanguageVariables } = languageStore
  const [selectedLanguage, setSelectedLanguage] = useState("en")
  useEffect(() => {
    getLanguageVariables(selectedLanguage)
  }, [selectedLanguage])


  return (
    <TranslationContext.Provider value={{selectedLanguage, setSelectedLanguage}}>
      {children}
    </TranslationContext.Provider>
  )
}


export {TranslationContext, TranslationProvider, useTranslation}


