import { PropsWithChildren, createContext, useContext, useEffect, useState } from "react"

import TrackPlayer, {
  useIsPlaying,
  useProgress,
  usePlaybackState,
  State,
} from "react-native-track-player"

import { Player } from "@components"
import { CallLeadLog } from "@models/leads"

interface Context {
  playing?: boolean
  loading: boolean
  track: string | undefined
  position: number
  duration: number
  load: (value: string | undefined) => void
  remove: () => void
  showPlayer: () => void
  loadTracks: (value: CallLeadLog) => void
  playTrack: () => void
}

const initials: Context = {
  playing: false,
  loading: true,
  track: undefined,
  position: 0,
  duration: 0,
  load: Promise.resolve,
  remove: Promise.resolve,
  loadTracks: Promise.resolve,
  showPlayer: Promise.resolve,
  playTrack: Promise.resolve,
}

const PlayerContext = createContext(initials)

export const PlayerProvider = ({ children }: PropsWithChildren) => {
  const [isPlayerVisible, setIsPlayerVisible] = useState(false)
  const [track, setTrack] = useState<string | undefined>()
  const [tracks, setTracks] = useState<CallLeadLog[]>([])

  const [loading, setLoading] = useState(true)

  const { playing } = useIsPlaying()
  const { state } = usePlaybackState()
  const { position, duration } = useProgress()

  useEffect(() => {
    TrackPlayer.setupPlayer()
  }, [])

  useEffect(() => {
    if (!state || [State.None, State.Loading].includes(state)) {
      setLoading(false)
    } else if (state === State.Ready) {
      setLoading(false)
    }
  }, [state])

  const load = async (track: string | undefined) => {
    setTrack(track)
    const url = track
    url && TrackPlayer.load({ url })
  }

  const loadTracks = (track: CallLeadLog) => {
    setTracks((prevTracks: CallLeadLog[]) => [...prevTracks, track])
    // TrackPlayer.add(tracks)
  }

  const playTrack = () => {
        TrackPlayer.play()
  }



  const remove = () => {
    TrackPlayer.stop()
    setTrack(undefined)
  }

  const showPlayer = () => {
    setIsPlayerVisible(true)
  }

  const onPlayerClose = () => {
    setIsPlayerVisible(false)
  }

  const value = {
    playing,
    loading,
    track,
    position,
    duration,
    load,
    remove,
    showPlayer,
    loadTracks,
    playTrack,
  }

  return (
    <PlayerContext.Provider value={value}>
      {children}
      <Player visible={isPlayerVisible} onClose={onPlayerClose} />
    </PlayerContext.Provider>
  )
}

export const usePlayer = () => useContext(PlayerContext)
