module.exports = {
    presets: [
    ],
    plugins: [
        'react-native-reanimated/plugin',
    ],
  };