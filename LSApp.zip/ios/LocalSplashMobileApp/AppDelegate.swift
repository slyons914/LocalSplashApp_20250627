import React
import Firebase
import PushKit
import UserNotifications
import GoogleMaps
import CallKit
#if DEBUG
//import FlipperKit
#endif

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate,PKPushRegistryDelegate, MessagingDelegate {
  
  var window: UIWindow?
  var reactBridge: RCTBridge!
  var callProvider: CXProvider?

  
  func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
    
    // RNCallKeep setup
//    let callKeepSettings = [
//      "appName": "Your App Name",
//      "supportsVideo": false,
//      "maximumCallsPerCallGroup": 1,
//      "supportsHolding": true,
//      "supportsDTMF": true,
//      "supportsGrouping": true,
//      "supportsUngrouping": true
//    ] as [String : Any]
//    
//    RNCallKeep.setup(callKeepSettings)
    
    RNVoipPushNotificationManager.voipRegistration()
    GMSServices.provideAPIKey("AIzaSyBnMoz1bb2uTDUTR3q-G7VdW2aHXhcevXs")
#if DEBUG && TARGET_OS_SIMULATOR
#if FB_SONARKIT_ENABLED
    initializeFlipper(with: application)
#endif
#endif
    
    
    self.setupCallProvider()
    self.voipRegistration()
    FirebaseApp.configure()
    
    UNUserNotificationCenter.current().delegate = self
    Messaging.messaging().delegate = self
    
    
    if #available(iOS 10.0, *) {
      // For iOS 10 display notification (sent via APNS)
      UNUserNotificationCenter.current().delegate = self
      let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
      UNUserNotificationCenter.current().requestAuthorization(
        options: authOptions,
        completionHandler: {_, _ in })
    } else {
      let settings: UIUserNotificationSettings =
      UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
      application.registerUserNotificationSettings(settings)
    }
    application.registerForRemoteNotifications()
    
    
    let jsCodeLocation = RCTBundleURLProvider.sharedSettings().jsBundleURL(forBundleRoot: "index")!
    self.reactBridge = RCTBridge(bundleURL: jsCodeLocation, moduleProvider: nil, launchOptions: launchOptions)
    RNCallKeep.setup([
      "appName": "LocalSplashMobileApp",
      "maximumCallGroups": 1,
      "maximumCallsPerCallGroup": 1,
      "supportsVideo": false
    ])
    let rootView = RCTRootView(bundleURL: jsCodeLocation, moduleName: "LocalSplashMobileApp", initialProperties: nil, launchOptions: launchOptions)
    let rootViewController = UIViewController()
    rootViewController.view = rootView
    
    window = UIWindow(frame: UIScreen.main.bounds)
    window?.rootViewController = rootViewController
    window?.makeKeyAndVisible()
    
    RNSplashScreen.show()
    
    return true
  }

  func application(_ application: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
        return RCTLinkingManager.application(application, open: url, options: options)
    }
  
  func setupCallProvider(){
    let providerConfiguration = CXProviderConfiguration(localizedName: "LocalSplashMobileApp")
    providerConfiguration.maximumCallGroups = 1
    providerConfiguration.maximumCallsPerCallGroup = 1
    
    callProvider = CXProvider(configuration: providerConfiguration)
    callProvider?.setDelegate(self, queue: nil)
  }
  
  // Register for VoIP notifications
  func voipRegistration() {
    // Create a push registry object
    let mainQueue = DispatchQueue.main
    let voipRegistry: PKPushRegistry = PKPushRegistry(queue: mainQueue)
    voipRegistry.delegate = self
    voipRegistry.desiredPushTypes = [PKPushType.voIP]
    
  }
  
  // Handle updated push credentials
  func pushRegistry(_ registry: PKPushRegistry, didUpdate credentials: PKPushCredentials, for type: PKPushType) {
    print(credentials.token)
    let deviceToken = credentials.token.map { String(format: "%02x", $0) }.joined()
    print("pushRegistry -> deviceToken :\(deviceToken)")
    RNVoipPushNotificationManager.didUpdate(credentials, forType: type.rawValue)
  }
  
  func pushRegistry(_ registry: PKPushRegistry, didInvalidatePushTokenFor type: PKPushType) {
    print("pushRegistry:didInvalidatePushTokenForType:")
  }
  
  func formatPhoneNumber(_ phoneNumber: String) -> String {
      // Filter out non-numeric characters and create an array of digits
      let digits = phoneNumber.compactMap { $0.wholeNumberValue }
      
      // Take the last 10 digits if available
      let lastTenDigits = digits.suffix(10)
      
      // Ensure we have exactly 10 digits
      guard lastTenDigits.count == 10 else { return phoneNumber }
    let startIndex = lastTenDigits.startIndex
    let areaCode = lastTenDigits[startIndex...startIndex+2].map(String.init).joined()
    let centralOfficeCode = lastTenDigits[startIndex+3...startIndex+5].map(String.init).joined()
    let lineNumber = lastTenDigits[startIndex+6...startIndex+9].map(String.init).joined()
    return "(\(areaCode)) \(centralOfficeCode)-\(lineNumber)"
  }
  
  func pushRegistry(_ registry: PKPushRegistry, didReceiveIncomingPushWith payload: PKPushPayload, for type: PKPushType, completion: @escaping () -> Void) {
    print(payload.dictionaryPayload)
    // Ensure payload data contains necessary fields
    guard let payloadData = payload.dictionaryPayload as? [String: Any],
          let aps = payloadData["aps"] as? [String: Any],
          let handle = payloadData["handle"] as? String,
          let src = payloadData["srcCallerIdName"] as? String,
          let callUUIDString = payloadData["callUUID"] as? String,
          let profileId = payloadData["profileId"] as? String,
          let callUUID = UUID(uuidString: callUUIDString) else {
      completion()
      return
    }
    
    let extra: [String: Any] = [
            "profileId": profileId
        ]
    let formattedHandle = formatPhoneNumber(handle)
    //    let appState = UIApplication.shared.applicationState
    //    if appState == .inactive || appState == .background {
    
    RNVoipPushNotificationManager.addCompletionHandler(callUUIDString, completionHandler: completion)
    RNVoipPushNotificationManager.didReceiveIncomingPush(with: payload, forType: type.rawValue)
    RNCallKeep.reportNewIncomingCall(callUUIDString, handle: formattedHandle, handleType: "generic", hasVideo: false, localizedCallerName: "\(formattedHandle)", supportsHolding: false, supportsDTMF: true, supportsGrouping: false, supportsUngrouping: false, fromPushKit: true, payload: extra)
    completion()
    //}
  }
  func reportIncomingCall(uuid: UUID, handle: String, completion: @escaping (Error?) -> Void) {
    let update = CXCallUpdate()
    update.remoteHandle = CXHandle(type: .generic, value: handle)
    update.hasVideo = false
    update.supportsDTMF = true
    update.localizedCallerName = ""
    update.supportsHolding = false
    update.supportsGrouping = false
    update.supportsUngrouping = false
    callProvider?.reportNewIncomingCall(with: uuid, update: update, completion: { error in
      completion(error)
    })
  }
  
  
  private func initializeFlipper(with application: UIApplication) {
#if DEBUG
    //    let client = FlipperClient.shared()
    //    let layoutDescriptionMapper = SKDescriptorMapper(defaults: ())
    //    client?.add(FlipperKitLayoutPlugin(rootNode: application, with: layoutDescriptionMapper))
    //    client?.add(FKUserDefaultsPlugin(suiteName: nil))
    //    client?.add(FlipperKitReactPlugin())
    //    client?.add(FlipperKitNetworkPlugin(networkAdapter: SKIOSNetworkAdapter()))
    //    client?.start()
#endif
  }
}

extension AppDelegate {
  func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
    let token = deviceToken.map { String(format: "%02.2hhx", $0) }.joined()
    print("Device Token: \(token)")
  }
  
  func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
    // Handle the notification and perform necessary actions
    completionHandler()
  }
  // MARK: - MessagingDelegate
  
  func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
    // You can send this token to your server for further use
    print("Firebase registration token: \(String(describing: fcmToken))")
  }
}

extension AppDelegate: UNUserNotificationCenterDelegate {
  // This method will be called when the app is in the foreground and a notification is received
  func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
    // Handle the notification while the app is in the foreground
    let payload = notification.request.content.userInfo
    
    // Access the APNS object of the notification
    if let apns = payload["aps"] as? [String: Any] {
      print(apns)
      // You can further access properties of the APNS object here
      // For example, badge count, sound, alert, etc.
    }
    
    completionHandler([.alert, .badge, .sound])
  }
  
  func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
    // Handle your notification here
  }
  
}


extension AppDelegate:CXProviderDelegate {
  // CXProviderDelegate methods
  func providerDidReset(_ provider: CXProvider) {
    // Handle the reset event
  }
  
  func provider(_ provider: CXProvider, perform action: CXAnswerCallAction) {
    // Handle the answer call action
    action.fulfill()
  }
  
  func provider(_ provider: CXProvider, perform action: CXEndCallAction) {
    // Handle the end call action
    action.fulfill()
  }
}
